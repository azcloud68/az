'use client'

/**
 * Dock utilities — dữ liệu ứng viên Dock + thao tác ghim/bỏ ghim (review #5).
 * Dock Manager: `dockPinned` (per-account, lưu trong appearance settings)
 * giữ DANH SÁCH THỨ TỰ app ghim; null = mặc định tự động theo module.
 */
import { useCallback, useMemo } from 'react'
import { useWos } from '@/core/client/wos-store'

export interface DockApp {
  id: string
  name: string
  icon: string
  color: string
  order: number
}

/** Danh sách app có mặt trong Dock (module bật + plugin app bật) — thứ tự mặc định */
export function useDockCandidates(): DockApp[] {
  const modules = useWos((s) => s.modules)
  const plugins = useWos((s) => s.plugins)
  return useMemo(
    () => [
      ...modules
        .filter((m) => m.enabled && m.showDock)
        .sort((a, b) => a.order - b.order)
        .map((m) => ({ id: m.id, name: m.name, icon: m.icon, color: m.color, order: m.order })),
      ...plugins
        .filter((p) => p.enabled && p.kind === 'app' && p.showDock)
        .map((p) => ({ id: p.slug, name: p.name, icon: p.icon, color: p.color, order: 100 + p.order })),
    ],
    [modules, plugins],
  )
}

/**
 * Ghim / bỏ ghim 1 app khỏi Dock (dùng ở Desktop icon menu + Dock menu).
 * Lần ghim ĐẦU TIÊN khi dockPinned === null: lấy danh sách mặc định làm nền
 * rồi thêm/bớt app — giữ nguyên trải nghiệm cũ cho người dùng chưa tuỳ biến.
 */
export function useToggleDockPin(): (id: string, pinned: boolean) => void {
  const candidates = useDockCandidates()
  const dockPinned = useWos((s) => s.dockPinned)
  const saveDockPinned = useWos((s) => s.saveDockPinned)
  return useCallback(
    (id: string, pinned: boolean) => {
      const base = dockPinned ?? candidates.map((c) => c.id)
      if (!base.includes(id) && !candidates.some((c) => c.id === id)) return // app không có trong Dock
      const next = pinned
        ? base.includes(id)
          ? base
          : [...base, id]
        : base.filter((x) => x !== id)
      void saveDockPinned(next)
    },
    [candidates, dockPinned, saveDockPinned],
  )
}
