'use client'

/**
 * APP: Terminal — shell bash THẬT chạy trên máy WOS (Orange Pi / sandbox).
 * - xterm.js + FitAddon, theme tối macOS Terminal
 * - Kết nối socket.io tới terminal-service (port 3005 qua Caddy gateway / path rewrite)
 * - Token ngắn hạn lấy từ /api/system/terminal/session (service đối chiếu ngược Next)
 * - Mỗi cửa sổ Terminal = 1 phiên shell riêng; đóng cửa sổ = đóng shell
 * - Nút "Phiên mới" mở cửa sổ Terminal độc lập tiếp theo
 */
import { useCallback, useEffect, useRef, useState } from 'react'
import { useRoute } from '@/core/client/route-context'
import { api } from '@/core/client/api'
import { useWindows } from '@/core/client/window-store'
import { io, type Socket } from 'socket.io-client'
import { Terminal } from '@xterm/xterm'
import { FitAddon } from '@xterm/addon-fit'
import { Button } from '@/components/ui/button'
import { Loader2, RefreshCw, SquarePlus, TerminalSquare, TriangleAlert } from 'lucide-react'

interface SessionCfg {
  token: string
  port: number
  path: string
}

export default function TerminalApp() {
  const { route } = useRoute()
  const openApp = useWindows((s) => s.openApp)
  const [status, setStatus] = useState<'connecting' | 'ready' | 'denied' | 'ended' | 'error'>('connecting')
  const [message, setMessage] = useState('')
  const [pty, setPty] = useState(false)
  const [nonce, setNonce] = useState(0) // tăng = mở lại phiên
  const hostRef = useRef<HTMLDivElement | null>(null)
  const termRef = useRef<Terminal | null>(null)
  const socketRef = useRef<Socket | null>(null)

  const reconnect = useCallback(() => setNonce((n) => n + 1), [])
  /** trạng thái mới nhất cho callback socket (tránh stale closure) */
  const statusRef = useRef<'connecting' | 'ready' | 'denied' | 'ended' | 'error'>('connecting')
  useEffect(() => {
    statusRef.current = status
  }, [status])

  useEffect(() => {
    let disposed = false
    let socket: Socket | null = null
    let term: Terminal | null = null
    let fit: FitAddon | null = null
    let ro: ResizeObserver | null = null

    const boot = async () => {
      setStatus('connecting')
      setMessage('')
      try {
        const cfg = await api<SessionCfg>('/api/system/terminal/session', { method: 'POST' })
        if (disposed) return

        term = new Terminal({
          fontFamily: '"JetBrains Mono", "Fira Code", "Sarasa Mono SC", Menlo, Consolas, "Liberation Mono", monospace',
          fontSize: 13.5,
          lineHeight: 1.15,
          cursorBlink: true,
          allowProposedApi: true,
          theme: {
            background: '#10131a',
            foreground: '#d6deeb',
            cursor: '#7aa2f7',
            selectionBackground: '#33467c',
            black: '#10131a',
            red: '#f7768e',
            green: '#9ece6a',
            yellow: '#e0af68',
            blue: '#7aa2f7',
            magenta: '#bb9af7',
            cyan: '#7dcfff',
            white: '#d6deeb',
          },
        })
        fit = new FitAddon()
        term.loadAddon(fit)
        term.open(hostRef.current!)
        term.write('\x1b[38;5;245mĐang kết nối shell…\x1b[0m\r\n')
        termRef.current = term

        // Kết nối service: sandbox → Caddy (?XTransformPort=); máy thật → path rewrite.
        // Review #8: POLLING TRƯỚC rồi nâng cấp websocket — kết nối được qua MỌI lớp proxy
        // (Caddy gateway nâng cấp WS ngay; Next rewrite /terminal-ws không hỗ trợ WS
        // upgrade thì socket.io vẫn chạy ổn định trên polling thay vì chết connect_error).
        // Tự động thử lại 3 lần trước khi báo lỗi kèm chẩn đoán.
        const useGateway = !cfg.path || cfg.path === '/'
        socket = useGateway
          ? io(`/?XTransformPort=${cfg.port}`, {
              auth: { token: cfg.token },
              transports: ['polling', 'websocket'],
              reconnectionAttempts: 3,
              reconnectionDelay: 1200,
              timeout: 10000,
            })
          : io('/', {
              path: cfg.path,
              auth: { token: cfg.token },
              transports: ['polling', 'websocket'],
              reconnectionAttempts: 3,
              reconnectionDelay: 1200,
              timeout: 10000,
            })
        socketRef.current = socket

        /** Chẩn đoán khi kết nối thất bại: service sống hay chết, proxy có tới được không */
        const probe = async (): Promise<string> => {
          try {
            const url = useGateway ? `/?XTransformPort=${cfg.port}` : cfg.path
            const res = await fetch(url, { signal: AbortSignal.timeout(4000) })
            const body = await res.text().catch(() => '')
            // engine.io trả "Transport unknown" cho GET thường → service CÒN SỐNG
            if (res.ok || body.includes('Transport unknown')) {
              return 'Terminal service đang chạy nhưng kết nối socket bị chặn (proxy/websocket). Thử lại, hoặc kiểm tra gateway trên máy chủ.'
            }
            return `Terminal service trả về HTTP ${res.status} — kiểm tra service trên máy chủ.`
          } catch {
            return 'Terminal service không phản hồi — kiểm tra service trên máy chủ (Orange Pi: systemctl status wos-terminal).'
          }
        }

        socket.on('ready', (info: { user: string; pty: boolean }) => {
          if (disposed || !term) return
          setPty(Boolean(info.pty))
          setStatus('ready')
          term.reset()
          term.writeln(
            `\x1b[1;34mWOS Terminal\x1b[0m — shell chạy trên máy WOS` + (info.pty ? '' : ' \x1b[90m(pipes)\x1b[0m'),
          )
          term.writeln('\x1b[90mGõ lệnh như trên Linux thật. "exit" để thoát phiên.\x1b[0m')
          term.focus()
          try {
            fit?.fit()
          } catch {
            /* cửa sổ chưa có kích thước */
          }
        })

        socket.on('data', (data: string) => {
          if (!disposed && term) term.write(data)
        })

        socket.on('denied', (d: { reason?: string }) => {
          if (disposed) return
          setStatus('denied')
          setMessage(d.reason || 'Không mở được phiên Terminal')
        })

        socket.on('exit', (d: { code: number }) => {
          if (disposed || !term) return
          setStatus('ended')
          term.writeln(`\r\n\x1b[90m〔Phiên shell đã kết thúc (mã ${d.code})〕\x1b[0m`)
        })

        // mất kết nối giữa chừng (mạng nhấp nháy) → đang thử lại
        socket.on('disconnect', (reason: string) => {
          if (disposed || statusRef.current !== 'ready') return
          if (reason === 'io client disconnect' || reason === 'io server disconnect') return
          setStatus('connecting')
          setMessage('Mất kết nối — đang thử lại…')
        })

        socket.on('connect', () => {
          if (disposed) return
          if (statusRef.current !== 'ready') {
            setStatus('connecting')
            setMessage('')
          }
        })

        socket.on('connect_error', () => {
          if (disposed) return
          setStatus('error')
          void probe().then((msg) => {
            if (!disposed) setMessage(msg)
          })
        })

        term.onData((data) => {
          if (socket?.connected) socket.emit('input', data)
        })

        // Resize theo cửa sổ WOS
        const doFit = () => {
          try {
            fit?.fit()
            if (socket?.connected && term) {
              socket.emit('resize', { cols: term.cols, rows: term.rows })
            }
          } catch {
            /* bỏ qua */
          }
        }
        ro = new ResizeObserver(() => doFit())
        ro.observe(hostRef.current!)
        setTimeout(doFit, 120)
      } catch (err) {
        if (disposed) return
        setStatus('error')
        setMessage(err instanceof Error ? err.message : 'Không lấy được phiên Terminal')
      }
    }
    void boot()

    return () => {
      disposed = true
      if (ro) ro.disconnect()
      socket?.disconnect()
      term?.dispose()
      socketRef.current = null
      termRef.current = null
    }
  }, [nonce])

  const newSession = () => {
    const key = `t:${Date.now().toString(36)}`
    openApp('terminal', { key, route: 'terminal' })
  }

  return (
    <div className="flex h-full w-full flex-col bg-[#10131a]">
      {/* Thanh công cụ mỏng kiểu macOS Terminal */}
      <div className="flex h-9 shrink-0 items-center gap-2 border-b border-white/10 px-3 text-[12px] text-white/70">
        <TerminalSquare className="h-3.5 w-3.5 text-sky-400" />
        <span className="font-medium">bash</span>
        {pty ? (
          <span className="rounded-full bg-emerald-500/15 px-2 py-0.5 text-[10.5px] font-medium text-emerald-300">
            PTY thật
          </span>
        ) : null}
        <span className="flex-1 truncate text-white/35">
          {status === 'ready' ? 'đang chạy' : status === 'connecting' ? 'đang kết nối…' : message}
        </span>
        <Button
          variant="ghost"
          size="sm"
          className="h-6 gap-1.5 px-2 text-[11.5px] text-white/70 hover:bg-white/10 hover:text-white"
          onClick={newSession}
          title="Mở cửa sổ Terminal mới (phiên shell riêng)"
        >
          <SquarePlus className="h-3.5 w-3.5" />
          Phiên mới
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="h-6 gap-1.5 px-2 text-white/70 hover:bg-white/10 hover:text-white"
          onClick={reconnect}
          title="Mở lại phiên shell"
        >
          <RefreshCw className="h-3.5 w-3.5" />
          Mở lại
        </Button>
      </div>

      {/* Vùng terminal */}
      <div className="relative min-h-0 flex-1 p-2">
        <div ref={hostRef} className="h-full w-full overflow-hidden rounded-lg" />

        {status === 'connecting' ? (
          <div className="absolute inset-0 flex items-center justify-center gap-2 text-[13px] text-white/60">
            <Loader2 className="h-4 w-4 animate-spin" />
            Đang mở shell trên máy…
          </div>
        ) : null}

        {status === 'denied' || status === 'error' ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-[#10131a]/90 text-center">
            <TriangleAlert className="h-8 w-8 text-amber-400" />
            <p className="max-w-sm px-6 text-[13px] text-white/70">{message}</p>
            <Button variant="secondary" size="sm" onClick={reconnect} className="gap-1.5">
              <RefreshCw className="h-3.5 w-3.5" /> Thử lại
            </Button>
          </div>
        ) : null}

        {status === 'ended' ? (
          <button
            onClick={reconnect}
            className="absolute inset-x-0 bottom-6 mx-auto flex w-fit items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-[12.5px] font-medium text-white/85 backdrop-blur transition hover:bg-white/20"
          >
            <SquarePlus className="h-3.5 w-3.5" />
            Mở phiên shell mới
          </button>
        ) : null}
      </div>
    </div>
  )
}
