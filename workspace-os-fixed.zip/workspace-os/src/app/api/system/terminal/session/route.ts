import { handle, ok, fail, requireModule } from '@/core/server/api'
import { createServiceToken } from '@/core/server/auth'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** POST /api/system/terminal/session — cấp token ngắn hạn (10 phút) cho Terminal
 *  service. Token được service MANG LẠI đối chiếu ngược qua /api/system/terminal/verify
 *  (kiểm cả session còn sống trong DB) — không chia sẻ secret qua env giữa 2 tiến trình.
 *  Trả kèm cấu hình kết nối: sandbox dùng Caddy gateway (port qua ?XTransformPort),
 *  máy thật (Orange Pi) dùng path /terminal-ws do Next rewrite chuyển tiếp. */
const TOKEN_TTL = 10 * 60 * 1000

export async function POST() {
  return handle(async () => {
    const session = await requireModule('terminal')
    if (session.role === 'viewer') return fail('Tài khoản chỉ đọc không dùng được Terminal', 403)
    const token = await createServiceToken(
      'terminal',
      { sid: session.sessionId, uid: session.id, role: session.role, user: session.username },
      TOKEN_TTL,
    )
    return ok({
      token,
      // Terminal service: cổng riêng (sandbox: 3005 qua Caddy; Orange Pi: 3069 qua Next rewrite)
      port: Number(process.env.WOS_TERMINAL_PORT || 3005),
      path: process.env.WOS_TERMINAL_PATH || '/',
    })
  })
}
