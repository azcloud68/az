#!/usr/bin/env bash
# Gỡ hoàn toàn Workspace OS
#   sudo bash uninstall.sh              # xoá sạch
#   sudo bash uninstall.sh --keep-data  # giữ storage/ + db/
set -euo pipefail
INSTALL_DIR="${WOS_DIR:-/opt/workspace-os}"
KEEP_DATA=0
[ "${1:-}" = "--keep-data" ] && KEEP_DATA=1

echo "Dừng service wos + wos-terminal…"
systemctl stop wos 2>/dev/null || true
systemctl disable wos 2>/dev/null || true
rm -f /etc/systemd/system/wos.service
systemctl stop wos-terminal 2>/dev/null || true
systemctl disable wos-terminal 2>/dev/null || true
rm -f /etc/systemd/system/wos-terminal.service
systemctl daemon-reload 2>/dev/null || true

if [ -d "$INSTALL_DIR" ]; then
  if [ "$KEEP_DATA" = 1 ]; then
    echo "Giữ lại: $INSTALL_DIR/storage và $INSTALL_DIR/db"
    find "$INSTALL_DIR" -mindepth 1 -maxdepth 1 ! -name storage ! -name db -exec rm -rf {} +
  else
    echo "Xoá toàn bộ: $INSTALL_DIR"
    rm -rf "$INSTALL_DIR"
  fi
else
  echo "Không tìm thấy $INSTALL_DIR"
fi

# Gỡ swap riêng của WOS nếu không còn process nào dùng
if swapon --show 2>/dev/null | grep -q swapfile_wos; then
  swapoff /swapfile_wos 2>/dev/null || true
  rm -f /swapfile_wos
  sed -i '/swapfile_wos/d' /etc/fstab 2>/dev/null || true
  echo "Đã gỡ swap WOS"
fi

echo "✅ Gỡ cài đặt hoàn tất."
