#!/usr/bin/env bash
# ============================================================================
#  Workspace OS (WOS) — GỠ CÀI ĐẶT
#  Dừng + xoá dịch vụ, xoá thư mục cài đặt. (install.sh cài lại bất cứ lúc nào)
#  Cách dùng:  sudo bash uninstall.sh [--keep-data]
#     --keep-data  giữ db/ + storage/ (chuyển sang /tmp trước khi xoá)
# ============================================================================
set -uo pipefail

C_G='\033[32m'; C_Y='\033[33m'; C_B='\033[36m'; C_0='\033[0m'
step() { echo -e "\n${C_B}▶ $*${C_0}"; }
ok()   { echo -e "  ${C_G}✔${C_0} $*"; }
warn() { echo -e "  ${C_Y}⚠${C_0} $*"; }

INSTALL_DIR="${WOS_DIR:-/opt/workspace-os}"
KEEP_DATA=0
[ "${1:-}" = "--keep-data" ] && KEEP_DATA=1

[ "$(id -u)" = "0" ] || { echo "Phải chạy bằng sudo/root"; exit 1; }

step "Dừng và xoá systemd services"
for svc in wos wos-terminal; do
  systemctl stop "$svc"    2>/dev/null || true
  systemctl disable "$svc" 2>/dev/null || true
  rm -f "/etc/systemd/system/$svc.service"
done
systemctl daemon-reload 2>/dev/null || true
pkill -f 'workspace-os/.next/standalone/server.js' 2>/dev/null || true
pkill -f 'workspace-os/mini-services/terminal-service' 2>/dev/null || true
ok "Services wos + wos-terminal đã dừng và xoá"

step "Xoá thư mục cài đặt"
if [ $KEEP_DATA = 1 ] && [ -d "$INSTALL_DIR/db" ]; then
  BK="/tmp/wos-backup-$(date +%s)"
  mkdir -p "$BK"
  [ -d "$INSTALL_DIR/db" ]      && cp -r "$INSTALL_DIR/db"      "$BK/" && ok "db/      → $BK"
  [ -d "$INSTALL_DIR/storage" ] && cp -r "$INSTALL_DIR/storage" "$BK/" && ok "storage/ → $BK"
fi
rm -rf "$INSTALL_DIR"
ok "Đã xoá $INSTALL_DIR"

echo -e "\n${C_G}✔ Gỡ cài đặt hoàn tất.${C_0} Cài lại bất cứ lúc nào: sudo bash install.sh"
[ $KEEP_DATA = 1 ] && echo "  (Bản giữ dữ liệu nằm trong /tmp/wos-backup-* — copy về chỗ cũ trước khi cài lại)"
