import type { NextConfig } from "next";

/**
 * WOS 3.0 — Terminal service qua Next rewrite (máy thật: Orange Pi).
 * Khi WOS_TERMINAL_PROXY=1 (install.sh đặt), mọi request /terminal-ws/* được Next
 * chuyển tiếp sang terminal-service (127.0.0.1:3069) — client chỉ cần cùng origin,
 * Cloudflare Tunnel chỉ cần 1 hostname. Sandbox dev KHÔNG bật (dùng Caddy gateway
 * ?XTransformPort=3005) nên rewrite tắt.
 */
const terminalProxy = process.env.WOS_TERMINAL_PROXY === "1";
const terminalPort = process.env.WOS_TERMINAL_PROXY_PORT || "3069";

const nextConfig: NextConfig = {
  output: "standalone",
  /* Build chặt: KHÔNG bỏ qua lỗi TypeScript (đã dọn sạch toàn bộ type errors) */
  typescript: {
    ignoreBuildErrors: false,
  },
  reactStrictMode: false,
  ...(terminalProxy
    ? {
        async rewrites() {
          return [
            {
              source: "/terminal-ws/:path*",
              destination: `http://127.0.0.1:${terminalPort}/terminal-ws/:path*`,
            },
          ];
        },
      }
    : {}),
};

export default nextConfig;
