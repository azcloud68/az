import type { NextConfig } from "next";

/**
 * WOS 3.0 — Terminal service qua Next rewrite (máy thật: Orange Pi).
 *
 * v3.1 (fix): rewrite được bật LUÔN LUÔN (không còn gate WOS_TERMINAL_PROXY lúc build).
 * Trước đây rewrite chỉ tồn tại khi build với WOS_TERMINAL_PROXY=1 — nếu ai build thủ công
 * (bun run build), thiếu .env, hoặc build trước khi sinh .env thì rewrite biến mất →
 * Terminal báo "Đường /terminal-ws chưa được chuyển tiếp" dù install đúng.
 * Giờ: rewrite luôn có; đích đến đọc WOS_TERMINAL_PROXY_PORT (mặc định 3069).
 * Nếu terminal-service không chạy, rewrite chỉ trả 502 — session API tự dò phương thức khác.
 *
 * Lưu ý: Next rewrite KHÔNG chuyển tiếp WebSocket upgrade → TerminalApp dùng polling
 * cho chế độ 'proxy' (ổn định, chậm hơn WS một chút). Sandbox dev có thể trỏ service
 * ra path '/' + dùng gateway ?XTransformPort.
 */
const terminalPort = process.env.WOS_TERMINAL_PROXY_PORT || "3069";

const nextConfig: NextConfig = {
  output: "standalone",
  /* Build chặt: KHÔNG bỏ qua lỗi TypeScript (đã dọn sạch toàn bộ type errors) */
  typescript: {
    ignoreBuildErrors: false,
  },
  reactStrictMode: false,
  async rewrites() {
    return [
      {
        source: "/terminal-ws/:path*",
        destination: `http://127.0.0.1:${terminalPort}/terminal-ws/:path*`,
      },
    ];
  },
};

export default nextConfig;
