/**
 * WOS Terminal Service — shell thật (bash) cho app Terminal của Workspace OS.
 *
 * CHẠY BẰNG NODE.JS (không phải bun): node-pty chỉ hoạt động đúng dưới node
 * (dưới bun, tiến trình con PTY thoát ngay sau prompt — đã kiểm chứng).
 * ⚠ v6.1: systemd chạy DIST/INDEX.JS (bản dịch sẵn bằng tsc — xem npm run build),
 * KHÔNG chạy file .ts này: Node < 22 không có type-stripping nên chạy .ts trực tiếp
 * sẽ bị ERR_UNKNOWN_FILE_EXTENSION (như trên Orange Pi chạy Node 20).
 * Sửa code ở đây xong → chạy `npm run build` rồi restart service.
 *
 * Kiến trúc & BẢO MẬT:
 *   Browser (xterm.js) ──socket.io──► service này ──PTY──► bash
 *   - Kết nối phải mang service-token (10 phút) do Next cấp; service ĐỐI CHIẾU NGƯỢC
 *     về Next /api/system/terminal/verify (kiểm cả session còn sống) trước khi mở shell
 *     → đăng xuất/thu hồi phiên = terminal tắt theo; không chia sẻ secret qua env.
 *   - Giới hạn: tối đa 8 shell cho toàn service, 3 shell / người dùng, tự tắt sau 30 phút idle.
 *   - Shell chạy với quyền của TIẾN TRÌNH service (orangepi trên máy thật) — không leo quyền.
 *   - Ngắt kết nối → SIGTERM shell, 3 giây không thoát thì SIGKILL (không mồ côi tiến trình).
 *
 * Chạy: sandbox (Caddy gateway) → path '/', cổng 3005 qua ?XTransformPort=3005
 *       Orange Pi → TERMINAL_SOCKET_PATH=/terminal-ws, Next rewrite chuyển tiếp (cổng 3069).
 */
import { createServer } from 'http'
import { createRequire } from 'module'
import { spawn, type ChildProcessWithoutNullStreams } from 'child_process'
import type { Socket } from 'socket.io'

const require = createRequire(import.meta.url)

const { Server } = require('socket.io')
const PORT = Number(process.env.TERMINAL_PORT || 3005)
const SOCKET_PATH = process.env.TERMINAL_SOCKET_PATH || '/'
const WOS_API = process.env.WOS_API_URL || 'http://127.0.0.1:3000'
const MAX_TOTAL = 8
const MAX_PER_USER = 3
const IDLE_TIMEOUT_MS = 30 * 60 * 1000

interface ShellSession {
  proc: ChildProcessWithoutNullStreams
  uid: string
  user: string
  role: string
  idleTimer: ReturnType<typeof setTimeout> | null
  pty: unknown // node-pty instance khi có (động)
}

const sessions = new Map<string, ShellSession>()
const perUser = new Map<string, number>()

// ==== node-pty (tuỳ chọn): PTY thật → có màu/tab-completion; fallback = pipes bash -i ===
type PtySpawn = (file: string, args: string[], opts: Record<string, unknown>) => {
  pid: number
  write: (data: string) => void
  kill: (signal?: string) => void
  on: (event: string, cb: (arg?: unknown) => void) => void
}
let ptySpawn: PtySpawn | null = null
try {
  const pty = require('node-pty')
  ptySpawn = pty.spawn as PtySpawn
  console.log('[terminal] node-pty OK — PTY thật (màu + tab-completion)')
} catch {
  console.log('[terminal] node-pty không khả dụng — dùng pipes bash -i (fallback)')
}

async function verifyToken(token: string): Promise<{ uid: string; user: string; role: string } | null> {
  try {
    const res = await fetch(`${WOS_API}/api/system/terminal/verify`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ token }),
      signal: AbortSignal.timeout(5000),
    })
    if (!res.ok) return null
    const data = (await res.json()) as { ok?: boolean; uid?: string; user?: string; role?: string }
    if (!data.ok || !data.uid) return null
    return { uid: data.uid, user: data.user || 'user', role: data.role || 'member' }
  } catch {
    return null
  }
}

function spawnShell(): { proc: ChildProcessWithoutNullStreams; pty: unknown } | null {
  const cwd = process.env.WOS_TERMINAL_CWD || process.env.HOME || process.cwd()
  const env = {
    ...process.env,
    TERM: 'xterm-256color',
    LANG: `${process.env.LANG || 'C.UTF-8'}`,
    HOME: process.env.HOME || '/root',
  }
  if (ptySpawn) {
    const p = ptySpawn(process.env.WOS_SHELL || '/bin/bash', [], {
      name: 'xterm-256color',
      cols: 100,
      rows: 30,
      cwd,
      env,
    })
    return { proc: p as unknown as ChildProcessWithoutNullStreams, pty: p }
  }
  const proc = spawn(process.env.WOS_SHELL || '/bin/bash', ['-i'], {
    cwd,
    env,
    stdio: ['pipe', 'pipe', 'pipe'],
  }) as ChildProcessWithoutNullStreams
  return { proc, pty: null }
}

function killSession(id: string) {
  const s = sessions.get(id)
  if (!s) return
  sessions.delete(id)
  const n = (perUser.get(s.uid) || 1) - 1
  if (n <= 0) perUser.delete(s.uid)
  else perUser.set(s.uid, n)
  if (s.idleTimer) clearTimeout(s.idleTimer)
  try {
    s.proc.kill('SIGTERM')
    setTimeout(() => {
      try {
        s.proc.kill('SIGKILL')
      } catch {
        /* đã thoát */
      }
    }, 3000).unref()
  } catch {
    /* đã thoát */
  }
  console.log(`[terminal] đóng shell (${s.user}) — còn ${sessions.size}`)
}

function touchIdle(id: string) {
  const s = sessions.get(id)
  if (!s) return
  if (s.idleTimer) clearTimeout(s.idleTimer)
  s.idleTimer = setTimeout(() => {
    const sock = s.pty ? null : null
    void sock
    killSession(id)
    // client sẽ nhận 'exit' qua sự kiện proc close
  }, IDLE_TIMEOUT_MS).unref()
}

const httpServer = createServer((req, res) => {
  // health-check nhẹ cho systemd/Caddy — path DỌC LẬP (không đè đường socket.io):
  // engine.io chiếm mọi URL bắt đầu bằng SOCKET_PATH nên probe ở chính path đó
  // sẽ luôn do engine.io trả lời ("Transport unknown") — vẫn coi như "service sống"
  // nhưng systemd/Caddy cần JSON rõ ràng → dùng /__wos_terminal_health.
  if (req.url?.split('?')[0] === '/__wos_terminal_health' && req.method === 'GET') {
    res.writeHead(200, { 'content-type': 'application/json' })
    res.end(JSON.stringify({ ok: true, service: 'wos-terminal', shells: sessions.size }))
    return
  }
  res.writeHead(404)
  res.end()
})

// ⚠ FIX socket qua proxy (Next rewrite /terminal-ws): engine.io mặc định chỉ nhận
// URL có dấu "/" cuối (vd "/terminal-ws/?EIO=4…"). Next rewrite + một số reverse
// proxy BỎ dấu "/" này khi chuyển tiếp ("/terminal-ws?EIO=4…") → request rơi vào
// handler 404 ở trên thay vì engine.io → client báo "kết nối socket bị chặn".
// addTrailingSlash:false cho engine.io nhận CẢ HAI dạng URL.
const io = new Server(httpServer, {
  path: SOCKET_PATH,
  // gateway '/' giữ mặc định (engine.io chiếm toàn bộ root); path riêng → false
  // để engine.io nhận CẢ "/terminal-ws/?EIO=…" lẫn "/terminal-ws?EIO=…"
  addTrailingSlash: SOCKET_PATH === '/',
  cors: { origin: true, methods: ['GET', 'POST'] },
  pingTimeout: 60000,
  pingInterval: 25000,
  maxHttpBufferSize: 256 * 1024,
})

io.use(async (socket, next) => {
  // BẮT BUỘC token hợp lệ trước khi nhận bất kỳ sự kiện nào
  const token = String(socket.handshake.auth?.token || '')
  if (!token) return next(new Error('UNAUTH'))
  const who = await verifyToken(token)
  if (!who) return next(new Error('UNAUTH'))
  if (who.role === 'viewer') return next(new Error('FORBIDDEN'))
  ;(socket.data as { who?: { uid: string; user: string; role: string } }).who = who
  next()
})

io.on('connection', (socket: Socket) => {
  const who = (socket.data as { who?: { uid: string; user: string; role: string } }).who
  if (!who || sessions.size >= MAX_TOTAL || (perUser.get(who.uid) || 0) >= MAX_PER_USER) {
    socket.emit('denied', {
      reason:
        sessions.size >= MAX_TOTAL
          ? `Máy đang chạy tối đa ${MAX_TOTAL} shell — thử lại sau`
          : `Bạn đang mở tối đa ${MAX_PER_USER} phiên Terminal`,
    })
    socket.disconnect(true)
    return
  }

  const spawned = spawnShell()
  if (!spawned) {
    socket.emit('denied', { reason: 'Không khởi tạo được shell trên máy chủ' })
    socket.disconnect(true)
    return
  }
  const { proc, pty } = spawned
  sessions.set(socket.id, { proc, uid: who.uid, user: who.user, role: who.role, idleTimer: null, pty })
  perUser.set(who.uid, (perUser.get(who.uid) || 0) + 1)
  touchIdle(socket.id)
  console.log(`[terminal] shell mới cho ${who.user} (${sessions.size} tổng)`)

  socket.emit('ready', {
    user: who.user,
    shell: process.env.WOS_SHELL || '/bin/bash',
    pty: Boolean(pty),
    idleTimeoutMin: IDLE_TIMEOUT_MS / 60000,
  })

  const onOutput = (data: unknown) => {
    touchIdle(socket.id)
    if (socket.connected) socket.emit('data', typeof data === 'string' ? data : String(data))
  }
  if (pty) {
    ;(pty as { on: (e: string, cb: (d: unknown) => void) => void }).on('data', onOutput)
    ;(pty as { on: (e: string, cb: (d: unknown) => void) => void }).on('exit', (code: unknown) => {
      socket.emit('exit', { code: typeof code === 'number' ? code : 0 })
      killSession(socket.id)
    })
  } else {
    proc.stdout.on('data', (chunk: Buffer) => onOutput(chunk.toString()))
    proc.stderr.on('data', (chunk: Buffer) => onOutput(chunk.toString()))
    proc.on('close', (code: number | null) => {
      socket.emit('exit', { code: code ?? 0 })
      killSession(socket.id)
    })
    proc.on('error', () => {
      socket.emit('exit', { code: 1 })
      killSession(socket.id)
    })
  }

  socket.on('input', (data: unknown) => {
    const s = sessions.get(socket.id)
    if (!s || typeof data !== 'string' || data.length > 65536) return
    touchIdle(socket.id)
    try {
      if (pty) (pty as { write: (d: string) => void }).write(data)
      else proc.stdin.write(data)
    } catch {
      /* shell đã đóng */
    }
  })

  socket.on('resize', (data: unknown) => {
    const s = sessions.get(socket.id)
    if (!s || !pty) return
    const { cols, rows } = (data || {}) as { cols?: number; rows?: number }
    if (Number.isInteger(cols) && Number.isInteger(rows) && cols > 0 && rows > 0 && cols <= 500 && rows <= 300) {
      try {
        ;(pty as unknown as { resize?: (c: number, r: number) => void }).resize?.(cols, rows)
      } catch {
        /* bỏ qua */
      }
    }
  })

  socket.on('disconnect', () => killSession(socket.id))
})

httpServer.listen(PORT, () => {
  console.log(`[terminal] WOS Terminal service lắng nghe cổng ${PORT} (path ${SOCKET_PATH})`)
  console.log(`[terminal] Đối chiếu token với ${WOS_API}`)
})

process.on('SIGTERM', () => {
  for (const id of [...sessions.keys()]) killSession(id)
  io.close()
  httpServer.close(() => process.exit(0))
})
