/**
 * WOS AI Bridge — background service worker (MV3)
 *
 * Luồng an toàn theo thiết kế Giai đoạn 4:
 *  1. User ghép nối extension với Workspace OS bằng MÃ GHÉP NỐI (sinh trong
 *     Trợ lý AI → Cài đặt → "Tạo mã ghép nối", hết hạn 10 phút, dùng 1 lần).
 *  2. Extension đổi mã lấy token (wosext_…) — lưu chrome.storage.local.
 *  3. Mỗi lần gửi: user chủ động bấm (context menu / popup / phím tắt) —
 *     KHÔNG tự động thu thập. activeTab: chỉ tab đang dùng, không cần
 *     host_permissions toàn域.
 *  4. Server đánh dấu nội dung là KHÔNG ĐÁNG TIN — AI chỉ tham khảo.
 */

const API_CTX = '/api/ai/context/external'
const API_PAIR = '/api/ai/ext-token'

async function getConfig() {
  const { wosServer, wosToken } = await chrome.storage.local.get(['wosServer', 'wosToken'])
  return { server: (wosServer || '').replace(/\/+$/, ''), token: wosToken || '' }
}

/** Ghép nối bằng mã — đổi pairCode lấy token dài hạn */
async function pair(server, pairCode) {
  const res = await fetch(server + API_PAIR, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ pairCode: pairCode.trim().toUpperCase(), label: 'Chrome Extension' }),
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(data.error || `Lỗi ghép nối (${res.status})`)
  await chrome.storage.local.set({ wosServer: server.replace(/\/+$/, ''), wosToken: data.token })
  return data
}

/** Hàm CHẠY TRONG TRANG — trích xuất nội dung (selection hoặc cả trang) */
function extractContent(mode) {
  try {
    const title = document.title || ''
    const url = location.href
    if (mode === 'selection') {
      const sel = window.getSelection ? String(window.getSelection()) : ''
      if (sel && sel.trim()) {
        return { ok: true, content: sel.trim().slice(0, 30000), selectionOnly: true, title, url }
      }
      return { ok: false, error: 'Bạn chưa bôi chọn đoạn văn bản nào trên trang này.' }
    }
    // page: ưu tiên article/main, loại bỏ nhiễu
    const root =
      document.querySelector('article') ||
      document.querySelector('main') ||
      document.querySelector('[role=main]') ||
      document.body
    let text = ''
    if (root) {
      const clone = root.cloneNode(true)
      clone
        .querySelectorAll('script,style,noscript,svg,iframe,nav,footer,header,aside,form,button')
        .forEach((el) => el.remove())
      text = (clone.innerText || clone.textContent || '')
        .replace(/[ \t]+\n/g, '\n')
        .replace(/\n{3,}/g, '\n\n')
        .trim()
    }
    if (!text) return { ok: false, error: 'Không trích xuất được nội dung trang này.' }
    return { ok: true, content: text.slice(0, 30000), selectionOnly: false, title, url }
  } catch (e) {
    return { ok: false, error: String(e && e.message ? e.message : e) }
  }
}

/** Lấy nội dung tab hiện tại rồi gửi về WOS */
async function sendCurrentTab(mode) {
  const { server, token } = await getConfig()
  if (!server || !token) {
    return { ok: false, error: 'Chưa ghép nối — mở popup và nhập địa chỉ Workspace OS + mã ghép nối.' }
  }
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
  if (!tab || !tab.id) return { ok: false, error: 'Không xác định được tab hiện tại.' }
  if (/^(chrome|edge|about|chrome-extension):/i.test(tab.url || '')) {
    return { ok: false, error: 'Không thể trích xuất trang nội bộ của trình duyệt.' }
  }
  const results = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: extractContent,
    args: [mode],
  })
  const extracted = results && results[0] && results[0].result
  if (!extracted || !extracted.ok) {
    return { ok: false, error: (extracted && extracted.error) || 'Không trích xuất được nội dung.' }
  }
  const res = await fetch(server + API_CTX, {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
    body: JSON.stringify(extracted),
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) {
    if (res.status === 401) {
      await chrome.storage.local.remove('wosToken')
      return { ok: false, error: 'Token đã bị thu hồi — hãy ghép nối lại trong popup.' }
    }
    throw new Error(data.error || `Lỗi gửi context (${res.status})`)
  }
  return { ok: true, data }
}

/* ---------- đăng ký context menu ---------- */

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'wos-send-selection',
    title: 'Gửi đoạn này cho Trợ lý AI Workspace OS',
    contexts: ['selection'],
  })
  chrome.contextMenus.create({
    id: 'wos-send-page',
    title: 'Gửi nội dung trang này cho Trợ lý AI Workspace OS',
    contexts: ['page'],
  })
})

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== 'wos-send-selection' && info.menuItemId !== 'wos-send-page') return
  const mode = info.menuItemId === 'wos-send-selection' ? 'selection' : 'page'
  try {
    const r = await sendCurrentTab(mode)
    if (r.ok) {
      chrome.action.setBadgeBackgroundColor({ color: '#7c3aed' })
      chrome.action.setBadgeText({ text: '✓' })
      setTimeout(() => chrome.action.setBadgeText({ text: '' }), 2500)
    } else if (r.error) {
      console.warn('[wos-bridge]', r.error)
    }
  } catch (e) {
    console.warn('[wos-bridge]', e)
  }
})

/* ---------- phím tắt ---------- */

chrome.commands.onCommand.addListener(async (command) => {
  if (command !== 'send-selection') return
  try {
    await sendCurrentTab('selection')
  } catch (e) {
    console.warn('[wos-bridge]', e)
  }
})

/* ---------- popup gửi tin ---------- */

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === 'PAIR') {
    pair(msg.server, msg.pairCode)
      .then((data) => sendResponse({ ok: true, data }))
      .catch((e) => sendResponse({ ok: false, error: String(e && e.message ? e.message : e) }))
    return true // async
  }
  if (msg && msg.type === 'SEND') {
    sendCurrentTab(msg.mode)
      .then((r) => sendResponse(r))
      .catch((e) => sendResponse({ ok: false, error: String(e && e.message ? e.message : e) }))
    return true
  }
  if (msg && msg.type === 'STATUS') {
    getConfig().then(({ server, token }) => sendResponse({ ok: true, server, token }))
    return true
  }
  if (msg && msg.type === 'DISCONNECT') {
    chrome.storage.local.remove('wosToken').then(() => sendResponse({ ok: true }))
    return true
  }
})
