/** WOS AI Bridge — popup logic */
const $ = (id) => document.getElementById(id)

function show(msg, ok) {
  const fb = $('feedback')
  fb.textContent = msg
  fb.className = 'feedback ' + (ok ? 'ok' : 'err')
}

function send(msg) {
  return new Promise((resolve) => chrome.runtime.sendMessage(msg, resolve))
}

async function refreshStatus() {
  const r = await send({ type: 'STATUS' })
  if (r && r.token) {
    $('paired').classList.remove('hidden')
    $('unpaired').classList.add('hidden')
    $('server-url').textContent = r.server.replace(/^https?:\/\//, '')
    $('status').textContent = 'Đã ghép nối'
    $('open-wos').href = r.server + '/'
    if (!$('in-server').value) $('in-server').value = r.server
  } else {
    $('paired').classList.add('hidden')
    $('unpaired').classList.remove('hidden')
    $('status').textContent = 'Chưa ghép nối'
  }
}

$('btn-pair').addEventListener('click', async () => {
  const server = $('in-server').value.trim()
  const code = $('in-code').value.trim()
  if (!server || !/^https?:\/\//.test(server)) return show('Nhập địa chỉ Workspace OS (bắt đầu bằng http:// hoặc https://)', false)
  if (!code) return show('Nhập mã ghép nối (8 ký tự)', false)
  $('btn-pair').disabled = true
  try {
    const r = await send({ type: 'PAIR', server, pairCode: code })
    if (r && r.ok) {
      show('✅ Đã ghép nối! Giờ bạn có thể gửi nội dung tab cho trợ lý.', true)
      await refreshStatus()
    } else {
      show('❌ ' + ((r && r.error) || 'Ghép nối thất bại'), false)
    }
  } finally {
    $('btn-pair').disabled = false
  }
})

$('btn-selection').addEventListener('click', async () => {
  $('btn-selection').disabled = true
  try {
    const r = await send({ type: 'SEND', mode: 'selection' })
    if (r && r.ok) show('✅ Đã gửi đoạn bôi chọn. Mở Trợ lý AI để hỏi kèm nội dung này.', true)
    else show('❌ ' + ((r && r.error) || 'Không gửi được'), false)
  } finally {
    $('btn-selection').disabled = false
  }
})

$('btn-page').addEventListener('click', async () => {
  $('btn-page').disabled = true
  try {
    const r = await send({ type: 'SEND', mode: 'page' })
    if (r && r.ok) show('✅ Đã gửi nội dung trang. Mở Trợ lý AI để hỏi kèm nội dung này.', true)
    else show('❌ ' + ((r && r.error) || 'Không gửi được'), false)
  } finally {
    $('btn-page').disabled = false
  }
})

$('btn-disconnect').addEventListener('click', async () => {
  await send({ type: 'DISCONNECT' })
  show('Đã gỡ ghép nối.', true)
  refreshStatus()
})

refreshStatus()
