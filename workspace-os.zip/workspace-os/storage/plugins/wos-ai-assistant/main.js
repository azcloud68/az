/* ============================================================
 * WOS AI Assistant — main.js (plugin entry)
 * Chat App + Desktop Widget dùng CHUNG một bộ não:
 *   - cùng conversation ID (activeConversationId lưu server — AISetting)
 *   - cùng module-scope store (một plugin = một JS context)
 * Backend: /api/ai/* (proxy Grok phía server — plugin KHÔNG giữ API key)
 * ============================================================ */
'use strict'

var h = WOS.h, Fragment = WOS.Fragment
var useState = WOS.useState, useEffect = WOS.useEffect, useRef = WOS.useRef, useMemo = WOS.useMemo, useCallback = WOS.useCallback
var api = WOS.api, bus = WOS.bus

/* ---------- tiện ích chung ---------- */

function cx() {
  var out = []
  for (var i = 0; i < arguments.length; i++) {
    var a = arguments[i]
    if (!a) continue
    if (typeof a === 'string') out.push(a)
    else if (typeof a === 'object') for (var k in a) if (a[k]) out.push(k)
  }
  return out.join(' ')
}

function fmtTime(ts) {
  if (!ts) return ''
  var d = new Date(ts)
  return d.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })
}

function fmtDate(ts) {
  if (!ts) return ''
  var d = new Date(ts)
  return d.toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit' })
}

var SOURCE_DEFS = [
  { key: 'tasks', icon: '📋', name: 'Công việc', desc: 'Việc còn tồn, mức ưu tiên, hạn chót' },
  { key: 'calendar', icon: '📅', name: 'Lịch', desc: 'Sự kiện ±1 tuần' },
  { key: 'weekly', icon: '🗓️', name: 'Việc tuần', desc: 'Tiến độ từng ngày trong tuần' },
  { key: 'projects', icon: '📁', name: 'Dự án', desc: 'Dự án đang chạy' },
  { key: 'activeWindow', icon: '🪟', name: 'App đang mở', desc: 'Cửa sổ đang xem trên desktop' },
  { key: 'external', icon: '🌐', name: 'Tab ngoài', desc: 'Context extension gửi (không đáng tin)' },
]

var CAT_META = {
  preference: { label: 'Sở thích', color: '#d97706', bg: 'oklch(0.75 0.14 70 / 15%)' },
  project: { label: 'Dự án', color: '#2563eb', bg: 'oklch(0.62 0.15 255 / 14%)' },
  decision: { label: 'Quyết định', color: '#7c3aed', bg: 'oklch(0.62 0.17 290 / 14%)' },
  pending: { label: 'Chưa xong', color: '#dc2626', bg: 'oklch(0.62 0.19 25 / 13%)' },
  fact: { label: 'Thông tin', color: '#059669', bg: 'oklch(0.7 0.13 160 / 14%)' },
}

/* ============================================================
 * MARKDOWN-LITE — render an toàn bằng React elements (không innerHTML)
 * Hỗ trợ: heading, bold, italic, code inline, code block, danh sách,
 *          bảng, blockquote, link, hr
 * ============================================================ */

var INLINE_RE = /(\*\*[^*]+\*\*|\*[^*\n]+\*|`[^`\n]+`|\[[^\]]+\]\([^)\s]+\))/

function inlineNodes(s) {
  var parts = String(s).split(INLINE_RE)
  var nodes = []
  for (var i = 0; i < parts.length; i++) {
    var p = parts[i]
    if (!p) continue
    if (p.indexOf('**') === 0 && p.length > 4) {
      nodes.push(h('strong', { key: i }, p.slice(2, -2)))
    } else if (p.indexOf('*') === 0 && p.length > 2) {
      nodes.push(h('em', { key: i }, p.slice(1, -1)))
    } else if (p.indexOf('`') === 0 && p.length > 2) {
      nodes.push(h('code', { key: i }, p.slice(1, -1)))
    } else if (p.indexOf('[') === 0) {
      var m = /\[([^\]]+)\]\(([^)\s]+)\)/.exec(p)
      if (m) nodes.push(h('a', { key: i, href: m[2], target: '_blank', rel: 'noreferrer' }, m[1]))
      else nodes.push(p)
    } else {
      nodes.push(p)
    }
  }
  return nodes
}

function textBlocks(src) {
  var lines = String(src).split('\n')
  var out = []
  var i = 0
  var key = 0
  function K() { return 'b' + key++ }
  while (i < lines.length) {
    var line = lines[i]
    if (!line.trim()) { i++; continue }
    // heading
    var hm = /^(#{1,4})\s+(.*)$/.exec(line)
    if (hm) {
      var lv = Math.min(4, hm[1].length)
      out.push(h('h' + lv, { key: K() }, inlineNodes(hm[2])))
      i++
      continue
    }
    // hr
    if (/^(\s*[-*_]){3,}\s*$/.test(line)) { out.push(h('hr', { key: K() })); i++; continue }
    // blockquote
    if (/^>\s?/.test(line)) {
      var q = []
      while (i < lines.length && /^>\s?/.test(lines[i])) { q.push(lines[i].replace(/^>\s?/, '')); i++ }
      out.push(h('blockquote', { key: K() }, inlineNodes(q.join(' '))))
      continue
    }
    // bảng
    if (/\|/.test(line) && i + 1 < lines.length && /^\s*\|?[\s:|-]+\|[\s:|-]*$/.test(lines[i + 1])) {
      var rows = []
      while (i < lines.length && /\|/.test(lines[i]) && lines[i].trim()) { rows.push(lines[i]); i++ }
      if (rows.length >= 2) {
        var parse = function (r) {
          return r.replace(/^\s*\|/, '').replace(/\|\s*$/, '').split('|').map(function (c) { return c.trim() })
        }
        var head = parse(rows[0])
        var body = rows.slice(2).map(parse)
        out.push(
          h('table', { key: K() },
            h('thead', null, h('tr', null, head.map(function (c, ci) { return h('th', { key: ci }, inlineNodes(c)) }))),
            h('tbody', null, body.map(function (r, ri) {
              return h('tr', { key: ri }, r.map(function (c, ci) { return h('td', { key: ci }, inlineNodes(c)) }))
            }))
          )
        )
        continue
      }
    }
    // danh sách không thứ tự
    if (/^\s*[-*+]\s+/.test(line)) {
      var items = []
      while (i < lines.length && /^\s*[-*+]\s+/.test(lines[i])) { items.push(lines[i].replace(/^\s*[-*+]\s+/, '')); i++ }
      out.push(h('ul', { key: K() }, items.map(function (t, ii) { return h('li', { key: ii }, inlineNodes(t)) })))
      continue
    }
    // danh sách có thứ tự
    if (/^\s*\d+[.)]\s+/.test(line)) {
      var ol = []
      while (i < lines.length && /^\s*\d+[.)]\s+/.test(lines[i])) { ol.push(lines[i].replace(/^\s*\d+[.)]\s+/, '')); i++ }
      out.push(h('ol', { key: K() }, ol.map(function (t, ii) { return h('li', { key: ii }, inlineNodes(t)) })))
      continue
    }
    // đoạn văn — gộp các dòng liền
    var para = [line]
    i++
    while (
      i < lines.length && lines[i].trim() &&
      !/^(#{1,4}\s|>\s?|\s*[-*+]\s|\s*\d+[.)]\s)/.test(lines[i]) &&
      !/^(\s*[-*_]){3,}\s*$/.test(lines[i])
    ) { para.push(lines[i]); i++ }
    out.push(h('p', { key: K() }, inlineNodes(para.join(' '))))
  }
  return out
}

function renderMarkdown(text) {
  var src = String(text || '')
  var out = []
  var parts = src.split(/```/)
  for (var i = 0; i < parts.length; i++) {
    if (i % 2 === 0) {
      var blocks = textBlocks(parts[i])
      for (var j = 0; j < blocks.length; j++) out.push(blocks[j])
    } else {
      var code = parts[i]
      var nl = code.indexOf('\n')
      var lang = ''
      if (nl > 0 && /^[a-z0-9+#-]*$/i.test(code.slice(0, nl).trim())) {
        lang = code.slice(0, nl).trim()
        code = code.slice(nl + 1)
      }
      code = code.replace(/\n$/, '')
      out.push(
        h('pre', { key: 'code' + i },
          lang ? h('code', { 'data-lang': lang }, code) : h('code', null, code))
      )
    }
  }
  return out
}

/** bản thu gọn cho widget — bỏ markdown, chỉ text + cắt dài */
function plainPreview(text, max) {
  var s = String(text || '')
    .replace(/```[\s\S]*?```/g, ' [code] ')
    .replace(/[#*_>`|]/g, '')
    .replace(/\[(.*?)\]\(.*?\)/g, '$1')
    .replace(/\s+/g, ' ')
    .trim()
  if (s.length > (max || 220)) s = s.slice(0, max || 220) + '…'
  return s
}

/* ============================================================
 * SHARED STORE — bộ não chung của Chat App + Widget
 * (cùng 1 plugin runtime → cùng module scope)
 * ============================================================ */

var store = {
  loaded: false,        // đã boot dữ liệu chưa
  conversations: [],
  activeId: '',         // conversation đang mở (đồng bộ server AISetting)
  messages: [],         // messages của activeId
  settings: null,       // /api/ai/settings
  provider: null,
  status: null,
  busy: false,
  phase: '',
  error: '',
  lastMeta: null,       // meta câu trả lời gần nhất (nguồn + tools)
  mode: 'auto',         // auto | workspace | manual
  compat: null,         // {missing:true} khi máy chủ KHÔNG có AI backend (/api/ai/* 404)
  providers: [],        // danh sách provider động (từ server registry)
  models: [],           // model khả dụng của provider đang chọn
  sources: { tasks: true, calendar: true, weekly: true, projects: false, activeWindow: true, external: true },
  preview: null,        // kết quả preview context
  external: [],         // external contexts chờ dùng
  listeners: [],
}

function notifyStore() {
  for (var i = 0; i < store.listeners.length; i++) {
    try { store.listeners[i]() } catch (e) { /* ignore */ }
  }
}

/** hook — đăng ký re-render khi store đổi */
function useAiStore() {
  var r = useState(0)
  var force = r[1]
  useEffect(function () {
    function fn() { force(function (n) { return n + 1 }) }
    store.listeners.push(fn)
    return function () {
      var idx = store.listeners.indexOf(fn)
      if (idx >= 0) store.listeners.splice(idx, 1)
    }
  }, [])
  return store
}

/** boot 1 lần — cả widget lẫn app gọi, ai tới trước boot trước */
function ensureBoot() {
  if (store.loaded) return Promise.resolve()
  store.loaded = true
  return refreshAll()
}

function refreshAll() {
  return Promise.all([loadSettings(), loadConversations(), loadStatus(), loadExternal()])
    .then(function () { store.compat = null; notifyStore() })
    .catch(function (e) {
      var msg = (e && e.message) || ''
      // 404 từ /api/ai/* → máy chủ đang chạy bản Workspace OS CHƯA có AI backend
      if (e && (e.status === 404 || /HTTP 404/i.test(msg))) {
        store.compat = {
          missing: true,
          detail: 'Máy chủ Workspace OS này chưa có AI backend — mọi API /api/ai/* trả về 404.',
        }
      } else {
        store.error = msg
      }
      notifyStore()
    })
}

function loadSettings() {
  return api('/api/ai/settings').then(function (res) {
    store.settings = res.settings
    store.provider = res.provider
    store.providers = res.providers || []   // danh sách provider động từ registry server
    store.models = res.models || []          // model khả dụng của provider đang chọn
    if (res.settings && res.settings.contextMode) store.mode = res.settings.contextMode
    if (res.settings && res.settings.sources) {
      for (var k in store.sources) {
        if (typeof res.settings.sources[k] === 'boolean') store.sources[k] = res.settings.sources[k]
      }
    }
  })
}

function loadConversations() {
  return api('/api/ai/conversations').then(function (res) {
    store.conversations = res.conversations || []
    var active = res.activeConversationId || ''
    var exists = store.conversations.some(function (c) { return c.id === active })
    // chỉ nhận active từ server khi đang KHÔNG trong phiên gửi (tránh đè activeId vừa đặt)
    if (!store.busy) store.activeId = exists ? active : store.activeId
    if (store.activeId && store.messages.length === 0) return loadMessages(store.activeId)
  })
}

function loadMessages(id) {
  if (!id) { store.messages = []; notifyStore(); return Promise.resolve() }
  return api('/api/ai/conversations/' + encodeURIComponent(id)).then(function (res) {
    // tránh đè hội thoại đã chuyển sang khác
    if (store.activeId !== id) return
    store.messages = res.messages || []
    var last = store.messages[store.messages.length - 1]
    store.lastMeta = last && last.role === 'assistant' ? last.meta : store.lastMeta
    notifyStore()
  })
}

function loadStatus() {
  return api('/api/ai/status').then(function (res) { store.status = res })
}

function loadExternal() {
  return api('/api/ai/context/external').then(function (res) { store.external = res.contexts || [] })
}

function setActiveConversation(id, silent) {
  store.activeId = id || ''
  store.messages = []
  store.lastMeta = null
  store.preview = null
  notifyStore()
  var p = api('/api/ai/conversations', { method: 'PATCH', body: { activeConversationId: id || '' } })
    .catch(function () { return null })
  if (id) loadMessages(id)
  return p
}

function newConversation() {
  return api('/api/ai/conversations', { method: 'POST', body: {} }).then(function (res) {
    store.conversations.unshift(res.conversation)
    store.activeId = res.conversation.id
    store.messages = []
    store.lastMeta = null
    notifyStore()
    return res.conversation
  })
}

function deleteConversation(id) {
  return api('/api/ai/conversations/' + encodeURIComponent(id), { method: 'DELETE' }).then(function () {
    store.conversations = store.conversations.filter(function (c) { return c.id !== id })
    if (store.activeId === id) { store.activeId = ''; store.messages = [] }
    notifyStore()
  })
}

/** GỬI TIN NHẮN — luồng chính, widget + app gọi chung */
function sendMessage(text) {
  text = String(text || '').trim()
  if (!text || store.busy) return Promise.resolve()
  store.busy = true
  store.error = ''
  store.phase = 'Đang đọc dữ liệu Workspace…'
  var tmpId = 'tmp-u-' + Date.now()
  store.messages.push({ id: tmpId, role: 'user', content: text })
  notifyStore()

  var body = {
    conversationId: store.activeId || undefined,
    message: text,
    mode: store.mode,
  }
  if (store.mode === 'manual') body.sources = store.sources
  if (WOS.getContext) {
    try { body.activeContext = WOS.getContext() } catch (e) { /* registry chưa sẵn sàng */ }
  }

  store.phase = 'Trợ lý đang suy nghĩ…'
  notifyStore()

  return api('/api/ai/chat', { method: 'POST', body: body })
    .then(function (res) {
      // bỏ tin nhắn tạm, thay bằng bản thật
      store.messages = store.messages.filter(function (m) { return m.id !== tmpId })
      store.messages.push(res.userMessage, res.message)
      store.activeId = res.conversationId
      store.lastMeta = res.message.meta
      if (res.isNew) {
        // PATCH TRƯỚC rồi mới GET — tránh race: server trả active cũ → widget tạo hội thoại mới
        return api('/api/ai/conversations', { method: 'PATCH', body: { activeConversationId: res.conversationId } })
          .then(function () { return loadConversations() })
          .then(function () { store.activeId = res.conversationId; notifyStore() })
      }
    })
    .then(function () {
      store.phase = ''
      store.busy = false
      notifyStore()
      if (store.external.length) loadExternal().then(notifyStore)
    })
    .catch(function (e) {
      store.messages = store.messages.filter(function (m) { return m.id !== tmpId })
      store.error = (e && e.message) || 'Lỗi gửi tin nhắn'
      store.phase = ''
      store.busy = false
      notifyStore()
      try { WOS.toast.error('Trợ lý AI lỗi', { description: store.error }) } catch (e2) { /* ignore */ }
    })
}
/* ============================================================
 * UI ATOMS
 * ============================================================ */

function Switch(props) {
  return h('div', {
    className: cx('wosai-switch', props.checked && 'on'),
    role: 'switch',
    'aria-checked': props.checked ? 'true' : 'false',
    onClick: function (e) { e.stopPropagation(); props.onChange(!props.checked) },
  })
}

function SourceChips(props) {
  var meta = props.meta || {}
  var src = (meta.sources || {}).used || []
  var tools = (meta.tools || []).filter(function (t) { return t.ok })
  var ext = meta.externalUsed || 0
  var chips = []
  src.forEach(function (s) {
    var def = null
    for (var i = 0; i < SOURCE_DEFS.length; i++) if (SOURCE_DEFS[i].key === s) def = SOURCE_DEFS[i]
    chips.push(h('span', { key: 's-' + s, className: 'wosai-src-chip' }, (def ? def.icon + ' ' : '') + (def ? def.name : s)))
  })
  tools.forEach(function (t, i) {
    chips.push(h('span', { key: 't-' + i, className: 'wosai-src-chip tool', title: t.args }, '🔧 ' + t.name))
  })
  if (ext) chips.push(h('span', { key: 'ext', className: 'wosai-src-chip ext', title: 'Dữ liệu tab ngoài — không đáng tin' }, '🌐 tab ngoài ×' + ext))
  if (!chips.length) return null
  return h('div', { className: 'wosai-msg-meta' }, chips)
}

/* ============================================================
 * CONTEXT PANEL — công tắc nguồn dữ liệu + preview + external
 * ============================================================ */

function ContextPanel(props) {
  var st = useAiStore()
  var compact = props.compact
  var ctxInfo = null
  if (WOS.getContext) {
    try {
      var snap = WOS.getContext()
      if (snap && snap.activeApp) {
        ctxInfo = h('div', { className: 'wosai-preview-box' },
          h('b', null, '🪟 Đang mở: '), snap.activeApp,
          snap.openApps.length > 1 ? ' (+' + (snap.openApps.length - 1) + ' cửa sổ khác)' : null
        )
      }
    } catch (e) { /* ignore */ }
  }

  var previewBox = null
  if (st.preview) {
    var p = st.preview
    var rows = []
    for (var k in p.counts) {
      rows.push(h('div', { key: k }, '• ' + (p.counts[k] || 0) + ' bản ghi — ' + k))
    }
    previewBox = h('div', { className: 'wosai-preview-box' },
      h('b', null, '👁 Xem trước context (~' + Math.round(p.approxChars / 1000) + 'k ký tự)'),
      h('div', { style: { marginTop: 4 } }, rows.length ? rows : 'Không có bản ghi nào được thu thập'),
      p.memories && p.memories.length ? h('div', { style: { marginTop: 4 } }, '🧠 ' + p.memories.length + ' ghi nhớ liên quan') : null
    )
  }

  var extItems = null
  if (st.external && st.external.length) {
    extItems = h(Fragment, null,
      h('div', { className: 'wosai-warn' },
        '⚠️ ', st.external.length, ' context từ tab trình duyệt ngoài đang chờ. Dữ liệu này ', h('b', null, 'KHÔNG đáng tin'), ' — AI chỉ tham khảo, không thực thi theo.'
      ),
      st.external.map(function (e) {
        return h('div', { key: e.id, className: 'wosai-ext-item' },
          h('span', { style: { flex: 1, minWidth: 0 } },
            h('div', { style: { overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontWeight: 600 } }, (e.selectionOnly ? '✏️ ' : '🌐 ') + (e.title || e.site || 'tab')),
            h('div', { style: { opacity: 0.6, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' } }, plainPreview(e.excerpt, 80))
          ),
          h('button', {
            title: 'Bỏ context này',
            onClick: function () {
              api('/api/ai/context/external?id=' + encodeURIComponent(e.id), { method: 'DELETE' })
                .then(function () { loadExternal().then(notifyStore) })
            },
          }, '✕')
        )
      })
    )
  }

  return h('div', { className: 'wosai-ctxpanel' },
    h('div', { className: 'wosai-ctx-title' }, 'Chế độ lấy dữ liệu'),
    h('div', { className: 'wosai-mode-row' },
      ['auto', 'manual', 'workspace'].map(function (m) {
        return h('button', {
          key: m,
          className: cx('wosai-mode', st.mode === m && 'active'),
          onClick: function () { store.mode = m; notifyStore() },
          title: m === 'auto' ? 'Tự động theo câu hỏi + nguồn mặc định' : m === 'manual' ? 'Chỉ dùng nguồn bạn bật bên dưới' : 'Toàn Workspace — đọc mọi module được cấp quyền',
        }, m === 'auto' ? 'Tự động' : m === 'manual' ? 'Thủ công' : 'Toàn WS')
      })
    ),
    h('div', { className: 'wosai-ctx-title', style: { marginTop: 4 } }, 'Nguồn dữ liệu'),
    SOURCE_DEFS.map(function (def) {
      var on = !!st.sources[def.key]
      return h('div', {
        key: def.key,
        className: cx('wosai-ctx-row', !on && 'off'),
        onClick: function () { store.sources[def.key] = !on; notifyStore() },
        title: def.desc,
      },
        h('span', { className: 'wosai-ctx-ico' }, def.icon),
        h('span', { className: 'wosai-ctx-name' }, def.name),
        st.preview && st.preview.counts[def.key] != null
          ? h('span', { className: 'wosai-ctx-count' }, st.preview.counts[def.key])
          : null,
        h(Switch, {
          checked: on,
          onChange: function (v) { store.sources[def.key] = v; notifyStore() },
        })
      )
    }),
    ctxInfo,
    extItems,
    h('button', {
      className: 'wosai-btn ghost',
      style: { justifyContent: 'center' },
      onClick: function () {
        store.preview = null
        notifyStore()
        var body = { sources: store.sources }
        if (WOS.getContext) { try { body.activeContext = WOS.getContext() } catch (e) { /* */ } }
        api('/api/ai/context/preview', { method: 'POST', body: body }).then(function (res) {
          store.preview = res
          notifyStore()
        }).catch(function (e) {
          try { WOS.toast.error('Không xem trước được context', { description: e.message }) } catch (e2) { /* */ }
        })
      },
    }, '👁 Xem trước dữ liệu sẽ gửi'),
    previewBox
  )
}

/* ============================================================
 * CHAT — khung tin nhắn + ô nhập
 * ============================================================ */

function MessageBubble(props) {
  var m = props.msg
  var isUser = m.role === 'user'
  return h('div', { className: cx('wosai-msg', isUser ? 'user' : 'bot') },
    h('div', { className: 'wosai-ava' }, isUser ? '🙋' : '🤖'),
    h('div', { className: 'wosai-bubble' },
      h('div', { className: 'wosai-md' }, renderMarkdown(m.content)),
      isUser ? null : h(SourceChips, { meta: m.meta })
    )
  )
}

var QUICK_PROMPTS = [
  'Việc gì còn tồn đọng?',
  'Ngày mai có lịch gì cần chuẩn bị?',
  'Tuần này công việc ra sao?',
  'Tóm tắt những gì đã thống nhất',
]

/* ---------- banner tương thích: thiếu AI backend ---------- */
function CompatBanner(props) {
  var st = useAiStore()
  if (!st.compat) return null
  return h('div', { className: 'wosai-compat' + (props.compact ? ' compact' : '') },
    h('div', { className: 'wosai-compat-icon' }, '⚠️'),
    h('div', { className: 'wosai-compat-body' },
      h('div', { className: 'wosai-compat-title' }, 'Plugin đã cài nhưng thiếu AI backend'),
      props.compact ? h('div', { className: 'wosai-compat-text' },
          st.compat.detail, ' Cần bản Workspace OS kèm module AI Assistant (GĐ1–4).'
        ) : h('div', { className: 'wosai-compat-text' },
          st.compat.detail,
          ' Plugin "Trợ lý AI" cần bản Workspace OS đã tích hợp AI Assistant (Giai đoạn 1–4) gồm:',
          h('ul', { className: 'wosai-compat-list' },
            h('li', null, '9 API ', h('b', null, '/api/ai/*'), ' (chat, hội thoại, bộ nhớ, cài đặt, ghép nối extension…)'),
            h('li', null, '6 model dữ liệu AI (', h('b', null, 'AIConversation, AIMessage, AIMemory, AISetting, AIExtToken, AIExternalContext'), ')'),
            h('li', null, 'Lõi mở rộng ', h('b', null, 'WOS.registerWidget'), ' + ', h('b', null, 'WOS.getContext'), ' trong plugin-runtime'),
            h('li', null, 'Provider AI phía server (Grok/x.ai hoặc built-in) — API key không nằm trong plugin')
          ),
          h('div', { className: 'wosai-compat-text' },
            '👉 Giải pháp: dùng gói mã nguồn đầy đủ ', h('b', null, 'workspace-os-ai-full.zip'),
            ' (kèm toàn bộ AI backend + plugin + extension), chạy ', h('b', null, 'bun install'),
            ' rồi ', h('b', null, 'bunx prisma db push'), ' và khởi động lại — xem README đi kèm.'
          )
        ),
      h('div', { style: { marginTop: 10, display: 'flex', gap: 8 } },
        h('button', {
          className: 'wosai-quick',
          onClick: function () { store.loaded = false; ensureBoot() },
        }, 'Kiểm tra lại'),
        props.compact ? h('button', {
          className: 'wosai-quick',
          onClick: function () { try { WOS.openApp('wos-ai-assistant') } catch (e) { /* */ } },
        }, 'Xem chi tiết') : null
      )
    )
  )
}

function ChatView(props) {
  var st = useAiStore()
  var compact = props.compact
  var inputRef = useRef(null)
  var scrollRef = useRef(null)
  var text = useState('')
  var val = text[0], setVal = text[1]

  useEffect(function () {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight
  }, [st.messages.length, st.phase])

  function submit() {
    if (!val.trim() || st.busy) return
    var t = val
    setVal('')
    sendMessage(t)
  }

  // thiếu AI backend → chỉ hiện banner chẩn đoán (không hiện khung chat)
  if (st.compat) {
    return h('div', { className: 'wosai-messages' }, h(CompatBanner, null))
  }

  var empty = st.messages.length === 0 && !st.busy
  var body
  if (empty) {
    body = h('div', { className: 'wosai-empty' },
      h('div', { className: 'wosai-empty-icon' }, '🤖'),
      h('div', { className: 'wosai-empty-title' }, 'Trợ lý AI Workspace OS'),
      h('div', { className: 'wosai-empty-sub' },
        'Tôi nhớ được những lần trao đổi trước, đọc được công việc, lịch, việc tuần và biết app nào đang mở. Hỏi tôi bất cứ điều gì về công việc của bạn.'
      ),
      h('div', { className: 'wosai-quickrow', style: { justifyContent: 'center', marginTop: 8 } },
        QUICK_PROMPTS.map(function (q) {
          return h('button', {
            key: q, className: 'wosai-quick',
            onClick: function () { sendMessage(q) },
          }, q)
        })
      )
    )
  } else {
    body = h('div', { className: 'wosai-scroll', ref: scrollRef },
      st.messages.map(function (m) { return h(MessageBubble, { key: m.id, msg: m }) }),
      st.busy && !st.phase ? h('div', { className: 'wosai-phase' }, h('div', { className: 'wosai-spin' }), 'Đang xử lý…') : null
    )
  }

  return h('div', { className: 'wosai-messages' },
    body,
    st.phase ? h('div', { className: 'wosai-phase' }, h('div', { className: 'wosai-spin' }), st.phase) : null,
    st.error && !st.busy ? h('div', { className: 'wosai-phase', style: { color: 'oklch(0.6 0.2 25)' } }, '⚠️ ', st.error) : null,
    h('div', { className: 'wosai-inputrow' },
      empty ? null : h('div', { className: 'wosai-quickrow' },
        QUICK_PROMPTS.slice(0, 2).map(function (q) {
          return h('button', { key: q, className: 'wosai-quick', onClick: function () { sendMessage(q) } }, q)
        })
      ),
      h('div', { className: 'wosai-inputbox' },
        h('textarea', {
          className: 'wosai-input',
          rows: 1,
          placeholder: 'Hỏi trợ lý về công việc, lịch, việc tuần…',
          value: val,
          ref: inputRef,
          onChange: function (e) { setVal(e.target.value) },
          onKeyDown: function (e) {
            if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); submit() }
          },
        }),
        h('button', {
          className: 'wosai-send',
          disabled: st.busy || !val.trim(),
          onClick: submit,
          'aria-label': 'Gửi',
        }, '➤')
      )
    )
  )
}

/* ============================================================
 * SIDEBAR — lịch sử hội thoại (dùng chung active với widget)
 * ============================================================ */

function Sidebar(props) {
  var st = useAiStore()
  return h('aside', { className: 'wosai-side' },
    h('div', { className: 'wosai-side-head' },
      h('div', { className: 'wosai-logo' }, '🤖'),
      h('div', null,
        h('div', { className: 'wosai-side-title' }, 'Trợ lý AI'),
        h('div', { className: 'wosai-side-sub' },
          st.provider ? st.provider.label : 'Đang tải…')
      )
    ),
    h('button', { className: 'wosai-newchat', onClick: function () { newConversation() } },
      '✚ Hội thoại mới'
    ),
    h('div', { className: 'wosai-conv-list' },
      st.conversations.length === 0
        ? h('div', { style: { padding: '10px 8px', fontSize: 11, opacity: 0.55 } }, 'Chưa có hội thoại nào')
        : st.conversations.map(function (c) {
          return h('div', {
            key: c.id,
            className: cx('wosai-conv', c.id === st.activeId && 'active'),
            onClick: function () { setActiveConversation(c.id) },
          },
            h('span', { className: 'wosai-conv-title', title: c.title }, '💬 ' + c.title),
            h('span', { className: 'wosai-conv-count' }, c.messageCount),
            h('button', {
              className: 'wosai-conv-del',
              title: 'Xoá hội thoại',
              onClick: function (e) {
                e.stopPropagation()
                deleteConversation(c.id)
              },
            }, '🗑')
          )
        })
    )
  )
}
/* ============================================================
 * MEMORY MANAGER (GĐ3) — xem/sửa/ghim/xoá bộ nhớ dài hạn
 * ============================================================ */

function MemoryPanel(props) {
  var st = useAiStore()
  var state = useState({ list: null, filter: '', adding: false, addCat: 'fact', addText: '', editing: null, editVal: '' })
  var s = state[0], set = state[1]

  var reload = useCallback(function () {
    api('/api/ai/memory' + (s.filter ? '?category=' + s.filter : '')).then(function (res) {
      set(function (prev) { return Object.assign({}, prev, { list: res.memories, cats: res.categories }) })
    }).catch(function (e) {
      set(function (prev) { return Object.assign({}, prev, { list: [], err: e.message }) })
    })
  }, [s.filter])

  useEffect(function () { reload() }, [reload])

  function patchMem(id, body) {
    return api('/api/ai/memory/' + encodeURIComponent(id), { method: 'PATCH', body: body }).then(reload)
  }

  var cats = s.cats || [
    { value: 'preference', label: 'Sở thích' }, { value: 'project', label: 'Dự án' },
    { value: 'decision', label: 'Quyết định' }, { value: 'pending', label: 'Chưa xong' },
    { value: 'fact', label: 'Thông tin' },
  ]

  var list = s.list
  var body
  if (!list) {
    body = h('div', { className: 'wosai-empty' }, h('div', { className: 'wosai-spin' }), 'Đang tải bộ nhớ…')
  } else if (list.length === 0) {
    body = h('div', { className: 'wosai-card', style: { textAlign: 'center', opacity: 0.7 } },
      '🧠 Chưa có ghi nhớ nào.', h('br', null),
      'Trợ lý sẽ tự ghi nhớ thông tin quan trọng sau các cuộc trò chuyện (bạn xác nhận trước khi tin), hoặc thêm thủ công bên dưới.'
    )
  } else {
    var pending = list.filter(function (m) { return !m.confirmed && !m.supersededBy })
    body = h(Fragment, null,
      pending.length ? h('div', { className: 'wosai-warn' },
        '⏳ ', pending.length, ' ghi nhớ do AI trích xuất đang chờ bạn xác nhận (viền nét đứt). Xác nhận để trợ lý tin vào các thông tin này.'
      ) : null,
      list.map(function (m) {
        var cat = CAT_META[m.category] || CAT_META.fact
        var isEditing = s.editing === m.id
        return h('div', {
          key: m.id,
          className: cx('wosai-mem', !m.confirmed && !m.supersededBy && 'unconfirmed', m.supersededBy && 'superseded'),
        },
          h('span', { className: 'wosai-mem-cat', style: { background: cat.bg, color: cat.color } }, cat.label),
          h('div', { className: 'wosai-mem-content' },
            isEditing
              ? h(Fragment, null,
                  h('textarea', {
                    className: 'wosai-text', value: s.editVal, rows: 3,
                    onChange: function (e) { set(function (p) { return Object.assign({}, p, { editVal: e.target.value }) }) },
                  }),
                  h('div', { style: { display: 'flex', gap: 6, marginTop: 6 } },
                    h('button', {
                      className: 'wosai-btn', style: { padding: '5px 12px' },
                      onClick: function () {
                        patchMem(m.id, { content: s.editVal }).then(function () {
                          set(function (p) { return Object.assign({}, p, { editing: null }) })
                        })
                      },
                    }, 'Lưu'),
                    h('button', {
                      className: 'wosai-btn ghost', style: { padding: '5px 12px' },
                      onClick: function () { set(function (p) { return Object.assign({}, p, { editing: null }) }) },
                    }, 'Huỷ')
                  )
                )
              : h('div', null, m.content),
            h('div', { className: 'wosai-mem-foot' },
              h('span', null, 'Nguồn: ', m.source === 'manual' ? '✍️ bạn tự thêm' : m.source.indexOf('conversation:') === 0 ? '🤖 AI trích xuất' : m.source),
              h('span', null, '• Cập nhật ' + fmtDate(m.updatedAt)),
              m.version > 1 ? h('span', null, '• v' + m.version) : null,
              m.confidence ? h('span', null, '• tin cậy ' + m.confidence + '%') : null,
              m.supersededBy ? h('span', null, '• đã bị thay thế') : null
            )
          ),
          !m.supersededBy ? h('div', { className: 'wosai-mem-actions' },
            !m.confirmed ? h('button', {
              className: 'wosai-iconbtn on', title: 'Xác nhận ghi nhớ này',
              onClick: function () { patchMem(m.id, { confirmed: true }) },
            }, '✓') : null,
            h('button', {
              className: cx('wosai-iconbtn', m.pinned && 'on'),
              title: m.pinned ? 'Bỏ ghim' : 'Ghim — luôn đưa vào mọi câu hỏi',
              onClick: function () { patchMem(m.id, { pinned: !m.pinned }) },
            }, '📌'),
            h('button', {
              className: 'wosai-iconbtn', title: 'Sửa nội dung',
              onClick: function () {
                set(function (p) { return Object.assign({}, p, { editing: m.id, editVal: m.content }) })
              },
            }, '✎'),
            h('button', {
              className: 'wosai-iconbtn danger', title: 'Xoá ghi nhớ',
              onClick: function () {
                api('/api/ai/memory/' + encodeURIComponent(m.id), { method: 'DELETE' }).then(reload)
              },
            }, '🗑')
          ) : null
        )
      })
    )
  }

  return h('div', { className: 'wosai-panel' },
    h('div', { className: 'wosai-panel-inner' },
      h('div', { className: 'wosai-section-title' }, '🧠 Bộ nhớ dài hạn',
        h('span', { style: { fontSize: 11, fontWeight: 400, opacity: 0.6 } },
          '— trợ lý nhớ sở thích, quyết định, dự án qua các phiên chat')
      ),
      h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: 5 } },
        h('button', {
          className: cx('wosai-quick', !s.filter && 'active'),
          style: !s.filter ? { background: 'oklch(0.62 0.17 290 / 15%)', borderColor: 'oklch(0.62 0.17 290 / 40%)' } : {},
          onClick: function () { set(function (p) { return Object.assign({}, p, { filter: '' }) }) },
        }, 'Tất cả'),
        cats.map(function (c) {
          return h('button', {
            key: c.value, className: 'wosai-quick',
            style: s.filter === c.value ? { background: 'oklch(0.62 0.17 290 / 15%)', borderColor: 'oklch(0.62 0.17 290 / 40%)' } : {},
            onClick: function () { set(function (p) { return Object.assign({}, p, { filter: c.value }) }) },
          }, c.label)
        }),
        h('button', {
          className: 'wosai-quick', style: { marginLeft: 'auto', color: 'oklch(0.6 0.2 25)' },
          onClick: function () {
            if (window.confirm('Xoá TOÀN BỘ bộ nhớ dài hạn? Hội thoại được giữ nguyên.')) {
              api('/api/ai/memory?all=1', { method: 'DELETE' }).then(reload)
            }
          },
        }, 'Xoá tất cả')
      ),
      s.adding ? h('div', { className: 'wosai-card' },
        h('div', { className: 'wosai-grid2' },
          h('div', { className: 'wosai-field' },
            h('label', null, 'Loại'),
            h('select', {
              className: 'wosai-text', value: s.addCat,
              onChange: function (e) { set(function (p) { return Object.assign({}, p, { addCat: e.target.value }) }) },
            }, cats.map(function (c) { return h('option', { key: c.value, value: c.value }, c.label) }))
          ),
          h('div', { className: 'wosai-field' },
            h('label', null, 'Nội dung ghi nhớ'),
            h('input', {
              className: 'wosai-text', placeholder: 'vd: Tôi thích trả lời ngắn gọn, đi thẳng vấn đề',
              value: s.addText,
              onChange: function (e) { set(function (p) { return Object.assign({}, p, { addText: e.target.value }) }) },
            })
          )
        ),
        h('div', { style: { display: 'flex', gap: 6, marginTop: 8 } },
          h('button', {
            className: 'wosai-btn', disabled: !s.addText.trim(),
            onClick: function () {
              api('/api/ai/memory', { method: 'POST', body: { category: s.addCat, content: s.addText } })
                .then(function () { set(function (p) { return Object.assign({}, p, { addText: '', adding: false }) }); reload() })
                .catch(function (e) { try { WOS.toast.error('Không thêm được', { description: e.message }) } catch (e2) { /* */ } })
            },
          }, 'Lưu ghi nhớ'),
          h('button', {
            className: 'wosai-btn ghost',
            onClick: function () { set(function (p) { return Object.assign({}, p, { adding: false }) }) },
          }, 'Đóng')
        )
      ) : h('button', { className: 'wosai-btn ghost', onClick: function () { set(function (p) { return Object.assign({}, p, { adding: true }) }) } },
        '✚ Thêm ghi nhớ thủ công'
      ),
      body
    )
  )
}

/* ============================================================
 * SETTINGS — model, context, bộ nhớ, ghép nối extension (GĐ4)
 * ============================================================ */

/* --- Groq Cloud (fix lỗi 4): admin nhập API key + quản lý model ngay trong UI --- */
function GroqCard(props) {
  var st = useAiStore()
  var state = useState({
    loading: true, err: '', admin: true, cfg: null,
    keyInput: '', baseInput: '', newModel: '',
    saving: false, testing: false, testMsg: '', fetching: false,
  })
  var s = state[0], set = state[1]
  function upd(patch) { set(function (p) { return Object.assign({}, p, patch) }) }

  function reload() {
    upd({ loading: true, err: '' })
    api('/api/ai/groq').then(function (res) {
      upd({ loading: false, cfg: res, baseInput: res.baseUrl || '', admin: true })
    }).catch(function (e) {
      var msg = (e && e.message) || 'Không tải được cấu hình Groq'
      var forbidden = /403|quản trị|admin/i.test(msg)
      upd({ loading: false, err: forbidden ? '' : msg, admin: !forbidden })
    })
  }
  useEffect(function () { reload() }, [])

  if (s.loading) {
    return h('div', { className: 'wosai-card' }, 'Đang tải cấu hình Groq…')
  }
  if (!s.admin) {
    return h('div', { className: 'wosai-card' },
      h('div', { className: 'wosai-warn' }, 'Chỉ quản trị viên (admin) được cấu hình API key Groq.'))
  }

  var cfg = s.cfg || { configured: false, hasKey: false, hasEnvKey: false, models: [], customModels: [], defaultModel: 'llama-3.3-70b-versatile' }

  function saveKey() {
    upd({ saving: true, err: '' })
    api('/api/ai/groq', { method: 'PUT', body: { apiKey: s.keyInput, baseUrl: s.baseInput } })
      .then(function (res) {
        upd({ saving: false, cfg: Object.assign({}, cfg, res, { models: res.models || [] }), keyInput: '' })
        try { WOS.toast.success('Đã lưu API key Groq') } catch (e) { /* */ }
      })
      .catch(function (e) {
        upd({ saving: false, err: (e && e.message) || 'Lỗi lưu key' })
      })
  }

  function clearKey() {
    upd({ saving: true, err: '' })
    api('/api/ai/groq', { method: 'DELETE' })
      .then(function (res) {
        upd({ saving: false, cfg: Object.assign({}, cfg, res) })
        try { WOS.toast.success('Đã xoá key Groq nhập từ UI') } catch (e) { /* */ }
      })
      .catch(function (e) { upd({ saving: false, err: (e && e.message) || 'Lỗi xoá key' }) })
  }

  function addModel() {
    var m = (s.newModel || '').trim()
    if (!m) return
    var next = (cfg.customModels || []).concat([m])
    api('/api/ai/groq', { method: 'PUT', body: { models: next } })
      .then(function (res) {
        upd({ newModel: '', cfg: Object.assign({}, cfg, res, { models: res.models || [] }) })
      })
      .catch(function (e) { upd({ err: (e && e.message) || 'Lỗi thêm model' }) })
  }

  function removeModel(m) {
    var next = (cfg.customModels || []).filter(function (x) { return x !== m })
    api('/api/ai/groq', { method: 'PUT', body: { models: next } })
      .then(function (res) {
        upd({ cfg: Object.assign({}, cfg, res, { models: res.models || [] }) })
      })
      .catch(function (e) { upd({ err: (e && e.message) || 'Lỗi xoá model' }) })
  }

  function fetchModels() {
    upd({ fetching: true, err: '' })
    api('/api/ai/groq', { method: 'POST', body: { action: 'fetch-models' } })
      .then(function (res) {
        upd({ fetching: false, cfg: Object.assign({}, cfg, { models: res.models || [] }) })
        try { WOS.toast.success('Đã lấy ' + ((res.models || []).length) + ' model từ Groq') } catch (e) { /* */ }
      })
      .catch(function (e) { upd({ fetching: false, err: (e && e.message) || 'Không lấy được danh sách model' }) })
  }

  function testKey() {
    upd({ testing: true, testMsg: '', err: '' })
    var model = (st.settings && st.settings.model) || cfg.defaultModel
    api('/api/ai/groq', { method: 'POST', body: { action: 'test', model: model } })
      .then(function (res) {
        upd({ testing: false, testMsg: 'Kết nối OK — model trả lời: ' + (res.reply || '…') })
      })
      .catch(function (e) { upd({ testing: false, testMsg: 'Lỗi: ' + ((e && e.message) || 'không kết nối được') }) })
  }

  return h('div', { className: 'wosai-card' },
    /* trạng thái key */
    h('div', { style: { display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 } },
      cfg.hasKey
        ? h('span', { style: { fontSize: 11.5, fontWeight: 600, color: '#059669' } }, '✅ Đã cấu hình key' + (cfg.hasEnvKey ? ' (từ .env — GROQ_API_KEY)' : ' (nhập từ UI)'))
        : h('span', { style: { fontSize: 11.5, fontWeight: 600, color: '#b45309' } }, '⚠️ Chưa có API key — lấy tại console.groq.com/keys (miễn phí)')
    ),
    /* nhập key + baseUrl */
    h('div', { className: 'wosai-grid2' },
      h('div', { className: 'wosai-field' },
        h('label', null, 'Groq API Key'),
        h('input', {
          className: 'wosai-text', type: 'password', value: s.keyInput,
          placeholder: cfg.hasKey ? '•••••••• (đã lưu — nhập để thay thế)' : 'gsk_...',
          onChange: function (e) { upd({ keyInput: e.target.value }) },
        })
      ),
      h('div', { className: 'wosai-field' },
        h('label', null, 'Base URL (tuỳ chọn)'),
        h('input', {
          className: 'wosai-text', value: s.baseInput, placeholder: 'https://api.groq.com/openai/v1',
          onChange: function (e) { upd({ baseInput: e.target.value }) },
        })
      )
    ),
    h('div', { style: { display: 'flex', gap: 6, marginTop: 6, flexWrap: 'wrap' } },
      h('button', {
        className: 'wosai-btn', disabled: s.saving || (!s.keyInput && !cfg.hasKey),
        onClick: saveKey,
      }, s.saving ? 'Đang lưu…' : '💾 Lưu key'),
      cfg.hasKey && !cfg.hasEnvKey
        ? h('button', { className: 'wosai-btn danger', disabled: s.saving, onClick: clearKey }, 'Xoá key')
        : null,
      h('button', { className: 'wosai-btn', disabled: s.testing || !cfg.hasKey, onClick: testKey },
          s.testing ? 'Đang thử…' : '🔍 Thử kết nối')
    ),
    s.testMsg
      ? h('div', { style: { marginTop: 6, fontSize: 11.5, opacity: 0.85 } }, s.testMsg)
      : null,
    /* quản lý model */
    h('div', { style: { marginTop: 12, paddingTop: 10, borderTop: '1px solid rgba(128,128,128,.2)' } },
      h('label', { style: { fontWeight: 600, fontSize: 12 } }, 'Model Groq'),
      h('div', { style: { marginTop: 4, marginBottom: 6, fontSize: 11, opacity: 0.75 } },
        'Model tuỳ chỉnh (admin thêm/xoá tay — hợp nhất với danh sách Groq trả về):'),
      h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: 4, marginBottom: 8 } },
        (cfg.customModels || []).length === 0
          ? h('span', { style: { fontSize: 11, opacity: 0.6 } }, '(chưa có model tuỳ chỉnh — dùng danh sách mặc định)')
          : (cfg.customModels || []).map(function (m) {
              return h('span', {
                key: m,
                style: {
                  display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 11,
                  padding: '2px 8px', borderRadius: 999,
                  background: 'rgba(124,58,237,.12)', color: '#7c3aed',
                },
              },
                m,
                h('button', {
                  onClick: function () { removeModel(m) },
                  style: { border: 'none', background: 'none', cursor: 'pointer', fontSize: 12, lineHeight: 1, color: '#7c3aed' },
                  title: 'Xoá model này',
                }, '×')
              )
            })
      ),
      h('div', { style: { display: 'flex', gap: 6 } },
        h('input', {
          className: 'wosai-text', style: { flex: 1 }, value: s.newModel,
          placeholder: 'Tên model mới (vd openai/gpt-oss-120b)',
          onChange: function (e) { upd({ newModel: e.target.value }) },
          onKeyDown: function (e) { if (e.key === 'Enter') { e.preventDefault(); addModel() } },
        }),
        h('button', { className: 'wosai-btn', disabled: !s.newModel, onClick: addModel }, '➕ Thêm')
      ),
      h('div', { style: { marginTop: 6 } },
        h('button', { className: 'wosai-btn', disabled: s.fetching || !cfg.hasKey, onClick: fetchModels },
          s.fetching ? 'Đang tải…' : '🔄 Lấy danh sách model từ Groq'),
        h('div', { style: { marginTop: 6, fontSize: 10.5, opacity: 0.65, lineHeight: 1.5 } },
          'Gợi ý chọn nhanh (đã có sẵn trên Groq): ',
          h('b', null, 'llama-3.3-70b-versatile'),
          ' (cân bằng — mặc định), ',
          h('b', null, 'llama-3.1-8b-instant'),
          ' (siêu nhanh), ',
          h('b', null, 'openai/gpt-oss-120b'),
          ' (mạnh, mã nguồn mở), ',
          h('b', null, 'meta-llama/llama-4-scout-17b-16e-instruct'),
          ' (đa phương thức).')
      ),
      (cfg.models && cfg.models.length)
        ? h('details', { style: { marginTop: 6 } },
            h('summary', { style: { fontSize: 11, cursor: 'pointer', opacity: 0.75 } },
              'Xem ' + cfg.models.length + ' model khả dụng'),
            h('div', { style: { fontSize: 10.5, opacity: 0.8, lineHeight: 1.7, maxHeight: 120, overflow: 'auto' } },
              cfg.models.join(' · '))
          )
        : null
    ),
    s.err
      ? h('div', { className: 'wosai-warn', style: { marginTop: 8 } }, s.err)
      : null
  )
}

function SettingsPanel(props) {
  var st = useAiStore()
  var state = useState({ saving: false, saved: false, pair: null, tokens: null })
  var s = state[0], set = state[1]
  var cfg = st.settings || {}

  function save(patch) {
    set(function (p) { return Object.assign({}, p, { saving: true, saved: false }) })
    api('/api/ai/settings', { method: 'PATCH', body: patch }).then(function () {
      return loadSettings()
    }).then(function () {
      set(function (p) { return Object.assign({}, p, { saving: false, saved: true }) })
      setTimeout(function () { set(function (p) { return Object.assign({}, p, { saved: false }) }) }, 1500)
      notifyStore()
    }).catch(function (e) {
      set(function (p) { return Object.assign({}, p, { saving: false }) })
      try { WOS.toast.error('Không lưu được cài đặt', { description: e.message }) } catch (e2) { /* */ }
    })
  }

  function loadTokens() {
    api('/api/ai/ext-token').then(function (res) {
      set(function (p) { return Object.assign({}, p, { tokens: res.tokens }) })
    }).catch(function () {
      set(function (p) { return Object.assign({}, p, { tokens: [] }) })
    })
  }
  useEffect(function () { loadTokens() }, [])

  var temp = useState(String(cfg.temperature != null ? cfg.temperature : 0.7))
  var tempVal = temp[0], setTemp = temp[1]

  return h('div', { className: 'wosai-panel' },
    h('div', { className: 'wosai-panel-inner' },
      /* --- Provider --- */
      h('div', { className: 'wosai-section-title' }, '⚙️ Bộ máy AI'),
      h('div', { className: 'wosai-card' },
        h('div', { className: 'wosai-grid2' },
          h('div', { className: 'wosai-field' },
            h('label', null, 'Provider'),
            h('select', {
              className: 'wosai-text', value: cfg.provider || '',
              onChange: function (e) { save({ provider: e.target.value }) },
            },
              h('option', { value: '' }, 'Tự động (provider tốt nhất đã cấu hình)'),
              (st.providers && st.providers.length ? st.providers : [
                { id: 'xai', label: 'Grok — x.ai', configured: false },
                { id: 'zai', label: 'Built-in (sandbox)', configured: true },
              ]).map(function (p) {
                return h('option', { key: p.id, value: p.id },
                  p.label + (p.configured ? '' : ' — chưa cấu hình'))
              })
            )
          ),
          h('div', { className: 'wosai-field' },
            h('label', null, 'Model'),
            h('div', { style: { display: 'flex', gap: 6 } },
              h('input', {
                className: 'wosai-text', style: { flex: 1 },
                defaultValue: cfg.model || '', placeholder: st.provider ? 'mặc định: ' + st.provider.model : '',
                list: 'wosai-model-list',
                onBlur: function (e) { save({ model: e.target.value.trim() }) },
              }),
              st.models && st.models.length
                ? h('datalist', { id: 'wosai-model-list' },
                    st.models.slice(0, 60).map(function (m) { return h('option', { key: m, value: m }) })
                  )
                : null
            )
          )
        ),
        h('div', { style: { marginTop: 10 } },
          !st.provider
            ? null
            : st.provider.provider === 'xai' && !st.provider.hasKey
              ? h('div', { className: 'wosai-warn' },
                  '🔑 Server chưa có XAI_API_KEY — đang dùng provider built-in. Để dùng Grok: thêm biến môi trường ',
                  h('code', null, 'XAI_API_KEY'), ' trong file .env của Workspace OS rồi khởi động lại.'
                )
              : h('div', { className: 'wosai-preview-box' },
                  '✅ Đang chạy: ', h('b', null, st.provider.label),
                  st.provider.supportsTools ? ' — tool calling đã bật.' : ' — tool calling không khả dụng với provider này.'
                )
        ),
        h('div', { style: { marginTop: 8, fontSize: 11, opacity: 0.7, lineHeight: 1.5 } },
          '💡 Thêm AI khác (Ollama local, OpenRouter, Groq, DeepSeek…) — không cần sửa code: cấu hình ',
          h('code', null, 'AI_COMPAT_BASE_URL'), ' / ', h('code', null, 'AI_COMPAT_API_KEY'), ' / ', h('code', null, 'AI_COMPAT_MODEL'),
          ' trong .env — xem ', h('b', null, 'docs/ai-integration-guide.md'), '.'
        )
      ),

      /* --- Groq Cloud (fix lỗi 4): nhập key + quản lý model ngay trong UI --- */
      h('div', { className: 'wosai-section-title' }, '⚡ Groq Cloud — API key & model'),
      h(GroqCard, null),

      /* --- Context --- */
      h('div', { className: 'wosai-section-title' }, '🧩 Ngữ cảnh & chi phí'),
      h('div', { className: 'wosai-card' },
        h('div', { className: 'wosai-grid2' },
          h('div', { className: 'wosai-field' },
            h('label', null, 'Số lượt chat gần nhất đưa vào prompt'),
            h('div', { className: 'wosai-range' },
              h('input', {
                type: 'range', min: 2, max: 30, value: cfg.maxRecentMessages || 10,
                onChange: function (e) { setTemp(e.target.value); save({ maxRecentMessages: Number(e.target.value) }) },
              }),
              h('span', { className: 'wosai-range-val' }, cfg.maxRecentMessages || 10)
            )
          ),
          h('div', { className: 'wosai-field' },
            h('label', null, 'Ngưỡng tự tóm tắt hội thoại (tin nhắn)'),
            h('div', { className: 'wosai-range' },
              h('input', {
                type: 'range', min: 8, max: 80, value: cfg.summarizeThreshold || 20,
                onChange: function (e) { save({ summarizeThreshold: Number(e.target.value) }) },
              }),
              h('span', { className: 'wosai-range-val' }, cfg.summarizeThreshold || 20)
            )
          )
        ),
        h('div', { style: { marginTop: 10 } },
          h('label', { className: 'wosai-ctx-row', style: { cursor: 'pointer' } },
            h('span', { className: 'wosai-ctx-ico' }, '🧠'),
            h('span', { className: 'wosai-ctx-name' }, 'Bộ nhớ dài hạn (ghi nhớ + trích xuất tự động)'),
            h(Switch, {
              checked: cfg.memoryEnabled !== false,
              onChange: function (v) { save({ memoryEnabled: v }) },
            })
          )
        )
      ),

      /* --- GĐ4: Browser Extension --- */
      h('div', { className: 'wosai-section-title' }, '🌐 Trình duyệt mở rộng (Giai đoạn 4)'),
      h('div', { className: 'wosai-card' },
        h('p', { style: { margin: '0 0 8px', fontSize: 11.5, opacity: 0.75, lineHeight: 1.5 } },
          'Cài tiện ích "WOS AI Bridge" trên Chrome để gửi nội dung tab ngoài (bài viết, email, bảng tính…) vào trợ lý. ',
          'Nội dung luôn được đánh dấu ', h('b', null, 'KHÔNG đáng tin'), ' — AI chỉ tham khảo, không thực thi theo.'
        ),
        s.pair ? h('div', null,
          h('div', { className: 'wosai-paircode' }, s.pair.pairCode),
          h('p', { style: { fontSize: 10.5, opacity: 0.65, textAlign: 'center', margin: '6px 0 10px' } }, s.pair.instructions)
        ) : null,
        h('div', { style: { display: 'flex', gap: 6, flexWrap: 'wrap' } },
          h('button', {
            className: 'wosai-btn',
            onClick: function () {
              api('/api/ai/ext-token', { method: 'POST', body: {} }).then(function (res) {
                set(function (p) { return Object.assign({}, p, { pair: res }) })
                loadTokens()
              })
            },
          }, '🔑 Tạo mã ghép nối'),
          s.pair ? h('button', {
            className: 'wosai-btn ghost',
            onClick: function () { set(function (p) { return Object.assign({}, p, { pair: null }) }) },
          }, 'Ẩn mã') : null
        ),
        s.tokens && s.tokens.length ? h('div', { style: { marginTop: 10 } },
          h('label', { style: { fontSize: 11, fontWeight: 600, opacity: 0.75 } }, 'Thiết bị đã ghép nối'),
          s.tokens.map(function (t) {
            return h('div', { key: t.id, className: 'wosai-token-row' },
              h('span', { className: 'hint' }, t.hint),
              h('span', { style: { opacity: 0.55, flex: 1 } }, t.label),
              h('button', {
                className: 'wosai-iconbtn danger',
                onClick: function () {
                  api('/api/ai/ext-token?id=' + encodeURIComponent(t.id), { method: 'DELETE' }).then(loadTokens)
                },
              }, 'Thu hồi')
            )
          })
        ) : null
      ),

      /* --- trạng thái lưu --- */
      h('div', { style: { textAlign: 'right', fontSize: 11, height: 16 } },
        s.saving ? 'Đang lưu…' : s.saved ? '✅ Đã lưu' : '')
    )
  )
}

/* ============================================================
 * CHAT APP — cửa sổ chính: sidebar + chat + context panel + tabs
 * ============================================================ */

function ChatApp(props) {
  var st = useAiStore()
  var tab = useState('chat')
  var cur = tab[0], setTab = tab[1]

  useEffect(function () { ensureBoot() }, [])

  var providerPill = st.provider
    ? h('span', { className: cx('wosai-provider-pill', !st.provider.hasKey && st.provider.provider !== 'xai' && 'warn'), title: st.provider.label },
        h('span', { className: 'wosai-dot' }),
        (st.providers && st.providers.length
          ? (st.providers.find(function (p) { return p.id === st.provider.provider }) || {}).label || st.provider.provider
          : st.provider.provider) + ' · ' + st.provider.model)
    : null

  var content
  if (cur === 'chat') {
    content = h('div', { className: 'wosai-chatwrap' },
      h(Sidebar),
      h(ChatView),
      h(ContextPanel)
    )
  } else if (cur === 'memory') {
    content = h(MemoryPanel)
  } else {
    content = h(SettingsPanel)
  }

  return h('div', { className: 'wosai-root' },
    h('div', { className: 'wosai-main' },
      h('div', { className: 'wosai-topbar' },
        h('div', { className: 'wosai-tabs' },
          h('button', { className: cx('wosai-tab', cur === 'chat' && 'active'), onClick: function () { setTab('chat') } }, '💬 Chat'),
          h('button', {
            className: cx('wosai-tab', cur === 'memory' && 'active'),
            onClick: function () { setTab('memory') },
            title: st.status ? st.status.stats.pendingMemories + ' ghi nhớ chờ xác nhận' : '',
          }, '🧠 Bộ nhớ', st.status && st.status.stats.pendingMemories ? h('span', { className: 'wosai-src-chip', style: { marginLeft: 4 } }, st.status.stats.pendingMemories) : null),
          h('button', { className: cx('wosai-tab', cur === 'settings' && 'active'), onClick: function () { setTab('settings') } }, '⚙️ Cài đặt')
        ),
        providerPill
      ),
      content
    )
  )
}

/* ============================================================
 * AI WIDGET (GĐ2) — mini chat trên desktop, dùng CHUNG conversation
 * với Chat App (activeConversationId đồng bộ qua server)
 * ============================================================ */

function AiWidget(props) {
  var st = useAiStore()
  var text = useState('')
  var val = text[0], setVal = text[1]
  var scrollRef = useRef(null)

  useEffect(function () { ensureBoot() }, [])
  useEffect(function () {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight
  }, [st.messages.length, st.phase])

  function submit() {
    if (!val.trim() || st.busy) return
    var t = val
    setVal('')
    sendMessage(t)
  }

  // thiếu AI backend → widget hiện cảnh báo gọn
  if (st.compat) {
    return h('div', { className: 'wosai-widget' }, h(CompatBanner, { compact: true }))
  }

  var recent = st.messages.slice(-12)
  var msgsBody
  if (recent.length === 0) {
    msgsBody = h('div', { className: 'wosai-w-empty' },
      h('div', { className: 'big' }, '🤖'),
      h('div', { style: { fontWeight: 700, fontSize: 12 } }, 'Trợ lý AI'),
      h('div', { style: { fontSize: 10.5, opacity: 0.7 } }, 'Hỏi nhanh — cùng bộ nhớ với cửa sổ chat')
    )
  } else {
    msgsBody = h('div', { className: 'wosai-w-msgs', ref: scrollRef },
      recent.map(function (m) {
        return h('div', {
          key: m.id,
          className: cx('wosai-w-bubble', m.role === 'user' ? 'user' : 'bot wide'),
          title: m.role === 'assistant' ? 'Bấm để mở toàn bộ câu trả lời' : '',
          onClick: m.role === 'assistant'
            ? function () { try { WOS.openApp('wos-ai-assistant') } catch (e) { /* */ } }
            : undefined,
        }, m.role === 'user' ? plainPreview(m.content, 160) : renderMarkdown(m.content))
      })
    )
  }

  return h('div', { className: 'wosai-widget' },
    h('div', { className: 'wosai-w-head' },
      h('div', { className: 'wosai-w-logo' }, '🤖'),
      h('div', { className: 'wosai-w-title' },
        'Trợ lý AI',
        st.activeId ? '' : ' — mới'
      ),
      h('button', {
        className: 'wosai-w-expand',
        title: 'Mở cửa sổ chat đầy đủ (cùng hội thoại)',
        onClick: function () { try { WOS.openApp('wos-ai-assistant') } catch (e) { /* */ } },
      }, '⤢ Mở đầy đủ')
    ),
    msgsBody,
    st.phase ? h('div', { className: 'wosai-w-phase' }, h('div', { className: 'wosai-spin' }), st.phase) : null,
    h('div', { className: 'wosai-w-inputrow' },
      h('input', {
        className: 'wosai-w-input',
        placeholder: 'Hỏi nhanh…',
        value: val,
        onChange: function (e) { setVal(e.target.value) },
        onKeyDown: function (e) { if (e.key === 'Enter') { e.preventDefault(); submit() } },
      }),
      h('button', { className: 'wosai-w-send', disabled: st.busy || !val.trim(), onClick: submit, 'aria-label': 'Gửi' }, '➤')
    )
  )
}

/* ============================================================
 * ĐĂNG KÝ — app cửa sổ + widget desktop (cùng bộ não)
 * ============================================================ */

WOS.registerApp({ component: ChatApp, windowSize: { w: 1020, h: 680 } })

/* widget desktop (GĐ2) — chỉ đăng ký khi lõi hỗ trợ (bản OS cũ chưa có
   WOS.registerWidget → bỏ qua để plugin vẫn mở được app + hiện banner hướng dẫn) */
if (typeof WOS.registerWidget === 'function') {
  WOS.registerWidget({
    type: 'bubble',
    title: 'Trợ lý AI',
    icon: '🤖',
    defaultW: 330,
    defaultH: 430,
    minW: 260,
    minH: 220,
    component: AiWidget,
  })
} else {
  try { console.warn('[wos-ai-assistant] Lõi Workspace OS chưa có WOS.registerWidget — widget desktop bị tắt. Cần bản OS kèm AI Assistant (GĐ1–4).') } catch (e) { /* */ }
}

/* phát event cài đặt thành công (Timeline/Activity ghi nhận) */
try {
  WOS.emitEvent('installed', { version: '1.0.0', features: ['chat', 'widget', 'memory', 'tools', 'extension'] })
} catch (e) { /* ignore */ }
