# WOS v2.1 — Security & Hardening Changelog

Bản vá theo báo cáo rà soát code (19 vấn đề). Mọi thay đổi đã được test E2E (33/33 pass).

## PHASE 1 — Bảo mật (chặn trước khi ra Internet)

### 1. Forgot Password — không còn lộ mã reset qua API (Critical)
- `POST /api/core/auth/forgot` **không trả mã** trong response nữa.
- Mã chỉ đến qua 2 kênh an toàn:
  1. **Log server**: `journalctl -u wos | grep WOS:reset`
  2. **Administration → Users** (admin đăng nhập mới thấy) — thẻ vàng "Mã đặt lại đang hiệu lực".
- Rate limit: 5 lần/15 phút theo IP, 3 mã/15 phút theo username; `/reset` giới hạn 10 lần thử/15 phút.
- Màn Login: bỏ hiển thị "Mã đặt lại: XXXXXXXX"; hướng dẫn liên hệ quản trị viên.

### 2. ZIP Symlink Attack — chặn thoát storage (Critical)
- `safeResolveReal()`: kiểm tra realpath TOÀN BỘ chuỗi thành phần — symlink trỏ ra ngoài storage → từ chối (symlink nội bộ vẫn dùng được).
- `unzipEntry()`: pre-scan `unzip -Z1` + `unzip -Zl` — từ chối ZIP chứa symlink / tên tuyệt đối / `..` / `\` / NUL, giới hạn 3000 mục; sau giải nén quét xoá symlink sót lại (phòng thủ 2 lớp).
- Mọi đường đọc file (download/preview/share/read) đã qua lớp realpath.

### 3. Backup không còn lộ secret (Critical)
- Export JSON: `core:auth_secret` bị **bỏ hẳn**; mọi key chứa secret/token/password/... → `[REDACTED]` (áp dụng cả backup Google Drive trong `sync.ts`).
- Import: dòng `[REDACTED]` được **bỏ qua** (giữ giá trị server hiện tại) — phục hồi backup cũ không phá vỡ đăng nhập.

### 4. Settings toàn hệ thống — chỉ admin
- `PUT /api/core/settings`: module **global** (tasks/calendar/files/... ) yêu cầu admin; module **per-user** (appearance) user tự sửa bộ của mình.

## PHASE 2 — Filesystem

### 5. Upload streaming (High)
- Parser multipart tự viết (`multipart.ts`): file **không bao giờ nằm nguyên trong RAM** (≈64KB/chunk) — thay `req.formData()` vốn buffer cả file.
- Đã test upload 60MB; hỗ trợ mọi client cũ (FormData) không đổi frontend.
- Quota **enforce thật** theo Setting `core:quota_gb`: kiểm trước bằng content-length (413), dọn file vượt sau khi ghi (413), cache usage invalidate sau upload.

### 6. Download/Preview/Share streaming (High)
- `createReadStream → Response`: tải file GB với RAM ~64KB.
- Hỗ trợ **HTTP Range** (206) — video preview tua được.

### 7. Rename/Move — sửa cây FileNode (High)
- Node con nhận **path = đích + đuôi cũ** (`Work/a.pdf`), KHÔNG còn bị đè mất thành `Work`; tên con giữ nguyên; chạy trong transaction.

### 8. Boundary startsWith (High)
- trash/restore/delete/rename/move dùng `path === p OR path.startsWith(p + '/')` — xoá `ABC` không còn đụng `ABC2`.

### 9. Chặn copy/move vào chính nó/con (High)
- Server từ chối `A → A` và `A → A/con` (2 lớp: route + storage) — hết đệ quy vô hạn `A/A/A/...`.
- Copy thư mục giờ copy cả metadata (favorite/tags) của con.

## PHASE 3 — Dữ liệu

### 10. Backup Restore nguyên tử (High)
- Toàn bộ restore trong **1 transaction** (dùng đúng transaction client, timeout 120s) — lỗi giữa chừng → rollback, hết restore nửa vời.
- **Giữ secret hiện tại xuyên qua restore** (auth_secret + credential sync) — session không chết sau import.
- **Snapshot DB trước khi restore** (`db/snapshots/pre-restore-*.db`, dùng SQLite backup API).
- Đủ bảng: thêm `workProcess/workStep/workPrep/workDay/workTask` (Weekly), `plugin`, `userLayout`. Không export User/Session/PasswordReset (an toàn — không lộ hash).
- Bảng tự tham chiếu (wikiPage/workStep/workTask) được topo-sort cha-trước-con.

### 11. Đổi mật khẩu giữ session hiện tại (Medium)
- `changePassword(userId, pass, exceptSessionId)` — các thiết bị KHÁC bị đăng xuất, mình vẫn ở lại. Reset password (quên pass) vẫn huỷ toàn bộ session.

## PHASE 4 — Logic

### 12. Reports Export GET/POST (High)
- Thêm `GET` (khớp `window.open`) + giữ `POST` — hết lỗi 405 khi bấm Export.

### 13. Calendar monthly + exceptions
- Cộng tháng **chặn cuối tháng**: 31/01 + 1 tháng = 28/02 (không trôi 03/03) — áp dụng cả Tasks repeat monthly.
- **Xoá 1 lần trong chuỗi lặp**: `DELETE /{id}?occurrence=YYYY-MM-DD` lưu vào `exceptions`; UI hỏi 2 bước ("Chỉ lần này" → "Toàn bộ chuỗi").

### 14. Weekly statistics — chỉ tính việc lá
- `stats` + `days`: nhóm (việc mẹ) không bị đếm vào tổng — khớp với WeekWidget.

### 15. Timezone theo Setting (Medium)
- Helper `datetime.ts`: `getUserTimezone()`, `isoDateInTz()`, `startOfDayInTz()`, `yearInTz()` — đọc Setting `core:timezone` (mặc định Asia/Bangkok).
- Áp dụng: Weekly (today/tuần hiện tại), Calendar (năm lịch lễ + ngày exception), Reports (ranh giới daily/weekly/monthly + định dạng ngày), Dashboard.
- Calendar UI: so ngày theo local browser — sự kiện sáng sớm (00:00–06:59) hiện đúng ô ngày.

### 16. Projects — kiểm tra ownership (Medium)
- `milestone.delete` / `member.remove` kiểm tra đối tượng **thực sự thuộc project này** — chặn xoá chéo project/tài khoản khác qua id.

## PHASE 5 — Production

### 17. TypeScript strict build
- Bỏ `ignoreBuildErrors: true` — `next build` production **pass sạch** với type-check đầy đủ.
- Thêm `@types/node` vào devDependencies.

### 18. install.sh — giữ PORT cũ
- Flag `APP_PORT_SET` chuyển lên TRƯỚC khi gán mặc định 3068 — logic "giữ nguyên cổng lần trước" hoạt động trở lại.

### 19. Quota cấu hình được
- `usage` API đọc Setting `core:quota_gb` (server-side, không tin client) — admin đổi hạn mức trong Settings → upload + hiển thị phản ánh ngay.

## Xác nhận giữ nguyên (theo review)
- Per-user permissions (User.permissions + user-permissions.ts) — vẫn hoạt động đầy đủ.
- Auth session (httpOnly/HMAC/DB-backed/scrypt) — không đổi.
- Per-user storage (ALS) — không đổi.

## Chạy lại test
```bash
bash scripts/e2e-test.sh   # 33 bài test — cần dev server chạy ở :3000
```
