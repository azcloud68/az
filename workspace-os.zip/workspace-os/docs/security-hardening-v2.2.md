# WOS v2.2 — Security & Hardening Changelog

Bản vá tiếp theo theo báo cáo rà soát `workspace-os (3).zip` (10 vấn đề còn lại sau v2.1:
5 lỗi đỏ File Manager + 4 lỗi cam + 1 lỗi vàng). Mọi thay đổi đã được test đơn vị
(test-symlink, test-zip-hardening, test-multipart) + E2E 37/37 pass.

## 5 LỖI ĐỎ (File Manager) — đã xử lý hết

### 1. ZIP bomb — giới hạn tổng dung lượng giải nén (HIGH)
- `unzipEntry()` giờ parse listing `unzip -Zl` lấy **dung lượng giải nén KHAI BÁO**
  của từng entry, cộng tổng và so với hạn mức TRƯỚC KHI giải nén:
  `maxTotalBytes = min(quota còn lại của user, trần cứng MAX_EXTRACT_BYTES = 2GB)`.
- Zip 10MB khai 10GB → bị chặn khi chưa đụng đĩa (thông báo rõ "chặn zip bomb").
- File Manager: `extract` đọc usage **FRESH** (bỏ cache 30s) + quota từ `core:quota_gb`.
- Cài plugin .zip cũng pre-scan tương tự (giới hạn 200MB khai báo) — trước đây chỉ
  kiểm SAU khi giải nên bom đã kịp phình đĩa.

### 2. Extract KHÔNG còn ghi đè tệp đang có (HIGH)
- Giải nén vào **thư mục staging riêng** (`.wos_extract_<random>`, cùng cha với đích
  để rename rẻ) rồi mới chuyển từng entry sang đích.
- Đích trùng tên → tự dedup `tên (1)`, `tên (2)`… (cùng logic với upload —
  `storage.uniqueRelPath()`); tệp/thư mục người dùng đang có **không bao giờ bị đè**.
- Flag `-o` của unzip giờ chỉ áp trong staging (thư mục rỗng dùng một lần).
- Lỗi giữa chừng → dọn sạch staging + cây đích (mới tạo hoàn toàn nên xoá an toàn).

### 3. Extract index FileNode ĐỆ QUY toàn bộ cây (HIGH)
- `unzipEntry()` trả `{ root, entries[] }` với entries là **toàn bộ cây con**
  (trước đây chỉ `readdir` tầng đầu → `project/src/index.ts` không có node DB).
- Route `extract` tạo FileNode cho mọi tầng — File Manager, search, favorite, tags
  giờ thấy đúng mọi file đã giải nén.

### 4. Thống nhất: mọi filesystem I/O đi qua safeResolveReal() (HIGH)
- Nguyên tắc mới ghi rõ ở đầu `storage.ts`:
  - `safeResolve()` → CHỈ dùng cho thao tác thuần đường dẫn (lexical).
  - `safeResolveReal()` → MỌI đọc/ghi thật.
- Đã thay hết trong `files/[op]/route.ts`: `read`, `write`, `newfile`, `view`,
  `info`, `favorite`, `compress`, `copy`, `extract`, `search` (walk đệ quy) và
  `upload` (mkdir + dọn file dở).
- Helper mới ở storage layer để route không tự gọi `fs.*` trên path lexical:
  `statEntry()`, `writeTextFile()`, `uniqueRelPath()`, `makeDir()`, `removeEntry()`.

### 5. Filesystem ↔ DB đồng bộ khi rename/move/copy/extract thất bại (HIGH)
- **rename/move**: FS đổi tên xong → nếu transaction DB (`retargetTree`) fail →
  **move ngược về chỗ cũ** (compensation); nếu compensation cũng fail thì log
  đường dẫn để xử lý tay.
- **copy**: DB fail → xoá BẢN SAO (bản gốc không bị động tới).
- **extract**: DB fail → xoá toàn bộ cây vừa giải nén (dedup đảm bảo cây đó
  100% mới tạo — không thể lỡ xoá dữ liệu cũ).
- **newfile / mkdir / compress**: DB fail → xoá tệp/thư mục vừa tạo.

## 4 LỖI CAM — đã xử lý

### 6. TOCTOU: verify fd qua /proc/self/fd (MEDIUM)
- Sau khi mở fd, đọc `/proc/self/fd/<n>` kiểm tra fd vẫn trỏ **vào trong** root —
  lấp khoảng hở "realpath-check xong → symlink bị đổi → read/write theo path cũ".
- Áp cho: `readFileStream` (download/preview/share — stream đọc từ fd ĐÃ MỞ nên
  symlink đổi giữa chừng không thể chuyển hướng luồng), `saveStream`, `writeTextFile`.
- Linux (Orange Pi) có /proc; hệ khác bỏ qua an toàn (vẫn còn lớp realpath).

### 7. Rate limit: không tin X-Forwarded-For client tự gửi (MEDIUM/HIGH)
- `reqIp()` mới — CHỈ tin header proxy khi cấu hình `WOS_TRUST_PROXY`:
  - `cloudflare` → dùng `CF-Connecting-IP` (Cloudflare edge ghi đè — client giả mạo vô dụng)
  - `forwarded` → lấy entry CUỐI `X-Forwarded-For` (proxy tự quản ghi đè/append)
  - để trống (mặc định) → trả `'direct'`, KHÔNG tin header nào client tự gửi
- Trước đây: client tự gửi `X-Forwarded-For: 1.1.1.1, 1.1.1.2, …` xoay IP vô hạn
  để vượt rate limit 5 lần/15 phút của forgot/reset.
- Lưu ý triển khai: **khi bật Cloudflare Tunnel phải đặt `WOS_TRUST_PROXY=cloudflare`
  trong .env rồi `systemctl restart wos`** (install.sh đã nhắc ở cuối output).
- Rate limit theo username (3 mã/15p forgot, 10 lần/15p reset) vẫn có hiệu lực
  bất kể chế độ IP.

### 8. Quota race condition — mutex + usage tươi (MEDIUM)
- `withStorageLock()`: mutex trong-process (globalThis — sống qua hot-reload)
  serialise các handler **upload** và **extract**.
- Upload đọc `storageUsage({ fresh: true })` (bỏ cache 30s) → 2 upload đồng thời
  không cùng thấy số usage cũ rồi cùng ghi vượt quota.
- `invalidateUsage()` gọi sau mọi thao tác đổi dung lượng (upload/extract/compress).

### 9. Reset code: 1 mã hợp lệ + tắt được log (MEDIUM)
- `createResetCode()` giờ **vô hiệu hoá mọi mã cũ** khi sinh mã mới — tại 1 thời
  điểm chỉ 1 mã hợp lệ (trước đây 3 mã cùng dùng được).
- Log journal giờ tuỳ chọn: `WOS_RESET_CODE_IN_LOG=0` để không bao giờ ghi mã
  vào journal (mặc định 1 = còn kênh tự cứu cho máy chỉ có 1 admin).
- LoginScreen cập nhật hướng dẫn lấy mã (admin channel + log).

## Quyết định thiết kế

### 10. Timezone = GLOBAL (chốt)
- `core:timezone` là thiết đặt toàn hệ thống do admin đặt trong Settings —
  phù hợp workspace cá nhân/gia đình 1 múi giờ (đã ghi rõ trong `datetime.ts`).
- Muốn per-user sau này: thêm cột `User.timezone`, `getUserTimezone()` đọc theo session.

### 11. Recurrence DST-safe (🟡 hoàn thiện luôn)
- Thay EVERY ngày cộng ms thuần (`+86400000`) bằng **cộng theo LỊCH tz người dùng**
  (`addDaysInTz` / `addMonthsInTz` trong `datetime.ts` — round-trip Intl, giữ nguyên
  giờ treo tường khi DST làm ngày 23h/25h).
- daily/weekly/monthly/yearly của Calendar + repeat daily/weekly/monthly của Tasks
  đều dùng helpers mới. Monthly vẫn chặn cuối tháng (31/01 + 1 = 28/02).

### 12. Policy dung lượng tập trung ở storage layer
- `MAX_FILE_BYTES` (env `WOS_MAX_FILE_MB`, mặc định 256MB, trần 4096) — export từ
  `storage.ts`, upload dùng chung; hết cảnh "256MB nằm riêng trong route upload".
- `MAX_EXTRACT_BYTES` = 2GB trần cứng chống zip bomb.

## Biến môi trường mới (đề do install.sh ghi sẵn)

| Biến | Mặc định | Ý nghĩa |
|------|----------|---------|
| `WOS_TRUST_PROXY` | (trống) | `cloudflare` / `forwarded` / trống — tin header IP nào |
| `WOS_MAX_FILE_MB` | `256` | Giới hạn 1 tệp upload (MB, tối đa 4096) |
| `WOS_RESET_CODE_IN_LOG` | `1` | `0` = không ghi mã reset vào journal |

## Checklist trước khi mở Cloudflare Tunnel
1. ✅ v2.1 + v2.2: Forgot Password, ZIP symlink/bomb/overwrite, Backup secret,
   Filesystem boundary/rollback — đã vá + E2E pass.
2. Đặt `WOS_TRUST_PROXY=cloudflare` trong `/opt/workspace-os/.env` rồi
   `sudo systemctl restart wos`.
3. Chạy thử thực tế trên Orange Pi 3B 2GB: file 100–256MB, ZIP lồng nhau,
   rename/move, quota, restore backup (kịch bản e2e-test.sh đã mô phỏng đủ).

## Test
- `bun scripts/test-symlink.ts` — symlink/zip độc hại chặn + index đệ quy.
- `bun scripts/test-zip-hardening.ts` — zip bomb, không ghi đè, dedup, mutex, dedup tên.
- `bun scripts/test-multipart.ts` — parser multipart stream.
- `bash scripts/e2e-test.sh` — 37 bài qua HTTP thật (login → upload/download/
  extract/backup/restore/settings/password/projects/weekly/calendar/users).
