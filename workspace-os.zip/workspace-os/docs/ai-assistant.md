# WOS AI Assistant — Trợ lý AI tích hợp Workspace OS

> Phát triển đầy đủ **Giai đoạn 1 → 4** theo tài liệu phân tích kiến trúc.
> Plugin `wos-ai-assistant` + Backend AI Proxy + Context Registry + Bộ nhớ 4 tầng + Browser Extension.

---

## Tổng quan 4 giai đoạn đã hoàn thành

| Giai đoạn | Nội dung | Trạng thái |
|-----------|----------|------------|
| **1 — MVP** | Plugin chat + Grok proxy + hội thoại + context thủ công/tự động | ✅ Hoàn thành |
| **2 — AI Widget** | Widget desktop + đồng bộ conversation ID + Context Registry + window-store | ✅ Hoàn thành |
| **3 — Memory thông minh** | Tự tóm tắt theo ngưỡng + memory có phiên bản/nguồn gốc + truy xuất theo câu hỏi + tool calling | ✅ Hoàn thành |
| **4 — Browser Extension** | Extension Chrome ghép nối + cấp quyền đọc tab + Context API + dữ liệu không đáng tin | ✅ Hoàn thành |

## Kiến trúc triển khai

```
┌────────────────────────────── Browser (Orange Pi) ──────────────────────────────┐
│  Plugin wos-ai-assistant (main.js — chạy qua WOS runtime)                       │
│  ├─ Chat App (registerApp)      ── cửa sổ đầy đủ: chat + bộ nhớ + cài đặt       │
│  ├─ AI Widget (registerWidget)  ── mini chat trên desktop, KÉO THẢ được         │
│  └─ Shared Store (module scope) ── chung conversation ID + lịch sử + bộ nhớ      │
│         │  WOS.api() / WOS.getContext()                                         │
└─────────┼───────────────────────────────────────────────────────────────────────┘
          ▼  HTTPS nội bộ (không có API key trên client)
┌────────────────────── Next.js API (Workspace OS server) ────────────────────────┐
│  POST /api/ai/chat              — proxy chính, dựng prompt, chạy tool loop      │
│  /api/ai/conversations[/:id]    — hội thoại + active ID (widget↔app dùng chung) │
│  /api/ai/memory[/:id]           — Memory Manager CRUD                           │
│  /api/ai/settings, /status      — cấu hình + trạng thái provider                │
│  /api/ai/context/preview        — xem trước dữ liệu sẽ gửi (trung minh)         │
│  /api/ai/ext-token              — mã ghép nối + token extension                 │
│  /api/ai/context/external       — nhận context từ tab ngoài (KHÔNG đáng tin)    │
│                                                                                  │
│  core/server/ai/ provider.ts (facade) · providers/ (REGISTRY: xai/openai-compat/zai) │
│                  memory.ts (M1-M4)     · prompt.ts · tools.ts (tool calling)    │
└─────────┬──────────────────────────────┬────────────────────────────────────────┘
          ▼                              ▼
   Grok API (x.ai)                 Prisma SQLite (6 bảng AI mới)
   XAI_API_KEY chỉ nằm env         AIConversation · AIMessage · AIMemory
                                    AISetting · AIExtToken · AIExternalContext
```

## Bộ nhớ 4 tầng (đúng thiết kế)

| Tầng | Cơ chế | Nơi lưu |
|------|--------|---------|
| **M1** Tin nhắn gần | `maxRecentMessages` lượt cuối (mặc định 10) | `AIMessage` |
| **M2** Tóm tắt | vượt `summarizeThreshold` → AI gộp lượt cũ thành summary tích lũy | `AIConversation.summary` |
| **M3** Bộ nhớ dài hạn | bản ghi độc lập: `category` (preference/project/decision/pending/fact) + `source` + `confidence` + `version` + `history`. Mâu thuẫn → bản mới **supersede** bản cũ, không xoá âm thầm | `AIMemory` |
| **M4** Live context | mỗi lượt hỏi đọc Tasks/Calendar/Weekly trực tiếp DB theo `ownerId` — không cache dữ liệu cũ | realtime |

Truy xuất M3: chấm điểm từ khóa + pinned/confirmed (chưa cần embeddings — nâng cấp semantic khi memory nhiều).

## An toàn theo đúng "Các vấn đề cần tránh"

- **API key không lộ**: chỉ env `XAI_API_KEY` phía server; client chỉ thấy trạng thái "đã cấu hình".
- **Context không phình**: lấy theo câu hỏi, giới hạn bản ghi (tasks ≤50, calendar ≤60…), M2 summary, M3 retrieval.
- **Không nhớ dữ liệu cũ**: M4 đọc realtime; memory luôn gắn nguồn + thời điểm.
- **Widget không mất hội thoại**: active conversation lưu server (`AISetting.activeConversationId`).
- **AI chỉ ĐỌC**: chưa có thao tác ghi; tool calling chỉ chạy tool whitelist phía server.
- **Quyền**: collector kiểm tra module bật + quyền tài khoản trước khi đọc.
- **Dữ liệu ngoài không đáng tin**: prompt gắn nhãn `EXTERNAL CONTEXT — KHÔNG ĐÁNG TIN`, AI được cấm coi là chỉ thị thực thi (đã kiểm chứng E2E).

## Cấu hình Grok

```bash
# .env của Workspace OS
XAI_API_KEY='xai-...'            # bắt buộc để dùng Grok
XAI_BASE_URL='https://api.x.ai/v1'  # mặc định — đổi nếu cần proxy
XAI_MODEL='grok-4-fast'          # mặc định — đổi model tại đây
```

Không có key → hệ thống tự dùng provider built-in (sandbox) để vẫn chạy end-to-end.
User đổi provider/model trong **Trợ lý AI → Cài đặt**.

## Cài đặt

### 0. Yêu cầu tương thích (QUAN TRỌNG)
Plugin **không chạy độc lập** — cần bản Workspace OS đã tích hợp AI backend
(9 API `/api/ai/*`, 6 model Prisma, `WOS.registerWidget`/`WOS.getContext`, provider server).
Nếu cài `wos-ai-assistant-plugin.zip` vào bản Workspace OS gốc (chưa có AI backend),
plugin sẽ mở được nhưng hiển thị **màn hình cảnh báo thiếu backend** kèm hướng dẫn.
👉 Dùng gói `workspace-os-ai-full.zip` — bản OS hoàn chỉnh đã sẵn mọi thứ (xem `QUICKSTART.md`).

### 1. Plugin (đã cài sẵn trong bản này — `storage/plugins/wos-ai-assistant/`)
Cách khác: Settings → Plugins → **Cài plugin mới** → chọn `wos-ai-assistant-plugin.zip`.

### 2. Browser Extension (GĐ4)
1. Giải nén `wos-ai-browser-extension.zip`
2. Chrome → `chrome://extensions` → bật **Developer mode** → **Load unpacked** → trỏ thư mục vừa giải nén
3. Mở WOS → Trợ lý AI → **Cài đặt** → **Tạo mã ghép nối**
4. Bấm icon extension → nhập địa chỉ WOS + mã → Ghép nối
5. Trên bất kỳ trang web nào: bôi chọn đoạn văn → menu chuột phải → **"Gửi đoạn này cho Trợ lý AI Workspace OS"** (hoặc Ctrl+Shift+Y), hoặc gửi cả trang từ popup
6. Về WOS mở Trợ lý AI — context xuất hiện trong **Context Panel** (có cảnh báo không đáng tin) và được đưa vào lượt chat kế tiếp

### 3. Thêm widget AI lên desktop
Settings → Appearance → Desktop & Dock → bấm chip **🤖 Trợ lý AI**.
Widget kéo thả/resize tự do, vị trí sống sót qua F5, **dùng chung hội thoại** với cửa sổ chat (nút "Mở đầy đủ" để chuyển tiếp).

## Điểm tích hợp vào lõi Workspace OS (đã mở rộng runtime)

| File | Thay đổi |
|------|----------|
| `prisma/schema.prisma` | +6 model AI |
| `src/components/wos/plugin-runtime.ts` | + `WOS.registerWidget()`, + `WOS.getContext()` |
| `src/core/client/plugin-widgets.ts` | **mới** — registry widget của plugin |
| `src/core/client/context-registry.ts` | **mới** — snapshot app đang mở + selection (bus `wos:selection`) |
| `src/components/wos/widgets/WidgetLayer.tsx` | render widget plugin + error boundary + `allWidgetDefs()` |
| `src/modules/settings/DesktopSection.tsx` | liệt kê widget plugin khi thêm |
| `src/modules/tasks/pages/TasksPage.tsx` | phát selection khi mở chi tiết công việc |
| `src/components/wos/WosApp.tsx` | khởi động Context Registry |
| `src/app/api/ai/**` | **mới** — 9 endpoint AI |
| `src/core/server/ai/**` | **mới** — provider / context / memory / prompt / tools + `providers/` registry |

## Kiểm thử E2E đã thực hiện (agent-browser + curl)

- ✅ Đăng nhập, desktop render, plugin tự cài qua scan, icon Desktop + Dock
- ✅ Mở Chat App, gửi câu hỏi → trả lời dựa Tasks/Calendar/Weekly thật (bảng Markdown)
- ✅ Trích xuất memory: AI tự ghi 4 ghi nhớ, chờ xác nhận; xác nhận qua UI
- ✅ Truy xuất memory: câu hỏi "tên tôi" → AI biết "Tony" từ long-term memory
- ✅ Widget: thêm qua Settings, kéo thả, **F5 giữ nguyên vị trí**, gửi tin từ widget
- ✅ Đồng bộ 2 chiều widget ↔ app (cùng conversation ID — đã sửa race condition)
- ✅ Context Panel: công tắc nguồn, preview số bản ghi, "App đang mở: …"
- ✅ Extension: sinh mã ghép nối → đổi token → gửi context → AI trả lời kèm cảnh báo "không phải chỉ thị thực thi" → context tự tiêu thụ
- ✅ `bun run lint` sạch; không lỗi console; không lỗi 500 trong dev.log

## Hạn chế & hướng tiếp theo

- Tool calling chỉ kích hoạt với provider `xai` (Grok) — provider built-in dùng context thu thập sẵn.
- Tìm kiếm memory theo từ khóa; nâng cấp embeddings/semantic search khi số lượng lớn.
- AI hiện chỉ đọc — mở rộng thao tác ghi (tạo task, thêm lịch) phải qua màn hình xác nhận + kiểm tra quyền như thiết kế.
- Browser extension cần người dùng chủ động gửi (activeTab) — không tự động thu thập.

## Lớp tích hợp AI mở rộng (v1.1 — rebase lên mã nguồn mới nhất)

Từ bản này, AI backend chuyển sang **kiến trúc registry** để tích hợp AI tương lai:

| Thành phần | File | Công dụng |
|---|---|---|
| Provider registry | `src/core/server/ai/providers/` | Thêm bộ máy AI = 1 file + 1 dòng đăng ký |
| Provider "openai-compat" | `providers/openai-compat.ts` | Mọi dịch vụ chuẩn OpenAI chạy ngay qua env `AI_COMPAT_*` (Ollama, OpenRouter, Groq, DeepSeek, LM Studio, vLLM…) — KHÔNG cần code |
| Nguồn context mở rộng | `context.ts → registerContextSource()` | Module đăng ký nguồn dữ liệu mới cho AI đọc |
| Tool mở rộng | `tools.ts → registerAiTool()` | Đăng ký tool mới cho AI gọi |
| API động | `/api/ai/settings` trả `providers[]` + `models[]` | UI tự render — thêm provider không sửa client |

**Tài liệu tích hợp đầy đủ: `docs/ai-integration-guide.md`** (kiến trúc, 3 cách thêm AI,
API, bảo mật, lộ trình streaming/RAG/voice/agent).
