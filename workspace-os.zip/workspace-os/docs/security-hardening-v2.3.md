# WOS Security Hardening v2.3

Bản vá theo review `workspace-os (4).zip` — **12 vấn đề** (4 đỏ, 5 cam, 3 vàng).
Nguyên tắc giữ nguyên như v2.1/v2.2: **không đổi UI, không thêm tính năng mới** —
chỉ đóng lỗ hổng và làm đúng transaction/validation ở biên.

## Tóm tắt 12 mục đã xử lý

| # | Vấn đề (theo review) | Mức | Cách vá |
|---|----------------------|-----|---------|
| 1 | Login không có rate-limit | 🔴 | 20 lần sai/15 phút theo IP + 10 lần sai/15 phút theo username — **chỉ đếm lần THẤT BẠI** (exceedsRate check trước, bumpRate sau khi sai) nên người dùng gõ đúng không tự khoá mình. Trả 429. |
| 2 | Google Drive OAuth thiếu `state` (CSRF) | 🔴 | `/gdrive/start` sinh state 32-byte random gắn với **sessionId** admin (TTL 10 phút, start mới đè state cũ). `/gdrive/callback` bắt buộc `consumeOAuthState()` **TRƯỚC KHI đổi code**, so sánh timing-safe, tiêu thụ đúng 1 lần (kể cả khi sai — chống dò). Kịch bản "nhét authorization code của Drive attacker" bị chặn. |
| 3 | Plugin ZIP có đường tấn công symlink | 🔴 | (a) `installPluginZip()` bỏ code kiểm riêng, dùng **CHUNG `inspectZipSafety()`** với File Manager (chặn symlink entry / zip-slip / zip-bomb / quá 3000 mục trước khi giải nén); (b) `removeAllSymlinks(tmp)` sau giải nén (giống extract); (c) asset API chuyển sang `resolvePluginAssetReal()` — **realpath**: symlink trong `plugins/<slug>/assets` trỏ ra ngoài (`/etc/passwd`) → 400. |
| 4 | Backup Restore lỗi FK Group/User | 🔴 | Trong transaction restore: `user.updateMany({ groupId: null })` **TRƯỚC** khi `deleteMany('group')` — hết cảnh FK từ chối → rollback cả batch khi hệ thống đang dùng Groups. |
| 5 | Backup DB/filesystem không đồng bộ | 🟠 | (a) Mỗi bản tar.gz Drive giờ có **`manifest.json`** (backupRunId, createdAt, sources) — DB + files được đánh version **cùng một thời điểm**; (b) **API restore toàn diện**: `POST /api/modules/sync {action:'restore', fileId}` tải tar về, pre-scan tên entry tar, snapshot DB + storage trước, swap storage qua holding-dir, áp DB transaction — **DB fail → rollback filesystem** (và ngược lại), không còn trạng thái nửa vời; (c) restore JSON trả kèm `missingFiles` (số FileNode trỏ tệp không có trên đĩa) — trung thực với admin. |
| 6 | Plugin upgrade mất plugin khi copy lỗi | 🟠 | Thứ tự mới: **filesystem trước DB** — copy pack vào `.wos_stage_*` → đẩy bản cũ sang `.wos_old_*` (rename atomic) → rename staging vào chỗ → mới update DB. DB lỗi → trả bản cũ về nguyên vẹn; cp lỗi giữa chừng → bản cũ không bao giờ bị xoá trước. |
| 7 | `handle()` trả lỗi nội bộ ra client | 🟠 | Production: lỗi không phải `ApiError` → **"Lỗi hệ thống"** (che Prisma/filesystem/Node — có thể lộ `/opt/workspace-os/storage/...`). Dev hoặc `WOS_DEBUG_ERRORS=1` → trả message gốc để gỡ rối. Mọi lỗi nghiệp vụ có chủ ý (validation, ZIP chặn, Google API...) đã chuyển sang `ApiError` (module lá `api-error.ts` — không tạo vòng import) nên người dùng vẫn thấy thông điệp tiếng Việt. |
| 8 | install.sh chấp nhận Node 18 (Next 16 cần ≥ 20.9) | 🟠 | So sánh **đầy đủ phiên bản** `node_at_least "20.9.0"` (sort -V) thay vì chỉ major ≥ 18. Node cũ → tự cài Node 22 hệ thống. |
| 9 | Không có lockfile trong zip | 🟠 | Zip giờ kèm **cả hai**: `bun.lock` (đường chính — bun install) và **`package-lock.json`** (fallback npm → `npm ci` cài đúng version đã khoá). Trên zip (4) trước đây: install.sh copy bun.lock nhưng zip không có file nào. |
| 10 | Task gán được projectId của user khác | 🟡 | POST/PATCH tasks + POST calendar: validate `project.ownerId === session.id` — không thì 404. |
| 11 | Wiki parentId chưa kiểm ownership/cycle | 🟡 | `assertWikiParent()` dùng chung (module `wiki-parent.ts`): cha phải **cùng owner + chưa xoá**; leo cây cha từ ứng viên, gặp chính trang đang dời → 400 "Không thể lồng trang vào chính nó hoặc con của nó" (chống A→B→C→A). |
| 12 | Invalid Date → Prisma 500 | 🟡 | Helper `parseDate` / `parseDateOrNull` trong api.ts — Invalid Date → **400** kèm tên trường ("Hạn chót không hợp lệ"...). Áp cho: calendar (start/end/recurrenceEnd, GET from/to), tasks (dueAt/reminderAt), projects (startDate/dueDate/expectedEndDate/actualEndDate, milestone dueAt). |

## Kiến trúc mới đáng chú ý

```
src/core/server/api-error.ts     ← ApiError tách module lá (chống vòng import:
                                   api → user-data → storage → api-error)
src/core/server/backup-restore.ts ← engine restore DÙNG CHUNG:
                                   validateBackupPayload / applyBackupPayload
                                   (transaction + Group-FK fix + giữ secret)
                                   snapshotDbFile / snapshotStorageTree
                                   restoreStorageTree / rollbackStorageTree
                                   exportPayloadFromSqlite (python3, BOOLEAN→bool,
                                   DATETIME epoch-ms → ISO)
src/core/server/wiki-parent.ts   ← guard cây wiki (ownership + cycle)
storage.ts: inspectZipSafety()   ← pre-scan ZIP dùng CHUNG (files + plugin)
             removeAllSymlinks() ← export cho plugin install
sync.ts: createOAuthState / consumeOAuthState — OAuth CSRF state
         restoreDriveBackup() — restore DB + files ĐỒNG THỜI có rollback
```

## API mới (không có UI — gọi qua curl)

```
POST /api/modules/sync            (admin)
     { "action": "restore", "fileId": "<Drive file id>" }
→ { restored, filesRestored, legacyBackup, missingFiles, snapshotDb, snapshotStorage }
```

Trả lời chi tiết:
- `filesRestored: true` — tar có `files/` → storage đã được swap (holding + rollback).
- `legacyBackup: true` — bản cũ không có manifest.json (vẫn restore được).
- `snapshotDb` / `snapshotStorage` — đường dẫn snapshot pre-restore nằm trong
  `db/snapshots/` (DB: python-sqlite backup; storage: tar.gz, bỏ qua nếu > 8GB).
- KHÔNG bao giờ restore Users/Session/PasswordReset; secret hiện tại
  (auth_secret, client_secret, refresh_token) được GIỮ lại xuyên qua restore.

## Filesystem layout thêm

- `<STORAGE_ROOT>/plugins/.wos_stage_*`, `.wos_old_*` — staging swap plugin
  (tiền tố `.` → `scanPluginsDir()` tự bỏ qua).
- `<cha-của-storage>/wos-restore-tmp/` — thư mục làm việc khi restore từ Drive
  (tải tar + giải nén + holding; tự dọn trong `finally`).
- `db/snapshots/pre-restore-*.db` và `pre-restore-*-storage.tar.gz`.

## Biến môi trường mới

| Biến | Mặc định | Ý nghĩa |
|------|----------|---------|
| `WOS_DEBUG_ERRORS` | (rỗng) | `=1` trả chi tiết lỗi nội bộ cho client khi production (CHỈ dùng gỡ rối) |

Các biến v2.2 (`WOS_TRUST_PROXY`, `WOS_MAX_FILE_MB`, `WOS_RESET_CODE_IN_LOG`)
giữ nguyên ý nghĩa — xem `docs/security-hardening-v2.2.md`.

## Kiểm chứng (máy dev, theo worklog)

- `tsc --noEmit` sạch; eslint sạch (toàn bộ file đụng đến).
- `test-symlink.ts` 7/7, `test-zip-hardening.ts` 8/8, `test-multipart.ts` PASS.
- `e2e-test.sh` **53/53 PASS** — gồm 7 section mới (20–26):
  login rate-limit (lần sai 11 → 429, login đúng vẫn 200), restore khi User còn
  groupId (FK), wiki cycle, task projectId chéo user → 404, invalid date → 400,
  plugin zip symlink bị chặn + asset realpath chặn `/etc/passwd`, OAuth state
  (đúng được nhận / sai bị chặn / dùng lại lần 2 bị chặn).
- `next build` production PASS.

## Lưu ý vận hành

- **Login rate-limit là bucket trong RAM** (sliding window 15 phút): restart
  service = xoá hết counter. Chạy e2e 3 lần liên tiếp trong 15 phút có thể
  khoá tạm IP `direct` (khoá 15 phút, không vĩnh viễn).
- Restore từ Drive nên chạy lúc **ít người dùng** — upload trong lúc restore
  có thể rơi vào cây vừa bị thay. Một restore/backup chạy tại một thời điểm
  (cờ globalThis, trả 409 nếu chồng nhau).
- Bản backup Drive cũ (không manifest) vẫn restore được nhưng nên tạo bản mới
  ngay sau khi nâng cấp lên v2.3.
- Trên Orange Pi: cần `python3` (có sẵn trên Debian/Ubuntu) cho snapshot DB và
  đọc `db/wos.db` trong tar khi tar không có `config/wos-export.json`.
