# Workspace OS (WOS)

> **Hệ điều hành làm việc trên nền Web** — mọi chức năng là một **Module**, như app trên macOS.
> Chạy hoàn toàn trên Orange Pi (ARM64) qua trình duyệt. **Không còn VNC/Desktop ảo** — đây là gói thuần web app.

```
Workspace OS
├─ Core Engine      (Auth, Permission, DB, API Gateway, Event Bus,
│                     Notification Center, Search, Theme, Widget, Module Manager, Settings)
├─ Module Manager   (bật/tắt từng app — Desktop/Dock/Settings/Widget tự cập nhật)
├─ Desktop macOS    (Window Manager: cửa sổ kéo/resize, traffic lights, Launchpad,
│                     icon desktop, widget desktop, right-click menu, Alt+Tab,
│                     khóa màn hình, đổi hình nền, kéo-thả tệp từ PC thật)
├─ Dashboard        (3 vùng widget động — dựng từ Widget Engine, mở như app)
├── Projects · Tasks · Calendar · **Công Việc Tuần (Weekly)** · Notes · Wiki · Files
├── Timeline · Reports · Activity · Notifications
├── Global Search    (Ctrl+K — mỗi module tự đăng ký dữ liệu)
├── Sync & Backup    (Google Drive OAuth trong app — không cần commandline)
└── Administration · Settings
```

Mọi module **không phụ thuộc nhau** — giao tiếp qua **Event Bus**. Thêm module mới = thêm 1 manifest + UI riêng, không sửa lõi.

---

## 1. Cài đặt nhanh (3 lệnh)

```bash
# 1. Giải nén
unzip workspace-os.zip && cd workspace-os

# 2. Cài tự động (Node 22 + Bun + swap + build + seed + systemd)
sudo bash install.sh

# 3. Mở trình duyệt
#    http://<ip-orangepi>:3068
```

`install.sh` hỏi mật khẩu admin. Enter để bỏ trống → sinh mật khẩu random và **in ra ở bước cuối** — lưu lại.

> Yêu cầu: Orange Pi OS / Debian 12 / Ubuntu 22.04+ (aarch64/x86_64), có Internet. Lần cài đầu mất ~10–20 phút (script tự tạo swap 2GB để build không hết RAM).

## 2. Tuỳ chọn cài lại

**Chạy lại `install.sh` lúc nào cũng được** — script tự dừng service cũ, xoá thư mục cài và cài lại từ đầu:

```bash
sudo bash install.sh                 # cài lại từ đầu
sudo bash install.sh --keep-data     # GIỮ storage/ + db/ (file người dùng)
sudo bash install.sh --yes           # non-interactive (mật khẩu random)
sudo bash install.sh --admin-password 'mk-cua-ban'
sudo bash install.sh --dir /opt/wos  # cài chỗ khác
```

| Tuỳ chọn | Ý nghĩa |
|---|---|
| `--yes` | Non-interactive, mật khẩu random tự sinh |
| `--keep-data` | Giữ `storage/` + `db/` khi cài lại |
| `--admin-user` / `--admin-password` | Đặt tài khoản admin |
| `--dir <đường dẫn>` | Thư mục cài (mặc định `/opt/workspace-os`) |

Gỡ hoàn toàn: `sudo bash uninstall.sh` (thêm `--keep-data` để giữ file).

## 3. Quản lý dịch vụ

| Lệnh | Chức năng |
|---|---|
| `systemctl status wos` | Trạng thái app chính (Next.js) |
| `systemctl status wos-terminal` | Trạng thái Terminal service (bash/PTY) |
| `journalctl -u wos -f` | Log realtime app chính |
| `journalctl -u wos-terminal -f` | Log Terminal service |
| `sudo systemctl restart wos` | Khởi động lại app chính |
| `ss -ltnp \| grep 3068` | Kiểm tra cổng (đổi cổng: `APP_PORT=4000 sudo bash install.sh`) |

Chạy lại install.sh mà không chỉ định cổng → **giữ nguyên cổng lần trước** (đọc từ `.env` cũ).

Terminal service chạy ở cổng `APP_PORT + 1` (mặc định 3069) qua path `/terminal-ws` do
Next.js rewrite chuyển tiếp — Cloudflare Tunnel chỉ cần map MỘT cổng (3068).
Nếu không build được `node-pty` (thiếu `build-essential`), Terminal tự chạy chế độ
pipes `bash -i` — vẫn gõ lệnh được, chỉ thiếu màu/tab-completion.
Cài build tools: `sudo apt install -y build-essential python3` rồi chạy lại `install.sh`.

## 4. Tính năng theo module

### 🖥️ WOS 3.0 — Web PC (Application System V3)

Phiên bản 3 chuyển WOS từ "mô phỏng desktop" thành **máy PC trên nền web**:

| App hệ thống | Tính năng |
|---|---|
| **Application System** | Registry app kiểu Launch Services: mọi tệp double-click tự mở đúng app (PDF→Documents, video→Media, text→Viewer) · `openFile()` / `openUrl()` là điểm vào duy nhất |
| **Window Manager V2** | **Snap** kiểu Windows/macOS: kéo sát biên trái/phải = 50%, lên đỉnh = maximize, 4 góc = 1/4 màn hình (có overlay preview) · kéo cửa sổ maximized thoát khỏi vùng và về kích thước cũ · **Window Persistence**: tắt trình duyệt / đăng nhập lại → mọi cửa sổ mở lại đúng vị trí — kích thước — route (lưu localStorage theo tài khoản, quá 7 ngày không phục hồi) |
| **Trình duyệt** | Browser app TRONG cửa sổ WOS: nhiều tab, thanh địa chỉ + tìm kiếm (DuckDuckGo/Google/Bing), back/forward/reload, catalog 12 ứng dụng web ở trang mới, iframe sandbox — phát hiện trang chặn nhúng (X-Frame-Options) và gợi ý mở tab ngoài |
| **Terminal** | **bash THẬT chạy trên máy** (PTY qua node-pty) — màu, tab-completion, Ctrl+C… · xterm.js full · mỗi cửa sổ 1 phiên shell · token ngắn hạn 10 phút đối chiếu ngược về Next (đăng xuất = terminal tắt) · giới hạn 3 phiên/người, 8 phiên/máy, tự tắt sau 30 phút idle |
| **System Monitor** | Activity Monitor: đồ thị CPU (tổng + từng nhân) / RAM / đĩa / mạng realtime (poll 2s, đọc /proc) · bảng tiến trình với CPU%/RSS/user · **admin kết thúc tiến trình** (SIGTERM, chặn tự sát) · nhiệt độ SoC (Orange Pi) |
| **Documents** | Document Engine: **PDF** (pdf.js — zoom/xoay/chuyển trang) · **DOCX** (docx-preview — trang giấy như Word) · **XLSX/XLS/CSV** (SheetJS — nhiều sheet, header nổi, xem giá trị cell) · **PPTX** (trích xuất slide, chế độ Present) |
| **Media Player** | Video/audio với điều khiển tự vẽ kiểu macOS: play/pause, seek, volume, tốc độ 0.5–2×, fullscreen — codec không hỗ trợ (mkv/avi) gợi ý tải về mở VLC |
| **Clipboard PC** | **Ctrl+C / Ctrl+X / Ctrl+V cho TỆP** trong Files + Desktop (copy = sao chép, cut = di chuyển) · tự đổi tên đích trùng ("bản sao") · dán text thành tệp .txt mới |
| **Downloads** | Trình quản lý tải xuống: tiến trình % theo stream, huỷ/tải lại, mở tệp/thư mục sau khi tải · chỉ báo trên thanh menu |
| **Web App Launcher** | Chuột phải desktop → **Thêm ứng dụng web** — Gmail/Drive/YouTube/ChatGPT… hiện thành icon desktop (lưu theo tài khoản), click mở trong app Trình duyệt |
| **System API** | `/api/system/info · resources · processes` — read-only /proc, có thể tắt app System Monitor qua Module Manager nếu không muốn user xem |
| **Settings → Hệ thống** | "About This Computer": board/CPU/RAM/kernel/uptime + tài nguyên live + lối nhanh tới app hệ thống |

> Kiến trúc hướng tới Orange Pi 3B 2GB: Next.js chỉ phục vụ UI/API/storage; Terminal là
> service Node riêng (cổng 3069) giới hạn RAM 250M; Browser là iframe nhẹ — lớp
> "Remote Browser" (Chromium stream từ máy khác) sẽ cắm thêm ở giai đoạn sau.

### Module nghiệp vụ

| Module | Tính năng chính |
|---|---|
| **Dashboard** | 3 vùng widget: Top (lời chào, thời tiết, disk, thông báo) / Center (timeline, task, mini calendar, dự án, tệp gần đây, quick note, wiki) / Bottom (activity, statistics, AI summary, tiến độ dự án) |
| **Tasks** | List / Kanban (kéo-thả) / Timeline / Archive · ưu tiên, nhãn, deadline, reminder, lặp lại, subtask, bình luận, lịch sử |
| **Calendar** | Day / Week / Month / Year · sự kiện lặp lại, danh mục màu, nhắc trước, ngày lễ VN |
| **Notes** | Markdown + preview live · ghim, nhãn, thùng rác |
| **Wiki** | Cây trang lồng nhau · **trình soạn thảo rich text** (đậm/nghiêng/gạch chân, tiêu đề, font chữ + cỡ, màu chữ + tô nền, căn lề, danh sách, **bảng**, link, ảnh, trích dẫn, code) · phiên bản tự động · **Xem thử phiên bản cũ + so sánh diff** với bản hiện tại · khôi phục |
| **Files** | Upload stream (kéo-thả), preview (ảnh/video/pdf/audio/text/md), **lightbox xem ảnh toàn màn hình** (zoom/xoay/chuyển ảnh), **right-click menu macOS** (mở/tải/đổi tên/di chuyển/chia sẻ/thông tin/xoá), **tìm kiếm toàn hệ thống** (đệ quy mọi thư mục), **sắp xếp** (tên/dung lượng/sửa đổi/**xem gần nhất**), tạo tệp/thư mục, rename, move, copy, nén/giải nén zip, yêu thích, thùng rác, share link công khai, quota |
| **Projects** | Thẻ dự án + tiến độ, **chi tiết dự án mở thành CỬA SỔ RIÊNG tồn tại độc lập như app chính**, milestone, thành viên, **thêm việc ngay trong dự án (đồng bộ app Tasks)**, ngày bắt đầu/dự kiến xong/kết thúc thực tế + timeline trực quan, liên kết Tasks/Calendar |
| **Công Việc Tuần** | **Quy trình** cài sẵn (bước × số lot × hàng/lot = khối lượng, điều kiện pha hóa chất trước N ngày) → thêm quy trình vào ngày = tự sinh danh sách việc chi tiết · tick hoàn thành / **pass kèm lý do** · **thêm lần pha** linh hoạt · **ngày Offline auto-pass** · thống kê từng ngày · **widget Timeline trên desktop cảnh báo đỏ sau 16h** |
| **Timeline** | Dòng thời gian mọi hoạt động — đọc từ Event Bus · **bấm dòng để copy** · **dọn dẹp dữ liệu** (giữ 7/30/90 ngày hoặc xoá tất cả) |
| **Notifications** | Read/Unread/Archive · toast + browser notification · nhắc việc |
| **Reports** | Biểu đồ 14/30/90 ngày, phân bổ ưu tiên, tiến độ dự án, storage · xuất **CSV / Excel / JSON** + In ra PDF |
| **Activity** | Log đầy đủ, lọc theo người dùng / module / hành động / thời gian · **bấm dòng để copy** · **dọn dẹp dữ liệu** (giữ 7/30/90 ngày hoặc xoá tất cả) |
| **Search** | **Ctrl+K** — tìm mọi module (task, note, wiki, file, dự án, activity) |
| **Administration** | Users / Groups / Roles (admin-member-viewer) / matrix phân quyền |
| **Settings** | General, **Appearance (hình nền + tuỳ biến icon/màu mọi app)**, **Sync & Backup (Google Drive)**, Localization, Notification, Storage, Security (đổi mật khẩu + session), Backup (xuất/nhập JSON), **Modules** (Module Manager) |

### Kiến trúc module chuẩn

Mỗi module đăng ký **manifest** (id, icon, màu, quyền, events, widgets, settings) và phải hỗ trợ: Menu, Dashboard Widget, Settings riêng, Permissions, API độc lập, Events, Search Provider, Notifications, Activity Log, Backup, Theme sáng/tối. Tắt module trong Settings → Modules → cửa sổ app tự đóng, Desktop/Dock/Settings/widget tự ẩn ngay.

### Giao diện desktop macOS (v2)

Sau khi đăng nhập bạn thấy **màn desktop** — không còn kiểu web sidebar:

- **Menubar 34px** trên cùng: logo, tên workspace, tên app đang focus, CPU/RAM, tìm kiếm (⌘K), thông báo, theme, Module Manager, user, đồng hồ.
- **Cửa sổ app thật sự**: mỗi app mở trong cửa sổ riêng — kéo theo titlebar, resize góc phải-dưới, double-click titlebar phóng to, **3 nút traffic lights** (đóng / thu nhỏ / phóng to) đúng chuẩn macOS, cửa sổ mất focus tự mờ nút.
- **Dock** dưới cùng: icon các app đang bật, chấm chỉ báo đang chạy; click = mở / đưa lên trước / thu nhỏ; **right-click** dock có menu riêng.
- **Icon desktop** cột phải: click mở app ngay.
- **Launchpad**: nút grid trên dock (hoặc F4) → lưới toàn bộ app + tìm kiếm.
- **Right-click desktop**: menu macOS riêng (Tạo mới thư mục/tệp, **Thêm Widget**, Launchpad, Dashboard, **Đổi hình nền**, **Tuỳ biến icon app**, tải tệp lên, sắp xếp cửa sổ, thu nhỏ/đóng tất cả, theme, khóa màn hình) — **menu chuột phải mặc định của trình duyệt bị chặn** trong môi trường WOS (vẫn giữ nguyên cho ô nhập liệu).
- **Kéo-thả tệp từ PC thật vào desktop**: overlay hiện tiến độ %, tệp vào thẳng thư mục **Desktop** của module Files (qua Event Bus — cửa sổ Files + icon desktop tự refresh).

### Nâng cấp v2.1 — Desktop hoàn chỉnh như PC thật

- **Widget trên desktop** (kiểu macOS): right-click → *Thêm Widget* → chọn **Ghi chú nhanh** · **Thời tiết** (tự tìm thành phố, open-meteo) · **Đồng hồ & Lịch mini** · **CPU/RAM/Đĩa** · **Việc hôm nay** (tick luôn) · **Timeline công việc tuần**. Widget **kéo-di chuyển, resize, xoá** được; vị trí lưu theo trình duyệt.
- **Thư mục Desktop**: right-click desktop → *Tạo mới → Thư mục/Tệp văn bản*; icon file/thư mục thật hiện trên desktop, **kéo thả đổi vị trí**, double-click mở, right-click đủ thao tác (đổi tên/xoá/chia sẻ/thông tin) — quản lý tiếp trong app Files.
- **Alt + Tab** chuyển cửa sổ như PC: giữ Alt, bấm Tab vòng lặp, thả Alt để chọn (overlay hiện thumbnail + tên cửa sổ).
- **Khóa màn hình Ctrl + Shift + Z** (hoặc nút khóa trên menubar / menu user): phủ mờ toàn màn + đồng hồ lớn, mở lại bằng mật khẩu tài khoản.
- **Đổi hình nền**: 10 gradient + màu dựng sẵn, **tải ảnh riêng lên** hoặc dán URL — lưu lại cho mọi lần đăng nhập (cũng đổi nhanh bằng right-click desktop).
- **Tuỳ biến icon + màu mọi app** (Settings → Appearance): chọn emoji từ thư viện, tải ảnh PNG/SVG làm icon, đổi màu nhận diện từng app — Dock/Desktop/Launchpad/titlebar đổi ngay.
- **Notification popover chuẩn**: panel kính mờ neo đúng góc phải, responsive mobile (không còn lệch/che nội dung).
- **Chi tiết dự án = cửa sổ riêng**: bấm thẻ dự án mở cửa sổ `Projects — <tên>` tồn tại độc lập trên desktop như app chính; mở app khác không tự đóng; sub-tab (Milestones/Tasks/Members/Calendar) giữ nguyên trạng thái.
- **Sync & Backup Google Drive** (Settings → Sync & Backup): tự tạo OAuth client ngay trong UI (redirect URI có sẵn để copy), xác thực bằng 1 cú click — **không cần rclone/commandline**. Chọn nguồn (DB SQLite + tệp storage + cấu hình), lịch tự động hằng ngày 02:00 / hằng tuần T2 03:00, giữ N bản, nén tar.gz (kèm `manifest.json` đánh version DB + tệp cùng thời điểm) upload resumable, xem lịch sử + tải bản sao lưu về. **Khôi phục toàn diện v2.3**: `POST /api/modules/sync {"action":"restore","fileId":"<id>"}` — trả lại CẢ database lẫn toàn bộ tệp storage cùng lúc (snapshot trước khi chạy + rollback nếu lỗi giữa đường; chi tiết `docs/security-hardening-v2.3.md`).

**Phím tắt:** `Ctrl+K` tìm kiếm · `Alt+Tab` chuyển cửa sổ · `Ctrl+Shift+Z` khóa màn hình · `F4`/nút grid Launchpad · `Esc` đóng menu/overlay · **`Ctrl+C/X/V` clipboard tệp trong Files** · `←/→` chuyển trang/trang slide · `Space` play/pause media · `Esc` thoát Present.

## 5. Cấu trúc dự án

```
workspace-os/
├── install.sh / uninstall.sh     # Cài tự động cho Orange Pi (2 service)
├── systemd/wos.service           # Next.js standalone (MemoryMax 1000M)
├── systemd/wos-terminal.service  # Terminal service PTY (MemoryMax 250M)
├── mini-services/terminal-service/  # Node + socket.io + node-pty — bash thật
├── prisma/schema.prisma          # SQLite — metadata mọi module
├── scripts/seed.mjs              # admin + dữ liệu demo
├── public/pdf.worker.min.mjs     # worker pdf.js cho Document Engine
├── src/
│   ├── core/server/              # CORE ENGINE: auth, api gateway, event bus,
│   │                             #   module registry, search engine, settings,
│   │                             #   storage, sysinfo, system-monitor (/proc)
│   ├── core/client/              # WOS store, window manager V2 (snap+persistence),
│   │                             #   applications.ts (App Registry + file router),
│   │                             #   clipboard, downloads, session-store
│   ├── components/wos/           # Shell desktop macOS: Login, MenuBar, Desktop,
│   │                             #   WindowFrame (snap/maximize/SnapOverlay), Dock,
│   │                             #   Launchpad, DesktopIcons (web app shortcuts)
│   ├── apps/                     # APP HỆ THỐNG V3: browser, terminal, monitor,
│   │                             #   downloads, document (PDF/DOCX/XLSX/PPTX), media
│   └── modules/                  # 13 module nghiệp vụ — mỗi module: pages/ + widgets
└── .env.example
```

## 6. Bảo mật

- Mật khẩu **scrypt hash**; session HMAC-SHA256 lưu DB (thu hồi được — Settings → Security).
- Phân quyền 3 vai trò: admin (toàn quyền) / member (đọc+ghi) / viewer (chỉ đọc).
- Upload stream thẳng xuống đĩa, chống path-traversal tuyệt đối, SQLite chỉ lưu metadata.
- Share link tệp có hạn mức tải và có thể tạo/huỷ bất cứ lúc nào.

## 7. Xử lý sự cố

| Hiện tượng | Cách xử lý |
|---|---|
| Build bị treo/hết RAM | Script tự tạo swap 2GB. Kiểm `swapon --show`, chạy lại `install.sh` |
| Cổng 3068 bị chiếm | `ss -ltnp \| grep 3068` → đổi `APP_PORT=4000 sudo bash install.sh` |
| Không vào được web | `journalctl -u wos -e` xem log |
| Quên mật khẩu | Màn login → "Quên mật khẩu?" (mã reset hiện ra + ghi trong log server), hoặc chạy lại `install.sh` |
| Nén/giải nén không chạy | `sudo apt install zip unzip` |
| Truy cập ngoài LAN | Cloudflare Tunnel map cổng 3068 — không cần mở port router |

## 8. Lộ trình

Nền tảng module hoá này cho phép cắm thêm các app tương lai — **AI Assistant, Linux Monitor, Stock Dashboard**… — mà không phải đập đi xây lại: chỉ cần manifest + thư mục `src/modules/<app-mới>/`.
