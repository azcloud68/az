#!/usr/bin/env bash
# ============================================================================
#  WORKSPACE OS (WOS) — CÀI ĐẶT TỰ ĐỘNG CHO ORANGE PI / DEBIAN / UBUNTU
# ----------------------------------------------------------------------------
#  Hệ điều hành làm việc trên nền Web — mọi chức năng là một Module.
#  KHÔNG còn VNC/Desktop ảo — gói này thuần web app (Next.js standalone).
#
#  Cách dùng:
#     sudo bash install.sh                       # cài tương tác (hỏi mật khẩu)
#     sudo bash install.sh --yes                 # non-interactive (mật khẩu random)
#     sudo bash install.sh --admin-password X    # đặt sẵn mật khẩu admin
#     sudo bash install.sh --keep-data           # giữ file trong storage/
#     sudo bash install.sh --dir /opt/wos        # cài vào thư mục khác
#
#  Sau khi cài:  http://<ip-orangepi>:3068
# ============================================================================
set -euo pipefail

# ------------------------------------------------------------------ cấu hình
INSTALL_DIR="${WOS_DIR:-/opt/workspace-os}"
# Đặt flag TRƯỚC khi gán mặc định — nếu không, "giữ nguyên cổng lần trước"
# bên dưới không bao giờ chạy vì APP_PORT luôn có giá trị (3068)
APP_PORT_SET=0; [ -n "${APP_PORT:-}" ] && APP_PORT_SET=1
APP_PORT="${APP_PORT:-3068}"
ADMIN_USER="${ADMIN_USER:-admin}"
ADMIN_PASSWORD="${ADMIN_PASSWORD:-}"
KEEP_DATA=0
ASSUME_YES=0

while [ $# -gt 0 ]; do
  case "$1" in
    --yes)            ASSUME_YES=1 ;;
    --keep-data)      KEEP_DATA=1 ;;
    --admin-user)     ADMIN_USER="${2:-}"; shift ;;
    --admin-password) ADMIN_PASSWORD="${2:-}"; shift ;;
    --dir)            INSTALL_DIR="${2:-}"; shift ;;
    *) echo "Tuỳ chọn không rõ: $1" >&2; exit 1 ;;
  esac
  shift
done

# ------------------------------------------------------------------ tiện ích
C_G='\033[32m'; C_Y='\033[33m'; C_B='\033[36m'; C_R='\033[31m'; C_0='\033[0m'
step()  { echo -e "\n${C_B}▶ $*${C_0}"; }
ok()    { echo -e "  ${C_G}✔${C_0} $*"; }
warn()  { echo -e "  ${C_Y}!${C_0} $*"; }
fail()  { echo -e "\n${C_R}✖ LỖI: $*${C_0}" >&2; exit 1; }
hr()    { echo -e "${C_B}────────────────────────────────────────────────────────${C_0}"; }

trap 'fail "Cài đặt bị gián đoạn ở dòng $LINENO khi chạy: $BASH_COMMAND — chạy lại install.sh để cài lại từ đầu."' ERR

rand_hex()  { head -c 16 /dev/urandom | od -An -tx1 | tr -d ' \n'; }
rand_pass() { head -c 64 /dev/urandom | tr -dc 'a-zA-Z0-9' | head -c 10; }
env_esc()   { printf "%s" "$1" | sed "s/'/'\\\\''/g"; }

RUN_USER=""
USER_HOME=""
as_user() {
  if command -v runuser >/dev/null 2>&1; then
    runuser -u "$RUN_USER" -- env HOME="$USER_HOME" "$@"
  else
    sudo -u "$RUN_USER" env HOME="$USER_HOME" "$@"
  fi
}

# Giữ nguyên cổng lần cài trước nếu user không chỉ định
if [ -f "$INSTALL_DIR/.env" ]; then
  if [ "$APP_PORT_SET" != 1 ]; then
    OLD_PORT="$(sed -n "s/^PORT=//p" "$INSTALL_DIR/.env" | tail -1 | tr -d "'\"")"
    case "$OLD_PORT" in ''|*[!0-9]*) ;; *) APP_PORT="$OLD_PORT"; ok "Giữ nguyên cổng lần trước: $APP_PORT";; esac
  fi
fi

hr; echo -e "${C_G}  WORKSPACE OS — CÀI ĐẶT CHO ORANGE PI${C_0}"; hr
echo "  Thư mục cài : $INSTALL_DIR"
echo "  Cổng        : $APP_PORT"
echo "  Chế độ      : $([ $KEEP_DATA = 1 ] && echo 'GIỮ storage/ (--keep-data)' || echo 'xóa sạch lần cài trước')"
hr

[ "$(id -u)" = "0" ] || fail "Phải chạy bằng sudo/root:  sudo bash install.sh"

case "$(uname -m)" in
  aarch64|x86_64) ok "Kiến trúc CPU: $(uname -m)" ;;
  *) warn "Kiến trúc $(uname -m) chưa được thử — tiếp tục" ;;
esac

if [ -n "${SUDO_USER:-}" ] && [ "${SUDO_USER:-}" != "root" ]; then
  RUN_USER="$SUDO_USER"
else
  RUN_USER="$(awk -F: '$3 >= 1000 && $3 < 65534 && $7 !~ /nologin|false/ {print $1; exit}' /etc/passwd)"
fi
[ -n "$RUN_USER" ] || RUN_USER="root"
# Lấy home directory của user chạy dịch vụ (awk an toàn hơn cut, có fallback)
USER_HOME="$(getent passwd "$RUN_USER" 2>/dev/null | awk -F: '{print $6; exit}' || true)"
[ -n "$USER_HOME" ] || USER_HOME="$(awk -F: -v u="$RUN_USER" '$1 == u {print $6; exit}' /etc/passwd 2>/dev/null || true)"
[ -n "$USER_HOME" ] || USER_HOME="/root"
ok "User chạy dịch vụ: $RUN_USER (home: $USER_HOME)"

# Kiểm tra cổng bị chiếm
if ss -ltn 2>/dev/null | grep -q ":${APP_PORT} "; then
  fail "Cổng $APP_PORT đang bị chiếm. Xem: ss -ltnp | grep $APP_PORT — hoặc đổi: APP_PORT=4000 sudo bash install.sh"
fi

# Hỏi mật khẩu admin
GENERATED_PW=0
if [ -z "$ADMIN_PASSWORD" ] && [ "$ASSUME_YES" != 1 ]; then
  read -rsp "Mật khẩu admin (Enter = sinh ngẫu nhiên): " ADMIN_PASSWORD; echo ""
fi
if [ -z "$ADMIN_PASSWORD" ]; then
  ADMIN_PASSWORD="$(rand_pass)"
  GENERATED_PW=1
fi

# ----------------------------------------------------------------------------
step "1/8 — Công cụ hệ thống (curl, git, zip, build-essential)"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq 2>/dev/null || warn "apt update lỗi (có thể offline) — tiếp tục"
apt-get install -y -qq curl git zip unzip build-essential 2>/dev/null \
  || warn "Không cài được gói apt — kiểm tra mạng"

# Swap 2GB cho máy RAM thấp (build Next.js cần RAM)
SWAP_KB=$(free -k 2>/dev/null | awk '/^Swap:/{print $2}' || echo 0)
if [ "${SWAP_KB:-0}" -lt 1500000 ]; then
  if [ ! -f /swapfile_wos ]; then
    step "Tạo swap 2GB cho lần build đầu"
    dd if=/dev/zero of=/swapfile_wos bs=1M count=2048 status=none
    chmod 600 /swapfile_wos
    mkswap /swapfile_wos >/dev/null
    swapon /swapfile_wos 2>/dev/null || warn "Không bật được swap (đã có?)"
    grep -q swapfile_wos /etc/fstab || echo '/swapfile_wos none swap sw 0 0' >> /etc/fstab
    ok "Swap 2GB đã thêm"
  else
    swapon /swapfile_wos 2>/dev/null || true
    ok "Swap đã có sẵn"
  fi
else
  ok "Đã có đủ swap (${SWAP_KB}KB)"
fi

# Node.js — Next.js 16 yêu cầu >= 20.9.0 (đủ mới VÀ chạy được bởi RUN_USER;
# node nằm trong /root/.nvm sẽ hỏng service). So sánh ĐẦY ĐỦ phiên bản (vd 20.9.0),
# không chỉ major — node 18/20.8 là KHÔNG ĐỦ cho next@16.
NODE_VER_NOW="$(node -v 2>/dev/null | sed 's/^v//' | tr -d ' ')"
node_at_least() {
  # $1 = phiên bản tối thiểu (vd 20.9.0); đúng khi NODE_VER_NOW >= $1
  [ -n "$NODE_VER_NOW" ] || return 1
  [ "$(printf '%s\n' "$1" "$NODE_VER_NOW" | sort -V | head -n1)" = "$1" ]
}
NODE_OK=0
if node_at_least "20.9.0"; then
  NODE_OK=1
  if [ "$RUN_USER" != "root" ] && ! as_user test -x "$(command -v node)" 2>/dev/null; then
    warn "Node tại $(command -v node) không dùng được bởi $RUN_USER — cài Node 22 hệ thống"
    NODE_OK=0
  fi
else
  if [ -n "$NODE_VER_NOW" ]; then
    warn "Node $NODE_VER_NOW quá cũ cho Next.js 16 (cần >= 20.9.0) — cài Node 22 hệ thống"
  fi
fi
if [ "$NODE_OK" != 1 ]; then
  step "Cài Node.js 22 (nodesource)"
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash - >/dev/null 2>&1 \
    || warn "nodesource lỗi — thử node có sẵn"
  apt-get install -y -qq nodejs 2>/dev/null || warn "Không cài được nodejs"
fi
ok "Node: $(node -v 2>/dev/null || echo 'KHÔNG CÓ') tại $(command -v node 2>/dev/null || echo '?')"

# Bun runtime (tuỳ chọn, nhanh hơn npm) — PHẢI chạy được bởi RUN_USER
# (bun cài cho root nằm trong /root/.bun sẽ Permission denied với user thường)
BUN_BIN=""
if [ -x "$USER_HOME/.bun/bin/bun" ]; then
  BUN_BIN="$USER_HOME/.bun/bin/bun"
elif command -v bun >/dev/null 2>&1; then
  BUN_BIN="$(command -v bun)"
fi
if [ -n "$BUN_BIN" ] && [ "$RUN_USER" != "root" ] && ! as_user test -x "$BUN_BIN" 2>/dev/null; then
  warn "Bun tại $BUN_BIN không dùng được bởi $RUN_USER — cài lại bun cho $RUN_USER"
  if command -v curl >/dev/null 2>&1; then
    as_user bash -c 'curl -fsSL https://bun.sh/install | bash' >/dev/null 2>&1 || true
    [ -x "$USER_HOME/.bun/bin/bun" ] && BUN_BIN="$USER_HOME/.bun/bin/bun"
  fi
  as_user test -x "$BUN_BIN" 2>/dev/null || BUN_BIN=""
fi
ok "Bun: ${BUN_BIN:-không dùng (fallback npm)}"

# ----------------------------------------------------------------------------
step "2/8 — Dừng + dọn lần cài trước"
systemctl stop wos 2>/dev/null || true
systemctl disable wos 2>/dev/null || true
sleep 1
if [ -d "$INSTALL_DIR" ] && [ "$KEEP_DATA" = 1 ]; then
  warn "Giữ storage/ + db/ theo --keep-data"
  mkdir -p /tmp/wos_keep
  [ -d "$INSTALL_DIR/storage" ] && cp -r "$INSTALL_DIR/storage" /tmp/wos_keep/
  [ -d "$INSTALL_DIR/db" ] && cp -r "$INSTALL_DIR/db" /tmp/wos_keep/
  rm -rf "$INSTALL_DIR"
  mkdir -p "$INSTALL_DIR"
  [ -d /tmp/wos_keep/storage ] && mv /tmp/wos_keep/storage "$INSTALL_DIR/"
  [ -d /tmp/wos_keep/db ] && mv /tmp/wos_keep/db "$INSTALL_DIR/"
  rm -rf /tmp/wos_keep
elif [ -d "$INSTALL_DIR" ]; then
  rm -rf "$INSTALL_DIR"
fi

# ----------------------------------------------------------------------------
step "3/8 — Sao chép mã nguồn"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$INSTALL_DIR"
for item in src prisma public scripts mini-services; do
  cp -r "$SCRIPT_DIR/$item" "$INSTALL_DIR/"
done
for f in package.json next.config.ts tsconfig.json tailwind.config.ts postcss.config.mjs components.json eslint.config.mjs; do
  [ -f "$SCRIPT_DIR/$f" ] && cp "$SCRIPT_DIR/$f" "$INSTALL_DIR/"
done
# Lockfile — KHOÁ version dependency khi deploy (v2.3): bun đường chính,
# npm fallback dùng package-lock.json (npm ci) — hết cảnh "mỗi lần cài một version"
[ -f "$SCRIPT_DIR/bun.lock" ] && cp "$SCRIPT_DIR/bun.lock" "$INSTALL_DIR/" || true
[ -f "$SCRIPT_DIR/package-lock.json" ] && cp "$SCRIPT_DIR/package-lock.json" "$INSTALL_DIR/" || true
mkdir -p "$INSTALL_DIR/db" "$INSTALL_DIR/storage"
chown -R "$RUN_USER:$RUN_USER" "$INSTALL_DIR"

# ----------------------------------------------------------------------------
step "4/8 — Sinh file .env"
AUTH_SECRET="$(rand_hex)$(rand_hex)"
cat > "$INSTALL_DIR/.env" <<EOF
NODE_ENV=production
PORT=$APP_PORT
HOSTNAME=0.0.0.0
DATABASE_URL='file:$INSTALL_DIR/db/custom.db'
STORAGE_ROOT='$INSTALL_DIR/storage'
AUTH_SECRET='$AUTH_SECRET'
ADMIN_USER='$ADMIN_USER'
ADMIN_PASSWORD='$(env_esc "$ADMIN_PASSWORD")'

# --- Bảo mật nâng cao (đọc docs/security-hardening-v2.2.md trước khi đổi) ---
# Chỉ tin IP từ header proxy khi server NHẬN traffic qua proxy (chống fake
# X-Forwarded-For để xoay IP lách rate limit):
#   cloudflare = sau Cloudflare Tunnel (dùng CF-Connecting-IP do edge ghi đè)
#   forwarded  = sau Caddy/nginx tự quản (lấy entry CUỐI X-Forwarded-For)
#   để trống   = không tin header nào client tự gửi (mặc định an toàn)
WOS_TRUST_PROXY=
# Giới hạn 1 tệp upload (MB) — mặc định 256, tối đa 4096
WOS_MAX_FILE_MB=256
# Ghi mã reset password vào log server (kênh tự cứu máy 1 admin):
# 1 = ghi (mặc định) | 0 = không ghi (chỉ xem mã qua Administration → Users)
WOS_RESET_CODE_IN_LOG=1

# --- Terminal service (V3): bash thật qua PTY, Next rewrite /terminal-ws ---
# Next build đọc các biến này để bật rewrite /terminal-ws -> 127.0.0.1:3069
WOS_TERMINAL_PATH=/terminal-ws
WOS_TERMINAL_PROXY=1
WOS_TERMINAL_PROXY_PORT=3069
EOF
chown "$RUN_USER:$RUN_USER" "$INSTALL_DIR/.env"
chmod 600 "$INSTALL_DIR/.env"
ok ".env đã tạo"

# ----------------------------------------------------------------------------
step "5/8 — Cài dependencies (khoá version theo lockfile)"
cd "$INSTALL_DIR"
DEPS_OK=0
if [ -n "$BUN_BIN" ]; then
  if as_user env HOME="$USER_HOME" "$BUN_BIN" install 2>&1 | tail -2; then
    DEPS_OK=1
  else
    warn "bun install lỗi — tự động chuyển sang npm"
  fi
fi
if [ "$DEPS_OK" != 1 ]; then
  if [ -f "$INSTALL_DIR/package-lock.json" ]; then
    # có lockfile → npm ci (cài ĐÚNG version đã khoá); lỗi thì mới buông xuống npm install
    as_user npm ci --no-audit --no-fund 2>&1 | tail -2 \
      || as_user npm install --no-audit --no-fund 2>&1 | tail -2 \
      || fail "Không cài được dependencies (npm) — kiểm tra kết nối mạng rồi chạy lại install.sh"
  else
    as_user npm install --no-audit --no-fund 2>&1 | tail -2 \
      || fail "Không cài được dependencies (npm) — kiểm tra kết nối mạng rồi chạy lại install.sh"
  fi
fi

# Terminal service deps (V3) — socket.io + node-pty (cần gcc/make/python3 để build;
# không build nổi thì service tự chạy chế độ pipes bash -i — vẫn dùng được, chỉ thiếu màu)
if [ -d "$INSTALL_DIR/mini-services/terminal-service" ]; then
  if as_user npm install --no-audit --no-fund --prefix "$INSTALL_DIR/mini-services/terminal-service" 2>&1 | tail -1; then
    if node -e "require('$INSTALL_DIR/mini-services/terminal-service/node_modules/node-pty')" 2>/dev/null; then
      ok "Terminal service: node-pty OK (PTY thật — màu + tab-completion)"
    else
      warn "Terminal service: node-pty không build được — sẽ chạy pipes bash -i (thiếu gcc/make?" \
           "cài: sudo apt install -y build-essential python3 rồi chạy lại install.sh)"
    fi
  else
    warn "Terminal service: cài deps lỗi — app Terminal sẽ không chạy (không chặn cài đặt chính)"
  fi
fi

# ----------------------------------------------------------------------------
step "6/8 — Database + Build production"
cd "$INSTALL_DIR"
as_user env DATABASE_URL="file:$INSTALL_DIR/db/custom.db" npx prisma db push --accept-data-loss 2>&1 | tail -1
as_user env DATABASE_URL="file:$INSTALL_DIR/db/custom.db" npx prisma generate 2>&1 | tail -1

step "Build standalone (5–15 phút trên Orange Pi — có thể chờ lâu ở bước này)"
cd "$INSTALL_DIR"
as_user npx next build 2>&1 | tail -4
[ -f "$INSTALL_DIR/.next/standalone/server.js" ] || fail "Build không ra standalone — xem log phía trên"
cp -r "$INSTALL_DIR/.next/static" "$INSTALL_DIR/.next/standalone/.next/" 2>/dev/null || true
cp -r "$INSTALL_DIR/public" "$INSTALL_DIR/.next/standalone/" 2>/dev/null || true
ok "Build xong"

# ----------------------------------------------------------------------------
step "7/8 — Seed dữ liệu ban đầu (admin + demo)"
cd "$INSTALL_DIR"
as_user env DATABASE_URL="file:$INSTALL_DIR/db/custom.db" STORAGE_ROOT="$INSTALL_DIR/storage" \
  ADMIN_USER="$ADMIN_USER" ADMIN_PASSWORD="$ADMIN_PASSWORD" node scripts/seed.mjs

# ----------------------------------------------------------------------------
step "8/8 — Systemd services: wos + wos-terminal"
NODE_BIN="$(command -v node)"
sed -e "s|__DIR__|$INSTALL_DIR|g" -e "s|__USER__|$RUN_USER|g" -e "s|__NODE__|$NODE_BIN|g" \
  "$SCRIPT_DIR/systemd/wos.service" > /etc/systemd/system/wos.service
if [ -f "$SCRIPT_DIR/systemd/wos-terminal.service" ] && [ -d "$INSTALL_DIR/mini-services/terminal-service/node_modules" ]; then
  sed -e "s|__DIR__|$INSTALL_DIR|g" -e "s|__USER__|$RUN_USER|g" -e "s|__NODE__|$NODE_BIN|g" \
      -e "s|__PORT__|$APP_PORT|g" -e "s|__PORT2__|$((APP_PORT + 1))|g" -e "s|__HOME__|$USER_HOME|g" \
    "$SCRIPT_DIR/systemd/wos-terminal.service" > /etc/systemd/system/wos-terminal.service
else
  warn "Bỏ qua wos-terminal (thiếu mini-services) — app Terminal sẽ báo không kết nối được"
fi
systemctl daemon-reload
systemctl enable wos >/dev/null 2>&1
systemctl enable wos-terminal >/dev/null 2>&1 || true
systemctl restart wos
systemctl restart wos-terminal >/dev/null 2>&1 || true
sleep 5

if systemctl is-active --quiet wos; then
  ok "Service wos đang chạy"
else
  warn "Service chưa lên — xem: journalctl -u wos -e"
fi
if systemctl is-active --quiet wos-terminal 2>/dev/null; then
  ok "Service wos-terminal đang chạy (cổng $((APP_PORT + 1)), path /terminal-ws)"
else
  warn "wos-terminal chưa lên (nếu đã cài) — xem: journalctl -u wos-terminal -e"
fi

IP="$(hostname -I 2>/dev/null | awk '{print $1}' || true)"
[ -n "$IP" ] || IP="<ip-orangepi>"

hr
echo -e "${C_G}  ✅ CÀI ĐẶT WORKSPACE OS HOÀN TẤT${C_0}"
hr
echo "  🌐 Truy cập   : http://$IP:$APP_PORT"
echo "  👤 Tài khoản  : $ADMIN_USER"
if [ "$GENERATED_PW" = 1 ]; then
  echo "  🔑 Mật khẩu   : $ADMIN_PASSWORD   (SINH NGẪU NHIÊN — LƯU NGAY!)"
else
  echo "  🔑 Mật khẩu   : (mật khẩu bạn đã nhập)"
fi
echo ""
echo "  Quản lý dịch vụ:"
echo "    systemctl status wos"
echo "    journalctl -u wos -f          # xem log realtime"
echo "    sudo systemctl restart wos    # khởi động lại"
echo ""
echo "  🖥️ Terminal (V3): bash thật trên máy — mở app Terminal trong WOS."
echo "    systemctl status wos-terminal"
echo "    journalctl -u wos-terminal -f"
echo ""
echo "  ⚠️ Đưa lên Internet (Cloudflare Tunnel):"
echo "    1. Các nhóm lỗi nghiêm trọng (Forgot Password, ZIP symlink/bomb,"
echo "       Backup secret, Filesystem) đã được vá ở v2.1/v2.2 — nhưng vẫn nên"
echo "       chạy thử thực tế trên Orange Pi TRƯỚC khi mở công."
echo "    2. Sau khi bật tunnel, sửa .env:  WOS_TRUST_PROXY=cloudflare  rồi"
echo "       sudo systemctl restart wos (rate limit mới đúng IP thật)."
echo ""
echo "  Chạy lại install.sh bất cứ lúc nào = cài lại từ đầu (thêm --keep-data để giữ file)."
hr
