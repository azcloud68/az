# Workspace OS — Worklog

---
Task ID: 1
Agent: main
Task: Clone + phân tích dự án Workspace OS (github.com/azcloud68/az) để sửa 10 lỗi/tính năng

Work Log:
- Clone repo → giải nén workspace-os.zip + wos-ai-assistant-plugin.zip
- Triển khai mã nguồn vào /home/z/my-project (Next.js 16, prisma sqlite, storage/plugins)
- bun install + db:push thành công; dev server chạy port 3000 (200 OK)
- 3 agent Explore khảo sát: terminal/ws, widget/plugin-runtime, files/dnd, wiki, desktop icons, settings/notification/backup/AI

Stage Summary:
- Terminal: rewrite /terminal-ws bị gate bởi WOS_TERMINAL_PROXY=1 lúc build (next.config.ts); terminal-service chạy port 3069 (systemd) hoặc 3005 (sandbox/gateway); TerminalApp có 3 mode proxy/direct/gateway, probe lỗi do rewrite không tồn tại
- DnD: Desktop.tsx chỉ đọc e.dataTransfer.files (không hỗ trợ folder/webkitGetAsEntry); upload API làm phẳng filename (sanitize cắt dấu /)
- Wiki: KHÔNG có UI sửa tiêu đề (chỉ prompt() khi tạo); API PATCH /api/modules/wiki/[id] đã hỗ trợ {title}
- Groq: chỉ là openai-compat qua env (AI_COMPAT_*), không có UI nhập key, không có provider riêng
- Widget: WOS.registerWidget TỒN TẠI trong plugin-runtime.ts (hệ plugin.json) nhưng KHÔNG có trên window.WOS (hệ legacy script injection) → plugin dùng window.WOS không đăng ký được widget
- Mở thư mục Desktop: system.openPath → openApp('files', {route: files:<enc path>}) — cần xác minh Entry.path có prefix 'Desktop/' hay không
- Module→Plugin: cần tạo builtin plugin rows cho browser, doc, tasks, weekly, calendar, notes, wiki (slug = module id)
- Notification email: chỉ placeholder "cần SMTP — đang chuẩn bị"; không có nodemailer
- Backup: tab Backup hiện chỉ export metadata JSON; cần thêm full backup (metadata + storage files)
- Icon: AppIconTile img path đã full-bleed nhưng glyph 48%; cần setting desktopIconScale slider
