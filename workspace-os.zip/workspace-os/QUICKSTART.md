# Workspace OS + AI Assistant — Khởi động nhanh

> Bản này = mã nguồn Workspace OS **mới nhất** + AI Assistant đủ 4 giai đoạn
> + **lớp tích hợp AI mở rộng** (thêm AI mới không phải sửa lõi).

Yêu cầu: Node.js 20+ (hoặc Bun 1.1+).

```bash
# 1) Cài dependencies
bun install        # hoặc: npm install

# 2) Tạo file .env từ mẫu
cp .env.example .env

# 3) Tạo database (SQLite) + Prisma client
bunx prisma db push

# 4) Seed tài khoản admin + dữ liệu demo (admin / admin123)
node scripts/seed.mjs

# 5) Chạy dev server
bun run dev        # hoặc: npm run dev
# Mở http://localhost:3000 — đăng nhập admin/admin123
```

Chạy production:

```bash
bun run build && bun run start
```

## Tích hợp AI

- Plugin "Trợ lý AI" nằm sẵn trong `storage/plugins/wos-ai-assistant/` — OS tự quét cài.
- **Dùng AI khác (Ollama local, OpenRouter, Groq, DeepSeek…): chỉ khai 3 biến
  `AI_COMPAT_*` trong `.env`** — không sửa code. Bảng cấu hình mẫu trong `.env.example`.
- Bật Grok: thêm `XAI_API_KEY='xai-...'` rồi restart.
- **Thêm provider / nguồn context / tool AI mới: đọc `docs/ai-integration-guide.md`**
  (kiến trúc registry, code mẫu từng bước, API đầy đủ, bảo mật, lộ trình RAG/streaming/voice).

## Tiện ích Chrome (GĐ4)

Xem `browser-extension/` — giải nén nếu cần, rồi `chrome://extensions` → bật
Chế độ dành cho nhà phát triển → "Tải tiện ích đã giải nén" → chọn thư mục.

Chi tiết kiến trúc / API / kiểm thử: `docs/ai-assistant.md` và `docs/ai-integration-guide.md`.
