'use client'

/**
 * APP: Terminal — shell bash THẬT chạy trên máy WOS (Orange Pi / sandbox).
 * - xterm.js + FitAddon, theme tối macOS Terminal
 * - Kết nối socket.io tới terminal-service theo CHIẾN LƯỢC do server dò sẵn
 *   (session API trả mode: proxy / direct / gateway) + tự thử lại từng phương
 *   thức nếu cái đầu thất bại (v6.2 — hết cảnh "socket bị chặn" mơ hồ)
 * - Token ngắn hạn lấy từ /api/system/terminal/session (service đối chiếu ngược Next)
 * - Mỗi cửa sổ Terminal = 1 phiên shell riêng; đóng cửa sổ = đóng shell
 * - Nút "Phiên mới" mở cửa sổ Terminal độc lập tiếp theo
 */
import { useCallback, useEffect, useRef, useState } from 'react'
import { useRoute } from '@/core/client/route-context'
import { api } from '@/core/client/api'
import { useWindows } from '@/core/client/window-store'
import { io, type Socket } from 'socket.io-client'
import { Terminal } from '@xterm/xterm'
import { FitAddon } from '@xterm/addon-fit'
import { Button } from '@/components/ui/button'
import { Loader2, RefreshCw, SquarePlus, TerminalSquare, TriangleAlert } from 'lucide-react'

interface SessionCfg {
  token: string
  port: number
  path: string
  /** proxy = qua Next rewrite /terminal-ws (cùng origin); direct = thẳng cổng service;
   *  gateway = Caddy ?XTransformPort (sandbox). Cũ: thiếu mode → suy đoán như trước. */
  mode?: 'proxy' | 'direct' | 'gateway'
}

type Strategy = 'proxy' | 'direct' | 'gateway'

const STRATEGY_LABEL: Record<Strategy, string> = {
  proxy: 'qua /terminal-ws',
  direct: 'trực tiếp',
  gateway: 'qua gateway',
}

export default function TerminalApp() {
  const { route } = useRoute()
  const openApp = useWindows((s) => s.openApp)
  const [status, setStatus] = useState<'connecting' | 'ready' | 'denied' | 'ended' | 'error'>('connecting')
  const [message, setMessage] = useState('')
  const [pty, setPty] = useState(false)
  /** phương thức kết nối đang dùng (hiện trên thanh công cụ) */
  const [strategy, setStrategy] = useState<Strategy | null>(null)
  const [nonce, setNonce] = useState(0) // tăng = mở lại phiên
  const hostRef = useRef<HTMLDivElement | null>(null)
  const termRef = useRef<Terminal | null>(null)
  const socketRef = useRef<Socket | null>(null)

  const reconnect = useCallback(() => setNonce((n) => n + 1), [])
  /** trạng thái mới nhất cho callback socket (tránh stale closure) */
  const statusRef = useRef<'connecting' | 'ready' | 'denied' | 'ended' | 'error'>('connecting')
  useEffect(() => {
    statusRef.current = status
  }, [status])

  useEffect(() => {
    let disposed = false
    let socket: Socket | null = null
    let term: Terminal | null = null
    let fit: FitAddon | null = null
    let ro: ResizeObserver | null = null
    /** các phương thức sẽ thử lần lượt (mảng dựng theo cfg.mode) */
    let ladder: Strategy[] = ['proxy', 'direct', 'gateway']
    let ladderIdx = 0
    let cfg: SessionCfg | null = null

    const boot = async () => {
      setStatus('connecting')
      setMessage('')
      try {
        cfg = await api<SessionCfg>('/api/system/terminal/session', { method: 'POST' })
        if (disposed) return

        // Thứ tự thử: theo mode server dò được, kèm phương thức dự phòng
        const mode = cfg.mode || (cfg.path && cfg.path !== '/' ? 'proxy' : 'gateway')
        ladder =
          mode === 'proxy'
            ? ['proxy', 'direct', 'gateway']
            : mode === 'direct'
              ? ['direct', 'gateway', 'proxy']
              : ['gateway', 'direct']
        ladderIdx = 0

        term = new Terminal({
          fontFamily: '"JetBrains Mono", "Fira Code", "Sarasa Mono SC", Menlo, Consolas, "Liberation Mono", monospace',
          fontSize: 13.5,
          lineHeight: 1.15,
          cursorBlink: true,
          allowProposedApi: true,
          theme: {
            background: '#10131a',
            foreground: '#d6deeb',
            cursor: '#7aa2f7',
            selectionBackground: '#33467c',
            black: '#10131a',
            red: '#f7768e',
            green: '#9ece6a',
            yellow: '#e0af68',
            blue: '#7aa2f7',
            magenta: '#bb9af7',
            cyan: '#7dcfff',
            white: '#d6deeb',
          },
        })
        fit = new FitAddon()
        term.loadAddon(fit)
        term.open(hostRef.current!)
        term.write('\x1b[38;5;245mĐang kết nối shell…\x1b[0m\r\n')
        termRef.current = term

        /** Dựng socket.io theo từng phương thức:
         *  - proxy: cùng origin qua Next rewrite — KHÔNG nâng cấp websocket (proxy
         *    không chuyển tiếp upgrade) → polling ổn định
         *  - direct: thẳng tới service — websocket thật
         *  - gateway: Caddy ?XTransformPort (hỗ trợ upgrade) */
        const buildSocket = (s: Strategy): Socket => {
          const common = {
            auth: { token: cfg!.token },
            reconnectionAttempts: 2,
            reconnectionDelay: 1200,
            timeout: 10000,
          }
          if (s === 'gateway') {
            return io(`/?XTransformPort=${cfg!.port}`, {
              ...common,
              transports: ['polling', 'websocket'],
            })
          }
          return s === 'direct'
            ? io(`${window.location.protocol}//${window.location.hostname}:${cfg!.port}`, {
                ...common,
                path: cfg!.path,
                // engine.io nhận cả "/path" và "/path/" (một số proxy bỏ dấu "/" cuối)
                addTrailingSlash: false,
                transports: ['polling', 'websocket'],
              })
            : io('/', {
                ...common,
                path: cfg!.path,
                addTrailingSlash: false,
                transports: ['polling'],
              })
        }

        /** Chẩn đoán khi mọi phương thức đều thất bại */
        const probe = async (): Promise<string> => {
          const tried = ladder.map((s) => STRATEGY_LABEL[s]).join(' → ')
          const last = ladder[ladder.length - 1] || 'proxy'
          try {
            const url =
              last === 'gateway'
                ? `/?XTransformPort=${cfg!.port}`
                : last === 'direct'
                  ? `${window.location.protocol}//${window.location.hostname}:${cfg!.port}${cfg!.path}`
                  : cfg!.path
            const res = await fetch(url, { signal: AbortSignal.timeout(4000) })
            const body = await res.text().catch(() => '')
            const ct = res.headers.get('content-type') || ''
            // trả về HTML = đường kết nối đang trỏ về trang web WOS (proxy chưa bật đúng)
            if (ct.includes('text/html')) {
              return `Đường /terminal-ws chưa được chuyển tiếp tới terminal service (build chưa bật WOS_TERMINAL_PROXY). Chạy lại install.sh trên máy chủ để sửa — đã thử: ${tried}.`
            }
            if (res.ok || body.includes('Transport unknown')) {
              return `Terminal service đang chạy nhưng socket.io không bắt tay được (đã thử: ${tried}). Kiểm tra: journalctl -u wos-terminal -e`
            }
            return `Terminal service trả về HTTP ${res.status} — kiểm tra service trên máy chủ (đã thử: ${tried}).`
          } catch {
            return 'Terminal service không phản hồi — kiểm tra service trên máy chủ (Orange Pi: systemctl status wos-terminal).'
          }
        }

        const attachHandlers = () => {
          if (!socket || disposed) return
          socket.on('ready', (info: { user: string; pty: boolean }) => {
            if (disposed || !term) return
            setPty(Boolean(info.pty))
            setStatus('ready')
            term.reset()
            term.writeln(
              `\x1b[1;34mWOS Terminal\x1b[0m — shell chạy trên máy WOS` + (info.pty ? '' : ' \x1b[90m(pipes)\x1b[0m'),
            )
            term.writeln('\x1b[90mGõ lệnh như trên Linux thật. "exit" để thoát phiên.\x1b[0m')
            term.focus()
            try {
              fit?.fit()
            } catch {
              /* cửa sổ chưa có kích thước */
            }
          })

          socket.on('data', (data: string) => {
            if (!disposed && term) term.write(data)
          })

          socket.on('denied', (d: { reason?: string }) => {
            if (disposed) return
            setStatus('denied')
            setMessage(d.reason || 'Không mở được phiên Terminal')
          })

          socket.on('exit', (d: { code: number }) => {
            if (disposed || !term) return
            setStatus('ended')
            term.writeln(`\r\n\x1b[90m〔Phiên shell đã kết thúc (mã ${d.code})〕\x1b[0m`)
          })

          // mất kết nối giữa chừng (mạng nhấp nháy) → đang thử lại
          socket.on('disconnect', (reason: string) => {
            if (disposed || statusRef.current !== 'ready') return
            if (reason === 'io client disconnect' || reason === 'io server disconnect') return
            setStatus('connecting')
            setMessage('Mất kết nối — đang thử lại…')
          })

          socket.on('connect', () => {
            if (disposed) return
            if (statusRef.current !== 'ready') {
              setStatus('connecting')
              setMessage('')
            }
          })

          socket.on('connect_error', () => {
            if (disposed) return
            // thử phương thức kết nối kế tiếp trước khi báo lỗi
            const next = ladder[ladderIdx + 1]
            if (next) {
              ladderIdx += 1
              socket?.removeAllListeners()
              socket?.disconnect()
              setStatus('connecting')
              setMessage(`Đang thử kết nối ${STRATEGY_LABEL[next]}…`)
              socket = buildSocket(next)
              socketRef.current = socket
              setStrategy(next)
              attachHandlers()
              return
            }
            setStatus('error')
            void probe().then((msg) => {
              if (!disposed) setMessage(msg)
            })
          })
        }

        socket = buildSocket(ladder[0])
        socketRef.current = socket
        setStrategy(ladder[0])
        attachHandlers()

        term.onData((data) => {
          if (socket?.connected) socket.emit('input', data)
        })

        // Resize theo cửa sổ WOS
        const doFit = () => {
          try {
            fit?.fit()
            if (socket?.connected && term) {
              socket.emit('resize', { cols: term.cols, rows: term.rows })
            }
          } catch {
            /* bỏ qua */
          }
        }
        ro = new ResizeObserver(() => doFit())
        ro.observe(hostRef.current!)
        setTimeout(doFit, 120)
      } catch (err) {
        if (disposed) return
        setStatus('error')
        setMessage(err instanceof Error ? err.message : 'Không lấy được phiên Terminal')
      }
    }
    void boot()

    return () => {
      disposed = true
      if (ro) ro.disconnect()
      socket?.removeAllListeners()
      socket?.disconnect()
      term?.dispose()
      socketRef.current = null
      termRef.current = null
    }
  }, [nonce])

  const newSession = () => {
    const key = `t:${Date.now().toString(36)}`
    openApp('terminal', { key, route: 'terminal' })
  }

  return (
    <div className="flex h-full w-full flex-col bg-[#10131a]">
      {/* Thanh công cụ mỏng kiểu macOS Terminal */}
      <div className="flex h-9 shrink-0 items-center gap-2 border-b border-white/10 px-3 text-[12px] text-white/70">
        <TerminalSquare className="h-3.5 w-3.5 text-sky-400" />
        <span className="font-medium">bash</span>
        {pty ? (
          <span className="rounded-full bg-emerald-500/15 px-2 py-0.5 text-[10.5px] font-medium text-emerald-300">
            PTY thật
          </span>
        ) : null}
        <span className="flex-1 truncate text-white/35">
          {status === 'ready'
            ? `đang chạy ${strategy ? `(${STRATEGY_LABEL[strategy]})` : ''}`
            : status === 'connecting'
              ? message || 'đang kết nối…'
              : message}
        </span>
        <Button
          variant="ghost"
          size="sm"
          className="h-6 gap-1.5 px-2 text-[11.5px] text-white/70 hover:bg-white/10 hover:text-white"
          onClick={newSession}
          title="Mở cửa sổ Terminal mới (phiên shell riêng)"
        >
          <SquarePlus className="h-3.5 w-3.5" />
          Phiên mới
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="h-6 gap-1.5 px-2 text-[11.5px] text-white/70 hover:bg-white/10 hover:text-white"
          onClick={reconnect}
          title="Mở lại phiên shell"
        >
          <RefreshCw className="h-3.5 w-3.5" />
          Mở lại
        </Button>
      </div>

      {/* Vùng terminal */}
      <div className="relative min-h-0 flex-1 p-2">
        <div ref={hostRef} className="h-full w-full overflow-hidden rounded-lg" />

        {status === 'connecting' ? (
          <div className="absolute inset-0 flex items-center justify-center gap-2 text-[13px] text-white/60">
            <Loader2 className="h-4 w-4 animate-spin" />
            {message || 'Đang mở shell trên máy…'}
          </div>
        ) : null}

        {status === 'denied' || status === 'error' ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-[#10131a]/90 text-center">
            <TriangleAlert className="h-8 w-8 text-amber-400" />
            <p className="max-w-sm px-6 text-[13px] text-white/70">{message}</p>
            <Button variant="secondary" size="sm" onClick={reconnect} className="gap-1.5">
              <RefreshCw className="h-3.5 w-3.5" /> Thử lại
            </Button>
          </div>
        ) : null}

        {status === 'ended' ? (
          <button
            onClick={reconnect}
            className="absolute inset-x-0 bottom-6 mx-auto flex w-fit items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-[12.5px] font-medium text-white/85 backdrop-blur transition hover:bg-white/20"
          >
            <SquarePlus className="h-3.5 w-3.5" />
            Mở phiên shell mới
          </button>
        ) : null}
      </div>
    </div>
  )
}
