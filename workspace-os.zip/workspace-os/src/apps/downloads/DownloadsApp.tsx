'use client'

/**
 * APP: Downloads — trình quản lý tải xuống (như PC): tiến trình từng tệp,
 * huỷ/tải lại/xoá khỏi danh sách, mở tệp đã tải (qua Application System)
 * hoặc mở thư mục chứa trong Files.
 */
import { useDownloads, formatBytes } from '@/core/client/downloads'
import { openFile } from '@/core/client/applications'
import { useWindows } from '@/core/client/window-store'
import { Button } from '@/components/ui/button'
import { Download, FileText, FolderOpen, RotateCw, Trash2, X, CheckCircle2, CircleAlert, Ban } from 'lucide-react'

export default function DownloadsApp() {
  const { items, cancel, retry, remove, clearFinished } = useDownloads()
  const openApp = useWindows((s) => s.openApp)

  const active = items.filter((i) => i.status === 'active')

  return (
    <div className="flex h-full w-full flex-col">
      {/* Header */}
      <div className="flex h-12 shrink-0 items-center gap-2.5 border-b px-4">
        <Download className="h-4.5 w-4.5 text-primary" />
        <h2 className="text-[15px] font-semibold">Tải xuống</h2>
        <span className="text-[12px] text-muted-foreground">
          {active.length > 0 ? `${active.length} đang tải` : `${items.length} mục`}
        </span>
        <div className="flex-1" />
        {items.some((i) => i.status !== 'active') ? (
          <Button variant="ghost" size="sm" className="h-7 gap-1.5 text-[12px]" onClick={clearFinished}>
            <Trash2 className="h-3.5 w-3.5" />
            Dọn danh sách
          </Button>
        ) : null}
      </div>

      {/* Danh sách */}
      <div className="min-h-0 flex-1 overflow-y-auto p-3">
        {items.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center gap-3 text-muted-foreground">
            <Download className="h-10 w-10 opacity-30" />
            <p className="text-[13.5px] font-medium">Chưa có tệp nào được tải</p>
            <p className="max-w-xs text-center text-[12px] leading-relaxed">
              Tải tệp từ File Manager hoặc trình xem — tiến trình sẽ hiện ở đây và trên thanh menu.
            </p>
          </div>
        ) : (
          <ul className="flex flex-col gap-2">
            {items.map((i) => {
              const pct = i.size > 0 ? Math.min(100, Math.round((i.received / i.size) * 100)) : 0
              return (
                <li key={i.id} className="rounded-xl border bg-card p-3 shadow-sm">
                  <div className="flex items-center gap-3">
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-muted">
                      {i.status === 'done' ? (
                        <CheckCircle2 className="h-4.5 w-4.5 text-emerald-600" />
                      ) : i.status === 'error' ? (
                        <CircleAlert className="h-4.5 w-4.5 text-destructive" />
                      ) : i.status === 'cancelled' ? (
                        <Ban className="h-4.5 w-4.5 text-muted-foreground" />
                      ) : (
                        <FileText className="h-4.5 w-4.5 text-muted-foreground" />
                      )}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[13px] font-medium">{i.name}</p>
                      <p className="truncate text-[11.5px] text-muted-foreground">
                        {i.status === 'active'
                          ? i.size > 0
                            ? `${formatBytes(i.received)} / ${formatBytes(i.size)} · ${pct}%`
                            : `${formatBytes(i.received)} · đang tải…`
                          : i.status === 'done'
                            ? `${formatBytes(i.size)} · hoàn tất ${new Date(i.finishedAt || 0).toLocaleTimeString('vi-VN')}`
                            : i.status === 'cancelled'
                              ? 'Đã huỷ'
                              : i.error || 'Lỗi tải'}
                      </p>
                    </div>
                    <div className="flex shrink-0 items-center gap-1">
                      {i.status === 'active' ? (
                        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => cancel(i.id)} title="Huỷ">
                          <X className="h-3.5 w-3.5" />
                        </Button>
                      ) : null}
                      {i.status === 'error' || i.status === 'cancelled' ? (
                        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => retry(i.id)} title="Tải lại">
                          <RotateCw className="h-3.5 w-3.5" />
                        </Button>
                      ) : null}
                      {i.status === 'done' && i.path ? (
                        <>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7"
                            onClick={() => openFile(i.path!)}
                            title="Mở tệp"
                          >
                            <FileText className="h-3.5 w-3.5" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7"
                            onClick={() => {
                              const dir = i.path!.split('/').slice(0, -1).join('/')
                              openApp('files', { route: `files:${encodeURIComponent(dir || '/')}` })
                            }}
                            title="Mở thư mục chứa"
                          >
                            <FolderOpen className="h-3.5 w-3.5" />
                          </Button>
                        </>
                      ) : null}
                      {i.status !== 'active' ? (
                        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => remove(i.id)} title="Xoá khỏi danh sách">
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      ) : null}
                    </div>
                  </div>
                  {i.status === 'active' ? (
                    <div className="mt-2.5 h-1.5 overflow-hidden rounded-full bg-muted">
                      <div
                        className={`h-full rounded-full bg-primary transition-all ${
                          i.size === 0 ? 'w-1/3 animate-[wos-indeterminate_1.1s_ease-in-out_infinite]' : ''
                        }`}
                        style={i.size > 0 ? { width: `${pct}%` } : undefined}
                      />
                    </div>
                  ) : null}
                </li>
              )
            })}
          </ul>
        )}
      </div>
    </div>
  )
}
