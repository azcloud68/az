'use client'

/**
 * APP: Browser — trình duyệt web TRONG cửa sổ WOS (kiến trúc Local WebView của V3).
 * - Tab nhiều trang, thanh địa chỉ + tìm kiếm, back/forward/reload/home
 * - iframe sandbox: web thật chạy trong cửa sổ OS
 * - Nhiều site chặn nhúng (X-Frame-Options/CSP) → dò bằng heuristic about:blank
 *   và luôn có nút "Mở tab ngoài" — đây là giới hạn web chuẩn, không phải bug WOS
 * - Catalog "ứng dụng web" trên trang mới (Gmail, Drive, ChatGPT, YouTube…)
 * - Route: 'browser' (trang chủ) | 'browser:<encodedUrl>' (mở URL — từ shortcut desktop,
 *   openUrl(), wosNavigate)
 * Lớp "Remote Browser" (Chromium trên máy khác, stream về) sẽ cắm thêm sau —
 * see docs/architecture (Giai đoạn 3 của roadmap Web PC).
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { useRoute } from '@/core/client/route-context'
import { normalizeUrl, urlOrSearch, prettyHost } from '@/core/client/applications'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  ArrowLeft, ArrowRight, Globe, House, Lock, MoreHorizontal, Plus, RotateCw,
  Search, SquareArrowOutUpRight, X, TriangleAlert,
} from 'lucide-react'

interface Tab {
  id: string
  url: string // URL đang điều hướng tới (kiểm soát bởi WOS)
  input: string // giá trị thanh địa chỉ (chưa commit)
  title: string
  history: string[]
  histIdx: number
  loading: boolean
  blocked: boolean
  iframeKey: number // tăng = reload
}

let tabSeq = 1
const newTab = (url = ''): Tab => ({
  id: `t${tabSeq++}`,
  url,
  input: url,
  title: url ? prettyHost(url) : 'Trang mới',
  history: url ? [url] : [],
  histIdx: url ? 0 : -1,
  loading: Boolean(url),
  blocked: false,
  iframeKey: 1,
})

/** Catalog ứng dụng web gợi ý trên trang mới (favicon qua Google favicon service) */
const CATALOG: { name: string; url: string; hue: string; glyph: string }[] = [
  { name: 'Gmail', url: 'https://mail.google.com', hue: '#ea4335', glyph: '✉' },
  { name: 'Google Drive', url: 'https://drive.google.com', hue: '#fbbc05', glyph: '▲' },
  { name: 'YouTube', url: 'https://www.youtube.com', hue: '#ff0000', glyph: '▶' },
  { name: 'ChatGPT', url: 'https://chat.openai.com', hue: '#10a37f', glyph: '✦' },
  { name: 'Claude', url: 'https://claude.ai', hue: '#d97757', glyph: '✵' },
  { name: 'Gemini', url: 'https://gemini.google.com', hue: '#4285f4', glyph: '◈' },
  { name: 'GitHub', url: 'https://github.com', hue: '#24292f', glyph: '⌥' },
  { name: 'Wikipedia', url: 'https://vi.wikipedia.org', hue: '#636466', glyph: 'W' },
  { name: 'Google Maps', url: 'https://maps.google.com', hue: '#34a853', glyph: '⌖' },
  { name: 'Notion', url: 'https://notion.so', hue: '#111111', glyph: 'N' },
  { name: 'VnExpress', url: 'https://vnexpress.net', hue: '#e11d48', glyph: 'V' },
  { name: 'Google', url: 'https://www.google.com', hue: '#4285f4', glyph: 'G' },
]

const SEARCH_ENGINES = [
  { id: 'https://duckduckgo.com/?q=', label: 'DuckDuckGo' },
  { id: 'https://www.google.com/search?q=', label: 'Google' },
  { id: 'https://www.bing.com/search?q=', label: 'Bing' },
]

export default function BrowserApp() {
  const { route } = useRoute()
  const [tabs, setTabs] = useState<Tab[]>([newTab()])
  const [activeId, setActiveId] = useState<string>('')
  const [engine, setEngine] = useState(SEARCH_ENGINES[0].id)
  const [searchOpen, setSearchOpen] = useState(false)
  const lastRouteRef = useRef('')
  const inputRef = useRef<HTMLInputElement | null>(null)
  const frameRef = useRef<HTMLIFrameElement | null>(null)

  const active = tabs.find((t) => t.id === activeId) || tabs[0]

  // Engine tìm kiếm: lưu per-account localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem('wos.browser.engine')
      if (saved && SEARCH_ENGINES.some((e) => e.id === saved)) setEngine(saved)
    } catch {
      /* bỏ qua */
    }
  }, [])

  const patch = useCallback((id: string, p: Partial<Tab>) => {
    setTabs((ts) => ts.map((t) => (t.id === id ? { ...t, ...p } : t)))
  }, [])

  /** Điều hướng tab tới URL (push history) */
  const navigate = useCallback(
    (id: string, rawInput: string) => {
      const url = urlOrSearch(rawInput, engine)
      if (!url) return
      setTabs((ts) =>
        ts.map((t) => {
          if (t.id !== id) return t
          const history = [...t.history.slice(0, t.histIdx + 1), url]
          return {
            ...t,
            url,
            input: url,
            title: prettyHost(url),
            history,
            histIdx: history.length - 1,
            loading: true,
            blocked: false,
            iframeKey: t.iframeKey + 1,
          }
        }),
      )
    },
    [engine],
  )

  // Route từ ngoài vào (shortcut desktop / openUrl) → mở tab mới
  useEffect(() => {
    if (route === lastRouteRef.current) return
    lastRouteRef.current = route
    if (!route.startsWith('browser:') && route !== 'browser') return
    const encoded = route.startsWith('browser:') ? route.slice('browser:'.length) : ''
    let url = ''
    try {
      url = encoded ? decodeURIComponent(encoded) : ''
    } catch {
      url = encoded
    }
    if (!url) return
    const tab = newTab(normalizeUrl(url))
    setTabs((ts) => [...ts, tab])
    setActiveId(tab.id)
  }, [route])

  const goBack = () => {
    if (!active || active.histIdx <= 0) return
    const idx = active.histIdx - 1
    patch(active.id, {
      url: active.history[idx],
      input: active.history[idx],
      title: prettyHost(active.history[idx]),
      histIdx: idx,
      loading: true,
      blocked: false,
      iframeKey: active.iframeKey + 1,
    })
  }
  const goForward = () => {
    if (!active || active.histIdx >= active.history.length - 1) return
    const idx = active.histIdx + 1
    patch(active.id, {
      url: active.history[idx],
      input: active.history[idx],
      title: prettyHost(active.history[idx]),
      histIdx: idx,
      loading: true,
      blocked: false,
      iframeKey: active.iframeKey + 1,
    })
  }
  const reload = () => {
    if (!active) return
    patch(active.id, { loading: true, blocked: false, iframeKey: active.iframeKey + 1 })
  }

  const addTab = () => {
    const id = `t${tabSeq++}`
    setTabs((ts) => [...ts, newTab()])
    setActiveId(id)
    setTimeout(() => inputRef.current?.focus(), 60)
  }

  const closeTab = (id: string) => {
    setTabs((ts) => {
      const next = ts.filter((t) => t.id !== id)
      if (next.length === 0) return [newTab()]
      return next
    })
    setActiveId((cur) => (cur === id ? '' : cur))
  }

  /** iframe onLoad — heuristic dò trang bị chặn nhúng:
   *  frame cross-origin thật → truy cập location.href NÉM lỗi (tốt);
   *  about:blank đọc được → gần như chắc chắn bị X-Frame-Options chặn. */
  const onFrameLoad = () => {
    if (!active) return
    let blocked = false
    try {
      const href = frameRef.current?.contentWindow?.location?.href
      if (!href || href === 'about:blank') blocked = true
    } catch {
      blocked = false // cross-origin → trang đã tải thật
    }
    patch(active.id, { loading: false, blocked })
  }

  // timeout: 8s không onLoad → có thể bị treo/chặn
  useEffect(() => {
    if (!active?.loading) return
    const t = setTimeout(() => patch(active.id, { loading: false }), 8000)
    return () => clearTimeout(t)
  }, [active?.id, active?.loading, active?.iframeKey, patch])

  const showNewTab = !active || !active.url
  const canBack = (active?.histIdx ?? 0) > 0
  const canForward = active ? active.histIdx < active.history.length - 1 : false

  const engineLabel = useMemo(
    () => SEARCH_ENGINES.find((e) => e.id === engine)?.label || 'DuckDuckGo',
    [engine],
  )

  return (
    <div className="flex h-full w-full flex-col bg-background">
      {/* ===== Thanh tab + điều khiển ===== */}
      <div className="flex h-11 shrink-0 items-center gap-1 border-b bg-muted/40 px-2">
        <div className="flex items-center gap-0.5 text-muted-foreground">
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={goBack} disabled={!canBack} title="Lùi">
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={goForward} disabled={!canForward} title="Tới">
            <ArrowRight className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={reload} disabled={showNewTab} title="Tải lại">
            <RotateCw className={`h-4 w-4 ${active?.loading ? 'animate-spin' : ''}`} />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={() => {
              const id = active?.id || tabs[0].id
              patch(id, { url: '', input: '', title: 'Trang mới', history: [], histIdx: -1, blocked: false })
            }}
            title="Trang chủ"
          >
            <House className="h-4 w-4" />
          </Button>
        </div>

        {/* Thanh địa chỉ */}
        <form
          className="flex min-w-0 flex-1 items-center gap-2"
          onSubmit={(e) => {
            e.preventDefault()
            if (active) navigate(active.id, active.input)
          }}
        >
          <div className="relative flex min-w-0 flex-1 items-center">
            {showNewTab ? (
              <Search className="pointer-events-none absolute left-2.5 h-3.5 w-3.5 text-muted-foreground" />
            ) : (
              <Lock className="pointer-events-none absolute left-2.5 h-3.5 w-3.5 text-emerald-600" />
            )}
            <Input
              ref={inputRef}
              value={active?.input || ''}
              onChange={(e) => active && patch(active.id, { input: e.target.value })}
              placeholder={`Tìm ${engineLabel} hoặc nhập địa chỉ…`}
              className="h-8 rounded-full bg-background pl-8 pr-3 text-[13px] shadow-none"
              spellCheck={false}
            />
            {active?.loading ? (
              <div className="absolute inset-x-14 bottom-0 h-0.5 overflow-hidden rounded bg-muted">
                <div className="h-full w-1/3 animate-[wos-indeterminate_1.1s_ease-in-out_infinite] bg-primary" />
              </div>
            ) : null}
          </div>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="relative h-7 w-7 shrink-0"
            onClick={() => setSearchOpen((v) => !v)}
            title="Đổi công cụ tìm kiếm"
          >
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </form>

        {searchOpen ? (
          <div className="absolute right-24 top-12 z-50 w-44 rounded-xl border bg-popover p-1 shadow-lg">
            {SEARCH_ENGINES.map((e) => (
              <button
                key={e.id}
                className={`flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-left text-[13px] hover:bg-accent ${
                  engine === e.id ? 'font-semibold' : ''
                }`}
                onClick={() => {
                  setEngine(e.id)
                  setSearchOpen(false)
                  try {
                    localStorage.setItem('wos.browser.engine', e.id)
                  } catch {
                    /* bỏ qua */
                  }
                }}
              >
                <Globe className="h-3.5 w-3.5 text-muted-foreground" />
                {e.label}
                {engine === e.id ? <span className="ml-auto text-primary">✓</span> : null}
              </button>
            ))}
          </div>
        ) : null}

        <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0" onClick={addTab} title="Tab mới">
          <Plus className="h-4 w-4" />
        </Button>
      </div>

      {/* ===== Dải tab ===== */}
      {tabs.length > 1 || !showNewTab ? (
        <div className="flex h-9 shrink-0 items-stretch gap-1 overflow-x-auto border-b bg-muted/20 px-2 pt-1.5">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setActiveId(t.id)}
              className={`group flex h-7 min-w-0 max-w-52 shrink-0 items-center gap-1.5 rounded-t-lg border-x border-t px-2.5 text-[12px] transition ${
                t.id === active?.id
                  ? 'border-border bg-background font-medium text-foreground'
                  : 'border-transparent text-muted-foreground hover:bg-muted/60'
              }`}
            >
              {t.loading ? (
                <RotateCw className="h-3 w-3 shrink-0 animate-spin text-muted-foreground" />
              ) : (
                <Globe className="h-3 w-3 shrink-0 text-muted-foreground" />
              )}
              <span className="truncate">{t.title}</span>
              {/* v6.3: nút đóng tab LUÔN HIỆN (trước ẩn đến khi hover — hover không
                  tồn tại trên touchscreen/mobile/tablet → không đóng được tab).
                  Vùng chạm to hơn (p-1) + mờ nhẹ khi tab không active cho gọn mắt */}
              <span
                role="button"
                tabIndex={0}
                aria-label="Đóng tab"
                className="ml-auto flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-muted-foreground/70 transition hover:bg-muted hover:text-foreground"
                onClick={(e) => {
                  e.stopPropagation()
                  closeTab(t.id)
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.stopPropagation()
                    closeTab(t.id)
                  }
                }}
              >
                <X className="h-3.5 w-3.5" />
              </span>
            </button>
          ))}
        </div>
      ) : null}

      {/* ===== Nội dung: trang mới (catalog) hoặc iframe ===== */}
      <div className="relative min-h-0 flex-1">
        {showNewTab ? (
          <div className="h-full overflow-y-auto">
            <div className="mx-auto flex max-w-2xl flex-col items-center gap-6 px-6 py-12">
              <div className="flex items-center gap-2.5">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                  <Globe className="h-5 w-5" />
                </span>
                <h1 className="text-xl font-semibold">Trình duyệt WOS</h1>
              </div>
              <form
                className="flex w-full max-w-lg items-center gap-2"
                onSubmit={(e) => {
                  e.preventDefault()
                  const el = e.currentTarget.elements.namedItem('q') as HTMLInputElement
                  if (active && el.value.trim()) navigate(active.id, el.value)
                  el.value = ''
                }}
              >
                <div className="relative flex-1">
                  <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    name="q"
                    placeholder={`Tìm ${engineLabel} hoặc nhập địa chỉ…`}
                    className="h-11 rounded-full pl-9 text-[14px] shadow-sm"
                    autoFocus
                  />
                </div>
              </form>
              <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-6">
                {CATALOG.map((c) => (
                  <button
                    key={c.url}
                    onClick={() => active && navigate(active.id, c.url)}
                    className="flex w-20 flex-col items-center gap-2 rounded-xl p-2 transition hover:bg-muted"
                    title={c.url}
                  >
                    <span
                      className="flex h-12 w-12 items-center justify-center rounded-full text-lg font-semibold text-white shadow-sm"
                      style={{ background: c.hue }}
                    >
                      {c.glyph}
                    </span>
                    <span className="w-full truncate text-center text-[11.5px] text-muted-foreground">{c.name}</span>
                  </button>
                ))}
              </div>
              <p className="max-w-md text-center text-[12px] leading-relaxed text-muted-foreground">
                Mọi trang web chạy trong cửa sổ WOS. Một số trang (Google, Facebook…) chặn nhúng iframe —
                khi đó dùng nút <b>Mở tab ngoài</b> ở góc phải dưới.
              </p>
            </div>
          </div>
        ) : (
          <>
            <iframe
              key={`${active.id}-${active.iframeKey}`}
              ref={frameRef}
              src={active.url}
              title={active.title}
              className="h-full w-full border-0 bg-white"
              sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-downloads allow-modals"
              allow="clipboard-read; clipboard-write; fullscreen; autoplay; encrypted-media"
              referrerPolicy="strict-origin-when-cross-origin"
              onLoad={onFrameLoad}
            />
            {active.blocked ? (
              <div className="absolute inset-x-0 top-0 flex items-center justify-center gap-2 border-b bg-amber-500/10 px-4 py-2 text-[12.5px] text-amber-700 dark:text-amber-300">
                <TriangleAlert className="h-3.5 w-3.5 shrink-0" />
                <span className="truncate">
                  Trang này chặn nhúng (X-Frame-Options / CSP) — WOS không hiển thị được nội dung.
                </span>
                <a
                  href={active.url}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="flex shrink-0 items-center gap-1 rounded-full bg-amber-500/20 px-2.5 py-0.5 font-medium hover:bg-amber-500/30"
                >
                  <SquareArrowOutUpRight className="h-3 w-3" />
                  Mở tab ngoài
                </a>
              </div>
            ) : null}
            {/* Cửa thoát hiểm: luôn mở được URL ngoài WOS */}
            <a
              href={active.url}
              target="_blank"
              rel="noreferrer noopener"
              title="Mở trong tab trình duyệt thật"
              className="absolute bottom-3 right-3 flex h-8 w-8 items-center justify-center rounded-full bg-background/85 text-muted-foreground shadow-md backdrop-blur transition hover:text-foreground"
            >
              <SquareArrowOutUpRight className="h-4 w-4" />
            </a>
          </>
        )}
      </div>
    </div>
  )
}
