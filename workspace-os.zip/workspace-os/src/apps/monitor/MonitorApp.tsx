'use client'

/**
 * APP: System Monitor (Activity Monitor) — CPU/RAM/Đĩa/Mạng + bảng tiến trình.
 * - Poll /api/system/resources mỗi 2s (đồ thị lịch sử 60 điểm, recharts)
 * - Poll /api/system/processes mỗi 3s (CPU% delta phía server)
 * - Admin: kết thúc tiến trình (SIGTERM) — chặn tự sát (pid server WOS)
 * - Ưu tiên Orange Pi: nhẹ, không websocket, chỉ polling khi app đang mở
 */
import { useCallback, useEffect, useRef, useState } from 'react'
import { api } from '@/core/client/api'
import { useWos } from '@/core/client/wos-store'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import {
  Activity, Cpu, Flame, Gauge, HardDrive, MemoryStick, Signal, Trash2, Wifi, RefreshCw,
} from 'lucide-react'

interface Resources {
  ts: number
  cpu: { percent: number; perCore: number[]; cores: number }
  mem: { total: number; used: number; available: number; percent: number; swapTotal: number; swapUsed: number }
  disk: { total: number; used: number; free: number; percent: number }
  load: [number, number, number]
  uptime: number
  temp: number | null
  net: { rx: number; tx: number; rxPerSec: number; txPerSec: number }
}

interface Proc {
  pid: number
  name: string
  cmd: string
  user: string
  cpu: number
  rss: number
  state: string
}

interface SysInfo {
  hostname: string
  platform: string
  arch: string
  kernel: string
  boardModel: string | null
  cpuModel: string
  cores: number
  memTotal: number
  temp: number | null
  uptimeHuman: string
  nodeVersion: string
}

function fmtBytes(n: number): string {
  if (!n || n <= 0) return '0 B'
  const units = ['B', 'KB', 'MB', 'GB', 'TB']
  let v = n
  let u = 0
  while (v >= 1024 && u < units.length - 1) {
    v /= 1024
    u++
  }
  return `${v >= 100 ? Math.round(v) : v.toFixed(1).replace(/\.0$/, '')} ${units[u]}`
}

function fmtUptime(sec: number): string {
  const d = Math.floor(sec / 86400)
  const h = Math.floor((sec % 86400) / 3600)
  const m = Math.floor((sec % 3600) / 60)
  return d > 0 ? `${d} ngày ${h} giờ` : h > 0 ? `${h} giờ ${m} phút` : `${m} phút`
}

function fmtRate(bytesPerSec: number): string {
  if (bytesPerSec < 1024) return `${Math.round(bytesPerSec)} B/s`
  if (bytesPerSec < 1024 * 1024) return `${(bytesPerSec / 1024).toFixed(1)} KB/s`
  return `${(bytesPerSec / 1024 / 1024).toFixed(2)} MB/s`
}

const HISTORY = 60

export default function MonitorApp() {
  const user = useWos((s) => s.user)
  const [res, setRes] = useState<Resources | null>(null)
  const [info, setInfo] = useState<SysInfo | null>(null)
  const [procs, setProcs] = useState<Proc[]>([])
  const [me, setMe] = useState<number>(0)
  const [cpuHist, setCpuHist] = useState<{ t: string; cpu: number; mem: number }[]>([])
  const [netHist, setNetHist] = useState<{ t: string; rx: number; tx: number }[]>([])
  const [killing, setKilling] = useState<number | null>(null)
  const [showAll, setShowAll] = useState(false)
  const alive = useRef(true)

  const loadResources = useCallback(async () => {
    try {
      const d = await api<Resources>('/api/system/resources')
      if (!alive.current) return
      setRes(d)
      setCpuHist((h) =>
        [...h, { t: new Date(d.ts).toLocaleTimeString('vi-VN', { minute: '2-digit', second: '2-digit' }), cpu: d.cpu.percent, mem: d.mem.percent }].slice(-HISTORY),
      )
      setNetHist((h) =>
        [...h, { t: new Date(d.ts).toLocaleTimeString('vi-VN', { minute: '2-digit', second: '2-digit' }), rx: d.net.rxPerSec, tx: d.net.txPerSec }].slice(-HISTORY),
      )
    } catch {
      /* bỏ qua — poll tiếp */
    }
  }, [])

  const loadProcs = useCallback(async () => {
    try {
      const d = await api<{ processes: Proc[]; me: number }>('/api/system/processes?limit=150')
      if (!alive.current) return
      setProcs(d.processes)
      setMe(d.me)
    } catch {
      /* bỏ qua */
    }
  }, [])

  useEffect(() => {
    alive.current = true
    void api<SysInfo>('/api/system/info').then((d) => alive.current && setInfo(d)).catch(() => {})
    void loadResources()
    void loadProcs()
    const iv1 = setInterval(loadResources, 2000)
    const iv2 = setInterval(loadProcs, 3000)
    return () => {
      alive.current = false
      clearInterval(iv1)
      clearInterval(iv2)
    }
  }, [loadResources, loadProcs])

  const kill = async (pid: number, name: string) => {
    setKilling(pid)
    try {
      await api('/api/system/processes', { method: 'POST', body: { pid } })
      toast.success(`Đã gửi SIGTERM tới ${name} (${pid})`)
      setTimeout(loadProcs, 800)
    } catch (err) {
      toast.error(`Không kết thúc được ${name}`, {
        description: err instanceof Error ? err.message : '',
      })
    } finally {
      setKilling(null)
    }
  }

  const visibleProcs = showAll ? procs : procs.slice(0, 25)

  return (
    <div className="flex h-full w-full flex-col">
      {/* Header */}
      <div className="flex shrink-0 flex-wrap items-center gap-2 border-b px-4 py-2.5">
        <Gauge className="h-4.5 w-4.5 text-rose-500" />
        <h2 className="text-[15px] font-semibold">System Monitor</h2>
        {info ? (
          <span className="hidden truncate text-[12px] text-muted-foreground md:inline">
            {info.boardModel || info.hostname} · {info.arch} · {info.cores} nhân · lênptime {fmtUptime(res?.uptime || 0)}
          </span>
        ) : null}
        <div className="flex-1" />
        {res?.temp != null ? (
          <Badge variant={res.temp > 75 ? 'destructive' : res.temp > 60 ? 'secondary' : 'outline'} className="gap-1">
            <Flame className="h-3 w-3" />
            {res.temp}°C
          </Badge>
        ) : null}
        {res ? (
          <Badge variant="outline" className="gap-1 tabular-nums">
            <Activity className="h-3 w-3" />
            load {res.load[0].toFixed(2)}
          </Badge>
        ) : null}
        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { void loadResources(); void loadProcs() }} title="Làm mới">
          <RefreshCw className="h-3.5 w-3.5" />
        </Button>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto">
        {/* 4 thẻ tài nguyên */}
        <div className="grid grid-cols-1 gap-3 p-3 sm:grid-cols-2">
          {/* CPU */}
          <div className="rounded-xl border bg-card p-3.5 shadow-sm">
            <div className="mb-1 flex items-center gap-2">
              <Cpu className="h-4 w-4 text-sky-500" />
              <h3 className="text-[13px] font-semibold">CPU</h3>
              <span className="ml-auto text-[18px] font-bold tabular-nums">{res?.cpu.percent ?? '—'}%</span>
            </div>
            <div className="h-[70px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={cpuHist} margin={{ top: 4, right: 4, bottom: 0, left: 4 }}>
                  <defs>
                    <linearGradient id="gCpu" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#0ea5e9" stopOpacity={0.35} />
                      <stop offset="100%" stopColor="#0ea5e9" stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="t" hide />
                  <YAxis domain={[0, 100]} hide />
                  <Tooltip
                    contentStyle={{ fontSize: 11, borderRadius: 8, padding: '4px 8px' }}
                    formatter={(v: number | string) => [`${v}%`, 'CPU']}
                    labelFormatter={() => ''}
                  />
                  <Area type="monotone" dataKey="cpu" stroke="#0ea5e9" strokeWidth={1.5} fill="url(#gCpu)" isAnimationActive={false} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            {res && res.cpu.perCore.length > 0 ? (
              <div className="mt-2 flex flex-wrap gap-1">
                {res.cpu.perCore.slice(0, 16).map((c, i) => (
                  <span
                    key={i}
                    className="h-1.5 w-6 overflow-hidden rounded-full bg-muted"
                    title={`Nhân ${i}: ${c}%`}
                  >
                    <span
                      className="block h-full rounded-full transition-all"
                      style={{ width: `${c}%`, background: c > 80 ? '#ef4444' : c > 50 ? '#f59e0b' : '#0ea5e9' }}
                    />
                  </span>
                ))}
              </div>
            ) : null}
          </div>

          {/* RAM */}
          <div className="rounded-xl border bg-card p-3.5 shadow-sm">
            <div className="mb-2 flex items-center gap-2">
              <MemoryStick className="h-4 w-4 text-violet-500" />
              <h3 className="text-[13px] font-semibold">Bộ nhớ</h3>
              <span className="ml-auto text-[18px] font-bold tabular-nums">{res?.mem.percent ?? '—'}%</span>
            </div>
            <div className="flex h-[70px] items-center gap-3">
              <div className="relative h-full w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={cpuHist} margin={{ top: 4, right: 4, bottom: 0, left: 4 }}>
                    <defs>
                      <linearGradient id="gMem" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#8b5cf6" stopOpacity={0.35} />
                        <stop offset="100%" stopColor="#8b5cf6" stopOpacity={0.02} />
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="t" hide />
                    <YAxis domain={[0, 100]} hide />
                    <Tooltip
                      contentStyle={{ fontSize: 11, borderRadius: 8, padding: '4px 8px' }}
                      formatter={(v: number | string) => [`${v}%`, 'RAM']}
                      labelFormatter={() => ''}
                    />
                    <Area type="monotone" dataKey="mem" stroke="#8b5cf6" strokeWidth={1.5} fill="url(#gMem)" isAnimationActive={false} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              <div className="shrink-0 space-y-1 text-[11px] tabular-nums text-muted-foreground">
                <p>{res ? `${fmtBytes(res.mem.used)} / ${fmtBytes(res.mem.total)}` : '—'}</p>
                {res && res.mem.swapTotal > 0 ? <p>Swap {fmtBytes(res.mem.swapUsed)}</p> : null}
                <p>{res ? `rảnh ${fmtBytes(res.mem.available)}` : ''}</p>
              </div>
            </div>
          </div>

          {/* Disk */}
          <div className="rounded-xl border bg-card p-3.5 shadow-sm">
            <div className="mb-2.5 flex items-center gap-2">
              <HardDrive className="h-4 w-4 text-emerald-500" />
              <h3 className="text-[13px] font-semibold">Ổ đĩa hệ thống</h3>
              <span className="ml-auto text-[18px] font-bold tabular-nums">{res?.disk.percent ?? '—'}%</span>
            </div>
            <div className="h-2.5 overflow-hidden rounded-full bg-muted">
              <div
                className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-500 transition-all"
                style={{ width: `${res?.disk.percent ?? 0}%` }}
              />
            </div>
            <p className="mt-2 text-[11.5px] tabular-nums text-muted-foreground">
              {res ? `đã dùng ${fmtBytes(res.disk.used)} · còn ${fmtBytes(res.disk.free)} / ${fmtBytes(res.disk.total)}` : '—'}
            </p>
          </div>

          {/* Network */}
          <div className="rounded-xl border bg-card p-3.5 shadow-sm">
            <div className="mb-1 flex items-center gap-2">
              <Wifi className="h-4 w-4 text-cyan-500" />
              <h3 className="text-[13px] font-semibold">Mạng</h3>
              <span className="ml-auto flex items-center gap-2 text-[11.5px] font-medium tabular-nums">
                <span className="flex items-center gap-1">
                  <Signal className="h-3 w-3 text-emerald-500" />
                  {res ? fmtRate(res.net.rxPerSec) : '—'}
                </span>
                <span className="flex items-center gap-1">
                  <Signal className="h-3 w-3 rotate-90 text-cyan-500" />
                  {res ? fmtRate(res.net.txPerSec) : '—'}
                </span>
              </span>
            </div>
            <div className="h-[70px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={netHist} margin={{ top: 4, right: 4, bottom: 0, left: 4 }}>
                  <defs>
                    <linearGradient id="gRx" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#10b981" stopOpacity={0.35} />
                      <stop offset="100%" stopColor="#10b981" stopOpacity={0.02} />
                    </linearGradient>
                    <linearGradient id="gTx" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#06b6d4" stopOpacity={0.3} />
                      <stop offset="100%" stopColor="#06b6d4" stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="t" hide />
                  <YAxis hide />
                  <Tooltip
                    contentStyle={{ fontSize: 11, borderRadius: 8, padding: '4px 8px' }}
                    formatter={(v: number | string, n: string) => [fmtRate(Number(v)), n === 'rx' ? 'tải xuống' : 'tải lên']}
                    labelFormatter={() => ''}
                  />
                  <Area type="monotone" dataKey="rx" stroke="#10b981" strokeWidth={1.5} fill="url(#gRx)" isAnimationActive={false} />
                  <Area type="monotone" dataKey="tx" stroke="#06b6d4" strokeWidth={1.5} fill="url(#gTx)" isAnimationActive={false} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Bảng tiến trình */}
        <div className="border-t px-3 pb-3 pt-2">
          <div className="mb-2 flex items-center gap-2">
            <h3 className="text-[13px] font-semibold">Tiến trình ({procs.length})</h3>
            <div className="flex-1" />
            {procs.length > 25 ? (
              <Button variant="ghost" size="sm" className="h-6 text-[11.5px]" onClick={() => setShowAll((v) => !v)}>
                {showAll ? 'Thu gọn' : `Hiện tất cả ${procs.length}`}
              </Button>
            ) : null}
          </div>
          <div className="overflow-hidden rounded-xl border">
            <table className="w-full text-[12px]">
              <thead>
                <tr className="border-b bg-muted/50 text-left text-[11px] uppercase tracking-wide text-muted-foreground">
                  <th className="px-3 py-2 font-medium">Tên</th>
                  <th className="px-2 py-2 font-medium">PID</th>
                  <th className="px-2 py-2 font-medium">Người dùng</th>
                  <th className="px-2 py-2 text-right font-medium">CPU</th>
                  <th className="px-2 py-2 text-right font-medium">Bộ nhớ</th>
                  <th className="px-2 py-2 font-medium">Trạng thái</th>
                  {user?.role === 'admin' ? <th className="px-2 py-2" /> : null}
                </tr>
              </thead>
              <tbody>
                {visibleProcs.map((p) => (
                  <tr key={p.pid} className="border-b last:border-0 hover:bg-muted/30">
                    <td className="max-w-[280px] px-3 py-1.5">
                      <p className="truncate font-medium">{p.name}</p>
                      {p.cmd && p.cmd !== p.name ? (
                        <p className="truncate text-[10.5px] text-muted-foreground">{p.cmd.slice(0, 80)}</p>
                      ) : null}
                    </td>
                    <td className="px-2 py-1.5 tabular-nums text-muted-foreground">{p.pid}</td>
                    <td className="px-2 py-1.5 text-muted-foreground">{p.user}</td>
                    <td className={`px-2 py-1.5 text-right font-medium tabular-nums ${p.cpu > 70 ? 'text-rose-600' : p.cpu > 30 ? 'text-amber-600' : ''}`}>
                      {p.cpu}%
                    </td>
                    <td className="px-2 py-1.5 text-right tabular-nums text-muted-foreground">{fmtBytes(p.rss)}</td>
                    <td className="px-2 py-1.5 text-muted-foreground">{p.state}</td>
                    {user?.role === 'admin' ? (
                      <td className="px-2 py-1.5 text-right">
                        {p.pid !== me && p.pid > 1 ? (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6 text-muted-foreground hover:text-rose-600"
                            disabled={killing === p.pid}
                            onClick={() => void kill(p.pid, p.name)}
                            title="Kết thúc tiến trình (SIGTERM)"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        ) : null}
                      </td>
                    ) : null}
                  </tr>
                ))}
                {procs.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-3 py-6 text-center text-muted-foreground">
                      Đang đọc /proc…
                    </td>
                  </tr>
                ) : null}
              </tbody>
            </table>
          </div>
          {user?.role === 'admin' ? (
            <p className="mt-1.5 text-[11px] text-muted-foreground">
              Kết thúc tiến trình = SIGTERM (nhẹ). Tiến trình WOS chính bị khoá để không tự chết remote.
            </p>
          ) : null}
        </div>

        {/* Thông tin máy */}
        {info ? (
          <div className="border-t px-3 py-3 text-[11.5px] leading-relaxed text-muted-foreground">
            <p>
              <b className="text-foreground">{info.hostname}</b>
              {info.boardModel ? ` · ${info.boardModel}` : ''} · {info.platform}/{info.arch} · kernel {info.kernel}
            </p>
            <p>
              CPU: {info.cpuModel} ({info.cores} nhân) · RAM {fmtBytes(info.memTotal)} · Node {info.nodeVersion} · WOS 3.0
            </p>
          </div>
        ) : null}
      </div>
    </div>
  )
}
