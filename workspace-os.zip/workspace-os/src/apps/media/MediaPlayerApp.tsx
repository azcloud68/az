'use client'

/**
 * APP: Media Player (V3) — trình phát video/audio kiểu macOS QuickTime.
 * Route: 'media:<encodedPath>'. Điều khiển tự vẽ: play/pause, seek, volume,
 * tốc độ, fullscreen, tải về (Download Manager). Codec trình duyệt không chạy
 * (mkv/avi) → gợi ý tải về mở bằng VLC.
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { useRoute } from '@/core/client/route-context'
import { startFileDownload } from '@/core/client/downloads'
import { Button } from '@/components/ui/button'
import {
  Download, Loader2, Maximize, Minimize, Music2, Pause, Play, TriangleAlert, Volume2, VolumeX,
} from 'lucide-react'

const VIDEO_EXTS = ['mp4', 'webm', 'mov', 'm4v', 'avi', 'mkv']
const AUDIO_EXTS = ['mp3', 'wav', 'ogg', 'flac', 'm4a', 'aac', 'opus']
const SPEEDS = [0.5, 1, 1.5, 2]

function fmtTime(sec: number): string {
  if (!Number.isFinite(sec) || sec < 0) return '0:00'
  const h = Math.floor(sec / 3600)
  const m = Math.floor((sec % 3600) / 60)
  const s = Math.floor(sec % 60)
  return h > 0 ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` : `${m}:${String(s).padStart(2, '0')}`
}

export default function MediaPlayerApp() {
  const { route } = useRoute()
  const mediaRef = useRef<HTMLVideoElement | HTMLAudioElement | null>(null)
  const [playing, setPlaying] = useState(false)
  const [cur, setCur] = useState(0)
  const [dur, setDur] = useState(0)
  const [volume, setVolume] = useState(1)
  const [muted, setMuted] = useState(false)
  const [speed, setSpeed] = useState(1)
  const [fullscreen, setFullscreen] = useState(false)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(true)
  const seekRef = useRef<HTMLInputElement | null>(null)
  const shellRef = useRef<HTMLDivElement | null>(null)

  const { path, name, ext, isAudio } = useMemo(() => {
    const enc = route.startsWith('media:') ? route.slice(6) : ''
    let p = enc
    try {
      p = decodeURIComponent(enc)
    } catch {
      /* giữ nguyên */
    }
    const n = p.split('/').pop() || p
    const i = n.lastIndexOf('.')
    const e = i > 0 ? n.slice(i + 1).toLowerCase() : ''
    return { path: p, name: n, ext: e, isAudio: AUDIO_EXTS.includes(e) }
  }, [route])

  const url = path ? `/api/modules/files/download?path=${encodeURIComponent(path)}&inline=1` : ''

  // Bắt sự kiện media chung (video + audio)
  const wireMedia = useCallback((el: HTMLVideoElement | HTMLAudioElement) => {
    el.addEventListener('loadedmetadata', () => {
      setDur(el.duration || 0)
      setLoading(false)
    })
    el.addEventListener('timeupdate', () => setCur(el.currentTime || 0))
    el.addEventListener('play', () => setPlaying(true))
    el.addEventListener('pause', () => setPlaying(false))
    el.addEventListener('ended', () => setPlaying(false))
    el.addEventListener('error', () => {
      setLoading(false)
      setError('Trình duyệt không phát được định dạng này')
    })
    el.addEventListener('waiting', () => setLoading(true))
    el.addEventListener('playing', () => setLoading(false))
  }, [])

  const togglePlay = useCallback(() => {
    const el = mediaRef.current
    if (!el) return
    if (el.paused) void el.play().catch(() => {})
    else el.pause()
  }, [])

  const toggleFullscreen = useCallback(async () => {
    try {
      if (!document.fullscreenElement) {
        await shellRef.current?.requestFullscreen()
        setFullscreen(true)
      } else {
        await document.exitFullscreen()
        setFullscreen(false)
      }
    } catch {
      /* bỏ qua */
    }
  }, [])

  useEffect(() => {
    const onFs = () => setFullscreen(Boolean(document.fullscreenElement))
    document.addEventListener('fullscreenchange', onFs)
    return () => document.removeEventListener('fullscreenchange', onFs)
  }, [])

  // Phím cách = play/pause
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === 'Space' && mediaRef.current) {
        e.preventDefault()
        togglePlay()
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [togglePlay])

  if (!path) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-3 text-muted-foreground">
        <Music2 className="h-10 w-10 opacity-40" />
        <p className="text-[13px] font-medium">Không có tệp để phát</p>
      </div>
    )
  }

  const unsupported = !VIDEO_EXTS.includes(ext) && !AUDIO_EXTS.includes(ext)

  return (
    <div ref={shellRef} className={`flex h-full w-full flex-col bg-black ${fullscreen ? '' : ''}`}>
      {/* Vùng hiển thị */}
      <div className="relative flex min-h-0 flex-1 items-center justify-center overflow-hidden">
        {unsupported ? (
          <div className="flex max-w-md flex-col items-center gap-4 px-8 text-center">
            <TriangleAlert className="h-10 w-10 text-amber-400" />
            <div>
              <p className="text-[14px] font-semibold text-white">
                Định dạng “.{ext}” không phát được trên trình duyệt
              </p>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-white/60">
                Trình duyệt chỉ phát mp4/webm (video) và mp3/wav/ogg/flac (audio). Tải tệp về và mở bằng
                VLC hoặc trình phát trên máy để xem “.{ext}”.
              </p>
            </div>
            <Button variant="secondary" size="sm" onClick={() => startFileDownload(path)} className="gap-1.5">
              <Download className="h-3.5 w-3.5" /> Tải về máy
            </Button>
          </div>
        ) : isAudio ? (
          <>
            {/* Bìa audio: gradient + tên bài + sóng giả */}
            <div className="flex h-full w-full flex-col items-center justify-center gap-5 px-8">
              <div
                className="flex h-40 w-40 items-center justify-center rounded-2xl shadow-2xl"
                style={{
                  background: `linear-gradient(135deg, hsl(${(name.length * 37) % 360} 70% 55%), hsl(${(name.length * 37 + 60) % 360} 70% 40%))`,
                }}
              >
                <Music2 className={`h-14 w-14 text-white/90 ${playing ? 'animate-pulse' : ''}`} />
              </div>
              <p className="max-w-md truncate text-center text-[15px] font-semibold text-white">{name}</p>
              <div className="flex h-8 items-end gap-1" aria-hidden>
                {Array.from({ length: 28 }).map((_, i) => (
                  <span
                    key={i}
                    className="w-1 rounded-full bg-white/40"
                    style={{
                      height: `${playing ? 20 + Math.abs(Math.sin(i * 1.7 + cur * 2)) * 80 : 12}%`,
                      transition: 'height .18s ease',
                    }}
                  />
                ))}
              </div>
              <audio
                ref={(el) => {
                  mediaRef.current = el
                  if (el) wireMedia(el)
                }}
                src={url}
                autoPlay
                className="hidden"
              />
            </div>
          </>
        ) : (
          <>
            <video
              ref={(el) => {
                mediaRef.current = el
                if (el) wireMedia(el)
              }}
              src={url}
              autoPlay
              playsInline
              className="h-full w-full object-contain"
              onClick={togglePlay}
            />
            {loading && !error ? (
              <div className="absolute inset-0 flex items-center justify-center">
                <Loader2 className="h-8 w-8 animate-spin text-white/80" />
              </div>
            ) : null}
            {error ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/80 text-center">
                <TriangleAlert className="h-9 w-9 text-amber-400" />
                <p className="max-w-sm px-6 text-[13px] text-white/75">
                  Không phát được “{name}” — codec không được trình duyệt hỗ trợ (vd mkv/avi H.265).
                </p>
                <Button variant="secondary" size="sm" onClick={() => startFileDownload(path)} className="gap-1.5">
                  <Download className="h-3.5 w-3.5" /> Tải về mở bằng VLC
                </Button>
              </div>
            ) : null}
          </>
        )}
      </div>

      {/* ===== Thanh điều khiển kiểu macOS ===== */}
      {!unsupported ? (
        <div className="flex shrink-0 flex-col gap-1 bg-black/95 px-4 pb-3 pt-2.5">
          {/* Thanh tiến trình */}
          <div className="flex items-center gap-2 text-[11px] tabular-nums text-white/70">
            <span className="w-12 text-right">{fmtTime(cur)}</span>
            <input
              ref={seekRef}
              type="range"
              min={0}
              max={dur || 0}
              step={0.1}
              value={Math.min(cur, dur || 0)}
              onChange={(e) => {
                const el = mediaRef.current
                if (el) {
                  el.currentTime = Number(e.target.value)
                  setCur(Number(e.target.value))
                }
              }}
              className="h-1.5 flex-1 cursor-pointer appearance-none rounded-full bg-white/20 accent-white
                         [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:appearance-none
                         [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-white"
              style={{
                background: `linear-gradient(to right, #fff ${dur ? (cur / dur) * 100 : 0}%, rgba(255,255,255,0.2) ${dur ? (cur / dur) * 100 : 0}%)`,
              }}
              aria-label="Vị trí phát"
            />
            <span className="w-12">{fmtTime(dur)}</span>
          </div>

          {/* Hàng nút */}
          <div className="flex items-center gap-1">
            <button
              onClick={togglePlay}
              className="flex h-9 w-9 items-center justify-center rounded-full bg-white text-black transition hover:bg-white/90"
              aria-label={playing ? 'Tạm dừng' : 'Phát'}
              title={playing ? 'Tạm dừng (Space)' : 'Phát (Space)'}
            >
              {playing ? <Pause className="h-4.5 w-4.5" /> : <Play className="h-4.5 w-4.5 translate-x-[1px]" />}
            </button>

            <div className="ml-1.5 flex items-center gap-1.5">
              <button
                onClick={() => {
                  const el = mediaRef.current
                  if (el) {
                    const v = el.muted ? 1 : 0
                    el.muted = v === 0
                    setMuted(v === 0)
                    if (v === 1) setVolume(1)
                  }
                }}
                className="flex h-7 w-7 items-center justify-center rounded-full text-white/70 hover:text-white"
                aria-label={muted ? 'Bật âm thanh' : 'Tắt âm thanh'}
              >
                {muted || volume === 0 ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
              </button>
              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={muted ? 0 : volume}
                onChange={(e) => {
                  const el = mediaRef.current
                  const v = Number(e.target.value)
                  setVolume(v)
                  setMuted(v === 0)
                  if (el) {
                    el.volume = v
                    el.muted = v === 0
                  }
                }}
                className="h-1 w-20 cursor-pointer appearance-none rounded-full bg-white/20
                           [&::-webkit-slider-thumb]:h-2.5 [&::-webkit-slider-thumb]:w-2.5 [&::-webkit-slider-thumb]:appearance-none
                           [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-white"
                style={{
                  background: `linear-gradient(to right, #fff ${(muted ? 0 : volume) * 100}%, rgba(255,255,255,0.2) ${(muted ? 0 : volume) * 100}%)`,
                }}
                aria-label="Âm lượng"
              />
            </div>

            <div className="flex-1 truncate px-3 text-center text-[12px] font-medium text-white/80">{name}</div>

            {/* Tốc độ */}
            <button
              onClick={() => {
                const el = mediaRef.current
                const next = SPEEDS[(SPEEDS.indexOf(speed) + 1) % SPEEDS.length]
                setSpeed(next)
                if (el) el.playbackRate = next
              }}
              className="rounded-md px-2 py-1 text-[11.5px] font-semibold tabular-nums text-white/70 transition hover:bg-white/10 hover:text-white"
              title="Tốc độ phát"
            >
              {speed}×
            </button>

            <button
              onClick={() => startFileDownload(path)}
              className="flex h-7 w-7 items-center justify-center rounded-full text-white/70 hover:text-white"
              aria-label="Tải về"
              title="Tải về máy"
            >
              <Download className="h-4 w-4" />
            </button>

            {!isAudio ? (
              <button
                onClick={() => void toggleFullscreen()}
                className="flex h-7 w-7 items-center justify-center rounded-full text-white/70 hover:text-white"
                aria-label="Toàn màn hình"
                title="Toàn màn hình"
              >
                {fullscreen ? <Minimize className="h-4 w-4" /> : <Maximize className="h-4 w-4" />}
              </button>
            ) : null}
          </div>
        </div>
      ) : null}
    </div>
  )
}
