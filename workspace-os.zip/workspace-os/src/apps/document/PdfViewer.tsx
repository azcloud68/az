'use client'

/**
 * Document Engine — PDF Viewer (pdfjs-dist v6).
 * Canvas render 1 trang + thanh công cụ: trang x/y, zoom −/+/reset, xoay 90°,
 * prev/next (phím ←/→), scale theo độ rộng container (ResizeObserver).
 */
import { useCallback, useEffect, useRef, useState } from 'react'
import * as pdfjs from 'pdfjs-dist'
import {
  Button } from '@/components/ui/button'
import { ChevronLeft, ChevronRight, Download, Loader2, RotateCw, ZoomIn, ZoomOut } from 'lucide-react'
import { startFileDownload } from '@/core/client/downloads'

// Worker đã copy vào public/ (xây zipfile kèm theo) — set 1 lần
if (typeof window !== 'undefined' && !pdfjs.GlobalWorkerOptions.workerSrc) {
  pdfjs.GlobalWorkerOptions.workerSrc = '/pdf.worker.min.mjs'
}

interface Props {
  path: string
  url: string
}

export function PdfViewer({ path, url }: Props) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const wrapRef = useRef<HTMLDivElement | null>(null)
  const taskRef = useRef<pdfjs.PDFDocumentLoadingTask | null>(null)
  const docRef = useRef<pdfjs.PDFDocumentProxy | null>(null)
  const [numPages, setNumPages] = useState(0)
  const [page, setPage] = useState(1)
  const [zoom, setZoom] = useState(1) // 1 = vừa độ rộng
  const [rotate, setRotate] = useState(0)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  // Tải document 1 lần
  useEffect(() => {
    let disposed = false
    setLoading(true)
    setError('')
    ;(async () => {
      try {
        const res = await fetch(url)
        if (!res.ok) throw new Error(`HTTP ${res.status}`)
        const data = new Uint8Array(await res.arrayBuffer())
        const task = pdfjs.getDocument({ data })
        const doc = await task.promise
        if (disposed) {
          void task.destroy()
          return
        }
        taskRef.current = task
        docRef.current = doc
        setNumPages(doc.numPages)
        setPage(1)
        setLoading(false)
      } catch (err) {
        if (!disposed) {
          setError(err instanceof Error ? err.message : 'Không đọc được tệp PDF')
          setLoading(false)
        }
      }
    })()
    return () => {
      disposed = true
      void taskRef.current?.destroy()
      taskRef.current = null
      docRef.current = null
    }
  }, [url])

  // Vẽ trang hiện tại (page/zoom/rotate/container width)
  const renderPage = useCallback(async () => {
    const doc = docRef.current
    const canvas = canvasRef.current
    if (!doc || !canvas || page < 1 || page > doc.numPages) return
    const p = await doc.getPage(page)
    const containerW = Math.max(280, wrapRef.current?.clientWidth || 800) - 32
    const base = p.getViewport({ scale: 1, rotation: (p.rotate + rotate) % 360 })
    const fitScale = (containerW / base.width) * zoom
    const viewport = p.getViewport({ scale: fitScale, rotation: (p.rotate + rotate) % 360 })
    const dpr = Math.min(2, window.devicePixelRatio || 1)
    canvas.width = Math.floor(viewport.width * dpr)
    canvas.height = Math.floor(viewport.height * dpr)
    canvas.style.width = `${Math.floor(viewport.width)}px`
    canvas.style.height = `${Math.floor(viewport.height)}px`
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    const task = p.render({
      canvas,
      viewport,
      transform: dpr !== 1 ? [dpr, 0, 0, dpr, 0, 0] : undefined,
    })
    await task.promise
  }, [page, zoom, rotate])

  useEffect(() => {
    void renderPage().catch(() => {})
  }, [renderPage, numPages, loading])

  // Re-render khi container đổi kích thước (resize cửa sổ)
  useEffect(() => {
    if (!wrapRef.current) return
    const ro = new ResizeObserver(() => void renderPage().catch(() => {}))
    ro.observe(wrapRef.current)
    return () => ro.disconnect()
  }, [renderPage])

  // Phím ←/→
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') setPage((v) => Math.max(1, v - 1))
      else if (e.key === 'ArrowRight') setPage((v) => Math.min(numPages, v + 1))
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [numPages])

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center gap-2 text-muted-foreground">
        <Loader2 className="h-5 w-5 animate-spin" />
        <span className="text-[13px]">Đang mở tệp PDF…</span>
      </div>
    )
  }
  if (error) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-3 text-muted-foreground">
        <p className="text-[13px]">Không đọc được tệp PDF — {error}</p>
        <Button variant="secondary" size="sm" onClick={() => startFileDownload(path)}>
          <Download className="h-3.5 w-3.5" /> Tải về xem offline
        </Button>
      </div>
    )
  }

  return (
    <div ref={wrapRef} className="flex h-full w-full flex-col">
      {/* Thanh công cụ */}
      <div className="flex h-11 shrink-0 items-center gap-1.5 border-b px-3">
        <Button variant="ghost" size="icon" className="h-7 w-7" disabled={page <= 1} onClick={() => setPage((v) => Math.max(1, v - 1))} title="Trang trước (←)">
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <span className="min-w-16 text-center text-[12.5px] font-medium tabular-nums">
          {page} / {numPages}
        </span>
        <Button variant="ghost" size="icon" className="h-7 w-7" disabled={page >= numPages} onClick={() => setPage((v) => Math.min(numPages, v + 1))} title="Trang sau (→)">
          <ChevronRight className="h-4 w-4" />
        </Button>
        <div className="mx-1.5 h-4 w-px bg-border" />
        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setZoom((z) => Math.max(0.4, +(z - 0.15).toFixed(2)))} title="Thu nhỏ">
          <ZoomOut className="h-4 w-4" />
        </Button>
        <button
          className="min-w-12 rounded px-1 text-center text-[12px] font-medium tabular-nums hover:bg-accent"
          onClick={() => setZoom(1)}
          title="Vừa khít chiều rộng"
        >
          {Math.round(zoom * 100)}%
        </button>
        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setZoom((z) => Math.min(4, +(z + 0.15).toFixed(2)))} title="Phóng to">
          <ZoomIn className="h-4 w-4" />
        </Button>
        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setRotate((r) => (r + 90) % 360)} title="Xoay 90°">
          <RotateCw className="h-4 w-4" />
        </Button>
        <div className="flex-1" />
        <Button variant="ghost" size="sm" className="h-7 gap-1.5 text-[12px]" onClick={() => startFileDownload(path)} title="Tải về">
          <Download className="h-3.5 w-3.5" />
          Tải về
        </Button>
      </div>

      {/* Trang */}
      <div className="min-h-0 flex-1 overflow-auto bg-neutral-200 p-4 dark:bg-neutral-900">
        <div className="flex min-h-full items-start justify-center">
          <canvas ref={canvasRef} className="rounded-md bg-white shadow-lg" />
        </div>
      </div>
    </div>
  )
}
