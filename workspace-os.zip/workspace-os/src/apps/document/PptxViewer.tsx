'use client'

/**
 * Document Engine — PPTX Viewer (JSZip parse XML).
 * Trích xuất văn bản từng slide (thẻ <a:t>) — chế độ xem text của slide,
 * điều hướng + danh sách slide + nút Present (chiếu to trong khung cửa sổ).
 * Đồ hoạ nâng cao của PowerPoint chưa render được — hiển thị rõ ghi chú này.
 */
import { useCallback, useEffect, useRef, useState } from 'react'
import JSZip from 'jszip'
import { Button } from '@/components/ui/button'
import { ChevronLeft, ChevronRight, Download, Loader2, Maximize2, Minimize2, Presentation } from 'lucide-react'
import { startFileDownload } from '@/core/client/downloads'

interface Props {
  path: string
  url: string
}

interface Slide {
  n: number
  lines: string[]
}

/** Đọc 1 slide XML → mảng đoạn văn (mỗi <a:p> là 1 đoạn gồm các <a:t> ghép lại) */
async function parseSlide(zip: JSZip, file: string): Promise<string[]> {
  const xml = await zip.file(file)?.async('string')
  if (!xml) return []
  const paragraphs = xml.match(/<a:p[\s>][\s\S]*?<\/a:p>|<a:p\/>/g) || []
  const lines: string[] = []
  for (const p of paragraphs) {
    const runs = p.match(/<a:t>([\s\S]*?)<\/a:t>/g) || []
    const text = runs
      .map((r) => r.replace(/<a:t>|<\/a:t>/g, ''))
      .join('')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'")
      .trim()
    if (text) lines.push(text)
  }
  if (lines.length === 0) lines.push('') // slide trống vẫn giữ chỗ
  return lines
}

export function PptxViewer({ path, url }: Props) {
  const [slides, setSlides] = useState<Slide[]>([])
  const [idx, setIdx] = useState(0)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [present, setPresent] = useState(false)
  const stageRef = useRef<HTMLDivElement | null>(null)

  useEffect(() => {
    let disposed = false
    setLoading(true)
    setError('')
    ;(async () => {
      try {
        const res = await fetch(url)
        if (!res.ok) throw new Error(`HTTP ${res.status}`)
        const buf = await res.arrayBuffer()
        if (disposed) return
        const zip = await JSZip.loadAsync(buf)
        const names = Object.keys(zip.files)
          .filter((n) => /^ppt\/slides\/slide\d+\.xml$/.test(n))
          .sort((a, b) => {
            const na = Number(a.match(/(\d+)/)![1])
            const nb = Number(b.match(/(\d+)/)![1])
            return na - nb
          })
        const out: Slide[] = []
        for (let i = 0; i < names.length; i++) {
          out.push({ n: i + 1, lines: await parseSlide(zip, names[i]) })
        }
        if (disposed) return
        setSlides(out)
        setIdx(0)
        setLoading(false)
      } catch (err) {
        if (!disposed) {
          setError(err instanceof Error ? err.message : 'Không đọc được tệp PowerPoint')
          setLoading(false)
        }
      }
    })()
    return () => {
      disposed = true
    }
  }, [url])

  const go = useCallback(
    (d: 1 | -1) => setIdx((v) => Math.max(0, Math.min(slides.length - 1, v + d))),
    [slides.length],
  )

  // Phím ←/→ khi đang Present
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') go(-1)
      else if (e.key === 'ArrowRight') go(1)
      else if (e.key === 'Escape') setPresent(false)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [go])

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center gap-2 text-muted-foreground">
        <Loader2 className="h-5 w-5 animate-spin" />
        <span className="text-[13px]">Đang mở tệp PowerPoint…</span>
      </div>
    )
  }
  if (error) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-3 text-muted-foreground">
        <p className="text-[13px]">Không đọc được tệp PowerPoint — {error}</p>
        <Button variant="secondary" size="sm" onClick={() => startFileDownload(path)}>
          <Download className="h-3.5 w-3.5" /> Tải về mở bằng PowerPoint
        </Button>
      </div>
    )
  }

  const slide = slides[idx]

  if (present) {
    return (
      <div ref={stageRef} className="flex h-full w-full flex-col bg-black">
        <div className="flex min-h-0 flex-1 flex-col items-center justify-center px-[6%]">
          {slide.lines.length > 0 && slide.lines[0] ? (
            <h2 className="mb-6 max-w-4xl text-center text-[clamp(20px,4vw,42px)] font-bold leading-snug text-white">
              {slide.lines[0]}
            </h2>
          ) : null}
          <div className="flex max-h-[50%] w-full max-w-3xl flex-col items-center gap-3 overflow-hidden">
            {slide.lines.slice(1).map((l, i) =>
              l ? (
                <p key={i} className="text-center text-[clamp(12px,1.6vw,18px)] leading-relaxed text-white/80">
                  {l}
                </p>
              ) : null,
            )}
          </div>
        </div>
        <div className="flex h-12 shrink-0 items-center gap-2 px-4 text-white/60">
          <Button variant="ghost" size="icon" className="h-8 w-8 text-white/80 hover:bg-white/10" onClick={() => go(-1)} disabled={idx === 0}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <span className="text-[12.5px] tabular-nums">
            {idx + 1} / {slides.length}
          </span>
          <Button variant="ghost" size="icon" className="h-8 w-8 text-white/80 hover:bg-white/10" onClick={() => go(1)} disabled={idx >= slides.length - 1}>
            <ChevronRight className="h-4 w-4" />
          </Button>
          <div className="flex-1" />
          <Button variant="ghost" size="sm" className="h-8 gap-1.5 text-[12px] text-white/80 hover:bg-white/10" onClick={() => setPresent(false)}>
            <Minimize2 className="h-3.5 w-3.5" /> Thoát chiếu (Esc)
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-full w-full">
      {/* Danh sách slide */}
      <div className="hidden w-44 shrink-0 overflow-y-auto border-r bg-muted/30 p-2 md:block">
        {slides.map((s, i) => (
          <button
            key={s.n}
            onClick={() => setIdx(i)}
            className={`mb-2 flex w-full flex-col overflow-hidden rounded-lg border text-left transition ${
              i === idx ? 'border-primary ring-1 ring-primary/40' : 'border-border hover:bg-muted'
            }`}
          >
            <span className="flex aspect-video items-center justify-center overflow-hidden bg-background p-2">
              <span className="line-clamp-3 text-[10px] leading-snug text-muted-foreground">
                {s.lines.slice(0, 3).join(' ') || '— trống —'}
              </span>
            </span>
            <span className="border-t bg-muted/50 px-2 py-1 text-[10px] font-medium text-muted-foreground">
              Slide {s.n}
            </span>
          </button>
        ))}
      </div>

      {/* Sân khấu */}
      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex h-11 shrink-0 items-center gap-1.5 border-b px-3">
          <Button variant="ghost" size="icon" className="h-7 w-7" disabled={idx === 0} onClick={() => go(-1)} title="Slide trước (←)">
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <span className="min-w-16 text-center text-[12.5px] font-medium tabular-nums">
            {idx + 1} / {slides.length}
          </span>
          <Button variant="ghost" size="icon" className="h-7 w-7" disabled={idx >= slides.length - 1} onClick={() => go(1)} title="Slide sau (→)">
            <ChevronRight className="h-4 w-4" />
          </Button>
          <div className="flex-1" />
          <Button variant="ghost" size="sm" className="h-7 gap-1.5 text-[12px]" onClick={() => setPresent(true)} title="Chiếu toàn màn hình cửa sổ">
            <Presentation className="h-3.5 w-3.5" />
            Present
          </Button>
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => startFileDownload(path)} title="Tải về">
            <Download className="h-3.5 w-3.5" />
          </Button>
        </div>

        <div className="min-h-0 flex-1 overflow-auto bg-neutral-200 p-4 dark:bg-neutral-900">
          <div className="mx-auto flex aspect-video w-full max-w-3xl flex-col items-center justify-center gap-4 rounded-lg bg-white px-8 py-6 shadow-lg dark:bg-neutral-100">
            {slide?.lines[0] ? (
              <h3 className="text-center text-[clamp(16px,2.4vw,26px)] font-bold leading-snug">{slide.lines[0]}</h3>
            ) : (
              <span className="text-[12px] text-muted-foreground">— slide không có văn bản —</span>
            )}
            {slide?.lines.slice(1).map((l, i) =>
              l ? (
                <p key={i} className="max-w-2xl text-center text-[13.5px] leading-relaxed text-neutral-600">
                  {l}
                </p>
              ) : null,
            )}
          </div>
          <p className="mt-3 text-center text-[11px] text-muted-foreground">
            Chế độ xem văn bản của slide — đồ hoạ nâng cao (hình ảnh, biểu đồ) chưa hiển thị
          </p>
        </div>
      </div>
    </div>
  )
}
