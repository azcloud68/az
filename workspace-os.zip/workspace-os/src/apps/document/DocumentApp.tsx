'use client'

/**
 * APP: Documents — Document Engine (V3) — mở PDF/DOCX/XLSX/PPTX ngay trên desktop WOS.
 * Route: 'doc:<encodedPath>'. Theo phần mở rộng → viewer phù hợp; ext lạ → gợi ý
 * mở bằng trình xem văn bản. Mọi viewer tải qua stream API của File Manager
 * (hỗ trợ Range, không phình RAM với tệp lớn).
 */
import { useMemo, useState } from 'react'
import { useRoute } from '@/core/client/route-context'
import { useWindows } from '@/core/client/window-store'
import { startFileDownload } from '@/core/client/downloads'
import { Button } from '@/components/ui/button'
import { FileQuestion, FileText, TriangleAlert } from 'lucide-react'
import { PdfViewer } from './PdfViewer'
import { DocxViewer } from './DocxViewer'
import { XlsxViewer } from './XlsxViewer'
import { PptxViewer } from './PptxViewer'

function extOf(name: string): string {
  const n = name.split('/').pop() || ''
  const i = n.lastIndexOf('.')
  return i > 0 ? n.slice(i + 1).toLowerCase() : ''
}

export default function DocumentApp() {
  const { route } = useRoute()
  const openApp = useWindows((s) => s.openApp)

  const { path, encoded } = useMemo(() => {
    const enc = route.startsWith('doc:') ? route.slice(4) : ''
    let p = enc
    try {
      p = decodeURIComponent(enc)
    } catch {
      /* giữ nguyên */
    }
    return { path: p, encoded: enc }
  }, [route])

  const ext = extOf(path)
  const url = path ? `/api/modules/files/download?path=${encodeURIComponent(path)}&inline=1` : ''
  const [fallbackTried, setFallbackTried] = useState(false)

  if (!path) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-3 text-muted-foreground">
        <FileText className="h-10 w-10 opacity-40" />
        <p className="text-[13px] font-medium">Không có tệp để mở</p>
      </div>
    )
  }

  switch (ext) {
    case 'pdf':
      return <PdfViewer path={path} url={url} />
    case 'docx':
      return <DocxViewer path={path} url={url} />
    case 'xlsx':
    case 'xls':
    case 'csv':
    case 'tsv':
      return <XlsxViewer path={path} url={url} ext={ext} />
    case 'pptx':
      return <PptxViewer path={path} url={url} />
    default: {
      // ext không thuộc Document Engine → gợi ý mở bằng trình xem văn bản (text/ảnh)
      return (
        <div className="flex h-full flex-col items-center justify-center gap-4 px-8 text-center">
          {fallbackTried ? (
            <div className="flex flex-col items-center gap-2 text-muted-foreground">
              <TriangleAlert className="h-8 w-8 text-amber-500" />
              <p className="text-[13px]">Không mở được tệp này</p>
            </div>
          ) : (
            <>
              <FileQuestion className="h-10 w-10 text-muted-foreground/60" />
              <div>
                <p className="text-[14px] font-semibold">Không mở được “.{ext || 'không rõ'}” bằng Documents</p>
                <p className="mt-1 text-[12.5px] text-muted-foreground">
                  Tệp: <span className="font-medium text-foreground">{path.split('/').pop()}</span>
                </p>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => {
                    setFallbackTried(true)
                    openApp('viewer', { key: `v:${encoded}`, route: `viewer:${encoded}` })
                  }}
                >
                  <FileText className="h-3.5 w-3.5" /> Mở bằng trình xem văn bản
                </Button>
                <Button variant="outline" size="sm" onClick={() => startFileDownload(path)}>
                  Tải về máy
                </Button>
              </div>
            </>
          )}
        </div>
      )
    }
  }
}
