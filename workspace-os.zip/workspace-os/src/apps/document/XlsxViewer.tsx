'use client'

/**
 * Document Engine — XLSX/CSV Viewer (SheetJS).
 * Tabs sheet, header sticky, cell ellipsis, click cell → xem giá trị đầy đủ.
 */
import { useEffect, useMemo, useState } from 'react'
import * as XLSX from 'xlsx'
import { Button } from '@/components/ui/button'
import { Download, Loader2, Table2 } from 'lucide-react'
import { startFileDownload } from '@/core/client/downloads'

interface Props {
  path: string
  url: string
  ext: string
}

interface SheetData {
  name: string
  rows: string[][]
}

export function XlsxViewer({ path, url, ext }: Props) {
  const [sheets, setSheets] = useState<SheetData[]>([])
  const [active, setActive] = useState(0)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [selected, setSelected] = useState<{ r: number; c: number; v: string } | null>(null)

  useEffect(() => {
    let disposed = false
    setLoading(true)
    setError('')
    ;(async () => {
      try {
        const res = await fetch(url)
        if (!res.ok) throw new Error(`HTTP ${res.status}`)
        const buf = await res.arrayBuffer()
        if (disposed) return
        const out: SheetData[] = []
        if (ext === 'csv' || ext === 'tsv') {
          const text = new TextDecoder().decode(buf)
          const delim = ext === 'tsv' ? '\t' : ','
          const rows = text.split(/\r?\n/).filter((l) => l.length > 0).map((l) => l.split(delim))
          out.push({ name: 'CSV', rows })
        } else {
          const wb = XLSX.read(buf, { type: 'array' })
          for (const name of wb.SheetNames) {
            const ws = wb.Sheets[name]
            const rows = XLSX.utils.sheet_to_json<string[]>(ws, { header: 1, raw: false, defval: '' })
            out.push({ name, rows: rows.map((r) => (Array.isArray(r) ? r.map((c) => String(c ?? '')) : [])) })
          }
        }
        if (disposed) return
        setSheets(out)
        setActive(0)
        setLoading(false)
      } catch (err) {
        if (!disposed) {
          setError(err instanceof Error ? err.message : 'Không đọc được bảng tính')
          setLoading(false)
        }
      }
    })()
    return () => {
      disposed = true
    }
  }, [url, ext])

  const sheet = sheets[active]
  const maxCols = useMemo(() => {
    if (!sheet) return 0
    return sheet.rows.reduce((m, r) => Math.max(m, r.length), 0)
  }, [sheet])

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center gap-2 text-muted-foreground">
        <Loader2 className="h-5 w-5 animate-spin" />
        <span className="text-[13px]">Đang mở bảng tính…</span>
      </div>
    )
  }
  if (error) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-3 text-muted-foreground">
        <p className="text-[13px]">Không đọc được bảng tính — {error}</p>
        <Button variant="secondary" size="sm" onClick={() => startFileDownload(path)}>
          <Download className="h-3.5 w-3.5" /> Tải về mở bằng Excel
        </Button>
      </div>
    )
  }

  return (
    <div className="flex h-full w-full flex-col">
      {/* Thanh công cụ + tabs sheet */}
      <div className="flex h-11 shrink-0 items-center gap-1 overflow-x-auto border-b px-3">
        <Table2 className="h-4 w-4 shrink-0 text-emerald-600" />
        {sheets.length > 1 ? (
          sheets.map((s, i) => (
            <button
              key={s.name + i}
              onClick={() => {
                setActive(i)
                setSelected(null)
              }}
              className={`shrink-0 rounded-md px-2.5 py-1 text-[12px] font-medium transition ${
                i === active ? 'bg-accent text-accent-foreground' : 'text-muted-foreground hover:bg-muted'
              }`}
            >
              {s.name}
            </button>
          ))
        ) : (
          <span className="px-1.5 text-[12.5px] font-medium">{sheet?.name}</span>
        )}
        <span className="shrink-0 text-[11.5px] text-muted-foreground">
          {sheet ? `${sheet.rows.length} hàng · ${maxCols} cột` : ''}
        </span>
        <div className="flex-1" />
        <Button variant="ghost" size="sm" className="h-7 shrink-0 gap-1.5 text-[12px]" onClick={() => startFileDownload(path)}>
          <Download className="h-3.5 w-3.5" />
          Tải về
        </Button>
      </div>

      {/* Bảng */}
      <div className="min-h-0 flex-1 overflow-auto">
        {sheet && sheet.rows.length > 0 ? (
          <table className="w-full border-collapse text-[12px]">
            <thead className="sticky top-0 z-10">
              <tr>
                <th className="w-10 border-b border-r bg-muted px-2 py-1.5 text-right text-[10.5px] font-medium text-muted-foreground">
                  #
                </th>
                {Array.from({ length: maxCols }).map((_, c) => {
                  const colName = XLSX.utils.encode_col(c)
                  return (
                    <th
                      key={c}
                      className="border-b border-r bg-muted px-3 py-1.5 text-left text-[11px] font-semibold uppercase tracking-wide text-muted-foreground"
                    >
                      {colName}
                    </th>
                  )
                })}
              </tr>
            </thead>
            <tbody>
              {sheet.rows.map((row, r) => (
                <tr key={r} className="hover:bg-muted/40">
                  <td className="border-b border-r bg-muted/50 px-2 py-1 text-right text-[10.5px] tabular-nums text-muted-foreground">
                    {r + 1}
                  </td>
                  {Array.from({ length: maxCols }).map((_, c) => {
                    const v = row[c] ?? ''
                    const isSel = selected?.r === r && selected?.c === c
                    const isHeader = r === 0 && v !== ''
                    return (
                      <td
                        key={c}
                        onClick={() => setSelected(v ? { r, c, v } : null)}
                        className={`max-w-56 cursor-default truncate border-b border-r px-3 py-1.5 ${
                          isSel ? 'bg-primary/15 ring-1 ring-inset ring-primary/40' : isHeader ? 'font-semibold' : ''
                        }`}
                        title={v}
                      >
                        {v}
                      </td>
                    )
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div className="flex h-40 items-center justify-center text-[13px] text-muted-foreground">Bảng tính trống</div>
        )}
      </div>

      {/* Thanh giá trị cell đang chọn */}
      {selected ? (
        <div className="flex shrink-0 items-center gap-2 border-t bg-muted/40 px-3 py-1.5 text-[12px]">
          <span className="rounded bg-muted px-1.5 py-0.5 text-[10.5px] font-semibold tabular-nums text-muted-foreground">
            {XLSX.utils.encode_cell({ r: selected.r, c: selected.c })}
          </span>
          <span className="min-w-0 flex-1 truncate" title={selected.v}>
            {selected.v}
          </span>
          <button className="text-[11px] text-muted-foreground hover:text-foreground" onClick={() => setSelected(null)}>
            đóng ✕
          </button>
        </div>
      ) : null}
    </div>
  )
}
