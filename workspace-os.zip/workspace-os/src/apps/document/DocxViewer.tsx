'use client'

/**
 * Document Engine — DOCX Viewer (docx-preview).
 * Trang giấy trắng ở giữa nền xám (kiểu Word Online), scroll dọc, zoom −/+.
 */
import { useEffect, useRef, useState } from 'react'
import { renderAsync } from 'docx-preview'
import { Button } from '@/components/ui/button'
import { Download, Loader2, ZoomIn, ZoomOut } from 'lucide-react'
import { startFileDownload } from '@/core/client/downloads'

interface Props {
  path: string
  url: string
}

export function DocxViewer({ path, url }: Props) {
  const containerRef = useRef<HTMLDivElement | null>(null)
  const [zoom, setZoom] = useState(1)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    let disposed = false
    setLoading(true)
    setError('')
    ;(async () => {
      try {
        const res = await fetch(url)
        if (!res.ok) throw new Error(`HTTP ${res.status}`)
        const data = await res.arrayBuffer()
        if (disposed || !containerRef.current) return
        containerRef.current.innerHTML = ''
        await renderAsync(data, containerRef.current, undefined, {
          inWrapper: true,
          ignoreWidth: false,
          ignoreHeight: false,
          ignoreFonts: false,
        })
        if (!disposed) setLoading(false)
      } catch (err) {
        if (!disposed) {
          setError(err instanceof Error ? err.message : 'Không đọc được tệp Word')
          setLoading(false)
        }
      }
    })()
    return () => {
      disposed = true
    }
  }, [url])

  return (
    <div className="flex h-full w-full flex-col">
      <div className="flex h-11 shrink-0 items-center gap-1.5 border-b px-3">
        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setZoom((z) => Math.max(0.5, +(z - 0.1).toFixed(2)))} title="Thu nhỏ">
          <ZoomOut className="h-4 w-4" />
        </Button>
        <button
          className="min-w-12 rounded px-1 text-center text-[12px] font-medium tabular-nums hover:bg-accent"
          onClick={() => setZoom(1)}
          title="Kích thước chuẩn"
        >
          {Math.round(zoom * 100)}%
        </button>
        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setZoom((z) => Math.min(2.5, +(z + 0.1).toFixed(2)))} title="Phóng to">
          <ZoomIn className="h-4 w-4" />
        </Button>
        <div className="flex-1" />
        <Button variant="ghost" size="sm" className="h-7 gap-1.5 text-[12px]" onClick={() => startFileDownload(path)} title="Tải về">
          <Download className="h-3.5 w-3.5" />
          Tải về
        </Button>
      </div>

      <div className="min-h-0 flex-1 overflow-auto bg-neutral-200 p-4 dark:bg-neutral-900">
        {/* Container luôn được mount (hiệu ứng render chạy ngay từ đầu — ref phải sẵn sàng) */}
        <div className="flex justify-center">
          <div
            ref={containerRef}
            className="origin-top"
            style={{ transform: `scale(${zoom})`, marginBottom: `${(zoom - 1) * 400}px` }}
          />
        </div>
        {loading ? (
          <div className="flex h-64 items-center justify-center gap-2 text-muted-foreground">
            <Loader2 className="h-5 w-5 animate-spin" />
            <span className="text-[13px]">Đang mở tệp Word…</span>
          </div>
        ) : null}
        {error ? (
          <div className="flex h-64 flex-col items-center justify-center gap-3 text-muted-foreground">
            <p className="text-[13px]">Không đọc được tệp Word — {error}</p>
            <Button variant="secondary" size="sm" onClick={() => startFileDownload(path)}>
              <Download className="h-3.5 w-3.5" /> Tải về mở bằng Word
            </Button>
          </div>
        ) : null}
      </div>
    </div>
  )
}
