'use client'

import { useEffect, useState, useCallback } from 'react'
import { useWos } from '@/core/client/wos-store'
import { api, timeAgo, formatBytes } from '@/core/client/api'
import { bus } from '@/core/client/event-bus'
import { TasksTodayWidget, TasksStatsWidget } from '@/modules/tasks/widgets'
import { MiniCalendarWidget } from '@/modules/calendar/widgets'
import { QuickNoteWidget } from '@/modules/notes/widgets'
import { ActiveProjectsWidget, ProjectProgressWidget } from '@/modules/projects/widgets'
import { RecentFilesWidget } from '@/modules/files/widgets'
import { TimelineFeedWidget } from '@/modules/timeline/widgets'
import { ActivityFeedWidget } from '@/modules/activity/widgets'
import { StatisticsWidget, AiSummaryWidget, DiskUsageChip } from '@/modules/reports/widgets'
import { WikiRecentWidget } from '@/modules/wiki/widgets'
import { Bell, CloudSun, Cloud, CloudRain } from 'lucide-react'

/**
 * Dashboard — KHÔNG viết cứng. 3 vùng TOP/CENTER/BOTTOM dựng từ Widget Engine:
 * widget do từng module đăng ký qua manifest (zone + span), component map ở đây.
 */
export default function DashboardPage() {
  const { user, settings, modules, navigate } = useWos()
  const [now, setNow] = useState(() => new Date())
  const [weather, setWeather] = useState<{ ok: boolean; temperature: number | null; weathercode: number } | null>(null)

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 60000)
    return () => clearInterval(t)
  }, [])

  useEffect(() => {
    const lat = settings.weather_lat || '10.762622'
    const lon = settings.weather_lon || '106.660172'
    api<{ ok: boolean; temperature: number | null; weathercode: number }>(`/api/core/weather?lat=${lat}&lon=${lon}`)
      .then(setWeather)
      .catch(() => setWeather(null))
  }, [settings.weather_lat, settings.weather_lon])

  // ==== Widget registry: id → component (module cắm widget vào đây) ====
  const widgetComponents: Record<string, React.ComponentType> = {
    'tasks.today': TasksTodayWidget,
    'tasks.stats': TasksStatsWidget,
    'calendar.mini': MiniCalendarWidget,
    'notes.quick': QuickNoteWidget,
    'projects.active': ActiveProjectsWidget,
    'projects.progress': ProjectProgressWidget,
    'files.recent': RecentFilesWidget,
    'timeline.feed': TimelineFeedWidget,
    'activity.feed': ActivityFeedWidget,
    'reports.statistics': StatisticsWidget,
    'reports.summary': AiSummaryWidget,
    'wiki.recent': WikiRecentWidget,
  }

  // Widget defs từ manifest các module ĐANG BẬT (bỏ widget bị tắt qua config.widgets.disabled)
  const allWidgets = modules
    .filter((m) => m.enabled)
    .flatMap((m) => {
      const disabled = ((m.config?.widgets as { disabled?: string[] } | undefined)?.disabled || []) as string[]
      const defs = (m.widgets as { id: string; title: string; zone: string; span: number }[] | undefined) || []
      return defs.filter((w) => !disabled.includes(w.id)).map((w) => ({ ...w, moduleId: m.id }))
    })

  const center = allWidgets.filter((w) => w.zone === 'center')
  const bottom = allWidgets.filter((w) => w.zone === 'bottom')

  const hour = now.getHours()
  const greeting =
    hour < 5 ? 'Chào đêm khuya' : hour < 11 ? 'Chào buổi sáng' : hour < 14 ? 'Chào buổi trưa' : hour < 18 ? 'Chào buổi chiều' : 'Chào buổi tối'

  const WeatherIcon =
    weather?.weathercode != null && weather.weathercode >= 51 ? CloudRain : weather?.weathercode != null && weather.weathercode >= 3 ? Cloud : CloudSun

  const dateStr = now.toLocaleDateString('vi-VN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })

  return (
    <div className="space-y-5">
      {/* ================= ZONE TOP ================= */}
      <div className="wos-glass flex flex-wrap items-center gap-x-8 gap-y-4 rounded-2xl px-5 py-4">
        <div className="min-w-0 flex-1">
          <h1 className="text-2xl font-bold tracking-tight">
            {greeting}, {user?.displayName} 👋
          </h1>
          <p className="mt-0.5 text-sm text-muted-foreground">{dateStr}</p>
        </div>
        {weather && weather.ok && (
          <button
            className="flex items-center gap-2.5 rounded-xl bg-black/[0.06] px-3.5 py-2 transition-colors hover:bg-black/[0.09] dark:bg-white/[0.08]"
            onClick={() => navigate('settings:general')}
            aria-label="Thời tiết"
          >
            <WeatherIcon className="h-7 w-7 text-sky-500" />
            <div className="text-left">
              <p className="text-lg font-bold leading-none tabular-nums">{weather.temperature}°C</p>
              <p className="text-[11px] text-muted-foreground">{settings.weather_city || 'Vị trí mặc định'}</p>
            </div>
          </button>
        )}
        <DiskUsageChip />
        <TopChip onClick={() => navigate('notifications')} />
      </div>

      {/* ================= ZONE CENTER ================= */}
      <section aria-label="Widgets trung tâm">
        <h2 className="mb-2 px-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Trung tâm</h2>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
          {center.map((w) => {
            const Component = widgetComponents[w.id]
            if (!Component) return null
            return (
              <div key={w.id} className={w.span === 2 ? 'md:col-span-2' : ''}>
                <Component />
              </div>
            )
          })}
        </div>
      </section>

      {/* ================= ZONE BOTTOM ================= */}
      <section aria-label="Widgets thống kê">
        <h2 className="mb-2 px-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Thống kê & hoạt động</h2>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
          {bottom.map((w) => {
            const Component = widgetComponents[w.id]
            if (!Component) return null
            return (
              <div key={w.id} className={w.span === 2 ? 'md:col-span-2' : ''}>
                <Component />
              </div>
            )
          })}
        </div>
      </section>
    </div>
  )
}

/** Chip thông báo + storage ở TOP zone */
function TopChip({ onClick }: { onClick: () => void }) {
  const [recent, setRecent] = useState<{ title: string; createdAt: string } | null>(null)
  const [storage, setStorage] = useState<{ used: number; quota: number } | null>(null)

  const load = useCallback(() => {
    api<{ notifications: { title: string; createdAt: string }[] }>('/api/core/notifications?filter=unread')
      .then((d) => setRecent(d.notifications[0] || null))
      .catch(() => {})
    api<{ usage: number; quota: number }>('/api/modules/files/usage?quota=20')
      .then((d) => setStorage({ used: d.usage, quota: d.quota }))
      .catch(() => {})
  }, [])

  useEffect(() => {
    load()
    return bus.onAny(() => load())
  }, [load])

  return (
    <button
      onClick={onClick}
      className="flex items-center gap-2.5 rounded-xl bg-black/[0.06] px-3.5 py-2 text-left transition-colors hover:bg-black/[0.09] dark:bg-white/[0.08]"
      aria-label="Xem thông báo"
    >
      <span className="relative">
        <Bell className="h-6 w-6 text-white/70" />
        {recent && <span className="absolute -right-1 -top-1 h-2.5 w-2.5 rounded-full bg-rose-400" />}
      </span>
      <div>
        <p className="max-w-[200px] truncate text-sm font-medium leading-tight">{recent ? recent.title : 'Không thông báo mới'}</p>
        <p className="text-[11px] text-muted-foreground">
          {storage ? `Storage: ${formatBytes(storage.used)} / ${formatBytes(storage.quota)}` : 'Notifications'}
          {recent && ` · ${timeAgo(recent.createdAt)}`}
        </p>
      </div>
    </button>
  )
}
