'use client'

import { useEffect, useState, useCallback, useMemo } from 'react'
import { useWos } from '@/core/client/wos-store'
import { useRoute } from '@/core/client/route-context'
import { useWindows } from '@/core/client/window-store'
import { setDynamicTitle } from '@/components/wos/app-registry'
import { api, timeAgo, fmtDate } from '@/core/client/api'
import { bus } from '@/core/client/event-bus'
import ReactMarkdown from 'react-markdown'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useToast } from '@/hooks/use-toast'
import { StickyNote, Plus, Trash2, Pin, Search, Eye, PenLine, Loader2, RotateCcw, Tags, AppWindow } from 'lucide-react'

interface NoteRow {
  id: string
  title: string
  content: string
  pinned: boolean
  tags: string
  trashedAt: string | null
  createdAt: string
  updatedAt: string
}

export default function NotesPage() {
  const { route } = useRoute()
  // route 'note:<id>' → chế độ cửa sổ RIÊNG (chỉ 1 ghi chú, full khung)
  if (route.startsWith('note:')) {
    return <SingleNoteWindow noteId={route.slice('note:'.length)} />
  }
  return <NotesMain />
}

/** Chế độ cửa sổ riêng — nội dung fill TOÀN khung (flex-1 + min-h-0, không còn nửa khung) */
function SingleNoteWindow({ noteId }: { noteId: string }) {
  const { emit } = useWos()
  const { navigate } = useRoute()
  const closeWindow = useWindows((s) => s.closeWindow)
  const { toast } = useToast()
  const [note, setNote] = useState<NoteRow | null>(null)
  const [notFound, setNotFound] = useState(false)
  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')
  const [mode, setMode] = useState<'edit' | 'preview'>('edit')
  const [saving, setSaving] = useState(false)
  const [dirty, setDirty] = useState(false)

  const load = useCallback(async () => {
    try {
      const data = await api<{ note: NoteRow | null }>(`/api/modules/notes/${noteId}`)
      if (!data.note || data.note.trashedAt) {
        setNotFound(true)
        return
      }
      setNote(data.note)
      setDynamicTitle(`n:${noteId}`, data.note.title)
      setTitle((prev) => (dirty ? prev : data.note!.title))
      setContent((prev) => (dirty ? prev : data.note!.content))
    } catch {
      setNotFound(true)
    }
     
  }, [noteId])

  useEffect(() => {
    load()
    return bus.onAny((ev) => {
      if (ev.module === 'notes') load()
    })
  }, [load])

  async function save() {
    if (!note || saving) return
    setSaving(true)
    try {
      await api(`/api/modules/notes/${note.id}`, { method: 'PATCH', body: { title, content } })
      setDirty(false)
      setDynamicTitle(`n:${noteId}`, title)
      emit('note.updated', 'notes', { title })
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : 'Không lưu được', variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  async function trash() {
    if (!note || !confirm(`Chuyển "${note.title}" vào thùng rác?`)) return
    await api(`/api/modules/notes/${note.id}`, { method: 'PATCH', body: { trashed: true } })
    emit('note.deleted', 'notes', { title: note.title })
    navigate('notes')
  }

  if (notFound) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center gap-3 py-16 text-muted-foreground">
        <StickyNote className="h-10 w-10 opacity-30" />
        <p className="text-sm">Ghi chú không tồn tại hoặc đã bị xoá</p>
        <Button size="sm" variant="outline" onClick={() => navigate('notes')}>Mở danh sách ghi chú</Button>
      </div>
    )
  }
  if (!note) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    )
  }

  return (
    <div className="flex h-full min-h-0 flex-1 flex-col">
      {/* Thanh công cụ riêng + Mở đầy đủ trong app Notes */}
      <div className="flex flex-wrap items-center gap-2 border-b px-3 py-2">
        <Input
          value={title}
          onChange={(e) => { setTitle(e.target.value); setDirty(true) }}
          onBlur={save}
          className="h-8 min-w-[140px] flex-1 border-0 bg-transparent px-1 text-sm font-semibold focus-visible:ring-0"
          aria-label="Tiêu đề ghi chú"
        />
        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => { setMode('edit'); void api(`/api/modules/notes/${note.id}`, { method: 'PATCH', body: { pinned: !note.pinned } }).then(load) }} aria-label="Ghim">
          <Pin className={`h-4 w-4 ${note.pinned ? 'fill-amber-500 text-amber-500' : ''}`} />
        </Button>
        <div className="flex items-center rounded-lg bg-muted p-0.5">
          <button
            onClick={() => setMode('edit')}
            className={`flex h-7 items-center gap-1.5 rounded-md px-2.5 text-xs font-medium ${mode === 'edit' ? 'bg-background shadow-sm' : 'text-muted-foreground'}`}
          >
            <PenLine className="h-3.5 w-3.5" /> Soạn
          </button>
          <button
            onClick={() => setMode('preview')}
            className={`flex h-7 items-center gap-1.5 rounded-md px-2.5 text-xs font-medium ${mode === 'preview' ? 'bg-background shadow-sm' : 'text-muted-foreground'}`}
          >
            <Eye className="h-3.5 w-3.5" /> Xem
          </button>
        </div>
        <Button size="sm" className="h-8" onClick={save} disabled={saving || !dirty}>
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : dirty ? 'Lưu' : 'Đã lưu'}
        </Button>
        <Button variant="ghost" size="icon" className="h-8 w-8 text-rose-500" onClick={trash} aria-label="Xoá">
          <Trash2 className="h-4 w-4" />
        </Button>
      </div>

      {/* Nội dung — FILL TOÀN KHUNG (fix lỗi chỉ hiện nửa khung) */}
      {mode === 'edit' ? (
        <textarea
          value={content}
          onChange={(e) => { setContent(e.target.value); setDirty(true) }}
          onBlur={save}
          onKeyDown={(e) => {
            if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); void save() }
          }}
          placeholder="Viết ghi chú bằng Markdown…"
          className="wos-scroll h-full min-h-0 flex-1 w-full resize-none bg-transparent p-4 font-mono text-sm leading-relaxed outline-none"
          aria-label="Nội dung ghi chú"
        />
      ) : (
        <div className="wos-scroll wos-md min-h-0 flex-1 overflow-y-auto p-5">
          <ReactMarkdown>{content || '*Ghi chú trống*'}</ReactMarkdown>
        </div>
      )}

      <div className="flex items-center gap-3 border-t px-3 py-1.5 text-[11px] text-muted-foreground">
        <Tags className="h-3 w-3" />
        {JSON.parse(note.tags || '[]').join(', ') || 'Không nhãn'}
        <span className="ml-auto">Sửa {timeAgo(note.updatedAt)}</span>
      </div>
    </div>
  )
}

function NotesMain() {
  const { emit } = useWos()
  const { toast } = useToast()
  const openApp = useWindows((s) => s.openApp)
  const [notes, setNotes] = useState<NoteRow[] | null>(null)
  const [trash, setTrash] = useState<NoteRow[]>([])
  const [showTrash, setShowTrash] = useState(false)
  const [query, setQuery] = useState('')
  const [selected, setSelected] = useState<string | null>(null)
  const [mode, setMode] = useState<'edit' | 'preview'>('edit')
  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')
  const [saving, setSaving] = useState(false)
  const [dirty, setDirty] = useState(false)

  const load = useCallback(async () => {
    try {
      const [all, trashed] = await Promise.all([
        api<{ notes: NoteRow[] }>('/api/modules/notes'),
        api<{ notes: NoteRow[] }>('/api/modules/notes?trash=1'),
      ])
      setNotes(all.notes)
      setTrash(trashed.notes)
    } catch {
      setNotes([])
    }
  }, [])

  useEffect(() => {
    load()
    return bus.onAny((ev) => {
      if (ev.module === 'notes') load()
    })
  }, [load])

  const note = useMemo(() => notes?.find((n) => n.id === selected) || null, [notes, selected])

  useEffect(() => {
    if (note) {
      setTitle(note.title)
      setContent(note.content)
      setDirty(false)
    } else {
      setTitle('')
      setContent('')
    }
  }, [note?.id])  

  async function createNote() {
    try {
      const data = await api<{ note: NoteRow }>('/api/modules/notes', {
        method: 'POST',
        body: { title: 'Ghi chú mới', content: '' },
      })
      emit('note.created', 'notes', { title: data.note.title })
      await load()
      setSelected(data.note.id)
      setMode('edit')
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : 'Không tạo được', variant: 'destructive' })
    }
  }

  /** Mở ghi chú trong cửa sổ RIÊNG (tồn tại độc lập — so sánh 2 ghi chú song song) */
  function openSeparate(n: NoteRow) {
    openApp('notes', { key: `n:${n.id}`, route: `note:${n.id}` })
  }

  async function save() {
    if (!note || saving) return
    setSaving(true)
    try {
      await api(`/api/modules/notes/${note.id}`, { method: 'PATCH', body: { title, content } })
      setDirty(false)
      await load()
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : 'Không lưu được', variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  async function togglePin() {
    if (!note) return
    await api(`/api/modules/notes/${note.id}`, { method: 'PATCH', body: { pinned: !note.pinned } })
    load()
  }

  async function trashNote(n: NoteRow) {
    if (!confirm(`Chuyển "${n.title}" vào thùng rác?`)) return
    await api(`/api/modules/notes/${n.id}`, { method: 'PATCH', body: { trashed: true } })
    emit('note.deleted', 'notes', { title: n.title })
    if (selected === n.id) setSelected(null)
    load()
  }

  async function restoreNote(n: NoteRow) {
    await api(`/api/modules/notes/${n.id}`, { method: 'PATCH', body: { trashed: false } })
    load()
  }

  async function deleteForever(n: NoteRow) {
    if (!confirm(`Xoá vĩnh viễn "${n.title}"?`)) return
    await api(`/api/modules/notes/${n.id}`, { method: 'DELETE' })
    load()
  }

  const list = (showTrash ? trash : notes) || []
  const filtered = list.filter(
    (n) => !query || n.title.toLowerCase().includes(query.toLowerCase()) || n.content.toLowerCase().includes(query.toLowerCase())
  )

  if (notes === null) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <h1 className="flex items-center gap-2.5 text-xl font-bold">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-yellow-500 text-white">
            <StickyNote className="h-5 w-5" />
          </span>
          Notes
          <Badge variant="secondary" className="font-normal">{notes.length} ghi chú</Badge>
        </h1>
        <div className="ml-auto flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Tìm ghi chú…" className="h-9 w-44 pl-8" />
          </div>
          <Button variant="outline" size="sm" className="h-9 gap-1.5" onClick={() => setShowTrash(!showTrash)}>
            <RotateCcw className="h-4 w-4" /> {showTrash ? 'Thoát rác' : `Thùng rác${trash.length ? ` (${trash.length})` : ''}`}
          </Button>
          <Button size="sm" className="h-9 gap-1.5" onClick={createNote}>
            <Plus className="h-4 w-4" /> Ghi chú mới
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-[300px_1fr]">
        {/* Danh sách */}
        <div className="wos-scroll max-h-[calc(100vh-220px)] space-y-2 overflow-y-auto pr-1">
          {filtered.length === 0 && (
            <div className="wos-glass flex flex-col items-center gap-2 rounded-2xl py-10 text-muted-foreground">
              <StickyNote className="h-8 w-8 opacity-30" />
              <p className="text-sm">{showTrash ? 'Thùng rác trống' : 'Chưa có ghi chú'}</p>
            </div>
          )}
          {filtered.map((n) => {
            const tags: string[] = JSON.parse(n.tags || '[]')
            const active = n.id === selected
            return (
              <button
                key={n.id}
                onClick={() => !showTrash && setSelected(n.id)}
                className={`w-full rounded-xl p-3 text-left transition-all hover:shadow-md ${
                  active ? 'bg-primary/10 ring-1 ring-primary/40' : 'wos-glass'
                }`}
              >
                <div className="flex items-start gap-2">
                  {n.pinned && <Pin className="mt-0.5 h-3.5 w-3.5 shrink-0 fill-amber-500 text-amber-500" />}
                  <p className="min-w-0 flex-1 truncate text-sm font-semibold">{n.title}</p>
                </div>
                <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">
                  {n.content.replace(/[#*`>\-[\]]/g, '').slice(0, 100) || 'Trống'}
                </p>
                <div className="mt-2 flex items-center gap-2">
                  <span className="text-[10px] text-muted-foreground">{timeAgo(n.updatedAt)}</span>
                  {tags.slice(0, 3).map((t) => (
                    <Badge key={t} variant="secondary" className="h-4 px-1.5 text-[9px]">{t}</Badge>
                  ))}
                  {!showTrash && (
                    <span
                      role="button"
                      tabIndex={0}
                      onClick={(e) => { e.stopPropagation(); openSeparate(n) }}
                      onKeyDown={(e) => { if (e.key === 'Enter') { e.stopPropagation(); openSeparate(n) } }}
                      className="ml-auto cursor-pointer rounded-lg p-1 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
                      title="Mở cửa sổ riêng"
                      aria-label={`Mở ${n.title} trong cửa sổ riêng`}
                    >
                      <AppWindow className="h-3.5 w-3.5" />
                    </span>
                  )}
                </div>
                {showTrash && (
                  <div className="mt-2 flex gap-2">
                    <Button size="sm" variant="outline" className="h-7 flex-1 text-xs" onClick={(e) => { e.stopPropagation(); restoreNote(n) }}>
                      <RotateCcw className="mr-1 h-3 w-3" /> Khôi phục
                    </Button>
                    <Button size="sm" variant="destructive" className="h-7 flex-1 text-xs" onClick={(e) => { e.stopPropagation(); deleteForever(n) }}>
                      Xoá vĩnh viễn
                    </Button>
                  </div>
                )}
              </button>
            )
          })}
        </div>

        {/* Editor / Preview */}
        <Card className="wos-glass flex min-h-[calc(100vh-220px)] flex-col border-0">
          {note && !showTrash ? (
            <>
              <div className="flex flex-wrap items-center gap-2 border-b px-4 py-3">
                <Input
                  value={title}
                  onChange={(e) => { setTitle(e.target.value); setDirty(true) }}
                  onBlur={save}
                  className="h-9 min-w-[160px] flex-1 border-0 bg-transparent px-0 text-base font-semibold focus-visible:ring-0"
                />
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={togglePin} aria-label="Ghim">
                  <Pin className={`h-4 w-4 ${note.pinned ? 'fill-amber-500 text-amber-500' : ''}`} />
                </Button>
                <Button variant="outline" size="sm" className="h-8 gap-1.5" onClick={() => openSeparate(note)} title="Mở ghi chú này trong cửa sổ riêng">
                  <AppWindow className="h-3.5 w-3.5" /> Cửa sổ riêng
                </Button>
                <div className="flex items-center rounded-lg bg-muted p-0.5">
                  <button
                    onClick={() => setMode('edit')}
                    className={`flex h-7 items-center gap-1.5 rounded-md px-2.5 text-xs font-medium ${mode === 'edit' ? 'bg-background shadow-sm' : 'text-muted-foreground'}`}
                  >
                    <PenLine className="h-3.5 w-3.5" /> Soạn
                  </button>
                  <button
                    onClick={() => setMode('preview')}
                    className={`flex h-7 items-center gap-1.5 rounded-md px-2.5 text-xs font-medium ${mode === 'preview' ? 'bg-background shadow-sm' : 'text-muted-foreground'}`}
                  >
                    <Eye className="h-3.5 w-3.5" /> Xem
                  </button>
                </div>
                <Button size="sm" className="h-8" onClick={save} disabled={saving || !dirty}>
                  {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : dirty ? 'Lưu' : 'Đã lưu'}
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8 text-rose-500" onClick={() => trashNote(note)} aria-label="Xoá">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
              <CardContent className="flex-1 p-0">
                {mode === 'edit' ? (
                  <textarea
                    value={content}
                    onChange={(e) => { setContent(e.target.value); setDirty(true) }}
                    onBlur={save}
                    placeholder="Viết ghi chú bằng Markdown… # Tiêu đề, - danh sách, - [ ] checklist, ```code```"
                    className="h-full min-h-[400px] w-full resize-none bg-transparent p-5 font-mono text-sm leading-relaxed outline-none"
                  />
                ) : (
                  <div className="wos-md h-full min-h-[400px] overflow-y-auto p-6">
                    <ReactMarkdown>{content || '*Ghi chú trống*'}</ReactMarkdown>
                  </div>
                )}
              </CardContent>
              <div className="flex items-center gap-3 border-t px-4 py-2 text-[11px] text-muted-foreground">
                <Tags className="h-3 w-3" />
                {JSON.parse(note.tags || '[]').join(', ') || 'Không nhãn'}
                <span className="ml-auto">Tạo {fmtDate(note.createdAt)} · Sửa {timeAgo(note.updatedAt)}</span>
              </div>
            </>
          ) : (
            <div className="flex flex-1 flex-col items-center justify-center gap-3 py-20 text-muted-foreground">
              <StickyNote className="h-10 w-10 opacity-30" />
              <p className="text-sm">Chọn một ghi chú bên trái hoặc tạo mới</p>
            </div>
          )}
        </Card>
      </div>
    </div>
  )
}
