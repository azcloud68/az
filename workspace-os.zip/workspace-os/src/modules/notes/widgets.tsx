'use client'

import { useEffect, useState } from 'react'
import { api } from '@/core/client/api'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { StickyNote, Save, Loader2 } from 'lucide-react'
import { toast } from 'sonner'

/** Widget: Quick Note — ghi nhanh xuống module Notes mà không rời Dashboard */
export function QuickNoteWidget() {
  const [noteId, setNoteId] = useState<string | null>(null)
  const [content, setContent] = useState('')
  const [saving, setSaving] = useState(false)
  const [dirty, setDirty] = useState(false)
  const [loaded, setLoaded] = useState(false)

  useEffect(() => {
    const KEY = 'wos_quick_note'
    const saved = localStorage.getItem(KEY)
    if (saved) {
      try {
        const { id, content } = JSON.parse(saved)
        setNoteId(id)
        setContent(content || '')
      } catch {
        /* bỏ qua */
      }
    }
    setLoaded(true)
  }, [])

  async function save() {
    if (!loaded || saving) return
    setSaving(true)
    try {
      const data = await api<{ note: { id: string } }>('/api/modules/notes', {
        method: 'PUT',
        body: { id: noteId || undefined, content },
      })
      setNoteId(data.note.id)
      localStorage.setItem('wos_quick_note', JSON.stringify({ id: data.note.id, content }))
      setDirty(false)
      toast.success('Đã lưu ghi chú nhanh')
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Lỗi khi lưu')
    } finally {
      setSaving(false)
    }
  }

  return (
    <Card className="wos-glass border-0">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="flex items-center gap-2 text-sm font-semibold">
          <StickyNote className="h-4 w-4 text-yellow-500" /> Quick Note
        </CardTitle>
        <Button size="sm" variant="ghost" className="h-7 gap-1 px-2 text-xs" onClick={save} disabled={saving || !dirty}>
          {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
          Lưu
        </Button>
      </CardHeader>
      <CardContent>
        <textarea
          value={content}
          onChange={(e) => {
            setContent(e.target.value)
            setDirty(true)
          }}
          placeholder="Ghi chú nhanh… (Markdown được hỗ trợ khi mở trong Notes)"
          className="h-36 w-full resize-none rounded-xl border bg-background/60 p-3 text-sm leading-relaxed outline-none transition-colors focus:border-primary"
        />
      </CardContent>
    </Card>
  )
}
