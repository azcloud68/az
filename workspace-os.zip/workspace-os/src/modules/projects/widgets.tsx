'use client'

import { useEffect, useState, useCallback } from 'react'
import { useWos } from '@/core/client/wos-store'
import { api, timeAgo } from '@/core/client/api'
import { bus } from '@/core/client/event-bus'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { FolderKanban, Loader2 } from 'lucide-react'

interface ProjectRow {
  id: string
  name: string
  description: string
  color: string
  status: string
  dueDate: string | null
  taskProgress: number
  milestoneProgress: number
  taskTotal: number
}

/** Widget: Dự án đang chạy (CENTER) */
export function ActiveProjectsWidget() {
  const { navigate } = useWos()
  const [projects, setProjects] = useState<ProjectRow[] | null>(null)

  const load = useCallback(async () => {
    try {
      const data = await api<{ projects: ProjectRow[] }>('/api/modules/projects')
      setProjects(data.projects.filter((p) => p.status === 'active').slice(0, 4))
    } catch {
      setProjects([])
    }
  }, [])

  useEffect(() => {
    load()
    return bus.onAny((ev) => {
      if (ev.module === 'projects') load()
    })
  }, [load])

  return (
    <Card className="wos-glass border-0">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="flex items-center gap-2 text-sm font-semibold">
          <FolderKanban className="h-4 w-4 text-orange-500" /> Dự án đang chạy
        </CardTitle>
        <button onClick={() => navigate('projects')} className="text-xs text-primary hover:underline">
          Tất cả dự án
        </button>
      </CardHeader>
      <CardContent>
        {projects === null ? (
          <div className="flex h-24 items-center justify-center">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        ) : projects.length === 0 ? (
          <p className="py-6 text-center text-sm text-muted-foreground">Chưa có dự án nào đang chạy</p>
        ) : (
          <div className="space-y-3">
            {projects.map((p) => (
              <button key={p.id} onClick={() => navigate(`projects:${p.id}`)} className="block w-full text-left">
                <div className="mb-1 flex items-center justify-between gap-2">
                  <span className="flex items-center gap-2 truncate text-sm font-medium">
                    <span className="h-2.5 w-2.5 shrink-0 rounded-sm" style={{ background: p.color }} />
                    {p.name}
                  </span>
                  <span className="shrink-0 text-xs tabular-nums text-muted-foreground">{p.taskProgress}%</span>
                </div>
                <Progress value={p.taskProgress} className="h-2" style={{ ['--progress-color' as string]: p.color }} />
              </button>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

/** Widget: Tiến độ dự án (BOTTOM) — gantt mini theo mốc */
export function ProjectProgressWidget() {
  const { navigate } = useWos()
  const [projects, setProjects] = useState<ProjectRow[] | null>(null)

  const load = useCallback(async () => {
    try {
      const data = await api<{ projects: ProjectRow[] }>('/api/modules/projects')
      setProjects(data.projects.slice(0, 5))
    } catch {
      setProjects([])
    }
  }, [])

  useEffect(() => {
    load()
    return bus.onAny((ev) => {
      if (ev.module === 'projects') load()
    })
  }, [load])

  return (
    <Card className="wos-glass border-0">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-sm font-semibold">
          <FolderKanban className="h-4 w-4 text-orange-500" /> Tiến độ dự án
        </CardTitle>
      </CardHeader>
      <CardContent>
        {projects === null ? (
          <div className="flex h-24 items-center justify-center">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        ) : projects.length === 0 ? (
          <p className="py-6 text-center text-sm text-muted-foreground">Chưa có dữ liệu</p>
        ) : (
          <div className="space-y-2.5">
            {projects.map((p) => (
              <button
                key={p.id}
                onClick={() => navigate(`projects:${p.id}`)}
                className="flex w-full items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-muted"
              >
                <span className="w-28 truncate text-left text-sm">{p.name}</span>
                <div className="h-2 flex-1 overflow-hidden rounded-full bg-muted">
                  <div
                    className="h-full rounded-full transition-all"
                    style={{ width: `${p.milestoneProgress}%`, background: p.color }}
                  />
                </div>
                <span className="w-24 shrink-0 text-right text-[11px] text-muted-foreground">
                  {p.dueDate ? `Hạn ${new Date(p.dueDate).toLocaleDateString('vi-VN')}` : timeAgo(p.dueDate || '') || '—'}
                </span>
              </button>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
