'use client'

/**
 * Projects — 2 chế độ theo route cửa sổ:
 * - 'projects'          : lưới thẻ dự án (cửa sổ chính)
 * - 'projects:<id>'     : CHI TIẾT dự án — mở thành CỬA SỔ RIÊNG (key p:<id>)
 *   → tồn tại độc lập trên desktop như app chính, chỉ tắt khi bấm nút đóng.
 * Tab Tasks: thêm việc NGAY TẠI CHỖ (sync sang module Task qua Event Bus).
 * Tab Calendar: ngày bắt đầu / dự kiến xong / kết thúc thực tế (nhập tay) + timeline trực quan.
 */
import { useEffect, useState, useCallback } from 'react'
import { useWos } from '@/core/client/wos-store'
import { useRoute } from '@/core/client/route-context'
import { useWindows } from '@/core/client/window-store'
import { setProjectName } from '@/components/wos/app-registry'
import { api, fmtDate, timeAgo } from '@/core/client/api'
import { bus } from '@/core/client/event-bus'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useToast } from '@/hooks/use-toast'
import {
  FolderKanban, Plus, Trash2, Loader2, Users, Flag, CheckCircle2, Circle,
  Link2, Archive, Calendar, ArrowLeft, FlagTriangleRight,
} from 'lucide-react'

interface Milestone { id: string; title: string; done: boolean; dueAt: string | null; position: number }
interface Member { id: string; userName: string; role: string }
interface Project {
  id: string
  name: string
  description: string
  color: string
  icon: string
  status: string
  startDate: string | null
  dueDate: string | null
  expectedEndDate: string | null
  actualEndDate: string | null
  updatedAt: string
  milestones: Milestone[]
  members: Member[]
  taskCounts: { todo: number; doing: number; done: number }
  taskProgress: number
  milestoneProgress: number
  taskTotal: number
}
interface TaskLite { id: string; title: string; status: string; priority: string; dueAt: string | null }
interface EventLite { id: string; title: string; start: string; category: string }

const STATUS_LABEL: Record<string, string> = { active: 'Đang chạy', paused: 'Tạm dừng', done: 'Hoàn thành', archived: 'Lưu trữ' }
const STATUS_COLOR: Record<string, string> = {
  active: 'bg-emerald-500', paused: 'bg-amber-500', done: 'bg-primary', archived: 'bg-neutral-400',
}
const COLORS = ['#f97316', '#ea580c', '#10b981', '#0891b2', '#eab308', '#ec4899', '#8b5cf6', '#f43f5e']

/** 'YYYY-MM-DD' từ ISO string (cho input date) */
function toDateInput(v: string | null | undefined): string {
  if (!v) return ''
  try {
    return new Date(v).toISOString().slice(0, 10)
  } catch {
    return ''
  }
}

export default function ProjectsPage() {
  const { emit } = useWos()
  const { route, navigate } = useRoute()
  const openApp = useWindows((s) => s.openApp)
  const { toast } = useToast()
  const [projects, setProjects] = useState<Project[] | null>(null)
  const [creating, setCreating] = useState(false)
  const [newName, setNewName] = useState('')
  const [newDesc, setNewDesc] = useState('')
  const [newColor, setNewColor] = useState(COLORS[0])

  // route 'projects:<id>' → chế độ chi tiết (cửa sổ riêng); 'projects' → lưới
  const detailId = route.startsWith('projects:') ? route.slice('projects:'.length) : null

  const load = useCallback(async () => {
    try {
      const data = await api<{ projects: Project[] }>('/api/modules/projects')
      setProjects(data.projects)
      for (const p of data.projects) setProjectName(p.id, p.name)
    } catch {
      setProjects([])
    }
  }, [])

  useEffect(() => {
    load()
    return bus.onAny((ev) => {
      if (ev.module === 'projects' || ev.module === 'tasks') load()
    })
  }, [load])

  async function create() {
    if (!newName.trim()) return
    try {
      await api('/api/modules/projects', { method: 'POST', body: { name: newName.trim(), description: newDesc, color: newColor } })
      emit('project.created', 'projects', { name: newName.trim() })
      setCreating(false)
      setNewName('')
      setNewDesc('')
      load()
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  /** Mở chi tiết dự án thành cửa sổ RIÊNG (macOS style — tồn tại độc lập) */
  function openProjectWindow(id: string) {
    openApp('projects', { key: `p:${id}`, route: `projects:${id}` })
  }

  if (detailId) {
    return <ProjectDetail id={detailId} onBack={() => navigate('projects')} />
  }

  if (projects === null) {
    return <div className="flex h-64 items-center justify-center"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <h1 className="flex items-center gap-2.5 text-xl font-bold">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-orange-500 text-white">
            <FolderKanban className="h-5 w-5" />
          </span>
          Projects
          <Badge variant="secondary" className="font-normal">{projects.filter((p) => p.status === 'active').length} đang chạy</Badge>
        </h1>
        <Button size="sm" className="ml-auto h-9 gap-1.5" onClick={() => setCreating(true)}>
          <Plus className="h-4 w-4" /> Dự án mới
        </Button>
      </div>

      {projects.length === 0 ? (
        <div className="wos-glass flex flex-col items-center gap-2 rounded-2xl py-14 text-muted-foreground">
          <FolderKanban className="h-10 w-10 opacity-30" />
          <p className="text-sm">Chưa có dự án nào — tạo dự án đầu tiên</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
          {projects.map((p) => (
            <Card
              key={p.id}
              className="wos-glass cursor-pointer border-0 transition-all hover:-translate-y-0.5 hover:shadow-lg"
              onClick={() => openProjectWindow(p.id)}
            >
              <CardHeader className="pb-2">
                <div className="flex items-start gap-3">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-xl font-bold text-white" style={{ background: p.color }}>
                    {p.name.slice(0, 1).toUpperCase()}
                  </div>
                  <div className="min-w-0 flex-1">
                    <CardTitle className="truncate text-base">{p.name}</CardTitle>
                    <div className="mt-1 flex flex-wrap items-center gap-2 text-[11px] text-muted-foreground">
                      <span className={`flex items-center gap-1 rounded-full px-2 py-0.5 font-medium text-white ${STATUS_COLOR[p.status]}`}>
                        {STATUS_LABEL[p.status]}
                      </span>
                      {p.expectedEndDate && <span className="flex items-center gap-1"><FlagTriangleRight className="h-3 w-3" />Dự kiến {fmtDate(p.expectedEndDate)}</span>}
                      {p.dueDate && <span className="flex items-center gap-1"><Calendar className="h-3 w-3" />Hạn {fmtDate(p.dueDate)}</span>}
                      <span className="flex items-center gap-1"><Users className="h-3 w-3" />{p.members.length}</span>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {p.description && <p className="mb-3 line-clamp-2 text-xs text-muted-foreground">{p.description}</p>}
                <div className="mb-1.5 flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Tiến độ ({p.taskTotal} việc)</span>
                  <span className="font-semibold tabular-nums">{p.taskProgress}%</span>
                </div>
                <Progress value={p.taskProgress} className="h-2" style={{ ['--progress-color' as string]: p.color }} />
                <div className="mt-3 grid grid-cols-3 gap-1.5 text-center text-[10px]">
                  <span className="rounded-lg bg-muted/60 py-1.5">
                    <b className="block text-sm tabular-nums">{p.taskCounts.todo}</b> cần làm
                  </span>
                  <span className="rounded-lg bg-muted/60 py-1.5">
                    <b className="block text-sm tabular-nums">{p.taskCounts.doing}</b> đang làm
                  </span>
                  <span className="rounded-lg bg-muted/60 py-1.5">
                    <b className="block text-sm tabular-nums">{p.taskCounts.done}</b> xong
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Dialog tạo dự án */}
      <Dialog open={creating} onOpenChange={setCreating}>
        <DialogContent className="wos-glass-strong sm:max-w-[440px]">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><FolderKanban className="h-4 w-4" /> Dự án mới</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <Input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="Tên dự án" autoFocus className="h-10 font-medium" />
            <Textarea value={newDesc} onChange={(e) => setNewDesc(e.target.value)} placeholder="Mô tả ngắn…" className="min-h-[70px]" />
            <div>
              <p className="mb-1.5 text-xs font-medium text-muted-foreground">Màu nhận diện</p>
              <div className="flex gap-2">
                {COLORS.map((c) => (
                  <button
                    key={c}
                    onClick={() => setNewColor(c)}
                    className={`h-7 w-7 rounded-lg ${newColor === c ? 'ring-2 ring-foreground ring-offset-2' : ''}`}
                    style={{ background: c }}
                    aria-label={c}
                  />
                ))}
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" size="sm" onClick={() => setCreating(false)}>Huỷ</Button>
              <Button size="sm" onClick={create} disabled={!newName.trim()}>Tạo dự án</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

/* ============ CHI TIẾT DỰ ÁN (render trong cửa sổ riêng 'projects:<id>') ============ */

function ProjectDetail({ id, onBack }: { id: string; onBack: () => void }) {
  const { emit } = useWos()
  const { navigate } = useRoute()
  const { toast } = useToast()
  const [project, setProject] = useState<Project | null>(null)
  const [tasks, setTasks] = useState<TaskLite[]>([])
  const [events, setEvents] = useState<EventLite[]>([])
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [milestoneTitle, setMilestoneTitle] = useState('')
  const [memberName, setMemberName] = useState('')
  const [tab, setTab] = useState<'milestones' | 'tasks' | 'members' | 'calendar'>('milestones')
  /** Form thêm việc ngay tại chỗ (sync module Task) */
  const [taskTitle, setTaskTitle] = useState('')
  const [taskPriority, setTaskPriority] = useState('medium')
  const [taskDue, setTaskDue] = useState('')
  const [addingTask, setAddingTask] = useState(false)
  /** Ngày bắt đầu / dự kiến / thực tế */
  const [startDate, setStartDate] = useState('')
  const [expectedEnd, setExpectedEnd] = useState('')
  const [actualEnd, setActualEnd] = useState('')
  const [dueDate, setDueDate] = useState('')

  const load = useCallback(async () => {
    try {
      const data = await api<{ project: Project; tasks: TaskLite[]; events: EventLite[] }>(`/api/modules/projects/${id}`)
      setProject(data.project)
      setName(data.project.name)
      setDescription(data.project.description)
      setStartDate(toDateInput(data.project.startDate))
      setExpectedEnd(toDateInput(data.project.expectedEndDate ?? data.project.dueDate))
      setActualEnd(toDateInput(data.project.actualEndDate))
      setDueDate(toDateInput(data.project.dueDate))
      setTasks(data.tasks)
      setEvents(data.events)
      setProjectName(id, data.project.name)
    } catch (err) {
      toast({ title: 'Không mở được dự án', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }, [id, toast])

  useEffect(() => {
    load()
    return bus.onAny((ev) => {
      if (ev.module === 'projects' || (ev.module === 'tasks' && ev.type === 'task.created')) load()
    })
  }, [load])

  async function patch(body: Record<string, unknown>, event = 'project.updated') {
    try {
      await api(`/api/modules/projects/${id}`, { method: 'PATCH', body })
      if (event) emit(event, 'projects', { name: body.name || project?.name })
      await load()
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  /** Thêm việc NGAY trong dự án — POST task API + emit → module Tasks tự cập nhật */
  async function addTask() {
    if (!taskTitle.trim()) return
    setAddingTask(true)
    try {
      await api('/api/modules/tasks', {
        method: 'POST',
        body: {
          title: taskTitle.trim(),
          priority: taskPriority,
          projectId: id,
          ...(taskDue ? { dueAt: new Date(taskDue + 'T17:00:00').toISOString() } : {}),
        },
      })
      emit('task.created', 'tasks', { title: taskTitle.trim() })
      setTaskTitle('')
      setTaskDue('')
      await load()
      toast({ title: 'Đã thêm việc vào dự án', description: 'Đồng bộ sang app Tasks' })
    } catch (err) {
      toast({ title: 'Không thêm được việc', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setAddingTask(false)
    }
  }

  async function removeProject() {
    if (!project || !confirm(`Xoá dự án "${project.name}"? Công việc liên kết sẽ được giữ lại.`)) return
    await api(`/api/modules/projects/${id}`, { method: 'DELETE' })
    emit('project.updated', 'projects', {})
    onBack()
  }

  if (!project) {
    return <div className="flex h-64 items-center justify-center"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
  }

  const milestonesDone = project.milestones.filter((m) => m.done).length
  const proj = project // giữ narrowing cho closure dưới (project là state — TS không hứa nó không đổi)

  /** Timeline: start → dự kiến (than mờ) + start → thực tế (than đậm, đỏ nếu trễ) */
  function TimelineBar() {
    const start = proj.startDate ? new Date(proj.startDate).getTime() : null
    const expected = proj.expectedEndDate ? new Date(proj.expectedEndDate).getTime() : null
    const actual = proj.actualEndDate ? new Date(proj.actualEndDate).getTime() : null
    if (!start || !expected) {
      return (
        <p className="rounded-xl bg-muted/50 p-3 text-xs text-muted-foreground">
          Nhập <b>Ngày bắt đầu</b> và <b>Ngày dự kiến xong</b> ở dưới để hiện timeline trực quan.
        </p>
      )
    }
    const span = Math.max(expected - start, 86400000)
    const clamp = (t: number) => Math.max(0, Math.min(1, (t - start) / span))
    const todayClamp = clamp(Date.now())
    const overdue = actual !== null && actual > expected
    return (
      <div className="wos-ptl p-2">
        <div
          className={`wos-ptl-plan ${overdue ? 'wos-ptl-over' : ''}`}
          style={{ left: `${8 + 0 * 84}%`, width: `${84 * (clamp(expected) - 0)}%` }}
        />
        <div
          className="wos-ptl-actual"
          style={{
            left: `${8 + 0 * 84}%`,
            width: `${84 * ((actual ? clamp(actual) : todayClamp) - 0)}%`,
            background: overdue ? 'linear-gradient(90deg, oklch(0.62 0.19 25), oklch(0.72 0.15 15))' : undefined,
          }}
        />
        <div className="relative mt-6 flex justify-between px-2 text-[10px] text-muted-foreground">
          <span>Bắt đầu: {fmtDate(proj.startDate)}</span>
          <span>Dự kiến: {fmtDate(proj.expectedEndDate)}</span>
        </div>
        {actual && (
          <p className={`px-2 text-[10.5px] font-medium ${overdue ? 'text-rose-500' : 'text-emerald-600'}`}>
            {overdue ? `Trễ ${Math.ceil((actual - expected) / 86400000)} ngày` : 'Hoàn thành đúng/kéo hơn dự kiến'} — thực tế: {fmtDate(proj.actualEndDate)}
          </p>
        )}
        {!actual && Date.now() > expected && (
          <p className="px-2 text-[10.5px] font-medium text-amber-600">Đã quá ngày dự kiến {Math.ceil((Date.now() - expected) / 86400000)} ngày — cập nhật ngày thực tế khi xong</p>
        )}
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {/* Header dự án */}
      <div className="flex flex-wrap items-center gap-2">
        <Button variant="ghost" size="sm" className="h-8 gap-1.5" onClick={onBack}>
          <ArrowLeft className="h-4 w-4" /> Danh sách
        </Button>
        <div className="flex min-w-0 flex-1 items-center gap-2.5">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-lg font-bold text-white" style={{ background: project.color }}>
            {project.name.slice(0, 1).toUpperCase()}
          </div>
          <Input
            value={name}
            onChange={(e) => setName(e.target.value)}
            onBlur={() => name !== project.name && patch({ name })}
            className="h-9 border-0 bg-transparent px-0 text-lg font-semibold focus-visible:ring-0"
          />
        </div>
        <Select value={project.status} onValueChange={(v) => patch({ status: v }, v === 'archived' ? 'project.archived' : 'project.updated')}>
          <SelectTrigger className="h-8 w-32 text-xs"><SelectValue /></SelectTrigger>
          <SelectContent>
            {Object.entries(STATUS_LABEL).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="wos-glass rounded-2xl p-3">
          <div className="mb-1 flex justify-between text-xs">
            <span className="text-muted-foreground">Tiến độ công việc</span>
            <span className="font-semibold tabular-nums">{project.taskProgress}%</span>
          </div>
          <Progress value={project.taskProgress} className="h-2" style={{ ['--progress-color' as string]: project.color }} />
        </div>
        <div className="wos-glass rounded-2xl p-3">
          <div className="mb-1 flex justify-between text-xs">
            <span className="text-muted-foreground">Mốc ({milestonesDone}/{project.milestones.length})</span>
            <span className="font-semibold tabular-nums">{project.milestoneProgress}%</span>
          </div>
          <Progress value={project.milestoneProgress} className="h-2" style={{ ['--progress-color' as string]: project.color }} />
        </div>
      </div>

      <Textarea
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        onBlur={() => description !== project.description && patch({ description })}
        placeholder="Mô tả dự án…"
        className="min-h-[60px]"
      />

      <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)}>
        <TabsList className="h-9 w-full flex-wrap justify-start">
          <TabsTrigger value="milestones" className="gap-1.5 text-xs"><Flag className="h-3.5 w-3.5" /> Milestones</TabsTrigger>
          <TabsTrigger value="tasks" className="gap-1.5 text-xs"><Link2 className="h-3.5 w-3.5" /> Tasks ({tasks.length})</TabsTrigger>
          <TabsTrigger value="members" className="gap-1.5 text-xs"><Users className="h-3.5 w-3.5" /> Members</TabsTrigger>
          <TabsTrigger value="calendar" className="gap-1.5 text-xs"><Calendar className="h-3.5 w-3.5" /> Calendar</TabsTrigger>
        </TabsList>

        {tab === 'milestones' && (
          <div className="mt-3 space-y-2">
            {project.milestones.map((m) => (
              <div key={m.id} className="flex items-center gap-3 rounded-xl bg-muted/50 px-3 py-2.5">
                <button
                  onClick={() => patch({ op: 'milestone.toggle', milestoneId: m.id })}
                  className="shrink-0"
                  aria-label="Đánh dấu mốc"
                >
                  {m.done ? <CheckCircle2 className="h-5 w-5 text-emerald-500" /> : <Circle className="h-5 w-5 text-muted-foreground" />}
                </button>
                <span className={`min-w-0 flex-1 text-sm ${m.done ? 'line-through opacity-60' : 'font-medium'}`}>{m.title}</span>
                {m.dueAt && <span className="shrink-0 text-[11px] text-muted-foreground">{fmtDate(m.dueAt)}</span>}
                <button
                  onClick={() => patch({ op: 'milestone.delete', milestoneId: m.id })}
                  className="text-muted-foreground hover:text-rose-500"
                  aria-label="Xoá mốc"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
            <div className="flex gap-2">
              <Input
                value={milestoneTitle}
                onChange={(e) => setMilestoneTitle(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && milestoneTitle.trim()) {
                    patch({ op: 'milestone.add', title: milestoneTitle.trim() })
                    setMilestoneTitle('')
                  }
                }}
                placeholder="Thêm mốc tiến độ…"
                className="h-9 text-sm"
              />
              <Button size="sm" variant="secondary" className="h-9" onClick={() => {
                if (milestoneTitle.trim()) {
                  patch({ op: 'milestone.add', title: milestoneTitle.trim() })
                  setMilestoneTitle('')
                }
              }}><Plus className="h-4 w-4" /></Button>
            </div>
          </div>
        )}

        {tab === 'tasks' && (
          <div className="mt-3 space-y-1.5">
            {/* Thêm việc NGAY tại Projects — sync module Task */}
            <div className="wos-glass mb-2 flex flex-wrap items-center gap-2 rounded-2xl p-2.5">
              <Input
                value={taskTitle}
                onChange={(e) => setTaskTitle(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && addTask()}
                placeholder="Thêm việc cho dự án này…"
                className="h-9 min-w-[180px] flex-1 text-sm"
              />
              <Select value={taskPriority} onValueChange={setTaskPriority}>
                <SelectTrigger className="h-9 w-[110px] text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Thấp</SelectItem>
                  <SelectItem value="medium">Trung bình</SelectItem>
                  <SelectItem value="high">Cao</SelectItem>
                  <SelectItem value="urgent">Khẩn cấp</SelectItem>
                </SelectContent>
              </Select>
              <Input
                type="date"
                value={taskDue}
                onChange={(e) => setTaskDue(e.target.value)}
                className="h-9 w-[150px] text-xs"
                aria-label="Hạn chót"
              />
              <Button size="sm" className="h-9 gap-1.5" onClick={addTask} disabled={!taskTitle.trim() || addingTask}>
                {addingTask ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />} Thêm việc
              </Button>
            </div>
            {tasks.length === 0 && (
              <div className="rounded-xl bg-muted/40 py-8 text-center">
                <p className="text-sm text-muted-foreground">Chưa có việc nào gắn với dự án — dùng form phía trên</p>
              </div>
            )}
            {tasks.map((t) => (
              <div key={t.id} className="flex items-center gap-3 rounded-xl bg-muted/50 px-3 py-2.5">
                <span className={`h-2 w-2 shrink-0 rounded-full ${t.status === 'done' ? 'bg-emerald-500' : t.status === 'doing' ? 'bg-amber-500' : 'bg-slate-400'}`} />
                <span className={`min-w-0 flex-1 truncate text-sm ${t.status === 'done' ? 'line-through opacity-60' : ''}`}>{t.title}</span>
                {t.dueAt && <span className="shrink-0 text-[11px] text-muted-foreground">{fmtDate(t.dueAt)}</span>}
                <Badge variant="secondary" className="shrink-0 text-[10px]">{t.priority}</Badge>
              </div>
            ))}
            <div className="flex justify-end">
              <Button size="sm" variant="outline" className="h-8 gap-1.5 text-xs" onClick={() => navigate('tasks')}>
                <Link2 className="h-3.5 w-3.5" /> Mở app Tasks
              </Button>
            </div>
          </div>
        )}

        {tab === 'members' && (
          <div className="mt-3 space-y-2">
            {project.members.map((m) => (
              <div key={m.id} className="flex items-center gap-3 rounded-xl bg-muted/50 px-3 py-2.5">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/15 text-xs font-semibold text-primary">
                  {m.userName.slice(0, 1).toUpperCase()}
                </div>
                <span className="min-w-0 flex-1 truncate text-sm font-medium">{m.userName}</span>
                <Badge variant="secondary" className="shrink-0">{m.role}</Badge>
                <button
                  onClick={() => patch({ op: 'member.remove', memberId: m.id })}
                  className="text-muted-foreground hover:text-rose-500"
                  aria-label="Xoá thành viên"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
            <div className="flex gap-2">
              <Input
                value={memberName}
                onChange={(e) => setMemberName(e.target.value)}
                placeholder="Tên thành viên mới…"
                className="h-9 text-sm"
              />
              <Button size="sm" variant="secondary" className="h-9" onClick={() => {
                if (memberName.trim()) {
                  patch({ op: 'member.add', userName: memberName.trim() })
                  setMemberName('')
                }
              }}><Plus className="h-4 w-4" /></Button>
            </div>
          </div>
        )}

        {tab === 'calendar' && (
          <div className="mt-3 space-y-3">
            <TimelineBar />
            <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
              <DateField label="Ngày bắt đầu (thực tế)" value={startDate} onChange={setStartDate} onBlur={() => patch({ startDate: startDate || null })} />
              <DateField label="Ngày dự kiến hoàn thành" value={expectedEnd} onChange={setExpectedEnd} onBlur={() => patch({ expectedEndDate: expectedEnd || null })} />
              <DateField label="Ngày kết thúc thực tế" value={actualEnd} onChange={setActualEnd} onBlur={() => patch({ actualEndDate: actualEnd || null })} />
              <DateField label="Hạn chót (deadline)" value={dueDate} onChange={setDueDate} onBlur={() => patch({ dueDate: dueDate || null })} />
            </div>
            <p className="rounded-xl bg-amber-500/10 p-3 text-xs text-amber-700 dark:text-amber-400">
              Thời gian thực tế thường khác dự kiến — nhập tay cả 3 mốc để so sánh trên timeline. Dòng trên = kế hoạch, dòng dưới = thực tế (đỏ khi trễ).
            </p>

            <div className="space-y-1.5">
              <p className="text-xs font-semibold text-muted-foreground">Sự kiện Calendar gắn với dự án ({events.length})</p>
              {events.length === 0 && (
                <div className="rounded-xl bg-muted/40 py-6 text-center">
                  <p className="text-sm text-muted-foreground">Chưa có sự kiện lịch nào</p>
                  <Button size="sm" variant="outline" className="mt-2 h-8" onClick={() => navigate('calendar')}>Mở Calendar</Button>
                </div>
              )}
              {events.map((e) => (
                <div key={e.id} className="flex items-center gap-3 rounded-xl bg-muted/50 px-3 py-2.5 text-sm">
                  <Calendar className="h-4 w-4 shrink-0 text-muted-foreground" />
                  <span className="min-w-0 flex-1 truncate font-medium">{e.title}</span>
                  <span className="shrink-0 text-[11px] text-muted-foreground">{fmtDate(e.start)}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </Tabs>

      <div className="flex items-center gap-2 border-t pt-3">
        <span className="text-[11px] text-muted-foreground">Cập nhật {timeAgo(project.updatedAt)}</span>
        <Button variant="outline" size="sm" className="ml-auto gap-1.5" onClick={() => patch({ status: 'archived' }, 'project.archived')}>
          <Archive className="h-4 w-4" /> Lưu trữ
        </Button>
        <Button variant="destructive" size="sm" className="gap-1.5" onClick={removeProject}>
          <Trash2 className="h-4 w-4" /> Xoá dự án
        </Button>
      </div>
    </div>
  )
}

function DateField({ label, value, onChange, onBlur }: { label: string; value: string; onChange: (v: string) => void; onBlur: () => void }) {
  return (
    <div>
      <p className="mb-1 text-xs font-medium text-muted-foreground">{label}</p>
      <Input type="date" value={value} onChange={(e) => onChange(e.target.value)} onBlur={onBlur} className="h-9 text-sm" />
    </div>
  )
}
