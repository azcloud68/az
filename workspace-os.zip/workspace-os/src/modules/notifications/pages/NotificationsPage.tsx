'use client'

import { useEffect, useState, useCallback } from 'react'
import { useWos } from '@/core/client/wos-store'
import { api, timeAgo } from '@/core/client/api'
import { bus, eventLabel } from '@/core/client/event-bus'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Bell, Check, Archive, Trash2, Loader2, BellRing, Settings2 } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface NotifRow {
  id: string
  title: string
  content: string
  module: string
  type: string
  read: boolean
  archived: boolean
  action: string
  createdAt: string
}

/** Notification Center đầy đủ — Read/Unread/Archive + cài đặt kênh */
export default function NotificationsPage() {
  const { notifications, refreshNotifications, notifAction, navigate, loadSettings, saveSettings } = useWos()
  const { toast } = useToast()
  const [tab, setTab] = useState<'all' | 'unread' | 'archived'>('all')
  const [browserOn, setBrowserOn] = useState(false)
  const [browserSupported, setBrowserSupported] = useState(true)

  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      setBrowserSupported(true)
      setBrowserOn(Notification.permission === 'granted')
    } else {
      setBrowserSupported(false)
    }
  }, [])

  useEffect(() => {
    refreshNotifications(tab)
    return bus.onAny((ev) => {
      if (ev.type.startsWith('module.') || ev.module === 'core') refreshNotifications(tab)
    })
  }, [tab, refreshNotifications])

  async function requestBrowser() {
    if (!browserSupported) {
      toast({ title: 'Trình duyệt không hỗ trợ thông báo', variant: 'destructive' })
      return
    }
    const perm = await Notification.requestPermission()
    if (perm === 'granted') {
      setBrowserOn(true)
      new Notification('Workspace OS', { body: 'Đã bật thông báo trình duyệt ✅' })
    } else {
      toast({ title: 'Bạn đã từ chối quyền thông báo' })
    }
  }

  async function emptyArchive() {
    if (!confirm('Xoá toàn bộ thông báo đã lưu trữ?')) return
    await api('/api/core/notifications', { method: 'DELETE', body: { archived: true } })
    refreshNotifications(tab)
  }

  const items = notifications.filter((n) =>
    tab === 'unread' ? !n.read : tab === 'archived' ? n.archived : !n.archived
  )

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <h1 className="flex items-center gap-2.5 text-xl font-bold">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-rose-500 text-white">
            <Bell className="h-5 w-5" />
          </span>
          Notifications
          <Badge variant="secondary" className="font-normal">
            {useWos.getState().unreadCount} chưa đọc
          </Badge>
        </h1>
        <div className="ml-auto flex items-center gap-2">
          <Button variant="outline" size="sm" className="h-9 gap-1.5" onClick={() => notifAction([], 'read-all')}>
            <Check className="h-4 w-4" /> Đọc tất cả
          </Button>
          {tab === 'archived' && items.length > 0 && (
            <Button variant="destructive" size="sm" className="h-9 gap-1.5" onClick={emptyArchive}>
              <Trash2 className="h-4 w-4" /> Dọn sạch
            </Button>
          )}
        </div>
      </div>

      {/* Cài đặt kênh nhanh */}
      <Card className="wos-glass border-0">
        <CardContent className="flex flex-wrap items-center gap-x-6 gap-y-3 py-3.5">
          <span className="flex items-center gap-2 text-sm font-medium">
            <Settings2 className="h-4 w-4 text-muted-foreground" /> Kênh nhận thông báo
          </span>
          <div className="flex items-center gap-2">
            <Switch
              id="browser-notif"
              checked={browserOn}
              onCheckedChange={(v) => (v ? requestBrowser() : setBrowserOn(false))}
              disabled={!browserSupported}
            />
            <Label htmlFor="browser-notif" className="text-sm text-muted-foreground">
              Browser {browserSupported ? '' : '(không hỗ trợ)'}
            </Label>
          </div>
          <span className="flex items-center gap-1.5 text-sm text-muted-foreground">
            <BellRing className="h-4 w-4" /> Toast: <Badge className="ml-1">luôn bật</Badge>
          </span>
          <span className="text-xs text-muted-foreground">Email/Desktop: cấu hình tại Settings → Notification</span>
        </CardContent>
      </Card>

      <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)}>
        <TabsList className="h-9">
          <TabsTrigger value="all" className="px-4">Tất cả</TabsTrigger>
          <TabsTrigger value="unread" className="px-4">Chưa đọc</TabsTrigger>
          <TabsTrigger value="archived" className="px-4">Lưu trữ</TabsTrigger>
        </TabsList>
      </Tabs>

      {items.length === 0 ? (
        <div className="wos-glass flex flex-col items-center gap-2 rounded-2xl py-14 text-muted-foreground">
          <Bell className="h-10 w-10 opacity-30" />
          <p className="text-sm">Không có thông báo</p>
        </div>
      ) : (
        <Card className="wos-glass border-0">
          <CardContent className="p-2">
            {items.map((n) => (
              <div
                key={n.id}
                className={`group flex items-start gap-3 rounded-xl px-3 py-3 transition-colors hover:bg-muted ${
                  n.archived ? 'opacity-50' : ''
                }`}
              >
                <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full" style={{ background: n.read ? 'transparent' : 'var(--primary)' }} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-baseline justify-between gap-2">
                    <p className={`truncate text-sm ${n.read ? 'font-normal' : 'font-semibold'}`}>{n.title}</p>
                    <span className="shrink-0 text-[11px] text-muted-foreground">{timeAgo(n.createdAt)}</span>
                  </div>
                  {n.content && <p className="mt-0.5 text-xs text-muted-foreground">{n.content}</p>}
                  <div className="mt-1.5 flex items-center gap-2">
                    <Badge variant="secondary" className="h-4 px-1.5 text-[9px] uppercase">{n.module}</Badge>
                    <Badge variant="outline" className="h-4 px-1.5 text-[9px]">{eventLabel(n.type) || n.type}</Badge>
                    {n.action && (
                      <button onClick={() => navigate(n.action.replace(/^wos:/, ''))} className="text-[11px] text-primary hover:underline">
                        Mở liên kết →
                      </button>
                    )}
                  </div>
                </div>
                <div className="flex shrink-0 items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                  <button
                    onClick={() => notifAction([n.id], n.read ? 'unread' : 'read')}
                    className="rounded-lg p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground"
                    title={n.read ? 'Đánh dấu chưa đọc' : 'Đánh dấu đã đọc'}
                  >
                    <Check className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={() => notifAction([n.id], 'archive')}
                    className="rounded-lg p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground"
                    title="Lưu trữ"
                  >
                    <Archive className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
