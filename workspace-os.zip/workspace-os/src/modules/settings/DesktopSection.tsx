'use client'

/**
 * DesktopSection — Settings → Appearance → "Desktop & Dock" (review #2/#4/#5/#7):
 * nơi duy nhất tuỳ biến desktop sau khi menu chuột phải được làm gọn:
 * 1. Cỡ icon desktop (Nhỏ 40 / Vừa 52 / Lớn 66)
 * 2. Vị trí nút cửa sổ: macOS (trái) / Windows (phải)
 * 3. Ẩn/hiện icon ứng dụng trên desktop
 * 4. Dock Manager: danh sách app ghim (bỏ ghim / về mặc định)
 * 5. Widget Manager: thêm / xoá widget (chuyển từ menu chuột phải desktop)
 * 6. Tải tệp lên Desktop (chuyển từ menu chuột phải desktop)
 */
import { useRef, useState } from 'react'
import { useWos, type DesktopIconSize, type WindowControlSide } from '@/core/client/wos-store'
import { useDesktopStore, system, ICON_SIZES } from '@/core/client/desktop'
import { useDockCandidates, useDockDefaultIds } from '@/components/wos/dock-utils'
import { WIDGET_DEFS, widgetDef } from '@/components/wos/widgets/registry'
import { addWidgetToDesktop } from '@/components/wos/widgets/WidgetLayer'
import { AppIcon } from '@/components/wos/ModuleIcon'
import { Button } from '@/components/ui/button'
import {
  Monitor, AppWindow, Pin, PinOff, RotateCcw, X, Plus, Sparkles, Upload, Loader2, LayoutGrid,
  Eye, FolderOpen, EyeOff,
} from 'lucide-react'
import { toast } from 'sonner'

interface WidgetLike {
  id?: string
  type?: string
}

export function DesktopSection() {
  const desktopIconSize = useWos((s) => s.desktopIconSize)
  const windowControls = useWos((s) => s.windowControls)
  const saveDesktopPrefs = useWos((s) => s.saveDesktopPrefs)
  const dockPinned = useWos((s) => s.dockPinned)
  const saveDockPinned = useWos((s) => s.saveDockPinned)
  const candidates = useDockCandidates()
  const defaultDockIds = useDockDefaultIds()
  const blob = useDesktopStore((s) => s.blob)
  const updateLayout = useDesktopStore((s) => s.update)
  const setHideAppIcons = useDesktopStore((s) => s.setHideAppIcons)
  const setHideAllIcons = useDesktopStore((s) => s.setHideAllIcons)
  const [saving, setSaving] = useState(false)
  const [uploading, setUploading] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)

  const hideAppIcons = blob?.hideAppIcons === true
  const hideAllIcons = blob?.hideAllIcons === true
  /** 3 chế độ hiển thị icon desktop: tất cả | chỉ file + thùng rác | ẩn hết */
  const iconMode: 'all' | 'files' | 'none' = hideAllIcons ? 'none' : hideAppIcons ? 'files' : 'all'
  function setIconMode(mode: 'all' | 'files' | 'none') {
    setHideAllIcons(mode === 'none')
    setHideAppIcons(mode === 'files')
  }
  const widgets = ((blob?.widgets || []) as unknown[])
    .map((w) => (w && typeof w === 'object' ? (w as WidgetLike) : null))
    .filter((w): w is WidgetLike => Boolean(w && w.id && w.type && widgetDef(w.type)))

  const dockIds = dockPinned ?? defaultDockIds
  const byId = new Map(candidates.map((c) => [c.id, c]))
  /** app CHƯA ghim — hiện trong popover "Thêm app" */
  const addable = candidates.filter((c) => !dockIds.includes(c.id))

  async function savePrefs(patch: { windowControls?: WindowControlSide; desktopIconSize?: DesktopIconSize }) {
    setSaving(true)
    try {
      await saveDesktopPrefs(patch)
    } catch (err) {
      toast.error('Không lưu được', { description: err instanceof Error ? err.message : '' })
    } finally {
      setSaving(false)
    }
  }

  async function uploadToDesktop(files: FileList | File[]) {
    const arr = Array.from(files)
    if (!arr.length) return
    setUploading(true)
    try {
      await system.uploadToDesktop(arr)
      toast.success('Đã tải lên Desktop', { description: `${arr.length} tệp` })
    } catch (err) {
      toast.error('Tải lên thất bại', { description: err instanceof Error ? err.message : '' })
    } finally {
      setUploading(false)
    }
  }

  function removeWidget(id: string) {
    updateLayout((prev) => ({
      ...prev,
      widgets: ((prev.widgets || []) as unknown[]).filter((raw) => (raw as WidgetLike).id !== id),
    }))
  }

  return (
    <div className="space-y-5">
      {/* ===== 1. Cỡ icon desktop (review #7) ===== */}
      <div className="grid grid-cols-1 items-center gap-2 md:grid-cols-[220px_1fr]">
        <p className="text-sm font-medium text-muted-foreground">Cỡ icon Desktop</p>
        <div className="flex gap-2">
          {(['small', 'medium', 'large'] as DesktopIconSize[]).map((s) => (
            <button
              key={s}
              onClick={() => void savePrefs({ desktopIconSize: s })}
              className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium transition-colors ${
                desktopIconSize === s ? 'bg-primary text-primary-foreground shadow' : 'bg-muted/60 text-muted-foreground hover:bg-muted'
              }`}
            >
              <LayoutGrid style={{ width: ICON_SIZES[s].tile * 0.42, height: ICON_SIZES[s].tile * 0.42 }} />
              {ICON_SIZES[s].label} · {ICON_SIZES[s].tile}px
            </button>
          ))}
        </div>
      </div>

      {/* ===== 2. Vị trí nút cửa sổ (review #4) ===== */}
      <div className="grid grid-cols-1 items-center gap-2 md:grid-cols-[220px_1fr]">
        <p className="text-sm font-medium text-muted-foreground">Kiểu nút cửa sổ</p>
        <div className="flex gap-2">
          <button
            onClick={() => void savePrefs({ windowControls: 'left' })}
            className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium transition-colors ${
              windowControls !== 'right' ? 'bg-primary text-primary-foreground shadow' : 'bg-muted/60 text-muted-foreground hover:bg-muted'
            }`}
          >
            <AppWindow className="h-4 w-4" /> macOS (nút bên trái)
          </button>
          <button
            onClick={() => void savePrefs({ windowControls: 'right' })}
            className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium transition-colors ${
              windowControls === 'right' ? 'bg-primary text-primary-foreground shadow' : 'bg-muted/60 text-muted-foreground hover:bg-muted'
            }`}
          >
            <AppWindow className="h-4 w-4" /> Windows (nút bên phải)
          </button>
        </div>
      </div>

      {/* ===== 3. Ẩn/hiện icon desktop (v6.1 — 3 chế độ, có "Ẩn tất cả" như macOS) ===== */}
      <div className="grid grid-cols-1 items-center gap-2 md:grid-cols-[220px_1fr]">
        <p className="text-sm font-medium text-muted-foreground">Icon trên Desktop</p>
        <div className="flex flex-wrap gap-2">
          {([
            { key: 'all', label: 'Hiện tất cả', icon: Eye },
            { key: 'files', label: 'Chỉ file + thùng rác', icon: FolderOpen },
            { key: 'none', label: 'Ẩn tất cả', icon: EyeOff },
          ] as const).map((o) => (
            <button
              key={o.key}
              onClick={() => setIconMode(o.key)}
              className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium transition-colors ${
                iconMode === o.key ? 'bg-primary text-primary-foreground shadow' : 'bg-muted/60 text-muted-foreground hover:bg-muted'
              }`}
            >
              <o.icon className="h-4 w-4" /> {o.label}
            </button>
          ))}
        </div>
        <p className="col-span-full -mt-2 text-xs text-muted-foreground md:col-span-1 md:col-start-2">
          {iconMode === 'none'
            ? 'Đang ẩn toàn bộ icon — desktop trống hoàn toàn (kéo-thả tệp lên desktop vẫn hoạt động)'
            : iconMode === 'files'
              ? 'Đang ẩn icon ứng dụng — chỉ hiện file, thư mục và thùng rác'
              : 'Đang hiện đầy đủ icon ứng dụng + file + thùng rác'}
        </p>
      </div>

      {/* ===== 4. Dock Manager (review #5) ===== */}
      <div className="rounded-xl bg-muted/40 p-4">
        <div className="mb-2 flex items-center justify-between gap-2">
          <p className="flex items-center gap-2 text-sm font-semibold">
            <Pin className="h-4 w-4 text-amber-500" /> Dock — {dockIds.length} app ghim
          </p>
          <Button
            size="sm"
            variant="outline"
            className="h-7 gap-1.5 text-xs"
            disabled={dockPinned === null}
            onClick={() => void saveDockPinned(null)}
            title="Quay lại danh sách mặc định tự động theo module"
          >
            <RotateCcw className="h-3.5 w-3.5" /> Mặc định
          </Button>
        </div>
        <p className="mb-3 text-xs text-muted-foreground">
          Kéo icon trong Dock để sắp xếp · kéo xuống khỏi Dock để bỏ ghim · right-click icon để ghim/bỏ ghim.
        </p>
        <div className="mb-3 flex flex-wrap gap-1.5">
          {dockIds.map((id) => {
              const m = byId.get(id)
              if (!m) return null
              return (
                <span
                  key={id}
                  className="flex items-center gap-1.5 rounded-full border bg-card px-2.5 py-1 text-[12px]"
                >
                  <AppIcon moduleId={id} icon={m.icon} px={14} className="h-3.5 w-3.5" />
                  <span className="max-w-[120px] truncate">{m.name}</span>
                  <button
                    onClick={() => void saveDockPinned(dockIds.filter((x) => x !== id))}
                    className="rounded-full p-0.5 text-muted-foreground transition hover:bg-black/10 hover:text-foreground dark:hover:bg-white/15"
                    aria-label={`Bỏ ${m.name} khỏi Dock`}
                    title="Bỏ ghim khỏi Dock"
                  >
                    <PinOff className="h-3 w-3" />
                  </button>
                </span>
              )
            })}
        </div>
        {/* Thêm app tuỳ ý — MỌI app (module + plugin), v6.3 */}
        <div className="mt-3 border-t pt-3">
          <p className="mb-2 text-xs font-medium text-muted-foreground">
            Thêm / bớt tuỳ ý — mọi ứng dụng ({candidates.length} app: module + plugin):
          </p>
          <div className="wos-scroll flex max-h-44 flex-wrap gap-1.5 overflow-y-auto pr-1">
            {candidates.map((c) => {
              const pinned = dockIds.includes(c.id)
              return (
                <button
                  key={c.id}
                  onClick={() => {
                    const next = pinned ? dockIds.filter((x) => x !== c.id) : [...dockIds, c.id]
                    void saveDockPinned(next)
                  }}
                  className={`flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[12px] transition ${
                    pinned ? 'border-amber-500/50 bg-amber-500/10 font-medium' : 'bg-card hover:bg-accent'
                  }`}
                  title={pinned ? `Bỏ ${c.name} khỏi Dock` : `Ghim ${c.name} vào Dock`}
                >
                  <AppIcon moduleId={c.id} icon={c.icon} px={14} className="h-3.5 w-3.5" />
                  <span className="max-w-[130px] truncate">{c.name}</span>
                  {c.isPlugin ? <span className="text-[9px] text-violet-500">plugin</span> : null}
                  {pinned ? <PinOff className="h-3 w-3 text-amber-600" /> : <Pin className="h-3 w-3 text-muted-foreground" />}
                </button>
              )
            })}
          </div>
        </div>
      </div>

      {/* ===== 5. Widget Manager (review #2 — chuyển từ menu desktop) ===== */}
      <div className="rounded-xl bg-muted/40 p-4">
        <div className="mb-2 flex items-center justify-between gap-2">
          <p className="flex items-center gap-2 text-sm font-semibold">
            <Sparkles className="h-4 w-4 text-violet-500" /> Widget trên Desktop — {widgets.length}
          </p>
        </div>
        {widgets.length > 0 ? (
          <div className="mb-3 flex flex-wrap gap-1.5">
            {widgets.map((w) => {
              const def = widgetDef(w.type!)
              const Icon = def?.icon
              return (
                <span key={w.id} className="flex items-center gap-1.5 rounded-full border bg-card px-2.5 py-1 text-[12px]">
                  {Icon ? <Icon className="h-3.5 w-3.5" /> : null}
                  {def?.title || w.type}
                  <button
                    onClick={() => removeWidget(w.id!)}
                    className="rounded-full p-0.5 text-muted-foreground transition hover:bg-black/10 hover:text-foreground dark:hover:bg-white/15"
                    aria-label={`Xoá widget ${def?.title || w.type}`}
                  >
                    <X className="h-3 w-3" />
                  </button>
                </span>
              )
            })}
          </div>
        ) : (
          <p className="mb-3 text-xs text-muted-foreground">Chưa có widget nào trên desktop.</p>
        )}
        <div className="flex flex-wrap items-center gap-1.5">
          {WIDGET_DEFS.map((w) => (
            <button
              key={w.type}
              onClick={() => {
                addWidgetToDesktop(w.type)
                toast.success(`Đã thêm widget ${w.title}`)
              }}
              className="flex items-center gap-1.5 rounded-full border bg-card px-2.5 py-1 text-[12px] transition hover:bg-accent"
            >
              <Plus className="h-3 w-3" /> {w.title}
            </button>
          ))}
        </div>
      </div>

      {/* ===== 6. Tải tệp lên Desktop (review #2 — chuyển từ menu desktop) ===== */}
      <div className="grid grid-cols-1 items-center gap-2 md:grid-cols-[220px_1fr]">
        <p className="text-sm font-medium text-muted-foreground">Tệp trên Desktop</p>
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
          <Button size="sm" variant="outline" className="h-8 gap-1.5 text-xs" disabled={uploading} onClick={() => fileRef.current?.click()}>
            {uploading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Upload className="h-3.5 w-3.5" />} Tải tệp lên Desktop…
          </Button>
          <p className="text-xs text-muted-foreground">Hoặc kéo-thả tệp từ máy vào nền desktop.</p>
          <input
            ref={fileRef}
            type="file"
            multiple
            className="hidden"
            onChange={(e) => {
              if (e.target.files?.length) void uploadToDesktop(e.target.files)
              e.target.value = ''
            }}
            aria-hidden
          />
        </div>
      </div>

      {saving ? (
        <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <Loader2 className="h-3 w-3 animate-spin" /> Đang lưu…
        </p>
      ) : null}
      <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
        <Monitor className="h-3.5 w-3.5" /> Mọi tuỳ chọn lưu theo tài khoản — đăng nhập máy nào cũng giữ nguyên.
      </p>
    </div>
  )
}
