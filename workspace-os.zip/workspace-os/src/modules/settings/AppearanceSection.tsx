'use client'

/**
 * AppearanceSection — Settings → Appearance:
 * 1. Hình nền desktop (mở WallpaperPicker + preview hiện tại).
 * 2. Hiệu ứng thời tiết Desktop: tự động theo thời tiết thật / thủ công, độ mạnh,
 *    vị trí (geolocation hoặc tìm thành phố) — per-account.
 * 3. Nhân vật desktop (mèo Nyanko): bật/tắt.
 * 4. Tuỳ biến icon + màu TẤT CẢ app (kể cả app PLUGIN) — ảnh tải lên hiển thị
 *    FULL size như icon macOS; kèm quản lý "icon đã ẩn từng app" (hiện lại).
 * Lưu Setting module 'appearance' qua wos-store saveAppearance/saveAtmosphere/savePet.
 */
import { useRef, useState } from 'react'
import { useWos, type IconOverride, type AtmosEffect, type AtmosIntensity } from '@/core/client/wos-store'
import { useTheme } from 'next-themes'
import { AppIconTile } from '@/components/wos/ModuleIcon'
import { WallpaperPicker } from '@/components/wos/WallpaperPicker'
import { wallpaperStyle } from '@/components/wos/wallpaper'
import { DesktopSection } from '@/modules/settings/DesktopSection'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import {
  Sun, Moon, Wallpaper as WallpaperIcon, Palette, RotateCcw, Loader2, Check, CloudSun, MapPin,
  Cat as CatIcon, EyeOff, Eye, Search, Monitor,
} from 'lucide-react'
import { toast } from 'sonner'
import { api } from '@/core/client/api'

/** Thư viện emoji cho icon app */
const EMOJI_LIBRARY: string[][] = [
  ['🏠', '🗂️', '📊', '📋', '📅', '🗒️', '📖', '📁', '🔗', '📈'],
  ['✅', '⏰', '🔔', '👥', '⚙️', '🧪', '🔬', '💊', '🩺', '🧬'],
  ['🚀', '💡', '🎨', '🖌️', '📝', '✍️', '📚', '🎓', '🧠', '🎯'],
  ['☁️', '🌙', '⭐', '🔥', '💧', '🌱', '🍀', '🌈', '☀️', '⛅'],
  ['💾', '🗄️', '🔒', '🔑', '🛠️', '⚙️', '🧰', '📡', '🖥️', '⌨️'],
  ['💼', '📈', '📉', '🧾', '📦', '🚚', '💰', '🏦', '🛒', '🏷️'],
]

const COLOR_SWATCHES = [
  '#f97316', '#ea580c', '#f59e0b', '#eab308', '#84cc16', '#22c55e', '#10b981',
  '#14b8a6', '#06b6d4', '#0891b2', '#3b82f6', '#2563eb', '#6366f1', '#8b5cf6',
  '#a855f7', '#d946ef', '#ec4899', '#f43f5e', '#64748b', '#0f172a',
]

const EFFECTS: { value: AtmosEffect; label: string; icon: string }[] = [
  { value: 'auto', label: 'Tự động (theo thời tiết thật)', icon: '🌡️' },
  { value: 'sunny', label: 'Nắng', icon: '☀️' },
  { value: 'clouds', label: 'Mây', icon: '☁️' },
  { value: 'rain', label: 'Mưa', icon: '🌧️' },
  { value: 'storm', label: 'Bão (mưa + sét + gió)', icon: '⛈️' },
  { value: 'snow', label: 'Tuyết', icon: '❄️' },
  { value: 'wind', label: 'Gió', icon: '💨' },
  { value: 'off', label: 'Tắt hiệu ứng', icon: '🚫' },
]

const INTENSITIES: { value: AtmosIntensity; label: string }[] = [
  { value: 'light', label: 'Nhẹ' },
  { value: 'normal', label: 'Vừa' },
  { value: 'strong', label: 'Mạnh' },
]

interface GeoResult { name: string; latitude: number; longitude: string | number; country?: string }

export function AppearanceSection() {
  const {
    wallpaper, iconOverrides, iconColors, saveAppearance, modules, plugins,
    atmosphere, saveAtmosphere, pet, savePet, iconHidden, setIconHidden,
  } = useWos()
  const { theme, setTheme } = useTheme()
  const [pickerOpen, setPickerOpen] = useState(false)
  const [emojiFor, setEmojiFor] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)
  const [uploadingFor, setUploadingFor] = useState<string | null>(null)

  // === thời tiết: tìm thành phố + geolocation ===
  const [geoQuery, setGeoQuery] = useState(atmosphere.city || '')
  const [geoResults, setGeoResults] = useState<GeoResult[]>([])
  const [geoSearching, setGeoSearching] = useState(false)
  const [locating, setLocating] = useState(false)

  async function persist(nextOverrides: Record<string, IconOverride>, nextColors: Record<string, string>) {
    setSaving(true)
    try {
      await saveAppearance({ app_icons: JSON.stringify(nextOverrides), app_colors: JSON.stringify(nextColors) })
    } catch (err) {
      toast.error('Không lưu được', { description: err instanceof Error ? err.message : '' })
    } finally {
      setSaving(false)
    }
  }

  function setEmoji(moduleId: string, emoji: string) {
    const next: Record<string, IconOverride> = { ...iconOverrides, [moduleId]: { type: 'emoji', value: emoji } }
    void persist(next, iconColors)
    setEmojiFor(null)
  }

  function setColor(moduleId: string, color: string) {
    const next = { ...iconColors, [moduleId]: color }
    void persist(iconOverrides, next)
  }

  function resetApp(moduleId: string) {
    const nextO = { ...iconOverrides }
    delete nextO[moduleId]
    const nextC = { ...iconColors }
    delete nextC[moduleId]
    void persist(nextO, nextC)
  }

  async function uploadIcon(moduleId: string, file: File) {
    if (!file.type.startsWith('image/')) {
      toast.error('Chọn tệp ảnh làm icon')
      return
    }
    setUploadingFor(moduleId)
    try {
      const form = new FormData()
      form.append('files', file)
      const res = await fetch('/api/modules/files/upload?dir=Icons', { method: 'POST', body: form })
      if (!res.ok) throw new Error(JSON.parse(await res.text()).error || `HTTP ${res.status}`)
      const data = (await res.json()) as { files?: { name?: string; path?: string }[] }
      const f = data.files?.[0]
      const rel = f?.path || `Icons/${f?.name || file.name}`
      const next: Record<string, IconOverride> = {
        ...iconOverrides,
        [moduleId]: { type: 'image', value: `/api/modules/files/download?path=${encodeURIComponent(rel)}&inline=1` },
      }
      await persist(next, iconColors)
      toast.success('Đã đổi icon', { description: 'Ảnh hiển thị full-size như icon macOS' })
    } catch (err) {
      toast.error('Tải icon thất bại', { description: err instanceof Error ? err.message : '' })
    } finally {
      setUploadingFor(null)
    }
  }

  async function searchCity() {
    if (!geoQuery.trim()) return
    setGeoSearching(true)
    try {
      const res = await fetch(
        `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(geoQuery.trim())}&count=6&language=vi`,
      )
      const data = (await res.json()) as { results?: GeoResult[] }
      setGeoResults(data.results || [])
    } catch {
      setGeoResults([])
    } finally {
      setGeoSearching(false)
    }
  }

  function useMyLocation() {
    if (!navigator.geolocation) {
      toast.error('Trình duyệt không hỗ trợ định vị')
      return
    }
    setLocating(true)
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocating(false)
        void saveAtmosphere({
          lat: Number(pos.coords.latitude.toFixed(5)),
          lon: Number(pos.coords.longitude.toFixed(5)),
          city: 'Vị trí của tôi',
          source: 'geolocation',
        })
        toast.success('Đã dùng vị trí hiện tại', { description: 'Hiệu ứng thời tiết sẽ đúng nơi bạn đang ở' })
      },
      () => {
        setLocating(false)
        toast.error('Không lấy được vị trí', { description: 'Hãy cho phép truy cập vị trí hoặc chọn thành phố thủ công' })
      },
      { timeout: 8000 },
    )
  }

  /** apps = module + app plugin (đổi icon được cho CẢ plugin cài thêm) */
  const apps = [
    ...[...modules].sort((a, b) => a.order - b.order).map((m) => ({ id: m.id, name: m.name, icon: m.icon, color: m.color, isPlugin: false })),
    ...plugins.filter((p) => p.kind === 'app').map((p) => ({ id: p.slug, name: `${p.name} (plugin)`, icon: p.icon, color: p.color, isPlugin: true })),
  ]

  const hiddenApps = apps.filter((a) => iconHidden[a.id])

  return (
    <Card className="wos-glass border-0">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg font-semibold">
          <Palette className="h-5 w-5 text-muted-foreground" /> Appearance
        </CardTitle>
        <p className="text-sm text-muted-foreground">Chủ đề, hình nền, hiệu ứng thời tiết, nhân vật và tuỳ biến icon mọi ứng dụng</p>
      </CardHeader>
      <CardContent className="space-y-5">
        {/* ===== DESKTOP & DOCK (review #2/#4/#5/#7 — chuyển từ menu chuột phải desktop) ===== */}
        <div className="rounded-xl bg-muted/40 p-4">
          <div className="mb-3 flex items-center gap-2">
            <Monitor className="h-4 w-4 text-primary" />
            <p className="text-sm font-semibold">Desktop &amp; Dock</p>
          </div>
          <DesktopSection />
        </div>

        {/* Chủ đề */}
        <div className="grid grid-cols-1 items-center gap-2 md:grid-cols-[220px_1fr]">
          <p className="text-sm font-medium text-muted-foreground">Chủ đề</p>
          <div className="flex gap-2">
            <button
              onClick={() => setTheme('light')}
              className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium transition-colors ${theme !== 'dark' ? 'bg-primary text-primary-foreground shadow' : 'bg-muted/60 text-muted-foreground hover:bg-muted'}`}
            >
              <Sun className="h-4 w-4" /> Sáng
            </button>
            <button
              onClick={() => setTheme('dark')}
              className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium transition-colors ${theme === 'dark' ? 'bg-primary text-primary-foreground shadow' : 'bg-muted/60 text-muted-foreground hover:bg-muted'}`}
            >
              <Moon className="h-4 w-4" /> Tối
            </button>
          </div>
        </div>

        {/* Hình nền */}
        <div className="grid grid-cols-1 items-center gap-2 md:grid-cols-[220px_1fr]">
          <p className="text-sm font-medium text-muted-foreground">Hình nền Desktop</p>
          <div className="flex items-center gap-3 rounded-xl bg-muted/50 p-3">
            <div className="wos-wallpaper h-14 w-24 rounded-lg" style={{ ...wallpaperStyle(wallpaper), animation: 'none', position: 'relative' }} />
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium">
                {wallpaper.kind === 'default' ? 'Sonoma Horizon (mặc định)' : wallpaper.kind === 'image' ? 'Ảnh tuỳ chỉnh' : 'Gradient / màu'}
              </p>
              <p className="text-xs text-muted-foreground">Đổi ngay trên desktop: right-click → Đổi hình nền…</p>
            </div>
            <Button size="sm" className="shrink-0 gap-1.5" onClick={() => setPickerOpen(true)}>
              <WallpaperIcon className="h-4 w-4" /> Đổi…
            </Button>
          </div>
        </div>

        {/* ===== HIỆU ỨNG THỜI TIẾT ===== */}
        <div className="rounded-xl bg-muted/40 p-4">
          <div className="mb-3 flex items-center justify-between">
            <p className="flex items-center gap-2 text-sm font-semibold">
              <CloudSun className="h-4 w-4 text-sky-500" /> Hiệu ứng thời tiết Desktop
            </p>
            {/* bật/tắt */}
            <button
              role="switch"
              aria-checked={atmosphere.enabled && atmosphere.effect !== 'off'}
              onClick={() => void saveAtmosphere({ enabled: !(atmosphere.enabled && atmosphere.effect !== 'off') })}
              className={`relative h-6 w-11 rounded-full transition-colors ${atmosphere.enabled && atmosphere.effect !== 'off' ? 'bg-emerald-500' : 'bg-muted-foreground/40'}`}
            >
              <span
                className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${atmosphere.enabled && atmosphere.effect !== 'off' ? 'left-[22px]' : 'left-0.5'}`}
              />
            </button>
          </div>

          <div className="space-y-3">
            <div>
              <p className="mb-1.5 text-xs font-medium text-muted-foreground">Hiệu ứng</p>
              <div className="flex flex-wrap gap-1.5">
                {EFFECTS.map((ef) => {
                  const active = atmosphere.enabled && atmosphere.effect === ef.value
                  return (
                    <button
                      key={ef.value}
                      onClick={() => void saveAtmosphere({ enabled: ef.value !== 'off', effect: ef.value })}
                      className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium transition-colors ${
                        active ? 'bg-sky-500 text-white shadow' : 'bg-muted/70 text-muted-foreground hover:bg-muted'
                      }`}
                    >
                      <span>{ef.icon}</span> {ef.label}
                    </button>
                  )
                })}
              </div>
              {atmosphere.enabled && atmosphere.effect === 'auto' && (
                <p className="mt-1.5 text-[11px] text-muted-foreground">
                  Mưa, mây, bão, tuyết, gió… sẽ tự đổi ĐÚNG theo thời tiết thật tại vị trí bên dưới (cập nhật mỗi 10 phút,
                  dùng chung nguồn với widget Thời tiết — hai bên luôn khớp nhau).
                </p>
              )}
            </div>

            <div>
              <p className="mb-1.5 text-xs font-medium text-muted-foreground">Độ mạnh hiệu ứng</p>
              <div className="flex gap-1.5">
                {INTENSITIES.map((it) => (
                  <button
                    key={it.value}
                    onClick={() => void saveAtmosphere({ intensity: it.value })}
                    className={`rounded-full px-3 py-1.5 text-xs font-medium transition-colors ${
                      atmosphere.intensity === it.value ? 'bg-primary text-primary-foreground shadow' : 'bg-muted/70 text-muted-foreground hover:bg-muted'
                    }`}
                  >
                    {it.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <p className="mb-1.5 text-xs font-medium text-muted-foreground">Vị trí (cho chế độ tự động)</p>
              <div className="flex flex-wrap items-center gap-2">
                <Button variant="outline" size="sm" className="h-8 gap-1.5 text-xs" disabled={locating} onClick={useMyLocation}>
                  {locating ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <MapPin className="h-3.5 w-3.5" />} Dùng vị trí của tôi
                </Button>
                <span className="text-[11px] text-muted-foreground">
                  Hiện tại: {atmosphere.city || 'TP. Hồ Chí Minh'} ({atmosphere.lat.toFixed(3)}, {atmosphere.lon.toFixed(3)})
                </span>
              </div>
              <div className="mt-2 flex gap-1.5">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
                  <input
                    value={geoQuery}
                    onChange={(e) => setGeoQuery(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && searchCity()}
                    placeholder="Tìm thành phố khác (Enter)…"
                    className="h-8 w-full rounded-lg bg-muted pl-8 pr-2.5 text-[12.5px] outline-none"
                  />
                </div>
                <Button variant="outline" size="sm" className="h-8 text-xs" onClick={searchCity} disabled={geoSearching}>
                  {geoSearching ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : 'Tìm'}
                </Button>
              </div>
              {geoResults.length > 0 && (
                <div className="mt-1.5 max-h-40 space-y-1 overflow-y-auto rounded-lg bg-muted/50 p-1.5">
                  {geoResults.map((r) => (
                    <button
                      key={`${r.name}-${r.latitude}`}
                      onClick={() => {
                        void saveAtmosphere({
                          lat: Number(r.latitude),
                          lon: Number(r.longitude),
                          city: r.name,
                          source: 'manual',
                        })
                        setGeoResults([])
                        toast.success(`Đã đặt vị trí: ${r.name}`)
                      }}
                      className="block w-full truncate rounded-md px-2 py-1.5 text-left text-[12px] hover:bg-muted"
                    >
                      {r.name}
                      {r.country ? `, ${r.country}` : ''}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* ===== NHÂN VẬT DESKTOP (MÈO) ===== */}
        <div className="grid grid-cols-1 items-center gap-2 md:grid-cols-[220px_1fr]">
          <p className="flex items-center gap-1.5 text-sm font-medium text-muted-foreground">
            <CatIcon className="h-4 w-4" /> Nhân vật desktop
          </p>
          <div className="flex items-center justify-between gap-3 rounded-xl bg-muted/50 p-3">
            <div className="min-w-0">
              <p className="text-sm font-medium">Mèo Nyanko 🐱</p>
              <p className="text-xs text-muted-foreground">
                Chạy trên desktop, đuổi bướm, ngồi lên icon và &quot;nghĩ&quot; ra thông báo mới trong bong bóng truyện tranh
              </p>
            </div>
            <button
              role="switch"
              aria-checked={pet.enabled}
              onClick={() => void savePet({ enabled: !pet.enabled })}
              className={`relative h-6 w-11 shrink-0 rounded-full transition-colors ${pet.enabled ? 'bg-emerald-500' : 'bg-muted-foreground/40'}`}
            >
              <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${pet.enabled ? 'left-[22px]' : 'left-0.5'}`} />
            </button>
          </div>
        </div>

        {/* ===== ICON ĐÃ ẨN TỪNG APP ===== */}
        {hiddenApps.length > 0 && (
          <div className="rounded-xl border border-amber-500/30 bg-amber-500/10 p-3">
            <div className="mb-2 flex items-center justify-between">
              <p className="flex items-center gap-1.5 text-sm font-semibold text-amber-700 dark:text-amber-300">
                <EyeOff className="h-4 w-4" /> Icon đang ẩn ({hiddenApps.length})
              </p>
              <Button
                variant="outline"
                size="sm"
                className="h-7 gap-1 text-xs"
                onClick={() => {
                  for (const a of hiddenApps) void setIconHidden(a.id, false)
                  toast.success('Đã hiện lại tất cả icon')
                }}
              >
                <Eye className="h-3.5 w-3.5" /> Hiện tất cả
              </Button>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {hiddenApps.map((a) => (
                <button
                  key={a.id}
                  onClick={() => void setIconHidden(a.id, false)}
                  className="flex items-center gap-1.5 rounded-full bg-background/70 px-2.5 py-1 text-xs font-medium shadow-sm transition hover:scale-[1.03]"
                  title={`Hiện lại ${a.name}`}
                >
                  <AppIconTile moduleId={a.id} icon={a.icon} color={a.color} size={18} glyphPx={10} className="!rounded-full" />
                  {a.name}
                  <Eye className="h-3 w-3 text-muted-foreground" />
                </button>
              ))}
            </div>
            <p className="mt-1.5 text-[11px] text-muted-foreground">Bấm từng app để hiện lại icon trên desktop</p>
          </div>
        )}

        {/* Icon tuỳ biến */}
        <div>
          <div className="mb-2 flex items-center justify-between">
            <p className="text-sm font-medium text-muted-foreground">
              Biểu tượng ứng dụng ({apps.length} app · gồm cả plugin)
            </p>
            {saving && <span className="flex items-center gap-1.5 text-xs text-muted-foreground"><Loader2 className="h-3.5 w-3.5 animate-spin" /> Đang lưu…</span>}
          </div>
          <p className="mb-3 text-xs text-muted-foreground">
            Bấm ô emoji để chọn icon mới · bấm ô màu để đổi màu · &quot;Ảnh&quot; tải icon PNG/SVG riêng (hiển thị full-size như macOS) · ↺ để trở về mặc định
          </p>
          <div className="space-y-1.5">
            {apps.map((m) => {
              const ov = iconOverrides[m.id]
              const color = iconColors[m.id] || m.color
              const hasEmoji = ov?.type === 'emoji'
              return (
                <div key={m.id} className="flex flex-wrap items-center gap-2.5 rounded-xl bg-muted/50 px-3 py-2.5">
                  {/* Preview — dùng đúng component desktop để ảnh hiển thị full-size */}
                  <AppIconTile moduleId={m.id} icon={m.icon} color={color} size={44} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold">{m.name}</p>
                    <p className="truncate text-[11px] text-muted-foreground">{m.id}{m.isPlugin ? ' · plugin' : ''}</p>
                  </div>

                  {/* Chọn emoji */}
                  <Popover open={emojiFor === m.id} onOpenChange={(o) => setEmojiFor(o ? m.id : null)}>
                    <PopoverTrigger asChild>
                      <Button variant="outline" size="sm" className="h-9 gap-1.5 text-xs">
                        {ov?.type === 'emoji' ? ov.value : '😀'} Emoji
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-[300px] p-3" align="end">
                      <p className="mb-2 text-xs font-medium text-muted-foreground">Chọn icon emoji cho {m.name}</p>
                      <div className="wos-scroll max-h-[260px] space-y-1.5 overflow-y-auto">
                        {EMOJI_LIBRARY.map((row, i) => (
                          <div key={i} className="flex justify-between">
                            {row.map((em) => (
                              <button
                                key={em}
                                onClick={() => setEmoji(m.id, em)}
                                className="relative flex h-8 w-8 items-center justify-center rounded-lg text-xl transition hover:bg-muted"
                                aria-label={`Icon ${em}`}
                              >
                                {em}
                                {ov?.value === em && <Check className="absolute -bottom-0.5 -right-0.5 h-3.5 w-3.5 rounded-full bg-primary p-0.5 text-primary-foreground" />}
                              </button>
                            ))}
                          </div>
                        ))}
                      </div>
                    </PopoverContent>
                  </Popover>

                  {/* Ảnh icon */}
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-9 gap-1.5 text-xs"
                    disabled={uploadingFor === m.id}
                    onClick={() => {
                      fileRef.current?.setAttribute('data-module-id', m.id)
                      fileRef.current?.click()
                    }}
                  >
                    {uploadingFor === m.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : null} Ảnh
                  </Button>

                  {/* Màu */}
                  <Popover>
                    <PopoverTrigger asChild>
                      <button
                        className="h-9 w-9 shrink-0 rounded-lg border border-border"
                        style={{ background: color }}
                        aria-label={`Màu ${m.name}`}
                        title="Đổi màu app"
                      />
                    </PopoverTrigger>
                    <PopoverContent className="w-[230px] p-3" align="end">
                      <p className="mb-2 text-xs font-medium text-muted-foreground">Màu nhận diện {m.name}</p>
                      <div className="grid grid-cols-7 gap-1.5">
                        {COLOR_SWATCHES.map((c) => (
                          <button
                            key={c}
                            onClick={() => setColor(m.id, c)}
                            className={`relative h-7 w-7 rounded-lg transition hover:scale-110 ${color === c ? 'ring-2 ring-foreground ring-offset-2' : ''}`}
                            style={{ background: c }}
                            aria-label={c}
                          />
                        ))}
                      </div>
                      <div className="mt-2 flex items-center gap-2">
                        <Input
                          type="color"
                          defaultValue={color}
                          onChange={(e) => setColor(m.id, e.target.value)}
                          className="h-8 w-12 cursor-pointer p-0.5"
                          aria-label="Màu tuỳ chỉnh"
                        />
                        <span className="text-[11px] text-muted-foreground">Màu tuỳ chỉnh</span>
                      </div>
                    </PopoverContent>
                  </Popover>

                  {/* Reset */}
                  {(ov || iconColors[m.id]) && (
                    <Button variant="ghost" size="sm" className="h-9 w-9 shrink-0 p-0" onClick={() => resetApp(m.id)} aria-label="Trở về mặc định" title="Trở về mặc định">
                      <RotateCcw className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              )
            })}
          </div>
        </div>
      </CardContent>

      <WallpaperPicker open={pickerOpen} onClose={() => setPickerOpen(false)} />

      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          const moduleId = (e.target as HTMLInputElement).dataset.moduleId
          if (e.target.files?.[0] && moduleId) void uploadIcon(moduleId, e.target.files[0])
          e.target.value = ''
        }}
        aria-hidden
      />
    </Card>
  )
}
