'use client'

/**
 * Settings → Sync & Backup Google Drive (section 'sync')
 * 3 card wos-glass: Google Drive (OAuth) • Nguồn & lịch backup • Lịch sử & tệp Drive
 */
import { useCallback, useEffect, useRef, useState } from 'react'
import { api, formatBytes, fmtDateTime } from '@/core/client/api'
import { useWos } from '@/core/client/wos-store'
import { useToast } from '@/hooks/use-toast'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import {
  CheckCircle2, Cloud, CloudUpload, Copy, Database, Download,
  ExternalLink, FileArchive, FileJson, FolderOpen, HardDrive, Info, Link2Off,
  Loader2, RefreshCw, Save, XCircle,
} from 'lucide-react'

interface SyncConfigDto {
  has_client_id: boolean
  has_secret: boolean
  has_token: boolean
  account: string
  sources: { db: boolean; files: boolean; config: boolean }
  schedule: 'off' | 'daily' | 'weekly'
  keep: number
  drive_usage: { limit: number; usage: number; usageInDrive: number } | null
}

interface BackupRunDto {
  id: string
  trigger: string
  status: string
  provider: string
  fileName: string
  size: number
  fileCount: number
  remoteId: string
  error: string
  startedAt: string
  finishedAt: string | null
}

interface DriveFileDto {
  id: string
  name: string
  size: number
  modifiedTime: string
}

export default function SyncSection() {
  const { toast } = useToast()
  const { user } = useWos()
  const isAdmin = user?.role === 'admin'

  const [config, setConfig] = useState<SyncConfigDto | null>(null)
  const [history, setHistory] = useState<BackupRunDto[]>([])
  const [driveFiles, setDriveFiles] = useState<DriveFileDto[] | null>(null)
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)

  // form Google Drive
  const [clientId, setClientId] = useState('')
  const [clientSecret, setClientSecret] = useState('')
  const [savingConn, setSavingConn] = useState(false)
  const [origin, setOrigin] = useState('')

  // form nguồn & lịch
  const [sources, setSources] = useState({ db: true, files: true, config: true })
  const [schedule, setSchedule] = useState<'off' | 'daily' | 'weekly'>('off')
  const [keep, setKeep] = useState('7')
  const [savingSrc, setSavingSrc] = useState(false)
  const [backing, setBacking] = useState(false)

  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const refreshDriveFiles = useCallback(async () => {
    try {
      const f = await api<{ files: DriveFileDto[] }>('/api/modules/sync/gdrive/files')
      setDriveFiles(f.files)
    } catch {
      setDriveFiles([])
    }
  }, [])

  const loadAll = useCallback(
    async (opts: { withFiles?: boolean } = {}) => {
      try {
        const d = await api<{ config: SyncConfigDto; history: BackupRunDto[] }>('/api/modules/sync')
        setConfig(d.config)
        setHistory(d.history)
        setSources(d.config.sources)
        setSchedule(d.config.schedule)
        setKeep(String(d.config.keep))
        if (opts.withFiles !== false) await refreshDriveFiles()
      } catch (err) {
        toast({
          title: 'Không tải được dữ liệu Sync',
          description: err instanceof Error ? err.message : '',
          variant: 'destructive',
        })
      } finally {
        setLoading(false)
      }
    },
    [refreshDriveFiles, toast],
  )

  // Mount: load + đọc kết quả OAuth redirect (?sync=ok|error)
  useEffect(() => {
    loadAll()
    const params = new URLSearchParams(window.location.search)
    const flag = params.get('sync')
    if (flag === 'ok') {
      toast({ title: 'Đã kết nối Google Drive', description: 'Tài khoản sẵn sàng để sao lưu.' })
      window.history.replaceState(null, '', window.location.pathname)
      loadAll()
    } else if (flag === 'error') {
      toast({
        title: 'Kết nối Google Drive thất bại',
        description: params.get('message') || 'Lỗi không xác định',
        variant: 'destructive',
      })
      window.history.replaceState(null, '', window.location.pathname)
    }
  }, [loadAll, toast])

  useEffect(() => {
    setOrigin(window.location.origin)
    return () => {
      if (pollRef.current) clearInterval(pollRef.current)
    }
  }, [])

  function stopPolling() {
    if (pollRef.current) {
      clearInterval(pollRef.current)
      pollRef.current = null
    }
  }

  // ---------- Google Drive ----------
  async function saveConnection() {
    if (!clientId.trim() && !clientSecret.trim()) {
      toast({ title: 'Chưa nhập gì để lưu', description: 'Điền Client ID hoặc Client Secret.', variant: 'destructive' })
      return
    }
    setSavingConn(true)
    try {
      const body: Record<string, unknown> = {}
      if (clientId.trim()) body.client_id = clientId.trim()
      if (clientSecret.trim()) body.client_secret = clientSecret.trim()
      await api('/api/modules/sync', { method: 'PUT', body })
      toast({ title: 'Đã lưu thông tin Google Drive' })
      setClientId('')
      setClientSecret('')
      await loadAll({ withFiles: false })
    } catch (err) {
      toast({ title: 'Lưu thất bại', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setSavingConn(false)
    }
  }

  async function connectGoogle() {
    // mở tab trước trong gesture để tránh popup blocker
    const win = window.open('', '_blank')
    try {
      const d = await api<{ url: string }>('/api/modules/sync/gdrive/start')
      if (win) win.location.href = d.url
      else window.location.href = d.url
      toast({ title: 'Đang mở trang Google…', description: 'Đồng ý uỷ quyền cho WOS rồi quay lại đây.' })
    } catch (err) {
      win?.close()
      toast({ title: 'Không mở được trang Google', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  async function disconnect() {
    try {
      await api('/api/modules/sync', { method: 'POST', body: { action: 'disconnect' } })
      toast({ title: 'Đã ngắt kết nối Google Drive', description: 'Refresh token và tài khoản đã bị xoá khỏi máy.' })
      setDriveFiles([])
      await loadAll({ withFiles: false })
    } catch (err) {
      toast({ title: 'Ngắt kết nối thất bại', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  function copyRedirectUri() {
    if (!origin) return
    navigator.clipboard
      .writeText(`${origin}/api/modules/sync/gdrive/callback`)
      .then(() => toast({ title: 'Đã sao chép Redirect URI' }))
      .catch(() => toast({ title: 'Không sao chép được', variant: 'destructive' }))
  }

  // ---------- Nguồn & lịch ----------
  async function saveSources() {
    const keepNum = Number.parseInt(keep, 10)
    if (!Number.isFinite(keepNum) || keepNum < 1 || keepNum > 50) {
      toast({ title: 'Số bản giữ lại phải từ 1 đến 50', variant: 'destructive' })
      return
    }
    if (!sources.db && !sources.files && !sources.config) {
      toast({ title: 'Phải chọn ít nhất một nguồn dữ liệu', variant: 'destructive' })
      return
    }
    setSavingSrc(true)
    try {
      await api('/api/modules/sync', { method: 'PUT', body: { sources, schedule, keep: keepNum } })
      toast({ title: 'Đã lưu nguồn & lịch backup' })
    } catch (err) {
      toast({ title: 'Lưu thất bại', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setSavingSrc(false)
    }
  }

  async function backupNow() {
    if (!config?.has_token) {
      toast({ title: 'Chưa kết nối Google Drive', description: 'Kết nối tài khoản ở card Google Drive phía trên.', variant: 'destructive' })
      return
    }
    try {
      await api<{ started: boolean }>('/api/modules/sync', { method: 'POST', body: { action: 'backup-now' } })
      setBacking(true)
      toast({ title: 'Bắt đầu sao lưu', description: 'Đang đóng gói và tải lên Google Drive — sẽ thông báo khi xong.' })
      startPolling(new Set(history.map((h) => h.id)))
    } catch (err) {
      toast({ title: 'Không bắt đầu được backup', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  function startPolling(baseline: Set<string>) {
    stopPolling()
    const startedAt = Date.now()
    pollRef.current = setInterval(async () => {
      if (Date.now() - startedAt > 10 * 60 * 1000) {
        stopPolling()
        setBacking(false)
        toast({ title: 'Hết thời gian chờ backup', description: 'Kiểm tra lịch sử bên dưới để biết trạng thái.', variant: 'destructive' })
        return
      }
      try {
        const d = await api<{ config: SyncConfigDto; history: BackupRunDto[] }>('/api/modules/sync')
        setConfig(d.config)
        setHistory(d.history)
        const done = d.history.find((h) => !baseline.has(h.id) && h.status !== 'running')
        if (done) {
          stopPolling()
          setBacking(false)
          if (done.status === 'ok') {
            toast({
              title: 'Sao lưu Google Drive thành công',
              description: `${done.fileName} • ${formatBytes(done.size)} • ${done.fileCount} tệp`,
            })
          } else {
            toast({ title: 'Sao lưu thất bại', description: done.error || 'Lỗi không xác định', variant: 'destructive' })
          }
          void refreshDriveFiles()
        }
      } catch {
        /* lỗi mạng tạm thời — thử lần poll sau */
      }
    }, 2000)
  }

  async function refreshAll() {
    setRefreshing(true)
    await loadAll()
    setRefreshing(false)
  }

  // ---------- Render ----------
  if (loading) {
    return (
      <div className="space-y-4">
        {[0, 1, 2].map((i) => (
          <Card key={i} className="wos-glass border-0">
            <CardContent className="p-6">
              <div className="h-5 w-48 animate-pulse rounded bg-muted" />
              <div className="mt-4 h-9 w-full animate-pulse rounded bg-muted" />
              <div className="mt-2 h-9 w-2/3 animate-pulse rounded bg-muted" />
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  const redirectUri = origin ? `${origin}/api/modules/sync/gdrive/callback` : '/api/modules/sync/gdrive/callback'
  const quota = config?.drive_usage
  const quotaPct = quota && quota.limit > 0 ? Math.min(100, Math.round((quota.usage / quota.limit) * 100)) : 0

  return (
    <div className="space-y-4">
      {!isAdmin && (
        <div className="flex items-center gap-2.5 rounded-xl bg-amber-500/10 p-3.5 text-sm text-amber-700 dark:text-amber-400">
          <Info className="h-4 w-4 shrink-0" />
          Bạn đang xem với quyền thường — chỉ quản trị viên mới thay đổi cấu hình Sync &amp; Backup.
        </div>
      )}

      {/* ============ CARD 1: GOOGLE DRIVE ============ */}
      <Card className="wos-glass border-0">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-lg font-semibold">
            <Cloud className="h-5 w-5 text-muted-foreground" /> Google Drive
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            Kết nối OAuth trực tiếp ngay trong app — không cần cài rclone hay gõ dòng lệnh nào.
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          {config?.has_token ? (
            <>
              <div className="flex flex-wrap items-center gap-3 rounded-xl bg-emerald-500/10 p-4">
                <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-600 dark:text-emerald-400" />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold">Đã kết nối Google Drive</p>
                  <p className="truncate text-xs text-muted-foreground">
                    {config.account || 'không rõ email'}
                  </p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-8 shrink-0 gap-1.5 border-destructive/40 text-destructive hover:bg-destructive/10 hover:text-destructive"
                  onClick={disconnect}
                  disabled={!isAdmin}
                >
                  <Link2Off className="h-4 w-4" /> Ngắt kết nối
                </Button>
              </div>

              {quota && (
                <div className="rounded-xl bg-muted/50 p-4">
                  <div className="mb-2 flex items-center justify-between text-xs">
                    <span className="flex items-center gap-1.5 font-medium">
                      <HardDrive className="h-3.5 w-3.5" /> Dung lượng Google Drive
                    </span>
                    <span className="text-muted-foreground">
                      {formatBytes(quota.usage)} / {quota.limit > 0 ? formatBytes(quota.limit) : 'không giới hạn'}
                    </span>
                  </div>
                  {quota.limit > 0 && (
                    <div className="h-2 overflow-hidden rounded-full bg-muted">
                      <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${quotaPct}%` }} />
                    </div>
                  )}
                  <p className="mt-2 text-[11px] text-muted-foreground">
                    Đã dùng trong Drive: {formatBytes(quota.usageInDrive)} • Sao lưu lưu ở thư mục
                    <span className="font-mono"> WorkspaceOS-Backup</span>
                  </p>
                </div>
              )}
            </>
          ) : (
            <>
              {/* Hướng dẫn từng bước */}
              <div className="rounded-xl bg-muted/50 p-4">
                <p className="mb-2 text-sm font-semibold">Hướng dẫn lấy Client ID / Secret (làm 1 lần, ~5 phút)</p>
                <ol className="list-decimal space-y-1.5 pl-5 text-xs leading-relaxed text-muted-foreground">
                  <li>
                    Mở{' '}
                    <a
                      className="inline-flex items-center gap-0.5 font-medium underline underline-offset-2 hover:text-foreground"
                      href="https://console.cloud.google.com/"
                      target="_blank"
                      rel="noreferrer"
                    >
                      Google Cloud Console <ExternalLink className="inline h-3 w-3" />
                    </a>{' '}
                    → tạo Project mới (vd <span className="font-mono">wos-backup</span>).
                  </li>
                  <li>
                    Menu <b>APIs &amp; Services → Library</b> → tìm <b>Google Drive API</b> → bấm{' '}
                    <b>Enable</b>.
                  </li>
                  <li>
                    <b>APIs &amp; Services → OAuth consent screen</b> → chọn <b>External</b> → điền tên app →
                    thêm đúng gmail của bạn vào mục <b>Test users</b>.
                  </li>
                  <li>
                    <b>APIs &amp; Services → Credentials → Create Credentials → OAuth client ID</b> → loại{' '}
                    <b>Web application</b>.
                  </li>
                  <li>
                    Ở <b>Authorized redirect URIs</b> bấm <b>Add URI</b> rồi dán đúng địa chỉ bên dưới →{' '}
                    <b>Create</b> → copy Client ID + Client Secret về đây.
                  </li>
                </ol>
              </div>

              {/* Redirect URI để copy */}
              <div className="flex items-center gap-2 rounded-xl border border-dashed p-3">
                <code className="min-w-0 flex-1 truncate font-mono text-xs" title={redirectUri}>
                  {redirectUri}
                </code>
                <Button variant="ghost" size="sm" className="h-8 shrink-0 gap-1 text-xs" onClick={copyRedirectUri} disabled={!origin}>
                  <Copy className="h-3.5 w-3.5" /> Sao chép
                </Button>
              </div>

              {/* Form credential */}
              <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                <div className="space-y-1.5">
                  <Label className="text-xs text-muted-foreground">Client ID</Label>
                  <Input
                    value={clientId}
                    onChange={(e) => setClientId(e.target.value)}
                    placeholder={config?.has_client_id ? 'Đã lưu — nhập lại nếu muốn thay đổi' : '123456789-abc.apps.googleusercontent.com'}
                    className="h-9 font-mono text-xs"
                    autoComplete="off"
                    spellCheck={false}
                    disabled={!isAdmin}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs text-muted-foreground">Client Secret</Label>
                  <Input
                    type="password"
                    value={clientSecret}
                    onChange={(e) => setClientSecret(e.target.value)}
                    placeholder={config?.has_secret ? 'Đã lưu — nhập lại nếu muốn thay đổi' : 'GOCSPX-…'}
                    className="h-9 font-mono text-xs"
                    autoComplete="off"
                    disabled={!isAdmin}
                  />
                </div>
              </div>

              <div className="flex flex-wrap justify-end gap-2 border-t pt-4">
                <Button variant="outline" size="sm" className="gap-1.5" onClick={saveConnection} disabled={savingConn || !isAdmin}>
                  {savingConn ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Lưu thông tin
                </Button>
                <Button
                  size="sm"
                  className="gap-1.5"
                  onClick={connectGoogle}
                  disabled={!config?.has_client_id || !config?.has_secret || !isAdmin}
                >
                  <CloudUpload className="h-4 w-4" /> Kết nối Google Drive
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* ============ CARD 2: NGUỒN & LỊCH BACKUP ============ */}
      <Card className="wos-glass border-0">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-lg font-semibold">
            <Database className="h-5 w-5 text-muted-foreground" /> Nguồn &amp; lịch backup
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            Chọn dữ liệu đưa vào bản tar.gz và lịch chạy tự động trên máy này.
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2.5">
            <SourceRow
              icon={<Database className="h-4 w-4" />}
              label="Cơ sở dữ liệu"
              desc="Snapshot SQLite (VACUUM INTO) — tasks, notes, wiki, users, settings…"
              checked={sources.db}
              onCheckedChange={(v) => setSources((s) => ({ ...s, db: v }))}
              disabled={!isAdmin}
            />
            <SourceRow
              icon={<FolderOpen className="h-4 w-4" />}
              label="Tệp người dùng (storage)"
              desc="Toàn bộ thư mục storage — Documents, Pictures, Projects…"
              checked={sources.files}
              onCheckedChange={(v) => setSources((s) => ({ ...s, files: v }))}
              disabled={!isAdmin}
            />
            <SourceRow
              icon={<FileJson className="h-4 w-4" />}
              label="Cấu hình & settings"
              desc="Xuất JSON metadata toàn hệ thống (như tính năng Backup)"
              checked={sources.config}
              onCheckedChange={(v) => setSources((s) => ({ ...s, config: v }))}
              disabled={!isAdmin}
            />
          </div>

          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">Lịch tự động</Label>
              <Select value={schedule} onValueChange={(v) => setSchedule(v as 'off' | 'daily' | 'weekly')} disabled={!isAdmin}>
                <SelectTrigger className="h-9">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="off">Tắt</SelectItem>
                  <SelectItem value="daily">Hằng ngày — 02:00</SelectItem>
                  <SelectItem value="weekly">Hằng tuần — Thứ 2, 03:00</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-[11px] text-muted-foreground">
                Bật trang Settings hoặc app bất kỳ để scheduler hoạt động (tick mỗi 60 giây).
              </p>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">Giữ lại (bản mới nhất trên Drive)</Label>
              <Input
                type="number"
                min={1}
                max={50}
                value={keep}
                onChange={(e) => setKeep(e.target.value)}
                className="h-9"
                disabled={!isAdmin}
              />
              <p className="text-[11px] text-muted-foreground">Bản cũ hơn sẽ tự xoá khỏi Drive sau mỗi lần backup.</p>
            </div>
          </div>

          {backing && (
            <div className="flex items-center gap-2.5 rounded-xl bg-primary/10 p-3 text-sm">
              <Loader2 className="h-4 w-4 shrink-0 animate-spin text-primary" />
              Đang sao lưu… hệ thống sẽ thông báo khi hoàn tất (có thể để yên và làm việc khác).
            </div>
          )}

          <div className="flex flex-wrap justify-end gap-2 border-t pt-4">
            <Button variant="outline" size="sm" className="gap-1.5" onClick={saveSources} disabled={savingSrc || !isAdmin}>
              {savingSrc ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Lưu thay đổi
            </Button>
            <Button size="sm" className="gap-1.5" onClick={backupNow} disabled={backing || !isAdmin}>
              {backing ? <Loader2 className="h-4 w-4 animate-spin" /> : <CloudUpload className="h-4 w-4" />} Sao lưu ngay
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* ============ CARD 3: LỊCH SỬ & TỆP TRÊN DRIVE ============ */}
      <Card className="wos-glass border-0">
        <CardHeader className="pb-3">
          <CardTitle className="flex flex-wrap items-center gap-2 text-lg font-semibold">
            <FileArchive className="h-5 w-5 text-muted-foreground" /> Lịch sử &amp; tệp trên Drive
            <Button
              variant="ghost"
              size="sm"
              className="ml-auto h-8 gap-1.5 text-xs"
              onClick={refreshAll}
              disabled={refreshing}
            >
              <RefreshCw className={`h-3.5 w-3.5 ${refreshing ? 'animate-spin' : ''}`} /> Làm mới
            </Button>
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            15 lần chạy gần nhất và các bản backup đang nằm trên Google Drive.
          </p>
        </CardHeader>
        <CardContent className="space-y-5">
          {/* Bảng BackupRun */}
          <div className="overflow-hidden rounded-xl border">
            <div className="max-h-72 overflow-y-auto overflow-x-auto wos-scroll">
              {history.length === 0 ? (
                <p className="p-4 text-center text-sm text-muted-foreground">Chưa có lần backup nào được chạy.</p>
              ) : (
                <Table>
                  <TableHeader className="sticky top-0 z-10 bg-background/95 backdrop-blur">
                    <TableRow>
                      <TableHead className="text-xs">Thời gian</TableHead>
                      <TableHead className="text-xs">Kiểu</TableHead>
                      <TableHead className="text-xs">Trạng thái</TableHead>
                      <TableHead className="text-xs">Tệp</TableHead>
                      <TableHead className="text-right text-xs">Dung lượng</TableHead>
                      <TableHead className="text-xs">Lỗi</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {history.map((h) => (
                      <TableRow key={h.id}>
                        <TableCell className="whitespace-nowrap text-xs">{fmtDateTime(h.startedAt)}</TableCell>
                        <TableCell className="whitespace-nowrap text-xs text-muted-foreground">
                          {h.trigger === 'manual' ? 'Thủ công' : 'Tự động'}
                        </TableCell>
                        <TableCell>
                          <StatusBadge status={h.status} />
                        </TableCell>
                        <TableCell className="max-w-40 truncate font-mono text-[11px]" title={h.fileName}>
                          {h.fileName || '—'}
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-right text-xs">
                          {h.size > 0 ? formatBytes(h.size) : '—'}
                        </TableCell>
                        <TableCell className="max-w-40 truncate text-[11px] text-destructive" title={h.error}>
                          {h.error || '—'}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </div>
          </div>

          {/* Tệp trên Drive */}
          <div>
            <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Tệp trong WorkspaceOS-Backup trên Drive
            </p>
            {driveFiles === null ? (
              <div className="space-y-1.5">
                {[0, 1].map((i) => (
                  <div key={i} className="h-11 animate-pulse rounded-xl bg-muted" />
                ))}
              </div>
            ) : driveFiles.length === 0 ? (
              <p className="rounded-xl border border-dashed p-4 text-center text-sm text-muted-foreground">
                Chưa có tệp backup nào trên Drive. Bấm <b>Sao lưu ngay</b> để tạo bản đầu tiên.
              </p>
            ) : (
              <div className="max-h-96 space-y-1.5 overflow-y-auto wos-scroll">
                {driveFiles.map((f) => (
                  <div key={f.id} className="flex items-center gap-3 rounded-xl bg-muted/50 px-3 py-2">
                    <FileArchive className="h-4 w-4 shrink-0 text-muted-foreground" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-mono text-xs" title={f.name}>
                        {f.name}
                      </p>
                      <p className="text-[11px] text-muted-foreground">
                        {formatBytes(f.size)} • {fmtDateTime(f.modifiedTime)}
                      </p>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 shrink-0 gap-1 text-xs"
                      onClick={() =>
                        window.open(
                          `/api/modules/sync/gdrive/file?id=${encodeURIComponent(f.id)}&name=${encodeURIComponent(f.name)}`,
                          '_blank',
                        )
                      }
                    >
                      <Download className="h-3.5 w-3.5" /> Tải về
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function SourceRow({
  icon, label, desc, checked, onCheckedChange, disabled,
}: {
  icon: React.ReactNode
  label: string
  desc: string
  checked: boolean
  onCheckedChange: (v: boolean) => void
  disabled?: boolean
}) {
  return (
    <div className="flex items-center gap-3 rounded-xl bg-muted/50 px-3 py-2.5">
      <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-background text-muted-foreground">
        {icon}
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-medium">{label}</p>
        <p className="truncate text-xs text-muted-foreground">{desc}</p>
      </div>
      <Switch checked={checked} onCheckedChange={onCheckedChange} disabled={disabled} aria-label={label} />
    </div>
  )
}

function StatusBadge({ status }: { status: string }) {
  if (status === 'ok') {
    return (
      <Badge className="gap-1 bg-emerald-500/15 text-emerald-600 hover:bg-emerald-500/25 dark:text-emerald-400">
        <CheckCircle2 className="h-3 w-3" /> Thành công
      </Badge>
    )
  }
  if (status === 'running') {
    return (
      <Badge className="gap-1 bg-amber-500/15 text-amber-600 hover:bg-amber-500/25 dark:text-amber-400">
        <Loader2 className="h-3 w-3 animate-spin" /> Đang chạy
      </Badge>
    )
  }
  return (
    <Badge variant="destructive" className="gap-1">
      <XCircle className="h-3 w-3" /> Lỗi
    </Badge>
  )
}
