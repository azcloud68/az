'use client'

import { useEffect, useState, useCallback, useRef } from 'react'
import { useWos } from '@/core/client/wos-store'
import { useRoute } from '@/core/client/route-context'
import { api, fmtDateTime, formatBytes } from '@/core/client/api'
import { useTheme } from 'next-themes'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Textarea } from '@/components/ui/textarea'
import { useToast } from '@/hooks/use-toast'
import { ModuleIcon } from '@/components/wos/ModuleIcon'
import { AppearanceSection } from '@/modules/settings/AppearanceSection'
import { PluginsSection } from '@/modules/settings/PluginsSection'
import dynamic from 'next/dynamic'
import {
  Settings, Loader2, Save, Lock, Download, Upload, HardDrive, Bell, Palette, Globe,
  Database, KeyRound, Monitor, Shield, LogOut, Sun, Moon, Zap, Cloud, Puzzle, Server, PackageOpen,
} from 'lucide-react'
import { SystemSection } from '@/modules/settings/SystemSection'

const SyncSection = dynamic(() => import('@/modules/settings/SyncSection'), {
  loading: () => <div className="flex h-40 items-center justify-center"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>,
})

interface SessionRow {
  id: string
  ip: string
  userAgent: string
  createdAt: string
  expiresAt: string
  current: boolean
}

export default function SettingsPage() {
  const { settings, saveSettings, loadSettings, user, modules, toggleModule, saveModuleConfig, emit } = useWos()
  const { route, navigate } = useRoute()
  const { toast } = useToast()
  const { theme, setTheme } = useTheme()

  // Deep link settings:<section>
  const deepLink = route.startsWith('settings:') ? route.split(':')[1] : null
  const [section, setSection] = useState(deepLink || 'general')
  const [form, setForm] = useState<Record<string, string>>({})
  const [saving, setSaving] = useState(false)
  const [moduleSettings, setModuleSettings] = useState<Record<string, Record<string, string>>>({})
  const [configModule, setConfigModule] = useState<string | null>(null)
  const [configTab, setConfigTab] = useState('general')

  useEffect(() => {
    if (deepLink) setSection(deepLink)
  }, [deepLink])

  // Load core settings + settings các module đang bật
  const loadAll = useCallback(async () => {
    await loadSettings('core')
    const perModule: Record<string, Record<string, string>> = {}
    await Promise.all(
      modules
        .filter((m) => m.enabled && ['tasks', 'calendar', 'notes', 'wiki', 'files', 'projects', 'timeline', 'notifications', 'reports', 'search', 'backup', 'dashboard'].includes(m.id))
        .map(async (m) => {
          try {
            perModule[m.id] = await loadSettings(m.id)
          } catch {
            perModule[m.id] = {}
          }
        })
    )
    setModuleSettings(perModule)
  }, [loadSettings, modules])

  useEffect(() => {
    loadAll()
  }, [loadAll])

  useEffect(() => {
    setForm({ ...settings })
  }, [settings])

  async function saveCore() {
    setSaving(true)
    try {
      await saveSettings('core', form)
      toast({ title: 'Đã lưu cấu hình hệ thống' })
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  async function saveModule(moduleId: string, values: Record<string, string>) {
    setSaving(true)
    try {
      await saveSettings(moduleId, values)
      setModuleSettings((prev) => ({ ...prev, [moduleId]: { ...prev[moduleId], ...values } }))
      toast({ title: `Đã lưu cấu hình ${moduleId}` })
    } finally {
      setSaving(false)
    }
  }

  const enabledModules = modules.filter((m) => m.enabled)
  const isAdmin = user?.role === 'admin'

  const CORE_SECTIONS = [
    { id: 'general', label: 'General', icon: Settings },
    { id: 'system', label: 'Hệ thống', icon: Server },
    { id: 'appearance', label: 'Appearance', icon: Palette },
    { id: 'plugins', label: 'Plugins', icon: Puzzle },
    { id: 'sync', label: 'Sync & Backup', icon: Cloud },
    { id: 'localization', label: 'Localization', icon: Globe },
    { id: 'language', label: 'Language', icon: Globe },
    { id: 'modules', label: 'Modules', icon: Zap },
    { id: 'notification', label: 'Notification', icon: Bell },
    { id: 'storage', label: 'Storage', icon: HardDrive },
    { id: 'security', label: 'Security', icon: Lock },
    { id: 'backup', label: 'Backup', icon: Database },
  ]

  // Sidebar settings: các mục core + mục riêng của từng module đang bật
  const moduleSections = enabledModules
    .filter((m) => ['tasks', 'calendar', 'notes', 'wiki', 'files', 'projects', 'timeline', 'reports', 'search'].includes(m.id))
    .map((m) => ({ id: `module:${m.id}`, label: m.name, moduleId: m.id, icon: null, color: m.color }))

  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-[220px_1fr]">
      {/* Settings sidebar — ĐỘNG: tắt module → mất mục setting của module đó */}
      <Card className="wos-glass h-fit border-0 p-2">
        <nav className="space-y-0.5">
          {CORE_SECTIONS.map((s) => (
            <button
              key={s.id}
              onClick={() => setSection(s.id)}
              className={`wos-nav-item flex w-full items-center gap-2.5 px-3 py-2 text-sm font-medium ${
                section === s.id ? 'active' : 'text-foreground/75'
              }`}
            >
              <s.icon className="h-4 w-4" /> {s.label}
            </button>
          ))}
          {moduleSections.length > 0 && (
            <>
              <p className="px-3 pb-1 pt-4 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                Cấu hình module
              </p>
              {moduleSections.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setSection(s.id)}
                  className={`wos-nav-item flex w-full items-center gap-2.5 px-3 py-2 text-sm font-medium ${
                    section === s.id ? 'active' : 'text-foreground/75'
                  }`}
                >
                  <span className="h-2 w-2 rounded-full" style={{ background: s.color }} /> {s.label}
                </button>
              ))}
            </>
          )}
        </nav>
      </Card>

      <div className="min-w-0 space-y-4">
        {/* ============ GENERAL ============ */}
        {section === 'general' && (
          <SettingsCard title="General" desc="Cấu hình workspace, múi giờ, thời tiết, AI Summary">
            <Field label="Tên Workspace">
              <Input value={form.workspace_name || ''} onChange={(e) => setForm({ ...form, workspace_name: e.target.value })} className="h-9" />
            </Field>
            <Field label="Múi giờ">
              <Select value={form.timezone || 'Asia/Bangkok'} onValueChange={(v) => setForm({ ...form, timezone: v })}>
                <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {['Asia/Bangkok', 'Asia/Ho_Chi_Minh', 'Asia/Singapore', 'Asia/Tokyo', 'Europe/Berlin', 'UTC'].map((t) => (
                    <SelectItem key={t} value={t}>{t}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Thành phố thời tiết">
              <Input value={form.weather_city || ''} onChange={(e) => setForm({ ...form, weather_city: e.target.value })} className="h-9" />
            </Field>
            <Field label="AI Summary trên Dashboard">
              <div className="flex items-center gap-2">
                <Switch checked={form.ai_summary !== 'off'} onCheckedChange={(v) => setForm({ ...form, ai_summary: v ? 'on' : 'off' })} />
                <span className="text-sm text-muted-foreground">Tổng hợp hoạt động tự động mỗi ngày</span>
              </div>
            </Field>
            <SaveBar onSave={saveCore} saving={saving} />
          </SettingsCard>
        )}

        {/* ============ APPEARANCE (wallpaper + icon tuỳ biến) ============ */}
        {section === 'appearance' && <AppearanceSection />}

        {/* ============ PLUGINS (app cài thêm) ============ */}
        {section === 'plugins' && <PluginsSection />}

        {/* ============ SYNC & BACKUP (Google Drive) ============ */}
        {section === 'sync' && <SyncSection />}

        {/* ============ LOCALIZATION / LANGUAGE ============ */}
        {(section === 'localization' || section === 'language') && (
          <SettingsCard title={section === 'localization' ? 'Localization' : 'Language'} desc="Ngôn ngữ và định dạng hiển thị">
            <Field label="Ngôn ngữ giao diện">
              <Select value={form.language || 'vi'} onValueChange={(v) => setForm({ ...form, language: v })}>
                <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="vi">Tiếng Việt</SelectItem>
                  <SelectItem value="en">English</SelectItem>
                  <SelectItem value="ja">日本語 (chuẩn bị)</SelectItem>
                </SelectContent>
              </Select>
            </Field>
            <Field label="Định dạng ngày">
              <Select value={form.date_format || 'dd/MM/yyyy'} onValueChange={(v) => setForm({ ...form, date_format: v })}>
                <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="dd/MM/yyyy">31/12/2026</SelectItem>
                  <SelectItem value="MM/dd/yyyy">12/31/2026</SelectItem>
                  <SelectItem value="yyyy-MM-dd">2026-12-31</SelectItem>
                </SelectContent>
              </Select>
            </Field>
            <SaveBar onSave={saveCore} saving={saving} />
          </SettingsCard>
        )}

        {/* ============ MODULES (Module Manager) ============ */}
        {section === 'modules' && (
          <>
            <SettingsCard title="Module Manager" desc="Bật/tắt và cấu hình từng module — Sidebar, Dock, Settings, Widget tự cập nhật">
              {!isAdmin && <p className="text-sm text-muted-foreground">Chỉ quản trị viên được cấu hình module.</p>}
              <div className="space-y-2">
                {[...modules].sort((a, b) => a.order - b.order).map((m) => (
                  <div key={m.id} className="flex items-center gap-3 rounded-xl bg-muted/50 px-3 py-2.5">
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-white" style={{ background: m.color }}>
                      <ModuleIcon icon={m.icon} className="h-4.5 w-4.5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="flex items-center gap-2 text-sm font-semibold">
                        {m.name}
                        <Badge variant="outline" className="h-4 px-1.5 text-[9px]">v{m.version}</Badge>
                        {m.core && <Badge className="h-4 px-1.5 text-[9px]">lõi</Badge>}
                      </p>
                      <p className="truncate text-xs text-muted-foreground">{m.description}</p>
                    </div>
                    {isAdmin && !m.core && (
                      <Button variant="outline" size="sm" className="h-8 shrink-0 text-xs" onClick={() => { setConfigModule(m.id); setConfigTab('general') }}>
                        Cấu hình
                      </Button>
                    )}
                    <Switch
                      checked={m.enabled}
                      disabled={!isAdmin || m.core}
                      onCheckedChange={(v) => toggleModule(m.id, v)}
                      aria-label={`${m.enabled ? 'Tắt' : 'Bật'} ${m.name}`}
                    />
                  </div>
                ))}
              </div>
            </SettingsCard>
          </>
        )}

        {/* ============ NOTIFICATION (fix lỗi 8: Email SMTP/Gmail hoàn chỉnh) ============ */}
        {section === 'notification' && (
          <EmailNotificationSection
            defaults={moduleSettings.notifications || {}}
            onSave={saveModule}
            saving={saving}
            isAdmin={user?.role === 'admin'}
          />
        )}

        {/* ============ STORAGE ============ */}
        {section === 'storage' && <StorageSection form={form} setForm={setForm} onSave={saveCore} saving={saving} />}

        {/* ============ HỆ THỐNG (About This Computer + tài nguyên) ============ */}
        {section === 'system' && <SystemSection />}

        {/* ============ SECURITY ============ */}
        {section === 'security' && <SecuritySection />}

        {/* ============ BACKUP ============ */}
        {section === 'backup' && <BackupSection emit={emit} />}

        {/* ============ MODULE SETTINGS ============ */}
        {section.startsWith('module:') && (() => {
          const moduleId = section.slice(7)
          const mod = modules.find((m) => m.id === moduleId)
          if (!mod) return null
          const defaults = moduleSettings[moduleId] || {}
          const fields = MODULE_SETTINGS_FIELDS[moduleId] || (() => null)
          return (
            <ModuleSettingsCard
              title={`${mod.name} — Settings`}
              desc={`Cấu hình riêng của module ${mod.name}`}
              moduleId={moduleId}
              defaults={defaults}
              onSave={saveModule}
              saving={saving}
              fields={fields}
            />
          )
        })()}
      </div>

      {/* Dialog cấu hình module chi tiết */}
      {configModule && (
        <ModuleConfigDialog
          moduleId={configModule}
          onClose={() => setConfigModule(null)}
          configTab={configTab}
          setConfigTab={setConfigTab}
        />
      )}
    </div>
  )
}

/* ================= Sub components ================= */

const MODULE_SETTINGS_FIELDS: Record<string, (vals: Record<string, string>, set: (v: Record<string, string>) => void) => React.ReactNode> = {
  tasks: (vals, set) => (
    <>
      <Field label="View mặc định khi mở Tasks">
        <Select value={vals.default_view || 'list'} onValueChange={(v) => set({ default_view: v })}>
          <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
          <SelectContent>
            {['list', 'kanban', 'timeline', 'archive'].map((v) => <SelectItem key={v} value={v}>{v}</SelectItem>)}
          </SelectContent>
        </Select>
      </Field>
      <Field label="Ưu tiên mặc định">
        <Select value={vals.default_priority || 'medium'} onValueChange={(v) => set({ default_priority: v })}>
          <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
          <SelectContent>
            {['low', 'medium', 'high', 'urgent'].map((v) => <SelectItem key={v} value={v}>{v}</SelectItem>)}
          </SelectContent>
        </Select>
      </Field>
      <Field label="Quick Add ở đầu trang">
        <Switch checked={vals.quick_add !== 'off'} onCheckedChange={(v) => set({ quick_add: v ? 'on' : 'off' })} />
      </Field>
      <Field label="Timeline — hiện việc đã hoàn thành">
        <Switch checked={vals.timeline_show_done !== 'off'} onCheckedChange={(v) => set({ timeline_show_done: v ? 'on' : 'off' })} />
      </Field>
      <Field label="Timeline — hiện việc không có hạn">
        <Switch checked={vals.timeline_show_no_due === 'on'} onCheckedChange={(v) => set({ timeline_show_no_due: v ? 'on' : 'off' })} />
      </Field>
      <Field label="Timeline — gộp nhóm theo ngày">
        <Switch checked={vals.timeline_group !== 'off'} onCheckedChange={(v) => set({ timeline_group: v ? 'on' : 'off' })} />
      </Field>
    </>
  ),
  calendar: (vals, set) => (
    <>
      <Field label="Ngày đầu tuần">
        <Select value={vals.first_day || 'monday'} onValueChange={(v) => set({ first_day: v })}>
          <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="monday">Thứ Hai</SelectItem>
            <SelectItem value="sunday">Chủ Nhật</SelectItem>
          </SelectContent>
        </Select>
      </Field>
      <Field label="Hiện ngày lễ">
        <Switch checked={vals.show_holidays !== 'off'} onCheckedChange={(v) => set({ show_holidays: v ? 'on' : 'off' })} />
      </Field>
      <Field label="Giờ bắt đầu lịch (Day view)">
        <Input type="number" value={vals.day_start || '8'} onChange={(e) => set({ day_start: e.target.value })} className="h-9" />
      </Field>
    </>
  ),
  notes: (vals, set) => (
    <>
      <Field label="Tự động lưu khi rời trường">
        <Switch checked={vals.autosave !== 'off'} onCheckedChange={(v) => set({ autosave: v ? 'on' : 'off' })} />
      </Field>
      <Field label="Cỡ chữ editor">
        <Input type="number" value={vals.font_size || '15'} onChange={(e) => set({ font_size: e.target.value })} className="h-9" />
      </Field>
    </>
  ),
  wiki: (vals, set) => (
    <Field label="Cho phép đọc không cần đăng nhập">
      <Switch checked={vals.allow_anonymous_read === 'on'} onCheckedChange={(v) => set({ allow_anonymous_read: v ? 'on' : 'off' })} />
    </Field>
  ),
  files: (vals, set) => (
    <>
      <Field label="View mặc định">
        <Select value={vals.default_view || 'grid'} onValueChange={(v) => set({ default_view: v })}>
          <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="grid">Grid</SelectItem>
            <SelectItem value="list">List</SelectItem>
          </SelectContent>
        </Select>
      </Field>
      <Field label="Preview trực tiếp khi bấm tệp">
        <Switch checked={vals.preview_inline !== 'off'} onCheckedChange={(v) => set({ preview_inline: v ? 'on' : 'off' })} />
      </Field>
    </>
  ),
  projects: (vals, set) => (
    <Field label="Kiểu thẻ dự án">
      <Select value={vals.card_style || 'progress'} onValueChange={(v) => set({ card_style: v })}>
        <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="progress">Hiện thanh tiến độ</SelectItem>
          <SelectItem value="minimal">Tối giản</SelectItem>
        </SelectContent>
      </Select>
    </Field>
  ),
  timeline: (vals, set) => (
    <Field label="Số sự kiện tối đa mỗi lần tải">
      <Input type="number" value={vals.limit || '100'} onChange={(e) => set({ limit: e.target.value })} className="h-9" />
    </Field>
  ),
  reports: (vals, set) => (
    <Field label="Định dạng xuất mặc định">
      <Select value={vals.export_format || 'csv'} onValueChange={(v) => set({ export_format: v })}>
        <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
        <SelectContent>
          {['csv', 'excel', 'json'].map((v) => <SelectItem key={v} value={v}>{v.toUpperCase()}</SelectItem>)}
        </SelectContent>
      </Select>
    </Field>
  ),
  search: (vals, set) => (
    <Field label="Số kết quả tối đa">
      <Input type="number" value={vals.limit || '24'} onChange={(e) => set({ limit: e.target.value })} className="h-9" />
    </Field>
  ),
}

function SettingsCard({ title, desc, children }: { title: string; desc?: string; children: React.ReactNode }) {
  return (
    <Card className="wos-glass border-0">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg font-semibold">
          <Settings className="h-5 w-5 text-muted-foreground" /> {title}
        </CardTitle>
        {desc && <p className="text-sm text-muted-foreground">{desc}</p>}
      </CardHeader>
      <CardContent className="space-y-4">{children}</CardContent>
    </Card>
  )
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="grid grid-cols-1 items-center gap-2 md:grid-cols-[220px_1fr]">
      <Label className="text-sm font-medium text-muted-foreground">{label}</Label>
      <div>{children}</div>
    </div>
  )
}

function SaveBar({ onSave, saving }: { onSave: () => void; saving: boolean }) {
  return (
    <div className="flex justify-end border-t pt-4">
      <Button size="sm" className="gap-1.5" onClick={onSave} disabled={saving}>
        {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Lưu thay đổi
      </Button>
    </div>
  )
}

function ThemeOption({ active, onClick, icon, label }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string }) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium transition-colors ${
        active ? 'bg-primary text-primary-foreground shadow' : 'bg-muted/60 text-muted-foreground hover:bg-muted'
      }`}
    >
      {icon} {label}
    </button>
  )
}

function ModuleSettingsCard({
  title, desc, moduleId, defaults, onSave, saving, fields,
}: {
  title: string
  desc: string
  moduleId: string
  defaults: Record<string, string>
  onSave: (moduleId: string, values: Record<string, string>) => Promise<void>
  saving: boolean
  fields: (vals: Record<string, string>, set: (v: Record<string, string>) => void) => React.ReactNode
}) {
  const [vals, setVals] = useState(defaults)
  useEffect(() => setVals(defaults), [defaults])  
  const set = (v: Record<string, string>) => setVals((prev) => ({ ...prev, ...v }))
  return (
    <SettingsCard title={title} desc={desc}>
      {fields(vals, set)}
      <SaveBar onSave={() => onSave(moduleId, vals)} saving={saving} />
    </SettingsCard>
  )
}

function StorageSection({ form, setForm, onSave, saving }: { form: Record<string, string>; setForm: (f: Record<string, string>) => void; onSave: () => void; saving: boolean }) {
  const [usage, setUsage] = useState<{ usage: number; quota: number } | null>(null)
  const [trashCount, setTrashCount] = useState(0)
  useEffect(() => {
    api<{ usage: number; quota: number }>('/api/modules/files/usage?quota=20').then(setUsage).catch(() => {})
    api<{ trash: unknown[] }>('/api/modules/files/trash').then((d) => setTrashCount(d.trash.length)).catch(() => {})
  }, [])
  const pct = usage && usage.quota ? (usage.usage / usage.quota) * 100 : 0
  const pctStr = pct >= 0.1 ? `${pct.toFixed(pct >= 10 ? 0 : 1)}%` : '<0.1%'
  return (
    <SettingsCard title="Storage" desc="Dung lượng, hạn mức và Recycle Bin">
      <div className="rounded-xl bg-muted/50 p-4">
        <div className="mb-2 flex justify-between text-sm">
          <span className="font-medium">Đã dùng {usage ? formatBytes(usage.usage) : '0 B'} / {usage ? formatBytes(usage.quota) : '20 GB'}</span>
          <span className="tabular-nums text-muted-foreground">{pctStr}</span>
        </div>
        <div className="h-3 overflow-hidden rounded-full bg-background">
          <div className="h-full rounded-full bg-gradient-to-r from-amber-400 to-orange-500" style={{ width: `${Math.min(100, pct)}%` }} />
        </div>
        <p className="mt-2 text-xs text-muted-foreground">Recycle Bin: {trashCount} mục</p>
      </div>
      <Field label="Hạn mức mặc định hiển thị (GB)">
        <Input
          value={form.quota_gb || '20'}
          onChange={(e) => setForm({ ...form, quota_gb: e.target.value })}
          type="number"
          className="h-9"
        />
      </Field>
      <SaveBar onSave={onSave} saving={saving} />
    </SettingsCard>
  )
}

function SecuritySection() {
  const { toast } = useToast()
  const [current, setCurrent] = useState('')
  const [next, setNext] = useState('')
  const [confirmPw, setConfirmPw] = useState('')
  const [sessions, setSessions] = useState<SessionRow[] | null>(null)
  const [saving, setSaving] = useState(false)

  const loadSessions = useCallback(() => {
    api<{ sessions: SessionRow[] }>('/api/core/auth/sessions').then((d) => setSessions(d.sessions)).catch(() => setSessions([]))
  }, [])
  useEffect(loadSessions, [loadSessions])

  async function changePassword() {
    if (next !== confirmPw) {
      toast({ title: 'Mật khẩu xác nhận không khớp', variant: 'destructive' })
      return
    }
    setSaving(true)
    try {
      await api('/api/core/auth/password', { method: 'PUT', body: { current, next } })
      toast({ title: 'Đã đổi mật khẩu', description: 'Các phiên khác đã bị đăng xuất' })
      setCurrent(''); setNext(''); setConfirmPw('')
      loadSessions()
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  async function logoutOthers() {
    await api('/api/core/auth/sessions', { method: 'DELETE', body: {} })
    toast({ title: 'Đã đăng xuất các thiết bị khác' })
    loadSessions()
  }

  return (
    <>
      <SettingsCard title="Security" desc="Mật khẩu và phiên đăng nhập">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
          <Input type="password" value={current} onChange={(e) => setCurrent(e.target.value)} placeholder="Mật khẩu hiện tại" className="h-9" />
          <Input type="password" value={next} onChange={(e) => setNext(e.target.value)} placeholder="Mật khẩu mới (≥6 ký tự)" className="h-9" />
          <Input type="password" value={confirmPw} onChange={(e) => setConfirmPw(e.target.value)} placeholder="Xác nhận mật khẩu" className="h-9" />
        </div>
        <div className="flex justify-end">
          <Button size="sm" className="gap-1.5" onClick={changePassword} disabled={saving || !current || next.length < 6}>
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <KeyRound className="h-4 w-4" />} Đổi mật khẩu
          </Button>
        </div>
      </SettingsCard>

      <SettingsCard title="Sessions" desc="Các thiết bị đang đăng nhập">
        <div className="space-y-2">
          {sessions === null ? (
            <Loader2 className="mx-auto h-5 w-5 animate-spin" />
          ) : sessions.length === 0 ? (
            <p className="text-sm text-muted-foreground">Không có phiên nào</p>
          ) : (
            sessions.map((s) => (
              <div key={s.id} className="flex items-center gap-3 rounded-xl bg-muted/50 px-3 py-2.5">
                <Monitor className="h-4 w-4 shrink-0 text-muted-foreground" />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">
                    {s.current ? 'Thiết bị hiện tại' : 'Thiết bị khác'} · IP {s.ip}
                  </p>
                  <p className="truncate text-[11px] text-muted-foreground">
                    {s.userAgent.slice(0, 60)} · hết hạn {fmtDateTime(s.expiresAt)}
                  </p>
                </div>
                {s.current && <Badge className="shrink-0">hiện tại</Badge>}
              </div>
            ))
          )}
        </div>
        <div className="flex justify-end border-t pt-3">
          <Button variant="outline" size="sm" className="gap-1.5" onClick={logoutOthers}>
            <LogOut className="h-4 w-4" /> Đăng xuất thiết bị khác
          </Button>
        </div>
      </SettingsCard>
    </>
  )
}

function BackupSection({ emit }: { emit: (type: string, module: string, payload?: Record<string, unknown>) => void }) {
  const { toast } = useToast()
  const fileRef = useRef<HTMLInputElement>(null)
  const tarRef = useRef<HTMLInputElement>(null)
  const [importing, setImporting] = useState(false)
  const [tab, setTab] = useState('metadata')
  const [busyFull, setBusyFull] = useState<'idle' | 'export' | 'import'>('idle')
  const [history, setHistory] = useState<BackupRunRow[] | null>(null)

  interface BackupRunRow {
    id: string
    provider: string
    trigger: string
    status: string
    fileName: string
    size: number
    fileCount: number
    error: string
    startedAt: string
    finishedAt?: string | null
  }

  const loadHistory = useCallback(() => {
    api<{ history?: BackupRunRow[] }>('/api/modules/sync')
      .then((d) => setHistory(d.history || []))
      .catch(() => setHistory([]))
  }, [])

  useEffect(() => {
    if (tab === 'history') loadHistory()
  }, [tab, loadHistory])

  async function importBackup(file: File) {
    setImporting(true)
    try {
      const text = await file.text()
      const json = JSON.parse(text)
      const r = await api<{ restored: number }>('/api/core/backup', { method: 'POST', body: json })
      emit('backup.imported', 'core', { rows: r.restored })
      toast({ title: 'Nhập sao lưu hoàn tất', description: `${r.restored} dòng dữ liệu` })
    } catch (err) {
      toast({ title: 'Nhập sao lưu thất bại', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setImporting(false)
    }
  }

  /** Xuất bản ĐẦY ĐỦ (metadata + tệp thật) — tải tar.gz trực tiếp (fix lỗi 9) */
  async function exportFull() {
    setBusyFull('export')
    try {
      const res = await fetch('/api/core/backup/full')
      if (!res.ok) {
        const data = (await res.json().catch(() => ({}))) as { error?: string }
        throw new Error(data.error || `HTTP ${res.status}`)
      }
      const blob = await res.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `wos-backup-full-${new Date().toISOString().slice(0, 10)}.tar.gz`
      document.body.appendChild(a)
      a.click()
      a.remove()
      URL.revokeObjectURL(url)
      emit('backup.exported', 'core', { full: true })
      toast({ title: 'Đã tải bản sao lưu đầy đủ', description: `${(blob.size / 1024 / 1024).toFixed(1)}MB — gồm cả tệp trong storage` })
    } catch (err) {
      toast({ title: 'Xuất bản đầy đủ thất bại', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setBusyFull('idle')
    }
  }

  /** Phục hồi từ tar.gz đầy đủ (DB + storage) */
  async function importFull(file: File) {
    if (!confirm('Phục hồi bản sao lưu ĐẦY ĐỦ sẽ GHI ĐÈ toàn bộ dữ liệu hiện tại (kể cả tệp trong storage)?\nHệ thống tự snapshot trước khi áp, nhưng hãy chắc chắn!')) return
    setBusyFull('import')
    try {
      const form = new FormData()
      form.append('file', file)
      const res = await fetch('/api/core/backup/full', { method: 'POST', body: form })
      const data = (await res.json().catch(() => ({}))) as { restored?: number; filesRestored?: boolean; error?: string }
      if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`)
      emit('backup.imported', 'core', { rows: data.restored, full: true })
      toast({
        title: 'Phục hồi hoàn tất',
        description: `${data.restored} dòng dữ liệu${data.filesRestored ? ' + toàn bộ tệp storage' : ''} — tải lại trang (F5) để thấy đổi mới`,
      })
      setTimeout(() => window.location.reload(), 1800)
    } catch (err) {
      toast({ title: 'Phục hồi thất bại', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setBusyFull('idle')
    }
  }

  return (
    <SettingsCard title="Backup" desc="Sao lưu toàn bộ hệ thống — metadata (JSON) hoặc bản đầy đủ (metadata + tệp thật)">
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="metadata" className="gap-1.5 text-xs">🧾 Metadata (JSON)</TabsTrigger>
          <TabsTrigger value="full" className="gap-1.5 text-xs">📦 Đầy đủ (kèm tệp)</TabsTrigger>
          <TabsTrigger value="history" className="gap-1.5 text-xs">🕘 Lịch sử</TabsTrigger>
        </TabsList>

        {/* ---- Tab 1: metadata JSON (như cũ) ---- */}
        {tab === 'metadata' && (
          <>
            <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
              <button
                onClick={() => {
                  window.open('/api/core/backup', '_blank')
                  emit('backup.exported', 'core', {})
                }}
                className="flex flex-col items-center gap-2 rounded-2xl bg-muted/50 p-6 transition-colors hover:bg-muted"
              >
                <Download className="h-8 w-8 text-primary" />
                <p className="font-medium">Xuất sao lưu</p>
                <p className="text-xs text-muted-foreground">wos-backup-YYYY-MM-DD.json</p>
              </button>
              <button
                onClick={() => fileRef.current?.click()}
                className="flex flex-col items-center gap-2 rounded-2xl bg-muted/50 p-6 transition-colors hover:bg-muted"
              >
                <Upload className="h-8 w-8 text-primary" />
                <p className="font-medium">{importing ? 'Đang nhập…' : 'Nhập sao lưu'}</p>
                <p className="text-xs text-muted-foreground">Chọn file .json đã xuất trước đó</p>
              </button>
              <input
                ref={fileRef}
                type="file"
                accept="application/json,.json"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files?.[0]) importBackup(e.target.files[0])
                  e.target.value = ''
                }}
              />
            </div>
            <div className="rounded-xl bg-amber-500/10 p-3 text-xs text-amber-700 dark:text-amber-400">
              <Shield className="mr-1.5 inline h-3.5 w-3.5" />
              Sao lưu JSON gồm toàn bộ metadata (tasks, notes, wiki, settings…) — KHÔNG chứa tệp thật. Cần cả tệp? Dùng tab <b>Đầy đủ (kèm tệp)</b>.
            </div>
          </>
        )}

        {/* ---- Tab 2: bản đầy đủ tar.gz (fix lỗi 9) ---- */}
        {tab === 'full' && (
          <>
            <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
              <button
                onClick={() => void exportFull()}
                disabled={busyFull !== 'idle'}
                className="flex flex-col items-center gap-2 rounded-2xl bg-muted/50 p-6 transition-colors hover:bg-muted disabled:opacity-60"
              >
                <PackageOpen className="h-8 w-8 text-primary" />
                <p className="font-medium">{busyFull === 'export' ? 'Đang đóng gói…' : 'Xuất bản ĐẦY ĐỦ'}</p>
                <p className="text-xs text-muted-foreground">wos-backup-full-….tar.gz (DB + toàn bộ tệp)</p>
              </button>
              <button
                onClick={() => tarRef.current?.click()}
                disabled={busyFull !== 'idle'}
                className="flex flex-col items-center gap-2 rounded-2xl bg-muted/50 p-6 transition-colors hover:bg-muted disabled:opacity-60"
              >
                <Upload className="h-8 w-8 text-primary" />
                <p className="font-medium">{busyFull === 'import' ? 'Đang phục hồi…' : 'Phục hồi từ tar.gz'}</p>
                <p className="text-xs text-muted-foreground">Metadata + tệp thật (tự snapshot trước khi áp)</p>
              </button>
              <input
                ref={tarRef}
                type="file"
                accept=".tar.gz,.gz,application/gzip"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files?.[0]) void importFull(e.target.files[0])
                  e.target.value = ''
                }}
              />
            </div>
            <div className="space-y-2 rounded-xl bg-emerald-500/10 p-3 text-xs text-emerald-700 dark:text-emerald-300">
              <p className="flex items-center gap-1.5 font-semibold">
                <Shield className="h-3.5 w-3.5" /> Bản đầy đủ gồm:
              </p>
              <ul className="list-inside list-disc space-y-0.5 pl-1 opacity-90">
                <li><b>db/wos.db</b> — snapshot SQLite nguyên vẹn (tasks, notes, wiki, calendar, settings, plugin…)</li>
                <li><b>files/</b> — TOÀN BỘ tệp thật trong storage của mọi người dùng</li>
                <li><b>config/wos-export.json</b> — metadata JSON (secret đã redact) để đối chiếu</li>
              </ul>
              <p className="opacity-80">Phục hồi: DB áp trong 1 transaction + storage swap có rollback; hệ thống tự snapshot bản hiện tại vào db/snapshots/ trước khi ghi đè.</p>
            </div>
          </>
        )}

        {/* ---- Tab 3: lịch sử backup ---- */}
        {tab === 'history' && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <p className="text-xs text-muted-foreground">15 lần sao lưu gần nhất (Drive + thủ công)</p>
              <Button variant="outline" size="sm" className="h-7 text-xs" onClick={loadHistory}>Làm mới</Button>
            </div>
            {history === null ? (
              <p className="py-6 text-center text-sm text-muted-foreground">Đang tải…</p>
            ) : history.length === 0 ? (
              <p className="py-6 text-center text-sm text-muted-foreground">Chưa có bản sao lưu nào</p>
            ) : (
              <div className="overflow-hidden rounded-xl border">
                <table className="w-full text-xs">
                  <thead className="bg-muted/60">
                    <tr>
                      <th className="px-3 py-2 text-left font-medium">Thời điểm</th>
                      <th className="px-3 py-2 text-left font-medium">Nguồn</th>
                      <th className="px-3 py-2 text-left font-medium">Trạng thái</th>
                      <th className="px-3 py-2 text-left font-medium">Dung lượng</th>
                    </tr>
                  </thead>
                  <tbody>
                    {history.map((r) => (
                      <tr key={r.id} className="border-t">
                        <td className="px-3 py-2">{fmtDateTime(r.startedAt)}</td>
                        <td className="px-3 py-2">{r.provider === 'manual-full' ? '📦 Thủ công (đầy đủ)' : r.provider === 'gdrive' ? '☁️ Google Drive' : r.provider}</td>
                        <td className="px-3 py-2">
                          {r.status === 'ok' ? <Badge className="bg-emerald-500/15 text-emerald-600">thành công</Badge>
                            : r.status === 'running' ? <Badge className="bg-amber-500/15 text-amber-600">đang chạy</Badge>
                            : <Badge className="bg-rose-500/15 text-rose-600" title={r.error}>lỗi</Badge>}
                        </td>
                        <td className="px-3 py-2 tabular-nums">{formatBytes(r.size)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </Tabs>
    </SettingsCard>
  )
}

function ModuleConfigDialog({
  moduleId, onClose, configTab, setConfigTab,
}: {
  moduleId: string
  onClose: () => void
  configTab: string
  setConfigTab: (t: string) => void
}) {
  const { modules, saveModuleConfig, toggleModule, loadSettings, saveSettings } = useWos()
  const { toast } = useToast()
  const mod = modules.find((m) => m.id === moduleId)
  const [config, setConfig] = useState<Record<string, unknown>>(mod?.config || {})
  const [moduleSettings, setModuleSettings] = useState<Record<string, string>>({})
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    loadSettings(moduleId).then(setModuleSettings).catch(() => {})
  }, [moduleId, loadSettings])

  if (!mod) return null

  const disabledWidgets = ((config.widgets as { disabled?: string[] } | undefined)?.disabled || []) as string[]
  const widgets = (mod.widgets as { id: string; title: string; zone: string; span: number }[]) || []
  const events = (mod.events as string[]) || []
  const tabs = ['general', 'permissions', 'widgets', 'notifications', 'backup', 'logs', 'advanced']

  async function save() {
    setSaving(true)
    try {
      await saveModuleConfig(moduleId, config)
      await saveSettings(moduleId, moduleSettings)
      toast({ title: `Đã lưu cấu hình ${mod?.name ?? moduleId}` })
      onClose()
    } finally {
      setSaving(false)
    }
  }

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="wos-glass-strong flex max-h-[85vh] flex-col overflow-y-auto p-0 sm:max-w-[620px]">
        <DialogHeader className="border-b px-5 py-4">
          <DialogTitle className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl text-white" style={{ background: mod.color }}>
              <ModuleIcon icon={mod.icon} className="h-4.5 w-4.5" />
            </div>
            {mod.name} — Cấu hình module
          </DialogTitle>
        </DialogHeader>

        <Tabs value={configTab} onValueChange={setConfigTab} className="px-5 pt-3">
          <TabsList className="h-9 w-full flex-wrap justify-start overflow-x-auto">
            {tabs.map((t) => (
              <TabsTrigger key={t} value={t} className="px-3 text-xs capitalize">{t}</TabsTrigger>
            ))}
          </TabsList>
        </Tabs>

        <div className="flex-1 space-y-4 p-5">
          {configTab === 'general' && (
            <div className="space-y-3">
              <div className="rounded-xl bg-muted/50 p-3 text-sm">
                <p><b>ID:</b> <code>{mod.id}</code> · <b>Phiên bản:</b> v{mod.version} · <b>Khu vực:</b> {mod.section}</p>
                <p className="mt-1 text-muted-foreground">{mod.description}</p>
              </div>
              <Field label="Module đang hoạt động">
                <Switch checked={mod.enabled} onCheckedChange={(v) => toggleModule(moduleId, v)} />
              </Field>
              {Object.keys(moduleSettings).length > 0 && (
                <div className="space-y-2 rounded-xl bg-muted/30 p-3">
                  <p className="text-xs font-semibold text-muted-foreground">Tuỳ chọn nhanh</p>
                  {Object.entries(moduleSettings).map(([k, v]) => (
                    <div key={k} className="flex items-center justify-between gap-3">
                      <span className="text-sm">{k}</span>
                      <Input
                        value={v}
                        onChange={(e) => setModuleSettings({ ...moduleSettings, [k]: e.target.value })}
                        className="h-8 w-40 text-xs"
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {configTab === 'permissions' && (
            <div className="space-y-3">
              <p className="text-sm text-muted-foreground">
                Phân quyền theo vai trò. <code>*</code> = toàn quyền, <code>read</code> = chỉ đọc, <code>write</code> = đọc + ghi.
              </p>
              {['admin', 'member', 'viewer'].map((role) => (
                <Field key={role} label={role}>
                  <Input
                    value={((config.permissions as Record<string, string[]>)?.[role] || mod.permissions?.[role as 'admin'] || []).join(', ')}
                    onChange={(e) => {
                      const perms = { ...((config.permissions as Record<string, string[]>) || {}) }
                      perms[role] = e.target.value.split(',').map((s) => s.trim()).filter(Boolean)
                      setConfig({ ...config, permissions: perms })
                    }}
                    className="h-9 font-mono text-xs"
                  />
                </Field>
              ))}
            </div>
          )}

          {configTab === 'widgets' && (
            <div className="space-y-2">
              {widgets.length === 0 && <p className="py-4 text-center text-sm text-muted-foreground">Module này không có widget nào</p>}
              {widgets.map((w) => {
                const off = disabledWidgets.includes(w.id)
                return (
                  <div key={w.id} className="flex items-center gap-3 rounded-xl bg-muted/50 px-3 py-2.5">
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium">{w.title}</p>
                      <p className="text-[11px] text-muted-foreground">zone: {w.zone} · span: {w.span} · id: {w.id}</p>
                    </div>
                    <Switch
                      checked={!off}
                      onCheckedChange={(v) => {
                        const next = v ? disabledWidgets.filter((id) => id !== w.id) : [...disabledWidgets, w.id]
                        setConfig({ ...config, widgets: { disabled: next } })
                      }}
                    />
                  </div>
                )
              })}
            </div>
          )}

          {configTab === 'notifications' && (
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Module phát các sự kiện sau — Notification Center tự lắng nghe qua Event Bus:</p>
              <div className="flex flex-wrap gap-1.5">
                {events.length === 0 && <p className="text-sm text-muted-foreground">Không có event</p>}
                {events.map((e) => (
                  <Badge key={e} variant="secondary" className="font-mono text-[10px]">{e}</Badge>
                ))}
              </div>
            </div>
          )}

          {configTab === 'backup' && (
            <p className="rounded-xl bg-muted/50 p-4 text-sm text-muted-foreground">
              Dữ liệu của module được đưa vào file sao lưu JSON của hệ thống (Settings → Backup). Tệp lớn của Files nằm trong storage/ và cần rsync riêng.
            </p>
          )}

          {configTab === 'logs' && (
            <p className="rounded-xl bg-muted/50 p-4 text-sm text-muted-foreground">
              Xem log thao tác của module trong <b>Activity</b> (lọc theo module) hoặc Timeline (event stream).
            </p>
          )}

          {configTab === 'advanced' && (
            <div className="space-y-2">
              <Field label="Ghi đè config JSON">
                <Textarea
                  value={JSON.stringify(config, null, 2)}
                  onChange={(e) => {
                    try {
                      setConfig(JSON.parse(e.target.value))
                    } catch {
                      /* json lỗi tạm — không update */
                    }
                  }}
                  className="min-h-[140px] font-mono text-xs"
                />
              </Field>
            </div>
          )}
        </div>

        <div className="flex justify-end gap-2 border-t px-5 py-3">
          <Button variant="outline" size="sm" onClick={onClose}>Đóng</Button>
          <Button size="sm" className="gap-1.5" onClick={save} disabled={saving}>
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Lưu cấu hình
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

/* ============================================================
 * EmailNotificationSection (fix lỗi 8) — kênh thông báo + Email SMTP/Gmail
 * - Kênh: Toast / Browser / Reminder (như cũ)
 * - Email: bật/tắt + cấu hình Gmail App Password hoặc SMTP riêng
 * - "Khi nào thông báo": gửi ngay / gộp 15 phút / gộp 1 giờ / gộp mỗi ngày
 * - "Tính năng thông báo": chọn nhóm sự kiện được gửi email
 * - Nút: Kiểm tra kết nối / Gửi email thử / Đẩy queue ngay / Thống kê
 * ============================================================ */
function EmailNotificationSection({
  defaults, onSave, saving, isAdmin,
}: {
  defaults: Record<string, string>
  onSave: (moduleId: string, values: Record<string, string>) => Promise<void>
  saving: boolean
  isAdmin: boolean
}) {
  const { toast } = useToast()
  const [vals, setVals] = useState<Record<string, string>>(defaults)
  useEffect(() => setVals(defaults), [defaults])
  const set = (v: Record<string, string>) => setVals((prev) => ({ ...prev, ...v }))

  const [stats, setStats] = useState<{ enabled?: boolean; ready?: boolean; mode?: string; queue?: { pending: number; sent: number; failed: number }; to?: string } | null>(null)
  const [testing, setTesting] = useState('')
  const [events, setEvents] = useState<Record<string, boolean>>(() => {
    try {
      return { tasks: true, calendar: true, files: true, system: true, plugin: true, ...JSON.parse(defaults.email_events || '{}') }
    } catch {
      return { tasks: true, calendar: true, files: true, system: true, plugin: true }
    }
  })

  const loadStats = useCallback(() => {
    api<typeof stats>('/api/modules/notifications/test-email', { method: 'POST', body: { action: 'stats' } })
      .then(setStats)
      .catch(() => setStats(null))
  }, [])
  useEffect(() => { loadStats() }, [loadStats])

  function toggleEvent(k: string, v: boolean) {
    const next = { ...events, [k]: v }
    setEvents(next)
    set({ email_events: JSON.stringify(next) })
  }

  async function callTest(action: 'verify' | 'send' | 'flush') {
    setTesting(action)
    try {
      const r = await api<{ message?: string; sent?: number; merged?: number; failed?: number }>(
        '/api/modules/notifications/test-email',
        { method: 'POST', body: { action } },
      )
      toast({ title: action === 'verify' ? 'Kết nối SMTP thành công' : action === 'send' ? 'Đã gửi email thử' : 'Đã đẩy queue', description: r.message || (r.sent != null ? `${r.sent} email (${r.merged || 0} gộp, ${r.failed || 0} lỗi)` : '') })
      loadStats()
    } catch (err) {
      toast({ title: 'Thất bại', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setTesting('')
    }
  }

  const emailOn = vals.email === 'on'
  const isGmail = (vals.email_smtp_host || '').includes('gmail')

  return (
    <SettingsCard title="Notification" desc="Kênh nhận thông báo: Toast, Browser, Reminder và Email (SMTP / Gmail)">
      {/* ---- Kênh cơ bản ---- */}
      <Field label="Toast trong ứng dụng">
        <Switch checked={vals.toast !== 'off'} onCheckedChange={(v) => set({ toast: v ? 'on' : 'off' })} />
      </Field>
      <Field label="Thông báo trình duyệt">
        <Switch checked={vals.browser !== 'off'} onCheckedChange={(v) => set({ browser: v ? 'on' : 'off' })} />
      </Field>
      <Field label="Nhắc việc tự động">
        <Switch checked={vals.reminder !== 'off'} onCheckedChange={(v) => set({ reminder: v ? 'on' : 'off' })} />
      </Field>

      <div className="my-4 border-t" />

      {/* ---- Email ---- */}
      <Field label="Email (SMTP / Gmail)">
        <Switch checked={emailOn} onCheckedChange={(v) => set({ email: v ? 'on' : 'off' })} />
      </Field>

      {emailOn && (
        <>
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <Button variant="outline" size="sm" className="h-8 gap-1.5 text-xs"
              onClick={() => set({ email_smtp_host: 'smtp.gmail.com', email_smtp_port: '465' })}>
              ⚡ Điền nhanh Gmail
            </Button>
            <span className="text-[11px] text-muted-foreground">
              {stats?.ready ? '✅ Đã sẵn sàng gửi' : '⚠️ Chưa cấu hình đủ host / tài khoản / mật khẩu / người nhận'}
            </span>
          </div>

          <div className="grid grid-cols-1 gap-3 rounded-xl bg-muted/40 p-4 md:grid-cols-2">
            <div className="space-y-1">
              <Label className="text-xs">SMTP Host</Label>
              <Input value={vals.email_smtp_host || ''} onChange={(e) => set({ email_smtp_host: e.target.value })} placeholder="smtp.gmail.com" className="h-9" disabled={!isAdmin} />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Cổng</Label>
              <Input value={vals.email_smtp_port || '465'} onChange={(e) => set({ email_smtp_port: e.target.value })} placeholder="465 (SSL) hoặc 587 (TLS)" className="h-9" disabled={!isAdmin} />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Tài khoản SMTP (Gmail)</Label>
              <Input value={vals.email_smtp_user || ''} onChange={(e) => set({ email_smtp_user: e.target.value })} placeholder="yourname@gmail.com" className="h-9" disabled={!isAdmin} />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Mật khẩu ứng dụng (App Password)</Label>
              <Input
                type="password"
                value={vals.email_smtp_password || ''}
                onChange={(e) => set({ email_smtp_password: e.target.value })}
                placeholder={vals.email_smtp_password === '__SAVED__' ? '•••••••••••• (đã lưu — nhập để đổi)' : '16 ký tự từ Google (vd abcd efgh ijkl mnop)'}
                className="h-9"
                disabled={!isAdmin}
              />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Tên người gửi (hiển thị)</Label>
              <Input value={vals.email_from || ''} onChange={(e) => set({ email_from: e.target.value })} placeholder="Workspace OS" className="h-9" disabled={!isAdmin} />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Email nhận thông báo</Label>
              <Input value={vals.email_to || ''} onChange={(e) => set({ email_to: e.target.value })} placeholder="admin@example.com" className="h-9" disabled={!isAdmin} />
            </div>
          </div>

          {isGmail && (
            <div className="mt-3 rounded-lg bg-amber-500/10 px-3.5 py-2.5 text-[11.5px] leading-relaxed text-amber-700 dark:text-amber-300">
              <b>📌 Lấy App Password Gmail (khóa Gmail):</b> Google Account → Security → bật <b>2-Step Verification</b> →
              tìm <b>App Passwords</b> → tạo mới (chọn Mail + thiết bị) → copy 16 ký tự vào ô mật khẩu trên.
              <span className="block opacity-80">Không dùng mật khẩu đăng nhập Gmail thường — Google sẽ chặn.</span>
            </div>
          )}

          {/* ---- Khi nào thông báo + gộp ---- */}
          <div className="mt-4 space-y-2">
            <Label className="text-sm font-medium">Khi nào gửi email</Label>
            <div className="flex flex-wrap gap-2">
              {[
                { id: 'immediate', label: '⚡ Gửi ngay', hint: 'mỗi thông báo 1 email (≤ 60 giây)' },
                { id: 'digest15', label: '🧹 Gộp 15 phút', hint: 'gom mọi thông báo trong 15 phút thành 1 email' },
                { id: 'digest60', label: '🕐 Gộp 1 giờ', hint: 'gom theo giờ — khuyên dùng' },
                { id: 'daily', label: '📅 Gộp mỗi ngày', hint: '1 email tổng hợp mỗi ngày' },
              ].map((m) => (
                <button
                  key={m.id}
                  title={m.hint}
                  disabled={!isAdmin}
                  onClick={() => set({ email_mode: m.id })}
                  className={`rounded-xl px-3.5 py-2 text-xs font-medium transition-colors ${
                    (vals.email_mode || 'immediate') === m.id
                      ? 'bg-primary text-primary-foreground shadow'
                      : 'bg-muted/60 text-muted-foreground hover:bg-muted'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>
            <p className="text-[11px] text-muted-foreground">
              Gộp thông báo (digest): nhiều sự kiện trong cùng cửa sổ thời gian được gom thành MỘT email đẹp mắt — hết spam hộp thư.
            </p>
          </div>

          {/* ---- Chọn tính năng thông báo ---- */}
          <div className="mt-4 space-y-2">
            <Label className="text-sm font-medium">Tính năng được gửi email</Label>
            <div className="grid grid-cols-2 gap-2 md:grid-cols-3">
              {[
                { id: 'tasks', label: '✅ Công việc' },
                { id: 'calendar', label: '📅 Lịch' },
                { id: 'files', label: '📁 Tệp' },
                { id: 'system', label: '⚙️ Hệ thống' },
                { id: 'plugin', label: '🧩 Plugin' },
              ].map((g) => (
                <label key={g.id} className="flex cursor-pointer items-center gap-2 rounded-lg bg-muted/50 px-3 py-2 text-xs font-medium">
                  <input
                    type="checkbox"
                    checked={events[g.id] !== false}
                    disabled={!isAdmin}
                    onChange={(e) => toggleEvent(g.id, e.target.checked)}
                    className="h-4 w-4 accent-violet-600"
                  />
                  {g.label}
                </label>
              ))}
            </div>
          </div>

          {/* ---- Hành động + thống kê ---- */}
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <Button variant="outline" size="sm" className="h-8 text-xs" disabled={!isAdmin || testing !== ''} onClick={() => void callTest('verify')}>
              {testing === 'verify' ? 'Đang kiểm tra…' : '🔌 Kiểm tra kết nối'}
            </Button>
            <Button variant="outline" size="sm" className="h-8 text-xs" disabled={!isAdmin || testing !== ''} onClick={() => void callTest('send')}>
              {testing === 'send' ? 'Đang gửi…' : '✉️ Gửi email thử'}
            </Button>
            <Button variant="outline" size="sm" className="h-8 text-xs" disabled={!isAdmin || testing !== ''} onClick={() => void callTest('flush')}>
              {testing === 'flush' ? 'Đang đẩy…' : '🚀 Đẩy email đang chờ'}
            </Button>
            {stats?.queue && (
              <span className="ml-auto text-[11px] text-muted-foreground">
                Queue: <b>{stats.queue.pending}</b> chờ · {stats.queue.sent} đã gửi · {stats.queue.failed} lỗi
                {stats.to ? ` → ${stats.to}` : ''}
              </span>
            )}
          </div>
        </>
      )}

      <SaveBar onSave={() => onSave('notifications', vals)} saving={saving} />
    </SettingsCard>
  )
}

