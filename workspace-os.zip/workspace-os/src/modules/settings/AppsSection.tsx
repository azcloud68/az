'use client'

/**
 * AppsSection (Settings → Ứng dụng cài thêm) — quản lý PLUGIN:
 * - Admin tải gói .wos/.zip lên → cài → app hiện trên Desktop/Launchpad/Dock
 * - Bật/tắt từng plugin, gỡ bỏ kèm dữ liệu
 * - Hướng dẫn quy ước phát triển (DEVELOPING-MODULES.md)
 */
import { useCallback, useEffect, useRef, useState } from 'react'
import { useWos } from '@/core/client/wos-store'
import { usePlugins } from '@/core/client/plugin-store'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Package, Upload, Loader2, Trash2, ExternalLink, ShieldCheck, Database, Info,
} from 'lucide-react'
import { toast } from 'sonner'

interface PluginRow {
  id: string
  appId: string
  name: string
  version: string
  description: string
  author: string
  icon: string
  permissions: string[]
  window?: { w?: number; h?: number }
  enabled: boolean
  installedAt: string
}

export function AppsSection() {
  const user = useWos((s) => s.user)
  const emit = useWos((s) => s.emit)
  const refresh = usePlugins((s) => s.load)
  const [plugins, setPlugins] = useState<PluginRow[] | null>(null)
  const [installing, setInstalling] = useState(false)
  const [busyId, setBusyId] = useState('')
  const fileRef = useRef<HTMLInputElement>(null)
  const isAdmin = user?.role === 'admin'

  const load = useCallback(async () => {
    try {
      const res = await fetch('/api/plugins', { credentials: 'same-origin' })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const data = (await res.json()) as { plugins: PluginRow[] }
      setPlugins(data.plugins || [])
    } catch {
      setPlugins([])
    }
  }, [])

  useEffect(() => {
    load()
  }, [load])

  async function install(file: File) {
    if (!/\.(wos|zip)$/i.test(file.name)) {
      toast.error('Gói phải có đuôi .wos hoặc .zip')
      return
    }
    setInstalling(true)
    try {
      const form = new FormData()
      form.append('file', file)
      const res = await fetch('/api/plugins', { method: 'POST', body: form, credentials: 'same-origin' })
      const data = (await res.json().catch(() => ({}))) as { error?: string; plugin?: PluginRow }
      if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`)
      toast.success('Đã cài ứng dụng bổ sung', {
        description: `${data.plugin?.name} v${data.plugin?.version} — tải lại trang để hiện icon`,
        action: { label: 'Tải lại', onClick: () => window.location.reload() },
        duration: 15000,
      })
      emit('plugin.installed', 'core', { title: data.plugin?.name })
      await load()
    } catch (err) {
      toast.error('Cài đặt thất bại', { description: err instanceof Error ? err.message : '' })
    } finally {
      setInstalling(false)
    }
  }

  async function toggle(row: PluginRow, enabled: boolean) {
    setBusyId(row.id)
    try {
      const res = await fetch('/api/plugins', {
        method: 'PATCH',
        headers: { 'content-type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ id: row.id, enabled }),
      })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      emit(enabled ? 'plugin.enabled' : 'plugin.disabled', 'core', { title: row.name })
      await load()
    } catch (err) {
      toast.error('Không đổi được trạng thái', { description: err instanceof Error ? err.message : '' })
    } finally {
      setBusyId('')
    }
  }

  async function uninstall(row: PluginRow) {
    if (!confirm(`Gỡ "${row.name}"? Dữ liệu của ứng dụng này cũng bị xoá.`)) return
    setBusyId(row.id)
    try {
      const res = await fetch('/api/plugins', {
        method: 'DELETE',
        headers: { 'content-type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ id: row.id }),
      })
      const data = (await res.json().catch(() => ({}))) as { error?: string }
      if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`)
      emit('plugin.uninstalled', 'core', { title: row.name })
      toast.success('Đã gỡ ứng dụng', { description: `${row.name} — tải lại trang để cập nhật`, duration: 12000 })
      await load()
      await refresh().catch(() => {})
    } catch (err) {
      toast.error('Gỡ thất bại', { description: err instanceof Error ? err.message : '' })
    } finally {
      setBusyId('')
    }
  }

  const iconIsImage = (icon: string) => icon.startsWith('/') || /\.(svg|png|jpe?g|webp|gif)$/i.test(icon)

  return (
    <div className="space-y-4">
      {/* Cài mới */}
      <Card className="wos-glass border-0">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Package className="h-4 w-4" /> Ứng dụng cài thêm (Plugin)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-sm text-muted-foreground">
            Cài thêm ứng dụng do bạn hoặc người khác phát triển: chỉ cần tải gói <b>.wos</b> lên —
            ứng dụng xuất hiện trên Desktop, Launchpad, Dock và chạy như app gốc của Workspace OS
            (kiểu cài phần mềm .exe trên Windows).
          </p>
          {isAdmin ? (
            <div className="flex flex-wrap items-center gap-2">
              <Button size="sm" className="h-9 gap-1.5" onClick={() => fileRef.current?.click()} disabled={installing}>
                {installing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />} Cài từ gói .wos
              </Button>
              <input
                ref={fileRef}
                type="file"
                accept=".wos,.zip"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files?.[0]) void install(e.target.files[0])
                  e.target.value = ''
                }}
                aria-label="Chọn gói plugin"
              />
              <p className="text-xs text-muted-foreground">Gói ≤ 50MB · zip chứa wos-module.json + main.js</p>
            </div>
          ) : (
            <p className="rounded-xl bg-muted/60 px-3 py-2 text-xs text-muted-foreground">
              Chỉ quản trị viên mới cài/gỡ ứng dụng bổ sung. Hỏi admin của workspace.
            </p>
          )}
        </CardContent>
      </Card>

      {/* Danh sách đã cài */}
      {plugins === null ? (
        <div className="flex h-32 items-center justify-center">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </div>
      ) : plugins.length === 0 ? (
        <Card className="wos-glass border-0">
          <CardContent className="flex flex-col items-center gap-2 py-10 text-muted-foreground">
            <Package className="h-10 w-10 opacity-30" />
            <p className="text-sm font-medium">Chưa có ứng dụng bổ sung nào</p>
            <p className="max-w-md text-center text-xs">
              Xem quy ước phát triển module trong tài liệu <b>DEVELOPING-MODULES.md</b> kèm bộ cài —
              hoặc dùng template <code className="rounded bg-muted px-1">plugin-template/</code> để bắt đầu.
            </p>
          </CardContent>
        </Card>
      ) : (
        <Card className="wos-glass border-0">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">{plugins.length} ứng dụng đã cài</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {plugins.map((p) => (
              <div key={p.id} className="flex flex-wrap items-center gap-3 rounded-xl bg-muted/40 p-3">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-background shadow-sm">
                  {iconIsImage(p.icon) ? (
                    <img src={p.icon} alt="" className="h-7 w-7 object-contain" />
                  ) : (
                    <span className="text-2xl leading-none">{p.icon}</span>
                  )}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <p className="text-sm font-semibold">{p.name}</p>
                    <Badge variant="secondary" className="font-normal">v{p.version}</Badge>
                    {p.permissions.includes('storage') && (
                      <Badge variant="outline" className="gap-1 font-normal"><Database className="h-3 w-3" /> storage</Badge>
                    )}
                    {p.permissions.includes('notifications') && (
                      <Badge variant="outline" className="gap-1 font-normal"><Info className="h-3 w-3" /> notify</Badge>
                    )}
                  </div>
                  <p className="mt-0.5 line-clamp-2 text-xs text-muted-foreground">
                    {p.description || 'Không có mô tả'}
                    {p.author ? ` · Tác giả: ${p.author}` : ''}
                  </p>
                </div>
                {isAdmin && (
                  <div className="flex shrink-0 items-center gap-2">
                    <Switch
                      checked={p.enabled}
                      disabled={busyId === p.id}
                      onCheckedChange={(v) => void toggle(p, v)}
                      aria-label={`Bật/tắt ${p.name}`}
                    />
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-muted-foreground hover:text-destructive"
                      disabled={busyId === p.id}
                      onClick={() => void uninstall(p)}
                      aria-label={`Gỡ ${p.name}`}
                      title="Gỡ ứng dụng"
                    >
                      {busyId === p.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
                    </Button>
                  </div>
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Quy ước phát triển */}
      <Card className="wos-glass border-0">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-base">
            <ShieldCheck className="h-4 w-4" /> Quy ước phát triển module
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <p className="text-muted-foreground">
            Ai cũng có thể phát triển ứng dụng cho Workspace OS mà không cần sửa mã nguồn hệ thống:
          </p>
          <ul className="list-disc space-y-1 pl-5 text-[13px] text-muted-foreground">
            <li>Gói <b>.wos</b> = zip chứa <code className="rounded bg-muted px-1">wos-module.json</code> (manifest: id, tên, icon, quyền) + <code className="rounded bg-muted px-1">main.js</code> (bundle gọi <code className="rounded bg-muted px-1">WOS.registerApp()</code>)</li>
            <li>Component dùng React <b>của hệ thống</b> (WOS.React) — không bundle React lại</li>
            <li>Dữ liệu lưu qua <code className="rounded bg-muted px-1">ctx.storage</code> — namespace riêng, giới hạn 10MB/plugin, người dùng thường không đụng DB của hệ thống</li>
            <li>Quyền: <code className="rounded bg-muted px-1">storage | events | notifications | ui</code> — khai báo trong manifest, server kiểm tra</li>
            <li>Tài liệu đầy đủ: <b>DEVELOPING-MODULES.md</b> + template sẵn <b>plugin-template/</b> trong bộ cài</li>
          </ul>
          <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <ExternalLink className="h-3 w-3" /> Chỉ cài gói từ nguồn tin cậy — plugin chạy trong trình duyệt của bạn.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
