'use client'

/**
 * Settings → Hệ thống (System) — "About This Computer" của WOS + tài nguyên live.
 * Đọc /api/system/info (1 lần) + /api/system/resources (poll 3s khi mở).
 */
import { useEffect, useState } from 'react'
import { api, formatBytes } from '@/core/client/api'
import { useWindows } from '@/core/client/window-store'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Cpu, Flame, Gauge, HardDrive, MemoryStick, MonitorSmartphone, Server, TerminalSquare, Wifi } from 'lucide-react'

interface SysInfo {
  hostname: string
  platform: string
  arch: string
  kernel: string
  boardModel: string | null
  cpuModel: string
  cores: number
  memTotal: number
  nodeVersion: string
}

interface Res {
  cpu: { percent: number; cores: number }
  mem: { total: number; used: number; percent: number; swapTotal: number; swapUsed: number }
  disk: { total: number; used: number; percent: number }
  load: [number, number, number]
  uptime: number
  temp: number | null
  net: { rxPerSec: number; txPerSec: number }
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-baseline justify-between gap-4 border-b py-2 last:border-0">
      <span className="shrink-0 text-[12.5px] text-muted-foreground">{label}</span>
      <span className="min-w-0 truncate text-right text-[13px] font-medium">{value}</span>
    </div>
  )
}

export function SystemSection() {
  const openApp = useWindows((s) => s.openApp)
  const [info, setInfo] = useState<SysInfo | null>(null)
  const [res, setRes] = useState<Res | null>(null)

  useEffect(() => {
    void api<SysInfo>('/api/system/info').then(setInfo).catch(() => {})
    const load = () => void api<Res>('/api/system/resources').then(setRes).catch(() => {})
    load()
    const iv = setInterval(load, 3000)
    return () => clearInterval(iv)
  }, [])

  const uptime = res?.uptime || 0
  const upStr =
    uptime > 86400
      ? `${Math.floor(uptime / 86400)} ngày ${Math.floor((uptime % 86400) / 3600)} giờ`
      : uptime > 3600
        ? `${Math.floor(uptime / 3600)} giờ ${Math.floor((uptime % 3600) / 60)} phút`
        : `${Math.floor(uptime / 60)} phút`

  return (
    <div className="space-y-4">
      {/* About This Computer */}
      <Card className="wos-glass border-0">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Server className="h-4.5 w-4.5 text-primary" />
            Thông tin máy chủ
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-0">
          <Row label="Tên máy" value={info?.hostname || '—'} />
          <Row label="Bo mạch" value={info?.boardModel || 'Máy ảo / không xác định'} />
          <Row label="Kiến trúc" value={info ? `${info.platform} · ${info.arch}` : '—'} />
          <Row label="Kernel" value={info?.kernel || '—'} />
          <Row label="CPU" value={info ? `${info.cpuModel} (${info.cores} nhân)` : '—'} />
          <Row label="RAM hệ thống" value={info ? formatBytes(info.memTotal) : '—'} />
          <Row label="Node.js" value={info?.nodeVersion || '—'} />
          <Row label="Workspace OS" value="3.0 — Web PC" />
          <Row label="Thời gian hoạt động" value={upStr} />
        </CardContent>
      </Card>

      {/* Tài nguyên live */}
      <Card className="wos-glass border-0">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Gauge className="h-4.5 w-4.5 text-rose-500" />
            Tài nguyên
            {res?.temp != null ? (
              <span className={`ml-auto flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-medium ${res.temp > 70 ? 'bg-rose-500/15 text-rose-600' : 'bg-muted text-muted-foreground'}`}>
                <Flame className="h-3 w-3" />
                {res.temp}°C
              </span>
            ) : null}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <div className="mb-1.5 flex items-center justify-between text-[12.5px]">
              <span className="flex items-center gap-1.5 text-muted-foreground">
                <Cpu className="h-3.5 w-3.5 text-sky-500" /> CPU
              </span>
              <span className="font-semibold tabular-nums">{res?.cpu.percent ?? '—'}%</span>
            </div>
            <Progress value={res?.cpu.percent || 0} className="h-2" />
            <p className="mt-1 text-[11px] text-muted-foreground">
              load: {res ? res.load.map((l) => l.toFixed(2)).join(' · ') : '—'}
            </p>
          </div>
          <div>
            <div className="mb-1.5 flex items-center justify-between text-[12.5px]">
              <span className="flex items-center gap-1.5 text-muted-foreground">
                <MemoryStick className="h-3.5 w-3.5 text-violet-500" /> Bộ nhớ
              </span>
              <span className="font-semibold tabular-nums">
                {res ? `${formatBytes(res.mem.used)} / ${formatBytes(res.mem.total)}` : '—'}
              </span>
            </div>
            <Progress value={res?.mem.percent || 0} className="h-2" />
            {res && res.mem.swapTotal > 0 ? (
              <p className="mt-1 text-[11px] text-muted-foreground">
                Swap: {formatBytes(res.mem.swapUsed)} / {formatBytes(res.mem.swapTotal)}
              </p>
            ) : null}
          </div>
          <div>
            <div className="mb-1.5 flex items-center justify-between text-[12.5px]">
              <span className="flex items-center gap-1.5 text-muted-foreground">
                <HardDrive className="h-3.5 w-3.5 text-emerald-500" /> Ổ đĩa
              </span>
              <span className="font-semibold tabular-nums">
                {res ? `${formatBytes(res.disk.used)} / ${formatBytes(res.disk.total)}` : '—'}
              </span>
            </div>
            <Progress value={res?.disk.percent || 0} className="h-2" />
          </div>
          <div className="flex items-center justify-between text-[12.5px]">
            <span className="flex items-center gap-1.5 text-muted-foreground">
              <Wifi className="h-3.5 w-3.5 text-cyan-500" /> Mạng
            </span>
            <span className="tabular-nums">
              ↓ {res ? formatBytes(res.net.rxPerSec) : '—'}/s · ↑ {res ? formatBytes(res.net.txPerSec) : '—'}/s
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Công cụ hệ thống */}
      <Card className="wos-glass border-0">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <MonitorSmartphone className="h-4.5 w-4.5 text-cyan-600" />
            Công cụ hệ thống
          </CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Button variant="secondary" size="sm" className="gap-1.5" onClick={() => openApp('monitor')}>
            <Gauge className="h-3.5 w-3.5" /> System Monitor
          </Button>
          <Button variant="secondary" size="sm" className="gap-1.5" onClick={() => openApp('terminal')}>
            <TerminalSquare className="h-3.5 w-3.5" /> Terminal
          </Button>
          <Button variant="secondary" size="sm" className="gap-1.5" onClick={() => openApp('browser')}>
            <Wifi className="h-3.5 w-3.5" /> Trình duyệt
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
