'use client'

/**
 * PluginsSection — quản lý plugin (app cài thêm):
 * - Danh sách plugin: bật/tắt, gỡ cài đặt, mở app
 * - CÀI 3 KIỂU (v5):
 *   1. Upload file .zip (plugin nặng nhiều file: plugin.json + main.js + assets…)
 *   2. Thư mục plugin riêng trên máy chủ — copy code lên rồi bấm "Quét lại"
 *   3. Dán manifest JSON (plugin nhẹ 1 file — kiểu cũ vẫn dùng được)
 * - Hướng dẫn phát triển plugin (template + API WOS)
 */
import { useRef, useState } from 'react'
import { useWos } from '@/core/client/wos-store'
import { useWindows } from '@/core/client/window-store'
import { api } from '@/core/client/api'
import { ModuleIcon } from '@/components/wos/ModuleIcon'
import { resetPlugin } from '@/components/wos/plugin-runtime'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Card, CardContent } from '@/components/ui/card'
import { useToast } from '@/hooks/use-toast'
import {
  Puzzle, Upload, Trash2, Play, Loader2, ExternalLink, BadgeCheck, ChevronDown, Package,
  FolderSearch, FileArchive, Copy, RefreshCw,
} from 'lucide-react'
import { toast } from 'sonner'

const EXAMPLE = `{
  "slug": "hello-world",
  "name": "Hello World",
  "description": "Plugin ví dụ: hiện chữ Hello",
  "icon": "👋",
  "color": "#f97316",
  "kind": "app",
  "version": "1.0.0",
  "author": "Bạn",
  "windowSize": { "w": 380, "h": 300 },
  "entry": "var h = WOS.h; WOS.css('.hw{padding:24px;font-size:22px}'); WOS.registerApp({ component: function(){ return h('div', {className:'hw'}, 'Xin chào WOS!') } })"
}`

const ZIP_EXAMPLE = `my-plugin.zip
├── plugin.json    ← manifest: slug, name, version, entry: "main.js"…
├── main.js        ← mã JS chính (WOS.registerApp / WOS.registerPet)
├── style.css      ← (tuỳ chọn) khai trong manifest: "styles": ["style.css"]
└── assets/        ← (tuỳ chọn) ảnh — dùng WOS.assetUrl('assets/x.png')`

export function PluginsSection() {
  const { plugins, refreshPlugins, patchPlugin, user, pluginsDir } = useWos()
  const openApp = useWindows((s) => s.openApp)
  const { toast: shadToast } = useToast()
  const isAdmin = user?.role === 'admin'
  const [pasteValue, setPasteValue] = useState('')
  const [installing, setInstalling] = useState(false)
  const [scanning, setScanning] = useState(false)
  const [guideOpen, setGuideOpen] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)
  const zipRef = useRef<HTMLInputElement>(null)

  async function install(manifest: unknown) {
    if (!manifest || typeof manifest !== 'object') {
      shadToast({ title: 'Manifest không hợp lệ', variant: 'destructive' })
      return
    }
    setInstalling(true)
    try {
      await api('/api/core/plugins', { method: 'POST', body: manifest as Record<string, unknown> })
      await refreshPlugins()
      toast.success('Đã cài plugin', { description: String((manifest as { name?: string }).name || '') })
      setPasteValue('')
    } catch (err) {
      toast.error('Cài plugin thất bại', { description: err instanceof Error ? err.message : '' })
    } finally {
      setInstalling(false)
    }
  }

  /** Cài từ file .zip — upload multipart → server giải nén + validate + đăng ký */
  async function installZip(file: File) {
    setInstalling(true)
    try {
      const form = new FormData()
      form.append('file', file)
      const res = await fetch('/api/core/plugins/install-zip', { method: 'POST', body: form })
      const data = (await res.json().catch(() => ({}))) as {
        plugin?: { name?: string; slug?: string; version?: string }
        error?: string
      }
      if (!res.ok) throw new Error(data.error || `Lỗi HTTP ${res.status}`)
      await refreshPlugins()
      toast.success('Đã cài plugin từ .zip', {
        description: `${data.plugin?.name || ''} v${data.plugin?.version || '1.0.0'} (${data.plugin?.slug || ''})`,
      })
    } catch (err) {
      toast.error('Cài .zip thất bại', { description: err instanceof Error ? err.message : '' })
    } finally {
      setInstalling(false)
    }
  }

  /** Quét lại thư mục plugin (đã copy code trực tiếp lên máy chủ) */
  async function rescan() {
    setScanning(true)
    try {
      await refreshPlugins(true)
      toast.success('Đã quét thư mục plugin', {
        description: 'Plugin mới trong thư mục đã hiển thị trong danh sách.',
      })
    } catch (err) {
      toast.error('Quét thất bại', { description: err instanceof Error ? err.message : '' })
    } finally {
      setScanning(false)
    }
  }

  async function uninstall(slug: string, name: string) {
    if (!confirm(`Gỡ cài đặt plugin "${name}"?`)) return
    try {
      await api(`/api/core/plugins?slug=${encodeURIComponent(slug)}`, { method: 'DELETE' })
      resetPlugin(slug)
      await refreshPlugins()
      useWindows.getState().closeModule(slug)
      toast.success('Đã gỡ plugin', { description: name })
    } catch (err) {
      toast.error('Gỡ plugin thất bại', { description: err instanceof Error ? err.message : '' })
    }
  }

  function onFile(file: File) {
    const reader = new FileReader()
    reader.onload = () => {
      try {
        const manifest = JSON.parse(String(reader.result))
        void install(manifest)
      } catch {
        shadToast({ title: 'File không phải JSON hợp lệ', variant: 'destructive' })
      }
    }
    reader.readAsText(file)
  }

  return (
    <div className="space-y-4">
      <Card className="wos-glass border-0">
        <CardContent className="space-y-3 py-4">
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="flex items-center gap-2 text-base font-bold">
              <Puzzle className="h-4.5 w-4.5 text-primary" /> Plugins — ứng dụng cài thêm
            </h2>
            <Badge variant="secondary" className="font-normal">{plugins.length} plugin</Badge>
            <Button
              variant="ghost"
              size="sm"
              className="ml-auto h-7 gap-1.5 text-xs text-muted-foreground"
              onClick={() => void rescan()}
              disabled={scanning}
              title="Quét lại thư mục plugin trên máy chủ"
            >
              {scanning ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />} Quét lại
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">Cài như cài phần mềm — xuất hiện ngay trên Desktop/Launchpad</p>

          {!isAdmin && (
            <p className="rounded-lg bg-muted/50 px-3 py-2 text-xs text-muted-foreground">
              Chỉ quản trị viên cài/gỡ plugin. Bạn vẫn bật/tắt được plugin đã cài.
            </p>
          )}

          {/* Danh sách plugin */}
          <div className="space-y-2">
            {plugins.length === 0 && (
              <div className="flex flex-col items-center gap-2 rounded-2xl border border-dashed py-10 text-muted-foreground">
                <Package className="h-8 w-8 opacity-30" />
                <p className="text-sm">Chưa có plugin nào (2 plugin dựng sẵn tự cài lần đầu tải danh sách)</p>
              </div>
            )}
            {plugins.map((p) => (
              <div key={p.slug} className="flex flex-wrap items-center gap-3 rounded-xl bg-muted/50 px-3 py-2.5">
                <div
                  className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-white shadow"
                  style={{ background: `linear-gradient(145deg, ${p.color}, ${p.color}bb)` }}
                >
                  <ModuleIcon icon={p.icon} px={22} />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="flex flex-wrap items-center gap-1.5 text-sm font-semibold">
                    {p.name}
                    <Badge variant="outline" className="h-4 px-1.5 text-[9px]">v{p.version}</Badge>
                    {p.builtin && (
                      <Badge className="h-4 gap-1 px-1.5 text-[9px]"><BadgeCheck className="h-2.5 w-2.5" /> dựng sẵn</Badge>
                    )}
                    <Badge variant="secondary" className="h-4 px-1.5 text-[9px]">{p.kind === 'pet' ? 'nhân vật' : 'app'}</Badge>
                  </p>
                  <p className="truncate text-xs text-muted-foreground">
                    {p.description} {p.author ? `· ${p.author}` : ''}
                  </p>
                </div>
                {p.kind === 'app' && (
                  <Button variant="outline" size="sm" className="h-8 gap-1.5" onClick={() => openApp(p.slug)} disabled={!p.enabled}>
                    <Play className="h-3.5 w-3.5" /> Mở
                  </Button>
                )}
                <Switch
                  checked={p.enabled}
                  onCheckedChange={(v) => {
                    resetPlugin(p.slug)
                    void patchPlugin(p.slug, { enabled: v })
                  }}
                  aria-label={`${p.enabled ? 'Tắt' : 'Bật'} ${p.name}`}
                />
                {isAdmin && !p.builtin ? (
                  <Button variant="outline" size="sm" className="h-8 gap-1.5 text-rose-500 hover:bg-rose-500/10" onClick={() => uninstall(p.slug, p.name)}>
                    <Trash2 className="h-3.5 w-3.5" /> Gỡ
                  </Button>
                ) : null}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Cài mới */}
      {isAdmin && (
        <>
          <Card className="wos-glass border-0">
            <CardContent className="space-y-3 py-4">
              <h3 className="text-sm font-bold">Cài plugin mới</h3>

              {/* Kiểu 1: .zip */}
              <div className="rounded-xl border border-primary/30 bg-primary/5 p-3">
                <p className="flex items-center gap-1.5 text-sm font-semibold">
                  <FileArchive className="h-4 w-4 text-primary" /> Cài từ file .zip <span className="text-[10px] font-normal text-muted-foreground">(khuyên dùng — plugin nhiều file)</span>
                </p>
                <div className="mt-2 flex flex-wrap items-center gap-2">
                  <Button size="sm" className="h-9 gap-1.5" onClick={() => zipRef.current?.click()} disabled={installing}>
                    {installing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />} Chọn file .zip
                  </Button>
                  <span className="text-xs text-muted-foreground">Tối đa 100MB · giải nén tự động + kiểm tra an toàn</span>
                </div>
                <pre className="wos-scroll mt-2 overflow-x-auto rounded-lg bg-black/80 p-2.5 text-[10.5px] leading-relaxed text-green-200">{ZIP_EXAMPLE}</pre>
              </div>

              {/* Kiểu 2: thư mục riêng */}
              <div className="rounded-xl border border-border bg-muted/40 p-3">
                <p className="flex items-center gap-1.5 text-sm font-semibold">
                  <FolderSearch className="h-4 w-4 text-primary" /> Thư mục plugin trên máy chủ (upload code trực tiếp)
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  Copy/SFTP code plugin vào thư mục dưới (mỗi plugin 1 thư mục con chứa <code>plugin.json</code>), rồi bấm <b>Quét lại</b> — hệ thống tự đăng ký và hiển thị.
                </p>
                {pluginsDir && (
                  <div className="mt-2 flex items-center gap-2">
                    <code className="wos-scroll flex-1 overflow-x-auto whitespace-nowrap rounded-lg bg-black/70 px-2.5 py-1.5 font-mono text-[11px] text-amber-200">{pluginsDir}</code>
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-8 w-8 shrink-0"
                      onClick={() => {
                        void navigator.clipboard.writeText(pluginsDir).then(() => toast.success('Đã sao chép đường dẫn'))
                      }}
                      aria-label="Sao chép đường dẫn"
                      title="Sao chép đường dẫn"
                    >
                      <Copy className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                )}
              </div>

              {/* Kiểu 3: JSON */}
              <div className="space-y-2">
                <p className="text-xs text-muted-foreground">Plugin nhẹ 1 file — dán manifest JSON:</p>
                <Textarea
                  value={pasteValue}
                  onChange={(e) => setPasteValue(e.target.value)}
                  placeholder='{ "slug": "my-plugin", "name": "…", "entry": "…" }'
                  className="min-h-[110px] font-mono text-xs"
                />
                <Button
                  size="sm"
                  className="h-9"
                  disabled={installing || !pasteValue.trim()}
                  onClick={() => {
                    try {
                      void install(JSON.parse(pasteValue))
                    } catch {
                      shadToast({ title: 'JSON không hợp lệ', variant: 'destructive' })
                    }
                  }}
                >
                  {installing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Puzzle className="h-4 w-4" />} Cài từ JSON
                </Button>
              </div>

              {/* Hướng dẫn */}
              <button
                className="flex w-full items-center gap-2 rounded-lg bg-muted/60 px-3 py-2 text-left text-xs font-medium text-muted-foreground transition-colors hover:text-foreground"
                onClick={() => setGuideOpen((v) => !v)}
                aria-expanded={guideOpen}
              >
                <ChevronDown className={`h-3.5 w-3.5 transition-transform ${guideOpen ? 'rotate-180' : ''}`} />
                Hướng dẫn phát triển plugin (WOS Plugin API)
              </button>
              {guideOpen && (
                <div className="wos-scroll max-h-72 space-y-2 overflow-y-auto rounded-xl bg-muted/40 p-3 text-xs leading-relaxed">
                  <p><b>1. Plugin là gì?</b> 1 ứng dụng gói lại: file .zip chứa <code>plugin.json</code> (manifest) + mã JS chạy phía trình duyệt. Sau khi cài (admin), app xuất hiện trong Launchpad/Desktop/Dock như app gốc.</p>
                  <p><b>2. Kiểu .zip (khuyên dùng)</b>: <code>plugin.json</code> khai <code>&quot;entry&quot;: &quot;main.js&quot;</code> (file mã chính), <code>&quot;styles&quot;: [&quot;style.css&quot;]</code> (CSS tự chèn), ảnh trong <code>assets/</code> lấy qua <code>WOS.assetUrl(&apos;assets/x.png&apos;)</code>.</p>
                  <p><b>3. entry không dùng JSX</b> — dùng <code>WOS.h</code> (React.createElement). Biến <code>WOS</code> gồm:</p>
                  <ul className="list-inside list-disc space-y-0.5 pl-2 text-muted-foreground">
                    <li><code>h, Fragment, useState, useEffect, useRef, useMemo, useCallback</code> — React</li>
                    <li><code>WOS.registerApp({'{'}component, windowSize{'}'})</code> — đăng ký app mở cửa sổ</li>
                    <li><code>WOS.registerPet({'{'}component{'}'})</code> — đăng ký nhân vật chạy trên desktop</li>
                    <li><code>WOS.notify({'{'}title, content{'}'})</code> — gửi thông báo (Notification Center)</li>
                    <li><code>WOS.emitEvent(type, payload)</code> — phát event (Timeline + Activity ghi nhận)</li>
                    <li><code>WOS.openApp(moduleId)</code> — mở app hệ thống (tasks, notes…)</li>
                    <li><code>WOS.api(path, opts)</code> — gọi API hệ thống; <code>WOS.bus</code> — event bus client</li>
                    <li><code>WOS.css(text)</code> — chèn CSS (prefix class theo slug); <code>WOS.storage</code> — localStorage riêng; <code>WOS.assetUrl(file)</code> — URL tài nguyên trong pack</li>
                  </ul>
                  <p><b>4. Ví dụ tối thiểu</b> (kiểu JSON — bấm để điền):</p>
                  <pre className="wos-scroll overflow-x-auto rounded-lg bg-black/80 p-2.5 text-[10.5px] text-green-200">{EXAMPLE}</pre>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-7 gap-1.5 text-xs"
                    onClick={() => setPasteValue(EXAMPLE)}
                  >
                    <ExternalLink className="h-3 w-3" /> Điền ví dụ vào ô JSON
                  </Button>
                  <p className="text-muted-foreground">Chi tiết đầy đủ: docs/plugin-development.md trong gói cài đặt.</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* input ẩn: .zip + .json */}
          <input
            ref={zipRef}
            type="file"
            accept=".zip,application/zip"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0]
              if (f) void installZip(f)
              e.target.value = ''
            }}
            aria-hidden
          />
          <input
            ref={fileRef}
            type="file"
            accept=".json,.wosplugin,application/json"
            className="hidden"
            onChange={(e) => {
              if (e.target.files?.[0]) onFile(e.target.files[0])
              e.target.value = ''
            }}
            aria-hidden
          />
        </>
      )}
    </div>
  )
}
