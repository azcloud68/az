'use client'

/**
 * MODULE: Weekly Work (Công Việc Tuần) — labo hoá việc test trong phòng thí nghiệm
 * Tab 1 "Tuần này": strip 7 ngày T2→CN + chi tiết ngày (thêm quy trình, tick, pass, prep, offline)
 *                   — việc hiển thị theo CÂY (bước lớn = nhóm tổng hợp, bước con tick được)
 * Tab 2 "Quy trình": template (Bước dạng outline nhiều cấp / Điều kiện / Xem trước)
 * Tab 3 "Timeline": dòng thời gian dọc cả tuần — từng ngày 1 node, cây việc, tick/pass/note, xập quy trình xong
 * Tab 4 "Thống kê": per-day trong khoảng chọn
 */
import { useCallback, useEffect, useMemo, useState } from 'react'
import { useRoute } from '@/core/client/route-context'
import { useWos } from '@/core/client/wos-store'
import { api } from '@/core/client/api'
import { bus } from '@/core/client/event-bus'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Progress } from '@/components/ui/progress'
import { useToast } from '@/hooks/use-toast'
import {
  ClipboardList, Loader2, Plus, Trash2, Pencil, ChevronUp, ChevronDown, ChevronLeft, ChevronRight,
  CheckCircle2, Circle, CircleSlash, FlaskConical, XCircle, CalendarDays, BarChart3, ListChecks,
  Sparkles, Info, ListTree, StickyNote, IndentIncrease, IndentDecrease, CornerDownRight,
} from 'lucide-react'
import {
  addDaysISO, fmtISODate, isISODate, parseISO, weekDates, weekStartISO,
  weekdayOfISO, fmtDM, fmtFullDate, toPosInt, AUTO_PASS_NOTE, buildTree,
  WEEKDAY_SHORT, WEEKDAY_FULL, type TreeNode,
} from '@/modules/weekly/lib'

// ---------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------
interface WStep { id: string; parentId?: string | null; name: string; lotCount: number; rowsPerLot: number; note?: string }
interface WPrep { id: string; name: string; offsetDays: number; detail: string }
interface WProcess {
  id: string
  name: string
  description: string
  color: string
  icon: string
  steps?: WStep[]
  preps?: WPrep[]
  _count?: { steps: number; preps: number }
}
interface WTask {
  id: string
  parentId?: string | null
  processId: string | null
  processName: string
  name: string
  lotCount: number | null
  rowsPerLot: number | null
  quantity: number | null
  isPrep: boolean
  prepRound: number
  status: string
  note: string
  order: number
}
interface WDay { id: string; date: string; offline: boolean; offlineNote: string; note: string }
interface DaySum { date: string; offline: boolean; total: number; done: number; passed: number; pending: number }
interface StatRow extends DaySum { offlineNote?: string; rate: number }
interface StatsSummary { days: number; offlineDays: number; total: number; done: number; passed: number; pending: number; rate: number }
/** Bước trong editor: dạng outline (depth) — cha = dòng ngay trên có depth nhỏ hơn */
interface StepDraft { tmpId: string; depth: number; name: string; lotCount: string; rowsPerLot: string; note: string }
interface PrepDraft { name: string; offsetDays: string; detail: string }
/** 1 ngày trong timeline (GET days?withTasks=1) */
interface TlDay extends DaySum { offlineNote?: string; note?: string; tasks: WTask[] }

const MODULE_COLOR = '#3b82f6'
const SWATCHES = ['#3b82f6', '#f97316', '#10b981', '#eab308', '#ec4899', '#8b5cf6', '#f43f5e', '#0891b2']
const EMOJIS = ['🧪', '🧫', '🔬', '🧬', '💊', '🌡️', '💧', '⚠️', '🥼', '📋']

/** Lý do pass nhanh — chip điền sẵn vào ô lý do (user vẫn sửa / tự nhập lý do khác) */
const PASS_REASON_CHIPS = ['Nghỉ làm', 'Thiếu mẫu', 'Thiếu hóa chất', 'Máy hỏng', 'Chờ việc khác', 'Quên làm']

const TODAY = () => fmtISODate(new Date())

// =====================================================================
// Outline helpers — soạn bước quy trình dạng cây (depth)
// =====================================================================
let stepTmpSeq = 0
function newStepDraft(depth: number): StepDraft {
  stepTmpSeq += 1
  return { tmpId: `s${stepTmpSeq}-${Date.now().toString(36)}`, depth, name: '', lotCount: '1', rowsPerLot: '1', note: '' }
}

/** hết subtree của dòng i (dòng i + mọi con cháu của nó) */
function subtreeEnd(rows: StepDraft[], i: number): number {
  let j = i + 1
  while (j < rows.length && rows[j].depth > rows[i].depth) j++
  return j
}

/** dòng i có phải bước lá (không có con) */
function isLeafAt(rows: StepDraft[], i: number): boolean {
  return i === rows.length - 1 || rows[i + 1].depth <= rows[i].depth
}

function canMoveStepUp(rows: StepDraft[], i: number): boolean {
  let k = i - 1
  while (k >= 0 && rows[k].depth > rows[i].depth) k--
  return k >= 0 && rows[k].depth === rows[i].depth
}
function canMoveStepDown(rows: StepDraft[], i: number): boolean {
  const end = subtreeEnd(rows, i)
  return end < rows.length && rows[end].depth === rows[i].depth
}

/** thêm bước con ngay dưới dòng i */
function addStepChildAt(rows: StepDraft[], i: number): StepDraft[] {
  const arr = [...rows]
  arr.splice(i + 1, 0, newStepDraft(rows[i].depth + 1))
  return arr
}

/** ⇥ làm bước con của dòng ngay trên (dời cả subtree) */
function indentStep(rows: StepDraft[], i: number): StepDraft[] {
  if (i <= 0) return rows
  const delta = rows[i - 1].depth + 1 - rows[i].depth
  if (delta <= 0) return rows // đã là con của dòng trên
  const end = subtreeEnd(rows, i)
  return rows.map((r, j) => (j >= i && j < end ? { ...r, depth: r.depth + delta } : r))
}

/** ⇤ thụt lùi 1 cấp (dời cả subtree) */
function outdentStep(rows: StepDraft[], i: number): StepDraft[] {
  if (rows[i].depth <= 0) return rows
  const end = subtreeEnd(rows, i)
  return rows.map((r, j) => (j >= i && j < end ? { ...r, depth: r.depth - 1 } : r))
}

/** dời dòng + subtree lên/xuống 1 vị trí anh em */
function moveStep(rows: StepDraft[], i: number, dir: 'up' | 'down'): StepDraft[] {
  const end = subtreeEnd(rows, i)
  if (dir === 'up') {
    if (!canMoveStepUp(rows, i)) return rows
    let k = i - 1
    while (k >= 0 && rows[k].depth > rows[i].depth) k--
    return [...rows.slice(0, k), ...rows.slice(i, end), ...rows.slice(k, i), ...rows.slice(end)]
  }
  if (!canMoveStepDown(rows, i)) return rows
  const end2 = subtreeEnd(rows, end)
  return [...rows.slice(0, i), ...rows.slice(end, end2), ...rows.slice(i, end), ...rows.slice(end2)]
}

/** xoá dòng + toàn bộ subtree */
function removeStep(rows: StepDraft[], i: number): StepDraft[] {
  const end = subtreeEnd(rows, i)
  return rows.filter((_, j) => j < i || j >= end)
}

/** outline → payload steps (phẳng kèm id/parentId tạm) cho API */
function stepsToPayload(rows: StepDraft[]) {
  const stack: string[] = []
  return rows.map((r) => {
    const d = Math.max(0, Math.min(r.depth, 4))
    stack.length = d
    stack[d] = r.tmpId
    return {
      id: r.tmpId,
      parentId: d > 0 ? stack[d - 1] || null : null,
      name: r.name,
      lotCount: r.lotCount,
      rowsPerLot: r.rowsPerLot,
      note: r.note,
    }
  })
}

/** steps từ API (phẳng kèm parentId) → outline draft */
function stepsFromProcess(steps: WStep[]): StepDraft[] {
  const depthById = new Map<string, number>()
  return (steps || []).map((s) => {
    const depth = s.parentId && depthById.has(s.parentId) ? depthById.get(s.parentId)! + 1 : 0
    depthById.set(s.id, depth)
    return {
      tmpId: s.id,
      depth,
      name: s.name,
      lotCount: String(s.lotCount),
      rowsPerLot: String(s.rowsPerLot),
      note: s.note || '',
    }
  })
}

/** thống kê nhanh 1 mảng steps: bao nhiêu bước lá / bao nhiêu nhóm / tổng hàng */
function stepStats(steps: WStep[]) {
  const ids = new Set(steps.map((s) => s.id))
  const groupIds = new Set(
    steps.map((s) => s.parentId).filter((p): p is string => !!p && ids.has(p)),
  )
  const leaves = steps.filter((s) => !groupIds.has(s.id))
  return {
    leaves,
    leafCount: leaves.length,
    groupCount: groupIds.size,
    totalRows: leaves.reduce((sum, s) => sum + s.lotCount * s.rowsPerLot, 0),
  }
}

/** đếm việc xong trong 1 mảng (dùng cho nhóm + tiến độ) */
function countSettled(tasks: WTask[]): number {
  return tasks.filter((t) => t.status === 'done' || t.status === 'passed').length
}

// =====================================================================
// PAGE
// =====================================================================
export default function WeeklyPage() {
  const { emit } = useWos()
  const { route, navigate } = useRoute()
  const { toast } = useToast()

  const [tab, setTab] = useState('week')
  const [weekStart, setWeekStart] = useState(() => weekStartISO(TODAY()))
  const [selectedDate, setSelectedDate] = useState(() => TODAY())
  const [processes, setProcesses] = useState<WProcess[] | null>(null)

  // Ngày đang xem chi tiết
  const [dayDetail, setDayDetail] = useState<{ day: WDay | null; tasks: WTask[] } | null>(null)
  const [dayLoading, setDayLoading] = useState(false)
  const [daySums, setDaySums] = useState<DaySum[]>([])

  // Form trong panel ngày
  const [selProcessId, setSelProcessId] = useState('')
  const [lotOverride, setLotOverride] = useState('')
  const [manualTask, setManualTask] = useState('')
  const [saving, setSaving] = useState(false)

  // Dialog pass việc
  const [passTask, setPassTask] = useState<WTask | null>(null)
  const [passReason, setPassReason] = useState('')
  // Dialog sửa việc
  const [editTask, setEditTask] = useState<WTask | null>(null)
  const [editDraft, setEditDraft] = useState({ name: '', note: '', quantity: '' })
  // Dialog offline
  const [offlineAsk, setOfflineAsk] = useState(false)
  const [offlineReason, setOfflineReason] = useState('')
  // Dialog thêm việc con (việc mẹ = nhóm HOẶC lá — đều làm mẹ được; date = ngày chứa việc mẹ)
  const [addChildTask, setAddChildTask] = useState<WTask | null>(null)
  const [addChildName, setAddChildName] = useState('')
  const [addChildDate, setAddChildDate] = useState('')
  const [addChildSaving, setAddChildSaving] = useState(false)

  // Editor quy trình
  const [editorOpen, setEditorOpen] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editorTab, setEditorTab] = useState('steps')
  const [previewDate, setPreviewDate] = useState('')
  const [draft, setDraft] = useState<{ name: string; description: string; color: string; icon: string; steps: StepDraft[]; preps: PrepDraft[] }>({
    name: '', description: '', color: MODULE_COLOR, icon: '🧪', steps: [], preps: [],
  })
  const [editorLoading, setEditorLoading] = useState(false)

  // Timeline (tab 3)
  const [tlDays, setTlDays] = useState<TlDay[] | null>(null)
  const [tlExpanded, setTlExpanded] = useState<Set<string>>(new Set())

  // Thống kê
  const [statsFrom, setStatsFrom] = useState(() => weekStartISO(TODAY()))
  const [statsTo, setStatsTo] = useState(() => addDaysISO(weekStartISO(TODAY()), 6))
  const [stats, setStats] = useState<{ days: StatRow[]; summary: StatsSummary } | null>(null)

  // ------------------------------------------------------------------
  // Loaders
  // ------------------------------------------------------------------
  const loadProcesses = useCallback(async () => {
    try {
      const data = await api<{ processes: WProcess[] }>('/api/modules/weekly/processes')
      setProcesses(data.processes)
    } catch {
      setProcesses([])
    }
  }, [])

  const loadWeek = useCallback(async () => {
    try {
      const data = await api<{ days: DaySum[] }>(`/api/modules/weekly/days?from=${weekStart}&to=${addDaysISO(weekStart, 6)}`)
      setDaySums(data.days)
    } catch {
      setDaySums([])
    }
  }, [weekStart])

  const loadDay = useCallback(async (silent = false) => {
    if (!silent) setDayLoading(true)
    try {
      const data = await api<{ day: WDay | null; tasks: WTask[] }>(`/api/modules/weekly/days/${selectedDate}`)
      setDayDetail(data)
    } catch {
      setDayDetail({ day: null, tasks: [] })
    } finally {
      if (!silent) setDayLoading(false)
    }
  }, [selectedDate])

  const loadTimeline = useCallback(async () => {
    try {
      const data = await api<{ days: TlDay[] }>(
        `/api/modules/weekly/days?from=${weekStart}&to=${addDaysISO(weekStart, 6)}&withTasks=1`,
      )
      setTlDays(data.days)
    } catch {
      setTlDays([])
    }
  }, [weekStart])

  const loadStats = useCallback(async () => {
    if (!isISODate(statsFrom) || !isISODate(statsTo)) return
    try {
      const data = await api<{ days: StatRow[]; summary: StatsSummary }>(
        `/api/modules/weekly/stats?from=${statsFrom}&to=${statsTo}`,
      )
      setStats(data)
    } catch {
      setStats(null)
    }
  }, [statsFrom, statsTo])

  useEffect(() => {
    loadProcesses()
    loadWeek()
    loadDay()
    // Tự refresh khi có thay đổi từ module weekly (kể từ widget/cửa sổ khác)
    return bus.onAny((ev) => {
      if (ev.module !== 'weekly') return
      loadProcesses()
      loadWeek()
      loadDay(true)
    })
  }, [loadProcesses, loadWeek, loadDay])

  useEffect(() => {
    if (tab === 'stats') loadStats()
  }, [tab, loadStats])

  // Tab thống kê đang mở → cũng tự refresh khi có thay đổi
  useEffect(() => {
    if (tab !== 'stats') return
    return bus.onAny((ev) => {
      if (ev.module === 'weekly') loadStats()
    })
  }, [tab, loadStats])

  // Timeline: load khi mở tab / đổi tuần + tự refresh khi có thay đổi
  useEffect(() => {
    if (tab === 'timeline') loadTimeline()
  }, [tab, loadTimeline])
  useEffect(() => {
    if (tab !== 'timeline') return
    return bus.onAny((ev) => {
      if (ev.module === 'weekly') loadTimeline()
    })
  }, [tab, loadTimeline])

  // Deep-link 'weekly:YYYY-MM-DD' → mở đúng ngày đó
  useEffect(() => {
    if (route.startsWith('weekly:')) {
      const d = route.slice('weekly:'.length)
      if (isISODate(d)) {
        setTab('week')
        setSelectedDate(d)
        setWeekStart(weekStartISO(d))
        navigate('weekly')
      }
    }
  }, [route, navigate])

  // ------------------------------------------------------------------
  // Actions — ngày & việc (dùng chung tab Tuần này + Timeline)
  // ------------------------------------------------------------------
  async function addProcessToDay() {
    if (!selProcessId || !isISODate(selectedDate)) return
    setSaving(true)
    try {
      const data = await api<{ addedSteps: number; addedGroups?: number; preps: { date: string; name: string }[] }>('/api/modules/weekly/days', {
        method: 'POST',
        body: {
          action: 'add-process',
          date: selectedDate,
          processId: selProcessId,
          ...(lotOverride ? { lotCount: Number(lotOverride) } : {}),
        },
      })
      toast({
        title: 'Đã thêm quy trình vào ngày',
        description: `${data.addedSteps} việc${data.addedGroups ? ` (${data.addedGroups} nhóm tổng hợp)` : ''}${data.preps.length ? ` · ${data.preps.length} việc chuẩn bị (lùi ngày)` : ''}`,
      })
      setLotOverride('')
      emit('weekly.day.updated', 'weekly', { date: selectedDate })
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : 'Không thêm được', variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  async function addManualTask() {
    const name = manualTask.trim()
    if (!name) return
    setSaving(true)
    try {
      await api('/api/modules/weekly/days', { method: 'POST', body: { action: 'add-task', date: selectedDate, name } })
      setManualTask('')
      emit('weekly.day.updated', 'weekly', { date: selectedDate })
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : 'Không thêm được', variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  /**
   * Mở dialog thêm việc con — date là NGÀY CHỨA VIỆC MẸ (API validate cùng ngày):
   * tab Tuần này → selectedDate; tab Timeline → ngày của node trong tuần đang xem.
   */
  function openAddChild(t: WTask, date: string) {
    setAddChildTask(t)
    setAddChildName('')
    setAddChildDate(date)
  }

  async function submitAddChild() {
    if (!addChildTask) return
    const name = addChildName.trim()
    if (!name || !isISODate(addChildDate)) return
    setAddChildSaving(true)
    try {
      const data = await api<{ ok: boolean; parentName: string | null }>('/api/modules/weekly/days', {
        method: 'POST',
        body: { action: 'add-task', date: addChildDate, name, parentId: addChildTask.id },
      })
      toast({ title: 'Đã thêm việc con', description: data.parentName ? `${name} → ${data.parentName}` : name })
      setAddChildTask(null)
      setAddChildName('')
      emit('weekly.day.updated', 'weekly', { date: addChildDate, child: name })
      // Reload dữ liệu tab đang mở (bus listener cũng tự chạy — gọi trực tiếp cho chắc)
      if (tab === 'timeline') loadTimeline()
      else {
        loadDay(true)
        loadWeek()
      }
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : 'Không thêm được việc con', variant: 'destructive' })
    } finally {
      setAddChildSaving(false)
    }
  }

  async function tickTask(t: WTask) {
    const next = t.status === 'done' ? 'pending' : 'done'
    try {
      await api(`/api/modules/weekly/tasks/${t.id}`, { method: 'PATCH', body: { status: next } })
      if (next === 'done') emit('weekly.task.completed', 'weekly', { title: t.name })
      else emit('weekly.day.updated', 'weekly', {})
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  function openPass(t: WTask) {
    setPassTask(t)
    setPassReason(t.note && t.note !== AUTO_PASS_NOTE ? t.note : '')
  }

  async function submitPass() {
    if (!passTask) return
    const reason = passReason.trim()
    if (!reason) return
    try {
      await api(`/api/modules/weekly/tasks/${passTask.id}`, { method: 'PATCH', body: { status: 'passed', note: reason } })
      emit('weekly.task.passed', 'weekly', { title: passTask.name })
      setPassTask(null)
      setPassReason('')
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  function openEdit(t: WTask) {
    setEditTask(t)
    setEditDraft({ name: t.name, note: t.note, quantity: t.quantity != null ? String(t.quantity) : '' })
  }

  async function saveEditTask() {
    if (!editTask) return
    try {
      const body: Record<string, unknown> = {
        name: editDraft.name.trim() || editTask.name,
        note: editDraft.note,
      }
      if (editDraft.quantity !== '') body.quantity = Number(editDraft.quantity)
      await api(`/api/modules/weekly/tasks/${editTask.id}`, { method: 'PATCH', body })
      setEditTask(null)
      emit('weekly.day.updated', 'weekly', {})
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  async function deleteTask(t: WTask) {
    if (!confirm(`Xoá việc "${t.name}"?`)) return
    try {
      await api(`/api/modules/weekly/tasks/${t.id}`, { method: 'DELETE' })
      emit('weekly.day.updated', 'weekly', {})
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  async function deleteGroupTask(t: WTask, childCount: number) {
    if (!confirm(`Xoá việc nhóm "${t.name}" cùng ${childCount} việc con?`)) return
    try {
      await api(`/api/modules/weekly/tasks/${t.id}`, { method: 'DELETE' })
      emit('weekly.day.updated', 'weekly', {})
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  async function reorder(t: WTask, direction: 'up' | 'down') {
    try {
      await api('/api/modules/weekly/days', { method: 'POST', body: { action: 'reorder', taskId: t.id, direction } })
      emit('weekly.day.updated', 'weekly', {})
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  async function addPrepRound(t: WTask, date: string) {
    try {
      await api('/api/modules/weekly/days', {
        method: 'POST',
        body: { action: 'add-prep', date, taskId: t.id },
      })
      toast({ title: 'Đã thêm lần pha', description: `${t.name} — lần ${t.prepRound + 1}` })
      emit('weekly.day.updated', 'weekly', { date })
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  async function toggleOffline(next: boolean) {
    if (!isISODate(selectedDate)) return
    if (next) {
      setOfflineReason(dayDetail?.day?.offlineNote || '')
      setOfflineAsk(true)
      return
    }
    try {
      await api(`/api/modules/weekly/days/${selectedDate}`, { method: 'PATCH', body: { offline: false } })
      emit('weekly.day.offline', 'weekly', { title: selectedDate, offline: false })
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  async function submitOffline() {
    try {
      await api(`/api/modules/weekly/days/${selectedDate}`, {
        method: 'PATCH',
        body: { offline: true, offlineNote: offlineReason.trim() },
      })
      emit('weekly.day.offline', 'weekly', { title: selectedDate, offline: true })
      setOfflineAsk(false)
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  async function saveDayNote(note: string) {
    if (!dayDetail?.day || dayDetail.day.note === note) return
    try {
      await api(`/api/modules/weekly/days/${selectedDate}`, { method: 'PATCH', body: { note } })
      emit('weekly.day.updated', 'weekly', { date: selectedDate })
    } catch {
      /* im lặng — lưu ghi chú ngày không quan trọng */
    }
  }

  async function deleteDay() {
    if (!confirm(`Xoá toàn bộ dữ liệu ngày ${fmtDM(selectedDate)} (gồm mọi việc)?`)) return
    try {
      await api(`/api/modules/weekly/days/${selectedDate}`, { method: 'DELETE' })
      emit('weekly.day.updated', 'weekly', { date: selectedDate, deleted: true })
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  // ------------------------------------------------------------------
  // Actions — quy trình
  // ------------------------------------------------------------------
  function openEditor(p: WProcess | null) {
    setEditingId(p?.id || null)
    setEditorTab('steps')
    setEditorOpen(true)
    setPreviewDate(selectedDate || TODAY())
    if (!p) {
      setDraft({ name: '', description: '', color: MODULE_COLOR, icon: '🧪', steps: [{ ...newStepDraft(0) }], preps: [] })
      return
    }
    setEditorLoading(true)
    api<{ process: WProcess & { steps: WStep[]; preps: WPrep[] } }>(`/api/modules/weekly/processes/${p.id}`)
      .then((data) => {
        const pr = data.process
        setDraft({
          name: pr.name,
          description: pr.description,
          color: pr.color,
          icon: pr.icon,
          steps: stepsFromProcess(pr.steps || []),
          preps: (pr.preps || []).map((pp) => ({ name: pp.name, offsetDays: String(pp.offsetDays), detail: pp.detail })),
        })
      })
      .catch(() => toast({ title: 'Không tải được quy trình', variant: 'destructive' }))
      .finally(() => setEditorLoading(false))
  }

  async function saveProcess() {
    const name = draft.name.trim()
    if (!name) return
    setSaving(true)
    try {
      const body = {
        name,
        description: draft.description,
        color: draft.color,
        icon: draft.icon,
        steps: stepsToPayload(draft.steps),
        preps: draft.preps.map((p) => ({ name: p.name, offsetDays: p.offsetDays, detail: p.detail })),
      }
      if (editingId) {
        await api(`/api/modules/weekly/processes/${editingId}`, { method: 'PATCH', body })
        emit('weekly.process.updated', 'weekly', { name })
      } else {
        await api('/api/modules/weekly/processes', { method: 'POST', body })
        emit('weekly.process.created', 'weekly', { name })
      }
      setEditorOpen(false)
      toast({ title: editingId ? 'Đã cập nhật quy trình' : 'Đã tạo quy trình', description: name })
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : 'Không lưu được', variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  async function deleteProcess(p: WProcess) {
    if (!confirm(`Xoá quy trình "${p.name}"? Các việc đã sinh ở các ngày vẫn giữ nguyên.`)) return
    try {
      await api(`/api/modules/weekly/processes/${p.id}`, { method: 'DELETE' })
      emit('weekly.process.deleted', 'weekly', { name: p.name })
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  // ------------------------------------------------------------------
  // Derives
  // ------------------------------------------------------------------
  const weekCells = useMemo(
    () =>
      weekDates(weekStart).map((date) => {
        const s = daySums.find((x) => x.date === date)
        return {
          date,
          total: s?.total || 0,
          done: s?.done || 0,
          passed: s?.passed || 0,
          pending: s?.pending || 0,
          offline: s?.offline || false,
        }
      }),
    [weekStart, daySums],
  )

  const day = dayDetail?.day || null
  const tasks = dayDetail?.tasks || []
  const dayCounts = useMemo(() => {
    const done = tasks.filter((t) => t.status === 'done').length
    const passed = tasks.filter((t) => t.status === 'passed').length
    return { total: tasks.length, done, passed, pending: tasks.length - done - passed }
  }, [tasks])

  /** cây việc trong ngày (cha = nhóm tổng hợp) — theo order */
  const dayTree = useMemo(() => buildTree(tasks), [tasks])
  /** map task → có thể lên/xuống trong nhóm anh em */
  const siblingFlags = useMemo(() => {
    const byId = new Map(tasks.map((t) => [t.id, t]))
    const effParent = (t: WTask) => (t.parentId && byId.has(t.parentId) ? t.parentId : null)
    const groups = new Map<string | null, WTask[]>()
    for (const t of tasks) {
      const pid = effParent(t)
      groups.set(pid, [...(groups.get(pid) || []), t])
    }
    const flags = new Map<string, { canUp: boolean; canDown: boolean }>()
    for (const sibs of groups.values()) {
      sibs.forEach((t, i) => flags.set(t.id, { canUp: i > 0, canDown: i < sibs.length - 1 }))
    }
    return flags
  }, [tasks])

  const taskGroups = useMemo(() => {
    const map = new Map<string, { key: string; name: string; color: string; tasks: WTask[] }>()
    for (const t of tasks) {
      const key = t.processId || '_manual'
      if (!map.has(key)) {
        const proc = processes?.find((p) => p.id === t.processId)
        map.set(key, {
          key,
          name: t.processId ? t.processName || proc?.name || 'Quy trình' : 'Việc tự thêm',
          color: t.processId ? proc?.color || MODULE_COLOR : '#94a3b8',
          tasks: [],
        })
      }
      map.get(key)!.tasks.push(t)
    }
    return [...map.values()]
  }, [tasks, processes])

  const selProcess = processes?.find((p) => p.id === selProcessId)
  const isCurrentWeek = weekStart === weekStartISO(TODAY())

  function shiftWeek(delta: number) {
    const next = addDaysISO(weekStart, delta * 7)
    setWeekStart(next)
    // giữ ngày đang chọn sang tuần tương ứng
    const offset = Math.min(Math.max(Math.round((parseISO(selectedDate).getTime() - parseISO(weekStart).getTime()) / 86400000), 0), 6)
    setSelectedDate(addDaysISO(next, offset))
  }

  function toggleTlExpand(key: string) {
    setTlExpanded((prev) => {
      const next = new Set(prev)
      if (next.has(key)) next.delete(key)
      else next.add(key)
      return next
    })
  }

  function jumpToDay(date: string) {
    setTab('week')
    setSelectedDate(date)
    setWeekStart(weekStartISO(date))
  }

  // =================================================================
  return (
    <div className="space-y-4">
      {/* Header module */}
      <div className="flex flex-wrap items-center gap-3">
        <h1 className="flex items-center gap-2.5 text-xl font-bold">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl text-white" style={{ background: MODULE_COLOR }}>
            <ClipboardList className="h-5 w-5" />
          </span>
          Công Việc Tuần
          {processes && <Badge variant="secondary" className="font-normal">{processes.length} quy trình</Badge>}
        </h1>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="week"><CalendarDays className="size-4" /> Tuần này</TabsTrigger>
          <TabsTrigger value="processes"><ListChecks className="size-4" /> Quy trình</TabsTrigger>
          <TabsTrigger value="timeline"><ListTree className="size-4" /> Timeline</TabsTrigger>
          <TabsTrigger value="stats"><BarChart3 className="size-4" /> Thống kê</TabsTrigger>
        </TabsList>

        {/* ============================ TAB: TUẦN NÀY ============================ */}
        <TabsContent value="week" className="mt-3 space-y-4">
          {/* Thanh điều hướng tuần */}
          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => shiftWeek(-1)} aria-label="Tuần trước">
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <div className="min-w-[150px] text-center text-sm font-medium">
              Tuần {fmtDM(weekStart)} → {fmtDM(addDaysISO(weekStart, 6))}
            </div>
            <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => shiftWeek(1)} aria-label="Tuần sau">
              <ChevronRight className="h-4 w-4" />
            </Button>
            {!isCurrentWeek && (
              <Button variant="ghost" size="sm" className="h-8" onClick={() => { setWeekStart(weekStartISO(TODAY())); setSelectedDate(TODAY()) }}>
                Về hôm nay
              </Button>
            )}
          </div>

          {/* Strip 7 ngày T2 → CN */}
          <div className="flex gap-2 overflow-x-auto pb-1 sm:grid sm:grid-cols-7 sm:overflow-visible" role="tablist" aria-label="Các ngày trong tuần">
            {weekCells.map((c) => {
              const isToday = c.date === TODAY()
              const isSel = c.date === selectedDate
              const doneRatio = c.total ? Math.round(((c.done + c.passed) / c.total) * 100) : 0
              return (
                <button
                  key={c.date}
                  role="tab"
                  aria-selected={isSel}
                  onClick={() => setSelectedDate(c.date)}
                  className={`wos-glass min-w-[86px] flex-1 rounded-xl p-2.5 text-left transition-all hover:-translate-y-0.5 hover:shadow-md sm:min-w-0 ${
                    isSel ? 'ring-2 ring-primary' : isToday ? 'ring-1 ring-primary/50' : ''
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-medium text-muted-foreground">{WEEKDAY_SHORT[weekdayOfISO(c.date)]}</span>
                    <span className={`text-sm font-semibold tabular-nums ${isToday ? 'text-primary' : ''}`}>{fmtDM(c.date)}</span>
                  </div>
                  <div className="mt-1.5 flex items-center gap-1.5">
                    {c.offline ? (
                      <span className="rounded-full bg-amber-500/15 px-2 py-0.5 text-[10px] font-semibold text-amber-600 dark:text-amber-400">Nghỉ</span>
                    ) : (
                      <span className="text-[10px] text-muted-foreground">{c.total ? `${c.done + c.passed}/${c.total} việc` : '— việc'}</span>
                    )}
                  </div>
                  <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-muted">
                    <div
                      className={`h-full rounded-full transition-all ${c.offline ? 'bg-amber-400' : doneRatio === 100 && c.total ? 'bg-emerald-500' : 'bg-primary'}`}
                      style={{ width: `${c.offline ? 100 : doneRatio}%` }}
                    />
                  </div>
                </button>
              )
            })}
          </div>

          {/* Khung chi tiết ngày */}
          <Card className="wos-glass border-0">
            <CardHeader className="flex-row flex-wrap items-center justify-between gap-3 pb-3">
              <div className="min-w-0">
                <CardTitle className="text-base">{fmtFullDate(selectedDate)}</CardTitle>
                <div className="mt-1 flex flex-wrap items-center gap-1.5">
                  <Badge variant="secondary" className="font-normal">{dayCounts.total} việc</Badge>
                  {dayCounts.done > 0 && <Badge className="bg-emerald-500 hover:bg-emerald-500">{dayCounts.done} xong</Badge>}
                  {dayCounts.passed > 0 && <Badge className="bg-amber-500 hover:bg-amber-500">{dayCounts.passed} pass</Badge>}
                  {dayCounts.pending > 0 && <Badge variant="outline">{dayCounts.pending} chờ</Badge>}
                </div>
              </div>
              <div className="flex items-center gap-2.5">
                <label className="flex cursor-pointer items-center gap-2 text-sm font-medium">
                  <Switch checked={!!day?.offline} onCheckedChange={(v) => toggleOffline(v)} aria-label="Đánh dấu ngày nghỉ" />
                  Nghỉ làm
                </label>
                {day && dayCounts.total > 0 && (
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-destructive" onClick={deleteDay} aria-label="Xoá ngày" title="Xoá ngày + mọi việc">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Offline banner */}
              {day?.offline && (
                <div className="rounded-xl border border-amber-500/40 bg-amber-500/10 px-4 py-3 text-sm">
                  <p className="font-medium text-amber-700 dark:text-amber-400">Ngày nghỉ — mọi việc còn lại đã tự động pass</p>
                  {day.offlineNote && <p className="mt-0.5 text-xs text-amber-700/80 dark:text-amber-400/80">Lý do: {day.offlineNote}</p>}
                </div>
              )}

              {/* Thêm quy trình vào ngày */}
              <div className="flex flex-wrap items-center gap-2 rounded-xl bg-muted/40 p-3">
                <Select value={selProcessId} onValueChange={setSelProcessId}>
                  <SelectTrigger className="h-9 min-w-[210px] flex-1" size="sm" aria-label="Chọn quy trình">
                    <SelectValue placeholder="Chọn quy trình thêm vào ngày…" />
                  </SelectTrigger>
                  <SelectContent>
                    {(processes || []).map((p) => (
                      <SelectItem key={p.id} value={p.id}>
                        <span className="mr-1.5">{p.icon}</span>
                        {p.name}
                        <span className="ml-1.5 text-xs text-muted-foreground">{p._count?.steps ?? p.steps?.length ?? 0} bước</span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Input
                  type="number"
                  min={1}
                  value={lotOverride}
                  onChange={(e) => setLotOverride(e.target.value)}
                  placeholder="Số lot (mặc định)"
                  className="h-9 w-[150px]"
                  aria-label="Ghi đè số lot"
                />
                <Button size="sm" className="h-9 gap-1.5" disabled={!selProcessId || saving} onClick={addProcessToDay}>
                  <Plus className="h-4 w-4" /> Thêm vào ngày
                </Button>
              </div>
              {/* Gợi ý việc sẽ sinh khi thêm quy trình */}
              {selProcess && (
                <p className="flex items-start gap-1.5 px-1 text-xs text-muted-foreground">
                  <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                  <span>
                    {(() => {
                      const st = stepStats(selProcess.steps || [])
                      return (
                        <>
                          Sẽ sinh <b>{st.leafCount} việc bước</b>
                          {st.groupCount > 0 && <> + <b>{st.groupCount} nhóm tổng hợp</b></>}
                        </>
                      )
                    })()}
                    {selProcess.preps?.some((p) => p.offsetDays > 0) && (
                      <>
                        {' + '}<b>{selProcess.preps!.filter((p) => p.offsetDays > 0).length} việc chuẩn bị</b> vào{' '}
                        {selProcess.preps!.filter((p) => p.offsetDays > 0).map((p) => `${p.name} (${fmtDM(addDaysISO(selectedDate, -p.offsetDays))})`).join(', ')}
                      </>
                    )}
                    {lotOverride && Number(lotOverride) > 0 && ` · dùng ${lotOverride} lot cho mọi bước`}
                  </span>
                </p>
              )}

              {/* Danh sách việc nhóm theo quy trình — hiển thị theo CÂY */}
              {dayLoading ? (
                <div className="flex h-28 items-center justify-center">
                  <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                </div>
              ) : tasks.length === 0 ? (
                <div className="flex flex-col items-center gap-2 rounded-xl border border-dashed py-10 text-center text-muted-foreground">
                  <Sparkles className="h-8 w-8 opacity-30" />
                  <p className="text-sm font-medium">Chưa có việc nào trong ngày này</p>
                  <p className="max-w-sm text-xs">Chọn quy trình phía trên rồi bấm <b>Thêm vào ngày</b> để sinh việc, hoặc thêm việc tay ở dưới.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {taskGroups.map((g) => {
                    const gTree = buildTree(g.tasks)
                    return (
                      <div key={g.key} className="rounded-xl border border-border/60">
                        <div className="flex items-center gap-2 border-b border-border/60 px-3 py-2">
                          <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: g.color }} />
                          <span className="min-w-0 truncate text-sm font-semibold">{g.name}</span>
                          <Badge variant="secondary" className="ml-auto font-normal">{g.tasks.length} việc</Badge>
                        </div>
                        <div className="divide-y divide-border/40">
                          {gTree.map((node) => (
                            <TaskTreeNode
                              key={node.data.id}
                              node={node}
                              flags={siblingFlags}
                              onTick={tickTask}
                              onPass={openPass}
                              onEdit={openEdit}
                              onDelete={deleteTask}
                              onDeleteGroup={deleteGroupTask}
                              onReorder={reorder}
                              onAddRound={(t) => addPrepRound(t, selectedDate)}
                              onAddChild={(t) => openAddChild(t, selectedDate)}
                            />
                          ))}
                        </div>
                      </div>
                    )
                  })}
                </div>
              )}

              {/* Thêm việc tay + ghi chú ngày */}
              <div className="flex flex-wrap items-center gap-2">
                <Input
                  value={manualTask}
                  onChange={(e) => setManualTask(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') addManualTask() }}
                  placeholder="Thêm việc tay cho ngày này…"
                  className="h-9 min-w-[200px] flex-1"
                />
                <Button size="sm" variant="outline" className="h-9 gap-1.5" disabled={!manualTask.trim() || saving} onClick={addManualTask}>
                  <Plus className="h-4 w-4" /> Thêm việc
                </Button>
              </div>
              {day && (
                <div className="flex items-center gap-2">
                  <Input
                    key={day.id + day.note}
                    defaultValue={day.note}
                    onBlur={(e) => saveDayNote(e.target.value)}
                    placeholder="Ghi chú cả ngày (không bắt buộc)…"
                    className="h-8 flex-1 text-sm"
                  />
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ============================ TAB: QUY TRÌNH ============================ */}
        <TabsContent value="processes" className="mt-3 space-y-4">
          <div className="flex items-center gap-2">
            <p className="text-sm text-muted-foreground">Quy trình = template cài sẵn: các Bước test (bước lớn chứa bước con) + Điều kiện chuẩn bị.</p>
            <Button size="sm" className="ml-auto h-9 gap-1.5" onClick={() => openEditor(null)}>
              <Plus className="h-4 w-4" /> Quy trình mới
            </Button>
          </div>

          {processes === null ? (
            <div className="flex h-40 items-center justify-center">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : processes.length === 0 ? (
            <div className="wos-glass flex flex-col items-center gap-2 rounded-2xl py-14 text-muted-foreground">
              <ListChecks className="h-10 w-10 opacity-30" />
              <p className="text-sm font-medium">Chưa có quy trình nào</p>
              <p className="max-w-md text-center text-xs">
                Tạo quy trình đầu tiên, ví dụ <b>&ldquo;Test Albumin SC&rdquo;</b>: các bước (Sắc ký chuẩn, Sắc ký mẫu…) với số lot × số hàng/lot,
                và điều kiện chuẩn bị như <b>&ldquo;Pha hóa chất trước 1 ngày&rdquo;</b>.
              </p>
              <Button size="sm" className="mt-2 gap-1.5" onClick={() => openEditor(null)}>
                <Plus className="h-4 w-4" /> Tạo quy trình
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
              {processes.map((p) => {
                const steps = p.steps || []
                const preps = p.preps || []
                const st = stepStats(steps)
                const depthById = new Map<string, number>()
                return (
                  <Card key={p.id} className="wos-glass cursor-pointer border-0 transition-all hover:-translate-y-0.5 hover:shadow-lg" onClick={() => openEditor(p)}>
                    <CardHeader className="pb-2">
                      <div className="flex items-start gap-3">
                        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-xl" style={{ background: `${p.color}22` }}>
                          {p.icon}
                        </div>
                        <div className="min-w-0 flex-1">
                          <CardTitle className="truncate text-base">{p.name}</CardTitle>
                          <div className="mt-1 flex flex-wrap gap-1.5 text-[11px] text-muted-foreground">
                            <span className="rounded-full bg-muted/70 px-2 py-0.5 font-medium">{st.leafCount} việc</span>
                            {st.groupCount > 0 && <span className="rounded-full bg-muted/70 px-2 py-0.5 font-medium">{st.groupCount} nhóm</span>}
                            <span className="rounded-full bg-muted/70 px-2 py-0.5 font-medium">{preps.length} điều kiện</span>
                            {st.totalRows > 0 && <span className="rounded-full bg-muted/70 px-2 py-0.5 font-medium">{st.totalRows} hàng/lần chạy</span>}
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 shrink-0 text-muted-foreground hover:text-destructive"
                          onClick={(e) => { e.stopPropagation(); deleteProcess(p) }}
                          aria-label={`Xoá quy trình ${p.name}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent>
                      {p.description ? (
                        <p className="line-clamp-2 text-xs text-muted-foreground">{p.description}</p>
                      ) : (
                        <p className="text-xs italic text-muted-foreground/60">Chưa có mô tả</p>
                      )}
                      {steps.length > 0 && (
                        <div className="mt-2 space-y-1">
                          {steps.slice(0, 4).map((s) => {
                            const depth = s.parentId && depthById.has(s.parentId) ? depthById.get(s.parentId)! + 1 : 0
                            depthById.set(s.id, depth)
                            const isGroup = steps.some((x) => x.parentId === s.id)
                            return (
                              <div
                                key={s.id}
                                className={`flex items-center justify-between rounded-lg px-2.5 py-1 text-xs ${depth > 0 ? 'bg-muted/30' : 'bg-muted/50'}`}
                                style={{ marginLeft: depth * 16 }}
                              >
                                <span className={`min-w-0 truncate ${isGroup ? 'font-semibold' : ''}`}>
                                  {depth > 0 && <CornerDownRight className="mr-1 inline h-3 w-3 text-muted-foreground" />}
                                  {s.name}
                                </span>
                                {!isGroup && (
                                  <span className="ml-2 shrink-0 tabular-nums text-muted-foreground">{s.lotCount}×{s.rowsPerLot}</span>
                                )}
                              </div>
                            )
                          })}
                          {steps.length > 4 && <p className="pl-1 text-[11px] text-muted-foreground">+{steps.length - 4} bước nữa…</p>}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          )}
        </TabsContent>

        {/* ============================ TAB: TIMELINE ============================ */}
        <TabsContent value="timeline" className="mt-3 space-y-4">
          {/* Điều hướng tuần */}
          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setWeekStart(addDaysISO(weekStart, -7))} aria-label="Tuần trước">
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <div className="min-w-[150px] text-center text-sm font-medium">
              Tuần {fmtDM(weekStart)} → {fmtDM(addDaysISO(weekStart, 6))}
            </div>
            <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setWeekStart(addDaysISO(weekStart, 7))} aria-label="Tuần sau">
              <ChevronRight className="h-4 w-4" />
            </Button>
            {!isCurrentWeek && (
              <Button variant="ghost" size="sm" className="h-8" onClick={() => setWeekStart(weekStartISO(TODAY()))}>
                Về hôm nay
              </Button>
            )}
          </div>

          {tlDays === null ? (
            <div className="flex h-40 items-center justify-center">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <div className="relative">
              {weekDates(weekStart).map((date) => {
                const d = tlDays.find((x) => x.date === date)
                const dayTasks = d?.tasks || []
                const done = d?.done || 0
                const passed = d?.passed || 0
                const total = d?.total || dayTasks.length
                const isToday = date === TODAY()
                const rate = total ? Math.round(((done + passed) / total) * 100) : 0

                // nhóm theo quy trình (việc chính) — giữ thứ tự xuất hiện
                const procSections: { key: string; processId: string; name: string; color: string; tasks: WTask[] }[] = []
                for (const t of dayTasks) {
                  if (t.isPrep || !t.processId) continue
                  let sec = procSections.find((s) => s.processId === t.processId)
                  if (!sec) {
                    const proc = processes?.find((p) => p.id === t.processId)
                    sec = {
                      key: `${date}:${t.processId}`,
                      processId: t.processId,
                      name: t.processName || proc?.name || 'Quy trình',
                      color: proc?.color || MODULE_COLOR,
                      tasks: [],
                    }
                    procSections.push(sec)
                  }
                  sec.tasks.push(t)
                }
                const extraTasks = dayTasks.filter((t) => t.isPrep || !t.processId)

                return (
                  <div key={date} className="flex gap-3">
                    {/* đường ray timeline */}
                    <div className="flex w-10 flex-col items-center pt-1.5" aria-hidden="true">
                      <span
                        className={`mt-1 h-3.5 w-3.5 shrink-0 rounded-full border-2 ${
                          d?.offline
                            ? 'border-amber-500 bg-amber-400'
                            : total > 0 && rate === 100
                              ? 'border-emerald-500 bg-emerald-400'
                              : isToday
                                ? 'border-primary bg-primary'
                                : total > 0
                                  ? 'border-primary/60 bg-background'
                                  : 'border-border bg-background'
                        }`}
                      />
                      <span className="w-px flex-1 bg-border/70" />
                    </div>

                    {/* nội dung ngày */}
                    <div className="min-w-0 flex-1 pb-6">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-sm font-semibold">
                          {WEEKDAY_FULL[weekdayOfISO(date)]} <span className="tabular-nums">{fmtDM(date)}</span>
                        </span>
                        {d?.offline ? (
                          <span className="rounded-full bg-amber-500/15 px-2 py-0.5 text-[10px] font-semibold text-amber-600 dark:text-amber-400">Nghỉ</span>
                        ) : total > 0 ? (
                          <span className="text-[11px] text-muted-foreground tabular-nums">{done + passed}/{total} việc</span>
                        ) : (
                          <span className="text-[11px] text-muted-foreground/60">— việc</span>
                        )}
                        {total > 0 && !d?.offline && (
                          <div className="flex min-w-[90px] max-w-[180px] flex-1 items-center gap-2">
                            <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-muted">
                              <div
                                className={`h-full rounded-full transition-all ${rate === 100 ? 'bg-emerald-500' : 'bg-primary'}`}
                                style={{ width: `${rate}%` }}
                              />
                            </div>
                            <span className="shrink-0 text-[10px] font-semibold tabular-nums text-muted-foreground">{rate}%</span>
                          </div>
                        )}
                        {dayTasks.length > 0 && (
                          <Button variant="ghost" size="sm" className="ml-auto h-7 gap-1 px-2 text-[11px] text-muted-foreground" onClick={() => jumpToDay(date)}>
                            Chi tiết <ChevronRight className="h-3 w-3" />
                          </Button>
                        )}
                      </div>

                      {/* banner ngày nghỉ */}
                      {d?.offline && (
                        <div className="mt-2 rounded-lg border border-amber-500/30 bg-amber-500/5 px-3 py-2 text-xs text-amber-700 dark:text-amber-400">
                          Ngày nghỉ — mọi việc còn lại đã tự động pass{d.offlineNote ? ` · ${d.offlineNote}` : ''}
                        </div>
                      )}
                      {d?.note && !d.offline && (
                        <p className="mt-1.5 px-0.5 text-[11px] italic text-muted-foreground">{d.note}</p>
                      )}

                      {/* các quy trình trong ngày */}
                      {dayTasks.length === 0 ? (
                        <p className="mt-2 rounded-xl border border-dashed px-3 py-2.5 text-xs text-muted-foreground/70">
                          Không có việc trong ngày này
                        </p>
                      ) : (
                        <div className={`mt-2 space-y-2 ${d?.offline ? 'opacity-70' : ''}`}>
                          {procSections.map((sec) => {
                            const settled = countSettled(sec.tasks)
                            const complete = settled === sec.tasks.length && sec.tasks.length > 0
                            const expanded = !complete || tlExpanded.has(sec.key)
                            return (
                              <div key={sec.key} className="rounded-xl border border-border/60">
                                <button
                                  type="button"
                                  className="flex w-full flex-wrap items-center gap-2 px-3 py-2 text-left transition-colors hover:bg-muted/40"
                                  onClick={() => toggleTlExpand(sec.key)}
                                  aria-expanded={expanded}
                                  aria-label={`${complete ? 'Mở rộng' : 'Xoá gọn'} quy trình ${sec.name}`}
                                >
                                  <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: sec.color }} />
                                  <span className="min-w-0 truncate text-sm font-semibold">{sec.name}</span>
                                  {complete ? (
                                    <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-500" />
                                  ) : (
                                    <Badge variant="secondary" className="font-normal tabular-nums">{settled}/{sec.tasks.length}</Badge>
                                  )}
                                  <ChevronRight
                                    className={`ml-auto h-4 w-4 shrink-0 text-muted-foreground transition-transform ${expanded ? 'rotate-90' : ''}`}
                                  />
                                </button>
                                {expanded && (
                                  <div className="border-t border-border/60 px-3 py-1.5">
                                    {buildTree(sec.tasks).map((node) => (
                                      <TimelineTaskNode
                                        key={node.data.id}
                                        node={node}
                                        depth={0}
                                        onTick={tickTask}
                                        onPass={openPass}
                                        onEdit={openEdit}
                                        onAddChild={(t) => openAddChild(t, date)}
                                      />
                                    ))}
                                  </div>
                                )}
                              </div>
                            )
                          })}

                          {/* việc phát sinh / chuẩn bị cuối ngày */}
                          {extraTasks.length > 0 && (
                            <div className="rounded-xl border border-dashed border-border/70">
                              <div className="flex items-center gap-2 px-3 py-2">
                                <Sparkles className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                                <span className="text-sm font-semibold text-muted-foreground">Việc phát sinh / Chuẩn bị</span>
                                <Badge variant="outline" className="ml-auto font-normal tabular-nums">{countSettled(extraTasks)}/{extraTasks.length}</Badge>
                              </div>
                              <div className="border-t border-dashed border-border/70 px-3 py-1.5">
                                {extraTasks.map((t) => (
                                  <TimelineTaskNode
                                    key={t.id}
                                    node={{ data: t, children: [] }}
                                    depth={0}
                                    onTick={tickTask}
                                    onPass={openPass}
                                    onEdit={openEdit}
                                    onAddChild={(x) => openAddChild(x, date)}
                                  />
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </TabsContent>

        {/* ============================ TAB: THỐNG KÊ ============================ */}
        <TabsContent value="stats" className="mt-3 space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            {[
              { label: 'Tuần này', from: weekStartISO(TODAY()) },
              { label: 'Tuần trước', from: addDaysISO(weekStartISO(TODAY()), -7) },
              { label: '30 ngày qua', from: addDaysISO(TODAY(), -29) },
            ].map((q) => (
              <Button
                key={q.label}
                variant="outline"
                size="sm"
                className="h-8"
                onClick={() => { setStatsFrom(q.from); setStatsTo(addDaysISO(q.from, q.label === '30 ngày qua' ? 29 : 6)) }}
              >
                {q.label}
              </Button>
            ))}
            <div className="ml-auto flex items-center gap-2">
              <Input type="date" value={statsFrom} onChange={(e) => setStatsFrom(e.target.value)} className="h-8 w-[150px] text-sm" aria-label="Từ ngày" />
              <span className="text-xs text-muted-foreground">→</span>
              <Input type="date" value={statsTo} onChange={(e) => setStatsTo(e.target.value)} className="h-8 w-[150px] text-sm" aria-label="Đến ngày" />
            </div>
          </div>

          {stats && stats.summary.total > 0 && (
            <div className="wos-glass grid grid-cols-2 gap-3 rounded-2xl p-4 sm:grid-cols-3 lg:grid-cols-6">
              {[
                { label: 'Tổng việc', value: stats.summary.total, cls: '' },
                { label: 'Hoàn thành', value: stats.summary.done, cls: 'text-emerald-600 dark:text-emerald-400' },
                { label: 'Pass', value: stats.summary.passed, cls: 'text-amber-600 dark:text-amber-400' },
                { label: 'Chờ làm', value: stats.summary.pending, cls: '' },
                { label: 'Ngày nghỉ', value: stats.summary.offlineDays, cls: 'text-amber-600 dark:text-amber-400' },
                { label: 'Tỉ lệ xong', value: `${stats.summary.rate}%`, cls: 'font-bold text-primary' },
              ].map((c) => (
                <div key={c.label} className="rounded-xl bg-muted/50 px-3 py-2.5 text-center">
                  <p className={`text-lg font-semibold tabular-nums ${c.cls}`}>{c.value}</p>
                  <p className="text-[11px] text-muted-foreground">{c.label}</p>
                </div>
              ))}
            </div>
          )}

          {stats === null ? (
            <div className="flex h-40 items-center justify-center">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : stats.days.length === 0 ? (
            <div className="wos-glass flex flex-col items-center gap-2 rounded-2xl py-14 text-muted-foreground">
              <BarChart3 className="h-10 w-10 opacity-30" />
              <p className="text-sm">Chưa có dữ liệu trong khoảng {fmtDM(statsFrom)} → {fmtDM(statsTo)}</p>
              <p className="text-xs">Thêm quy trình vào ngày ở tab <b>Tuần này</b> để có dữ liệu thống kê.</p>
            </div>
          ) : (
            <Card className="wos-glass border-0">
              <CardContent className="divide-y divide-border/50 p-0">
                {stats.days.map((d) => (
                  <button
                    key={d.date}
                    className="flex w-full flex-wrap items-center gap-x-4 gap-y-2 px-4 py-3 text-left transition-colors hover:bg-muted/50"
                    onClick={() => jumpToDay(d.date)}
                  >
                    <div className="w-[110px] shrink-0">
                      <p className="text-sm font-semibold tabular-nums">{fmtDM(d.date)} <span className="font-normal text-muted-foreground">{WEEKDAY_SHORT[weekdayOfISO(d.date)]}</span></p>
                      {d.offline ? (
                        <span className="rounded-full bg-amber-500/15 px-2 py-0.5 text-[10px] font-semibold text-amber-600 dark:text-amber-400">
                          Nghỉ{d.offlineNote ? ` · ${d.offlineNote}` : ''}
                        </span>
                      ) : (
                        <span className="text-[10px] text-muted-foreground">{d.date.slice(0, 4)}</span>
                      )}
                    </div>
                    <div className="flex flex-wrap items-center gap-1.5 text-xs">
                      <Badge variant="secondary" className="font-normal tabular-nums">{d.total} việc</Badge>
                      <Badge className="bg-emerald-500 hover:bg-emerald-500 tabular-nums" variant="default">{d.done} xong</Badge>
                      <Badge className="bg-amber-500 hover:bg-amber-500 tabular-nums">{d.passed} pass</Badge>
                      <Badge variant="outline" className="tabular-nums">{d.pending} chờ</Badge>
                    </div>
                    <div className="flex min-w-[120px] flex-1 items-center gap-2">
                      <Progress value={d.rate} className="h-2" />
                      <span className="shrink-0 text-xs font-semibold tabular-nums text-primary">{d.rate}%</span>
                    </div>
                  </button>
                ))}
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* =============== Dialog: nhập lý do PASS =============== */}
      <Dialog open={!!passTask} onOpenChange={(v) => { if (!v) { setPassTask(null); setPassReason('') } }}>
        <DialogContent className="wos-glass-strong sm:max-w-[400px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <XCircle className="h-4 w-4 text-amber-500" /> {tab === 'timeline' ? 'Bỏ qua việc' : 'Pass việc'}
            </DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">
            Việc <b className="text-foreground">{passTask?.name}</b> không làm được. Nhập lý do (bắt buộc):
          </p>
          {/* Chip lý do nhanh — click điền vào ô (vẫn sửa / tự nhập lý do khác) */}
          <div className="flex flex-wrap gap-1.5">
            {PASS_REASON_CHIPS.map((chip) => (
              <button
                key={chip}
                type="button"
                onClick={() => setPassReason(chip)}
                className="rounded-full bg-amber-500/10 px-2.5 py-1 text-xs text-amber-600 transition-colors hover:bg-amber-500/20 dark:text-amber-400"
              >
                {chip}
              </button>
            ))}
          </div>
          <Textarea
            value={passReason}
            onChange={(e) => setPassReason(e.target.value)}
            placeholder="Vd: thiếu hoá chất, máy hỏng, mẫu lỗi…"
            className="min-h-[80px]"
            autoFocus
          />
          <div className="flex justify-end gap-2">
            <Button variant="outline" size="sm" onClick={() => { setPassTask(null); setPassReason('') }}>Huỷ</Button>
            <Button size="sm" className="bg-amber-500 hover:bg-amber-500" disabled={!passReason.trim()} onClick={submitPass}>
              {tab === 'timeline' ? 'Bỏ qua' : 'Pass việc'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* =============== Dialog: thêm việc con =============== */}
      <Dialog open={!!addChildTask} onOpenChange={(v) => { if (!v) setAddChildTask(null) }}>
        <DialogContent className="wos-glass-strong sm:max-w-[400px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CornerDownRight className="h-4 w-4 text-primary" /> Thêm việc con
            </DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">
            Thêm vào: <b className="text-foreground">{addChildTask?.name}</b>
            {isISODate(addChildDate) && <> · {fmtFullDate(addChildDate)}</>}
            {addChildTask && (addChildTask.processId ? ' (việc trong quy trình)' : '')}
            <span className="mt-1 block text-xs">Việc mẹ sẽ thành nhóm tổng hợp tiến độ từ các việc con.</span>
          </p>
          <Input
            value={addChildName}
            onChange={(e) => setAddChildName(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') submitAddChild() }}
            placeholder="Tên việc con, vd: Pha dung dịch chuẩn L1…"
            autoFocus
            aria-label="Tên việc con"
          />
          <div className="flex justify-end gap-2">
            <Button variant="outline" size="sm" onClick={() => setAddChildTask(null)}>Huỷ</Button>
            <Button size="sm" className="gap-1.5" disabled={!addChildName.trim() || addChildSaving} onClick={submitAddChild}>
              {addChildSaving && <Loader2 className="h-4 w-4 animate-spin" />}
              Thêm
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* =============== Dialog: sửa việc / ghi chú =============== */}
      <Dialog open={!!editTask} onOpenChange={(v) => { if (!v) setEditTask(null) }}>
        <DialogContent className="wos-glass-strong sm:max-w-[420px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><Pencil className="h-4 w-4" /> Sửa việc</DialogTitle>
          </DialogHeader>
          {editTask && (
            <div className="space-y-3">
              <div>
                <label className="mb-1 block text-xs font-medium text-muted-foreground">Tên việc</label>
                <Input value={editDraft.name} onChange={(e) => setEditDraft({ ...editDraft, name: e.target.value })} className="h-9" />
              </div>
              {editTask.quantity != null && (
                <div>
                  <label className="mb-1 block text-xs font-medium text-muted-foreground">Tổng số hàng</label>
                  <Input
                    type="number"
                    min={0}
                    value={editDraft.quantity}
                    onChange={(e) => setEditDraft({ ...editDraft, quantity: e.target.value })}
                    className="h-9"
                  />
                </div>
              )}
              <div>
                <label className="mb-1 block text-xs font-medium text-muted-foreground">Ghi chú</label>
                <Textarea value={editDraft.note} onChange={(e) => setEditDraft({ ...editDraft, note: e.target.value })} className="min-h-[70px]" placeholder="Vấn đề gặp phải, ghi chú thêm…" />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" size="sm" onClick={() => setEditTask(null)}>Huỷ</Button>
                <Button size="sm" onClick={saveEditTask}>Lưu</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* =============== Dialog: lý do nghỉ =============== */}
      <Dialog open={offlineAsk} onOpenChange={setOfflineAsk}>
        <DialogContent className="wos-glass-strong sm:max-w-[400px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><CalendarDays className="h-4 w-4 text-amber-500" /> Đánh dấu ngày nghỉ</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">
            Ngày <b className="text-foreground">{fmtFullDate(selectedDate)}</b>. Mọi việc còn <b>pending</b> sẽ được tự động pass với ghi chú
            &ldquo;{AUTO_PASS_NOTE}&rdquo;. Khi bỏ Offline, những việc này sẽ quay lại pending.
          </p>
          <Input
            value={offlineReason}
            onChange={(e) => setOfflineReason(e.target.value)}
            placeholder="Lý do nghỉ (vd: ốm, máy bảo trì…)"
          />
          <div className="flex justify-end gap-2">
            <Button variant="outline" size="sm" onClick={() => setOfflineAsk(false)}>Huỷ</Button>
            <Button size="sm" className="gap-1.5" onClick={submitOffline}>
              <CalendarDays className="h-4 w-4" /> Xác nhận nghỉ
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* =============== Dialog: editor quy trình (3 tab con) =============== */}
      <Dialog open={editorOpen} onOpenChange={setEditorOpen}>
        <DialogContent className="wos-glass-strong max-h-[85vh] overflow-y-auto sm:max-w-[680px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ListChecks className="h-4 w-4" style={{ color: draft.color }} />
              {editingId ? 'Sửa quy trình' : 'Quy trình mới'}
            </DialogTitle>
          </DialogHeader>
          {editorLoading ? (
            <div className="flex h-40 items-center justify-center">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex gap-2">
                <div className="relative">
                  <Input
                    value={draft.icon}
                    onChange={(e) => setDraft({ ...draft, icon: e.target.value.slice(0, 2) })}
                    className="h-9 w-[46px] text-center text-lg"
                    aria-label="Icon"
                  />
                </div>
                <Input
                  value={draft.name}
                  onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                  placeholder="Tên quy trình, vd: Test Albumin SC"
                  className="h-9 flex-1 font-medium"
                  autoFocus={!editingId}
                />
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <Input
                  value={draft.description}
                  onChange={(e) => setDraft({ ...draft, description: e.target.value })}
                  placeholder="Mô tả ngắn…"
                  className="h-9 min-w-[180px] flex-1 text-sm"
                />
                <div className="flex items-center gap-1.5">
                  {SWATCHES.map((c) => (
                    <button
                      key={c}
                      onClick={() => setDraft({ ...draft, color: c })}
                      className={`h-6 w-6 rounded-lg transition-transform hover:scale-110 ${draft.color === c ? 'ring-2 ring-foreground ring-offset-2' : ''}`}
                      style={{ background: c }}
                      aria-label={`Màu ${c}`}
                    />
                  ))}
                </div>
                <div className="flex items-center gap-1">
                  {EMOJIS.map((e) => (
                    <button
                      key={e}
                      onClick={() => setDraft({ ...draft, icon: e })}
                      className={`rounded-md px-1 text-base transition-transform hover:scale-110 ${draft.icon === e ? 'bg-muted ring-1 ring-foreground/40' : ''}`}
                      aria-label={`Icon ${e}`}
                    >
                      {e}
                    </button>
                  ))}
                </div>
              </div>

              <Tabs value={editorTab} onValueChange={setEditorTab}>
                <TabsList className="w-full">
                  <TabsTrigger value="steps" className="gap-1.5"><ListChecks className="size-3.5" /> Bước</TabsTrigger>
                  <TabsTrigger value="preps" className="gap-1.5"><FlaskConical className="size-3.5" /> Điều kiện</TabsTrigger>
                  <TabsTrigger value="preview" className="gap-1.5"><Sparkles className="size-3.5" /> Xem trước</TabsTrigger>
                </TabsList>

                {/* ---- Bước (outline nhiều cấp) ---- */}
                <TabsContent value="steps" className="mt-2 space-y-2">
                  <p className="text-xs text-muted-foreground">
                    Mỗi bước lá: tên, số lot × số hàng/lot. Dùng <b>⇥</b> để làm bước con của dòng ngay trên, <b>⇤</b> để thụt lùi — bước lớn chứa bước con.
                  </p>
                  {draft.steps.map((s, i) => {
                    const hasChildren = !isLeafAt(draft.steps, i)
                    const canIndent = i > 0 && draft.steps[i - 1].depth + 1 > s.depth
                    const canOutdent = s.depth > 0
                    const up = canMoveStepUp(draft.steps, i)
                    const down = canMoveStepDown(draft.steps, i)
                    return (
                      <div
                        key={s.tmpId}
                        className={`flex flex-wrap items-center gap-1.5 rounded-xl p-2 ${s.depth > 0 ? 'bg-muted/30' : 'bg-muted/40'}`}
                        style={{ marginLeft: s.depth * 22 }}
                      >
                        {s.depth > 0 && <CornerDownRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground/70" aria-hidden="true" />}
                        <Input
                          value={s.name}
                          onChange={(e) => setDraft({ ...draft, steps: draft.steps.map((x, j) => (j === i ? { ...x, name: e.target.value } : x)) })}
                          placeholder={hasChildren ? `Nhóm bước, vd: Sắc ký mẫu` : `Bước, vd: Pha mẫu`}
                          className={`h-8 min-w-[130px] flex-1 text-sm ${hasChildren ? 'font-semibold' : ''}`}
                          aria-label={`Tên bước dòng ${i + 1}`}
                        />
                        {!hasChildren && (
                          <>
                            <Input
                              type="number" min={1}
                              value={s.lotCount}
                              onChange={(e) => setDraft({ ...draft, steps: draft.steps.map((x, j) => (j === i ? { ...x, lotCount: e.target.value } : x)) })}
                              placeholder="lot"
                              className="h-8 w-[64px] text-sm tabular-nums"
                              aria-label="Số lot"
                              title="Số lot cần test"
                            />
                            <span className="text-xs text-muted-foreground">×</span>
                            <Input
                              type="number" min={1}
                              value={s.rowsPerLot}
                              onChange={(e) => setDraft({ ...draft, steps: draft.steps.map((x, j) => (j === i ? { ...x, rowsPerLot: e.target.value } : x)) })}
                              placeholder="hàng"
                              className="h-8 w-[64px] text-sm tabular-nums"
                              aria-label="Số hàng mỗi lot"
                              title="Số hàng test mỗi lot"
                            />
                          </>
                        )}
                        <Input
                          value={s.note}
                          onChange={(e) => setDraft({ ...draft, steps: draft.steps.map((x, j) => (j === i ? { ...x, note: e.target.value } : x)) })}
                          placeholder="Ghi chú bước…"
                          className="h-8 min-w-[110px] flex-[2] text-sm"
                          aria-label="Ghi chú bước"
                        />
                        <div className="flex shrink-0 items-center gap-0.5">
                          <Button
                            variant="ghost" size="icon" className="h-7 w-7"
                            title="Thêm bước con dưới bước này"
                            aria-label="Thêm bước con"
                            onClick={() => setDraft({ ...draft, steps: addStepChildAt(draft.steps, i) })}
                          >
                            <CornerDownRight className="h-3.5 w-3.5 text-primary" />
                          </Button>
                          <Button
                            variant="ghost" size="icon" className="h-7 w-7"
                            disabled={!canIndent}
                            title="⇥ Làm bước con của dòng ngay trên"
                            aria-label="Xuống cấp (làm bước con)"
                            onClick={() => setDraft({ ...draft, steps: indentStep(draft.steps, i) })}
                          >
                            <IndentIncrease className="h-3.5 w-3.5" />
                          </Button>
                          <Button
                            variant="ghost" size="icon" className="h-7 w-7"
                            disabled={!canOutdent}
                            title="⇤ Thụt lùi 1 cấp"
                            aria-label="Thụt lùi cấp"
                            onClick={() => setDraft({ ...draft, steps: outdentStep(draft.steps, i) })}
                          >
                            <IndentDecrease className="h-3.5 w-3.5" />
                          </Button>
                          <Button
                            variant="ghost" size="icon" className="h-7 w-7"
                            disabled={!up}
                            onClick={() => setDraft({ ...draft, steps: moveStep(draft.steps, i, 'up') })}
                            aria-label="Đưa bước lên (kèm bước con)"
                            title="Đưa cả nhóm lên"
                          >
                            <ChevronUp className="h-3.5 w-3.5" />
                          </Button>
                          <Button
                            variant="ghost" size="icon" className="h-7 w-7"
                            disabled={!down}
                            onClick={() => setDraft({ ...draft, steps: moveStep(draft.steps, i, 'down') })}
                            aria-label="Đưa bước xuống (kèm bước con)"
                            title="Đưa cả nhóm xuống"
                          >
                            <ChevronDown className="h-3.5 w-3.5" />
                          </Button>
                          <Button
                            variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive"
                            aria-label="Xoá bước"
                            title={hasChildren ? 'Xoá cả nhóm bước con' : 'Xoá bước'}
                            onClick={() => {
                              const end = subtreeEnd(draft.steps, i)
                              if (end - i > 1) {
                                if (!confirm(`Xoá "${s.name || 'bước này'}" cùng ${end - i - 1} bước con?`)) return
                              }
                              setDraft({ ...draft, steps: removeStep(draft.steps, i) })
                            }}
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </div>
                    )
                  })}
                  <Button variant="outline" size="sm" className="gap-1.5" onClick={() => setDraft({ ...draft, steps: [...draft.steps, { ...newStepDraft(0) }] })}>
                    <Plus className="h-4 w-4" /> Thêm bước
                  </Button>
                  {draft.steps.length > 0 && (
                    <p className="text-xs text-muted-foreground">
                      Tổng: <b>{draft.steps.filter((_, i) => isLeafAt(draft.steps, i)).length} việc</b>
                      {draft.steps.some((_, i) => !isLeafAt(draft.steps, i)) && (
                        <> · <b>{draft.steps.filter((_, i) => !isLeafAt(draft.steps, i)).length} nhóm</b></>
                      )}{' '}
                      · <b>{draft.steps.reduce((sum, x, i) => (isLeafAt(draft.steps, i) ? sum + toPosInt(x.lotCount) * toPosInt(x.rowsPerLot) : sum), 0)} hàng</b> mỗi lần chạy.
                    </p>
                  )}
                </TabsContent>

                {/* ---- Điều kiện ---- */}
                <TabsContent value="preps" className="mt-2 space-y-2">
                  <p className="text-xs text-muted-foreground">Việc chuẩn bị trước ngày chính (vd: pha hoá chất trước 1 ngày). Chi tiết mô tả từng lần pha.</p>
                  {draft.preps.map((p, i) => (
                    <div key={i} className="flex flex-wrap items-center gap-1.5 rounded-xl bg-muted/40 p-2">
                      <Input
                        value={p.name}
                        onChange={(e) => setDraft({ ...draft, preps: draft.preps.map((x, j) => (j === i ? { ...x, name: e.target.value } : x)) })}
                        placeholder={`Điều kiện ${i + 1}, vd: Pha hoá chất`}
                        className="h-8 min-w-[140px] flex-1 text-sm"
                        aria-label={`Tên điều kiện ${i + 1}`}
                      />
                      <div className="flex shrink-0 items-center gap-1">
                        <Input
                          type="number" min={1}
                          value={p.offsetDays}
                          onChange={(e) => setDraft({ ...draft, preps: draft.preps.map((x, j) => (j === i ? { ...x, offsetDays: e.target.value } : x)) })}
                          className="h-8 w-[64px] text-sm tabular-nums"
                          aria-label="Số ngày trước"
                          title="Số ngày trước ngày chính"
                        />
                        <span className="text-xs text-muted-foreground">ngày trước</span>
                      </div>
                      <Input
                        value={p.detail}
                        onChange={(e) => setDraft({ ...draft, preps: draft.preps.map((x, j) => (j === i ? { ...x, detail: e.target.value } : x)) })}
                        placeholder="Chi tiết, vd: lần 1 pha hoá chất, lần 2 pha dung dịch thẩm tách…"
                        className="h-8 min-w-[160px] flex-[2] text-sm"
                        aria-label="Chi tiết điều kiện"
                      />
                      <div className="flex shrink-0 items-center gap-0.5">
                        <Button variant="ghost" size="icon" className="h-7 w-7" disabled={i === 0} onClick={() => {
                          const arr = [...draft.preps]; [arr[i - 1], arr[i]] = [arr[i], arr[i - 1]]; setDraft({ ...draft, preps: arr })
                        }} aria-label="Đưa điều kiện lên"><ChevronUp className="h-3.5 w-3.5" /></Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7" disabled={i === draft.preps.length - 1} onClick={() => {
                          const arr = [...draft.preps]; [arr[i + 1], arr[i]] = [arr[i], arr[i + 1]]; setDraft({ ...draft, preps: arr })
                        }} aria-label="Đưa điều kiện xuống"><ChevronDown className="h-3.5 w-3.5" /></Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive" onClick={() => setDraft({ ...draft, preps: draft.preps.filter((_, j) => j !== i) })} aria-label="Xoá điều kiện"><Trash2 className="h-3.5 w-3.5" /></Button>
                      </div>
                    </div>
                  ))}
                  <Button variant="outline" size="sm" className="gap-1.5" onClick={() => setDraft({ ...draft, preps: [...draft.preps, { name: '', offsetDays: '1', detail: '' }] })}>
                    <Plus className="h-4 w-4" /> Thêm điều kiện
                  </Button>
                </TabsContent>

                {/* ---- Xem trước ---- */}
                <TabsContent value="preview" className="mt-2 space-y-2">
                  <div className="flex items-center gap-2">
                    <label className="text-xs font-medium text-muted-foreground">Nếu thêm vào ngày</label>
                    <Input
                      type="date"
                      value={previewDate || TODAY()}
                      onChange={(e) => setPreviewDate(e.target.value)}
                      className="h-8 w-[160px] text-sm"
                      aria-label="Ngày xem trước"
                    />
                  </div>
                  <div className="max-h-64 overflow-y-auto rounded-xl border border-dashed p-2">
                    {(() => {
                      const base = isISODate(previewDate) ? previewDate : TODAY()
                      const items: { icon: string; date: string; text: string; cls: string; depth: number }[] = []
                      for (const p of draft.preps) {
                        const off = toPosInt(p.offsetDays)
                        items.push({ icon: '🧪', date: addDaysISO(base, -off), text: `${p.name || '(điều kiện chưa tên)'}${off > 1 ? ` — chuẩn bị trước ${off} ngày` : ' — chuẩn bị trước 1 ngày'}${p.detail ? ` · ${p.detail}` : ''}`, cls: 'text-amber-700 dark:text-amber-400', depth: 0 })
                      }
                      draft.steps.forEach((s, i) => {
                        const leaf = isLeafAt(draft.steps, i)
                        const lot = toPosInt(s.lotCount)
                        const rows = toPosInt(s.rowsPerLot)
                        items.push({
                          icon: leaf ? '📋' : '🗂️',
                          date: base,
                          text: leaf
                            ? `${s.name || '(bước chưa tên)'} — ${lot} lot × ${rows} hàng = ${lot * rows} hàng${s.note ? ` · ${s.note}` : ''}`
                            : `${s.name || '(nhóm chưa tên)'} — nhóm tổng hợp tiến độ${s.note ? ` · ${s.note}` : ''}`,
                          cls: leaf ? '' : 'font-semibold',
                          depth: s.depth,
                        })
                      })
                      if (items.length === 0) {
                        return <p className="py-6 text-center text-xs text-muted-foreground">Chưa có bước/điều kiện nào — thêm ở 2 tab trên để xem danh sách việc phát sinh.</p>
                      }
                      return items.map((it, i) => (
                        <div key={i} className="flex items-center gap-2 rounded-lg px-2 py-1.5 text-xs hover:bg-muted/50" style={{ marginLeft: it.depth * 18 }}>
                          <span className="shrink-0 text-base">{it.icon}</span>
                          <span className="w-[86px] shrink-0 font-semibold tabular-nums">{fmtDM(it.date)}</span>
                          <span className={`min-w-0 flex-1 ${it.cls}`}>{it.text}</span>
                        </div>
                      ))
                    })()}
                  </div>
                </TabsContent>
              </Tabs>

              <div className="flex justify-end gap-2 border-t pt-3">
                <Button variant="outline" size="sm" onClick={() => setEditorOpen(false)}>Huỷ</Button>
                <Button size="sm" className="gap-1.5" disabled={!draft.name.trim() || saving} onClick={saveProcess}>
                  {saving && <Loader2 className="h-4 w-4 animate-spin" />}
                  {editingId ? 'Lưu thay đổi' : 'Tạo quy trình'}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

// =====================================================================
// Cây việc trong panel ngày (tab Tuần này)
// =====================================================================
function TaskTreeNode({
  node, flags, onTick, onPass, onEdit, onDelete, onDeleteGroup, onReorder, onAddRound, onAddChild,
}: {
  node: TreeNode<WTask>
  flags: Map<string, { canUp: boolean; canDown: boolean }>
  onTick: (t: WTask) => void
  onPass: (t: WTask) => void
  onEdit: (t: WTask) => void
  onDelete: (t: WTask) => void
  onDeleteGroup: (t: WTask, childCount: number) => void
  onReorder: (t: WTask, d: 'up' | 'down') => void
  onAddRound: (t: WTask) => void
  onAddChild: (t: WTask) => void
}) {
  const { data: task, children } = node
  if (children.length === 0) {
    return (
      <TaskRow
        task={task}
        canUp={flags.get(task.id)?.canUp ?? true}
        canDown={flags.get(task.id)?.canDown ?? true}
        indent={!!task.parentId}
        onTick={() => onTick(task)}
        onPass={() => onPass(task)}
        onEdit={() => onEdit(task)}
        onDelete={() => onDelete(task)}
        onReorder={(d) => onReorder(task, d)}
        onAddRound={() => onAddRound(task)}
        onAddChild={() => onAddChild(task)}
      />
    )
  }
  // dòng nhóm: in đậm + thanh tiến độ con — không tick trực tiếp
  const settled = countSettled(children.map((c) => c.data))
  const pct = Math.round((settled / children.length) * 100)
  const flag = flags.get(task.id)
  return (
    <div>
      <div className="group flex flex-wrap items-center gap-x-2 gap-y-1 bg-muted/50 px-3 py-2">
        {task.status === 'done' ? (
          <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-500" aria-label="Nhóm đã hoàn thành" />
        ) : (
          <ListTree className="h-5 w-5 shrink-0 text-muted-foreground/70" aria-hidden="true" />
        )}
        <span className={`min-w-0 text-sm font-semibold ${task.status === 'done' ? 'text-muted-foreground' : ''}`}>{task.name}</span>
        <Badge variant="secondary" className="font-normal tabular-nums">{settled}/{children.length} con</Badge>
        <div className="flex min-w-[70px] max-w-[160px] flex-1 items-center gap-1.5">
          <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-muted">
            <div className={`h-full rounded-full transition-all ${pct === 100 ? 'bg-emerald-500' : 'bg-primary'}`} style={{ width: `${pct}%` }} />
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-0.5 opacity-60 transition-opacity group-hover:opacity-100">
          <Button variant="ghost" size="icon" className="h-7 w-7" disabled={!flag?.canUp} onClick={() => onReorder(task, 'up')} aria-label="Đưa nhóm lên" title="Đổi thứ tự: lên">
            <ChevronUp className="h-3.5 w-3.5" />
          </Button>
          <Button variant="ghost" size="icon" className="h-7 w-7" disabled={!flag?.canDown} onClick={() => onReorder(task, 'down')} aria-label="Đưa nhóm xuống" title="Đổi thứ tự: xuống">
            <ChevronDown className="h-3.5 w-3.5" />
          </Button>
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => onEdit(task)} aria-label="Sửa nhóm" title="Sửa tên / ghi chú">
            <Pencil className="h-3.5 w-3.5" />
          </Button>
          <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive" onClick={() => onDeleteGroup(task, children.length)} aria-label="Xoá nhóm và mọi việc con" title="Xoá nhóm + mọi việc con">
            <Trash2 className="h-3.5 w-3.5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 opacity-0 transition-opacity hover:text-primary focus-visible:opacity-100 group-hover:opacity-100"
            onClick={() => onAddChild(task)}
            aria-label="Thêm việc con"
            title="Thêm việc con vào nhóm này"
          >
            <Plus className="h-3 w-3" />
          </Button>
        </div>
      </div>
      <div className="divide-y divide-border/40 border-l-2 border-border/60 pl-0">
        {children.map((child) => (
          <TaskTreeNode
            key={child.data.id}
            node={child}
            flags={flags}
            onTick={onTick}
            onPass={onPass}
            onEdit={onEdit}
            onDelete={onDelete}
            onDeleteGroup={onDeleteGroup}
            onReorder={onReorder}
            onAddRound={onAddRound}
            onAddChild={onAddChild}
          />
        ))}
      </div>
    </div>
  )
}

// =====================================================================
// 1 hàng việc (bước lá) trong ngày — tab Tuần này
// =====================================================================
function TaskRow({
  task, canUp, canDown, indent, onTick, onPass, onEdit, onDelete, onReorder, onAddRound, onAddChild,
}: {
  task: WTask
  canUp: boolean
  canDown: boolean
  indent: boolean
  onTick: () => void
  onPass: () => void
  onEdit: () => void
  onDelete: () => void
  onReorder: (d: 'up' | 'down') => void
  onAddRound: () => void
  onAddChild: () => void
}) {
  const done = task.status === 'done'
  const passed = task.status === 'passed'
  const autoNote = task.note === AUTO_PASS_NOTE
  return (
    <div className={`group flex flex-wrap items-center gap-x-2 gap-y-1 px-3 py-2 transition-colors hover:bg-muted/40 ${indent ? 'bg-muted/15' : ''}`}>
      {/* Nút tick: Circle / CheckCircle2 / CircleSlash (passed) */}
      <button onClick={onTick} className="shrink-0 rounded-full focus:outline-none focus-visible:ring-2 focus-visible:ring-ring" aria-label={done ? 'Bỏ hoàn thành' : 'Đánh dấu hoàn thành'} title={done ? 'Bỏ hoàn thành' : 'Hoàn thành'}>
        {done ? (
          <CheckCircle2 className="h-5 w-5 text-emerald-500" />
        ) : passed ? (
          <CircleSlash className="h-5 w-5 text-amber-500" />
        ) : (
          <Circle className="h-5 w-5 text-muted-foreground transition-colors group-hover:text-primary" />
        )}
      </button>

      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-1.5">
          <span className={`text-sm ${done ? 'text-muted-foreground line-through' : passed ? 'text-muted-foreground' : 'font-medium'}`}>
            {task.isPrep && <FlaskConical className="mr-1 inline h-3.5 w-3.5 text-amber-500" />}
            {task.name}
          </span>
          {task.isPrep && task.prepRound > 1 && (
            <Badge className="bg-amber-500/15 text-amber-600 hover:bg-amber-500/15 dark:text-amber-400">Lần {task.prepRound}</Badge>
          )}
          {task.quantity != null && task.quantity > 0 && (
            <Badge variant="secondary" className="font-normal tabular-nums" title={task.lotCount ? `${task.lotCount} lot × ${task.rowsPerLot} hàng` : ''}>
              {task.quantity} hàng
            </Badge>
          )}
          {passed && !autoNote && task.note && (
            <span className="truncate text-xs italic text-amber-600/90 dark:text-amber-400/90">— {task.note}</span>
          )}
        </div>
        {!passed && task.note && (
          <p className="truncate text-[11px] text-muted-foreground/80">{task.note}</p>
        )}
      </div>

      {/* Hành động */}
      <div className="flex shrink-0 items-center gap-0.5 opacity-60 transition-opacity group-hover:opacity-100">
        {!done && !passed && (
          <Button variant="ghost" size="sm" className="h-7 gap-1 px-2 text-xs text-amber-600 hover:text-amber-600 dark:text-amber-400" onClick={onPass} title="Pass — không làm được">
            <XCircle className="h-3.5 w-3.5" /> Pass
          </Button>
        )}
        {task.isPrep && (
          <Button variant="ghost" size="sm" className="h-7 gap-1 px-2 text-xs" onClick={onAddRound} title="Thêm lần pha (nhân bản việc prep)">
            <FlaskConical className="h-3.5 w-3.5" /> Thêm lần pha
          </Button>
        )}
        <Button variant="ghost" size="icon" className="h-7 w-7" disabled={!canUp} onClick={() => onReorder('up')} aria-label="Đưa việc lên" title="Đổi thứ tự: lên">
          <ChevronUp className="h-3.5 w-3.5" />
        </Button>
        <Button variant="ghost" size="icon" className="h-7 w-7" disabled={!canDown} onClick={() => onReorder('down')} aria-label="Đưa việc xuống" title="Đổi thứ tự: xuống">
          <ChevronDown className="h-3.5 w-3.5" />
        </Button>
        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onEdit} aria-label="Sửa việc" title="Sửa tên / số hàng / ghi chú">
          <Pencil className="h-3.5 w-3.5" />
        </Button>
        <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive" onClick={onDelete} aria-label="Xoá việc">
          <Trash2 className="h-3.5 w-3.5" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="h-7 w-7 opacity-0 transition-opacity hover:text-primary focus-visible:opacity-100 group-hover:opacity-100"
          onClick={onAddChild}
          aria-label="Thêm việc con"
          title="Thêm việc con vào việc này (việc này sẽ thành nhóm)"
        >
          <Plus className="h-3 w-3" />
        </Button>
      </div>
    </div>
  )
}

// =====================================================================
// 1 node việc trong Timeline (đệ quy: nhóm + lá)
// =====================================================================
function TimelineTaskNode({
  node, depth, onTick, onPass, onEdit, onAddChild,
}: {
  node: TreeNode<WTask>
  depth: number
  onTick: (t: WTask) => void
  onPass: (t: WTask) => void
  onEdit: (t: WTask) => void
  onAddChild: (t: WTask) => void
}) {
  const { data: task, children } = node

  // ---- dòng nhóm: in đậm + thanh tiến độ theo con ----
  if (children.length > 0) {
    const settled = countSettled(children.map((c) => c.data))
    const pct = Math.round((settled / children.length) * 100)
    return (
      <div className="group py-1">
        <div className="flex flex-wrap items-center gap-x-2 gap-y-1" style={{ marginLeft: depth * 16 }}>
          {task.status === 'done' ? (
            <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-500" aria-label="Nhóm đã hoàn thành" />
          ) : (
            <ListTree className="h-4 w-4 shrink-0 text-muted-foreground/70" aria-hidden="true" />
          )}
          <span className={`min-w-0 text-sm font-semibold ${task.status === 'done' ? 'text-muted-foreground' : ''}`}>{task.name}</span>
          <Badge variant="secondary" className="font-normal tabular-nums">{settled}/{children.length}</Badge>
          <div className="h-1.5 min-w-[50px] max-w-[140px] flex-1 overflow-hidden rounded-full bg-muted">
            <div className={`h-full rounded-full transition-all ${pct === 100 ? 'bg-emerald-500' : 'bg-primary'}`} style={{ width: `${pct}%` }} />
          </div>
          <button
            type="button"
            onClick={() => onAddChild(task)}
            className="ml-auto shrink-0 rounded-md p-1 text-muted-foreground opacity-0 transition-opacity hover:text-primary focus:opacity-100 focus:outline-none focus-visible:ring-2 focus-visible:ring-ring group-hover:opacity-100"
            aria-label={`Thêm việc con vào ${task.name}`}
            title="Thêm việc con vào nhóm này"
          >
            <Plus className="h-3 w-3" />
          </button>
        </div>
        {task.note && <p className="mt-0.5 text-[11px] text-amber-600/90 dark:text-amber-400/90" style={{ marginLeft: depth * 16 + 22 }}>{task.note}</p>}
        <div className="mt-0.5 border-l-2 border-border/50">
          {children.map((child) => (
            <TimelineTaskNode key={child.data.id} node={child} depth={depth + 1} onTick={onTick} onPass={onPass} onEdit={onEdit} onAddChild={onAddChild} />
          ))}
        </div>
      </div>
    )
  }

  // ---- dòng lá: tick + tên + số lượng + note + bỏ qua ----
  const done = task.status === 'done'
  const passed = task.status === 'passed'
  return (
    <div className="group flex items-start gap-2 py-1" style={{ marginLeft: depth * 16 }}>
      <button
        onClick={() => onTick(task)}
        className="mt-0.5 shrink-0 rounded-full focus:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        aria-label={done ? `Bỏ hoàn thành ${task.name}` : `Đánh dấu hoàn thành ${task.name}`}
        title={done ? 'Bỏ hoàn thành' : 'Hoàn thành'}
      >
        {done ? (
          <CheckCircle2 className="h-5 w-5 text-emerald-500" />
        ) : passed ? (
          <CircleSlash className="h-5 w-5 text-amber-500" />
        ) : (
          <Circle className="h-5 w-5 text-muted-foreground transition-colors group-hover:text-primary" />
        )}
      </button>
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-1.5">
          <span className={`text-sm ${done ? 'text-muted-foreground line-through' : passed ? 'text-muted-foreground' : 'font-medium'}`}>
            {task.isPrep && <FlaskConical className="mr-1 inline h-3.5 w-3.5 text-amber-500" />}
            {task.name}
          </span>
          {task.isPrep && task.prepRound > 1 && (
            <Badge className="bg-amber-500/15 text-amber-600 hover:bg-amber-500/15 dark:text-amber-400">Lần {task.prepRound}</Badge>
          )}
          {task.quantity != null && task.quantity > 0 && (
            <Badge variant="secondary" className="font-normal tabular-nums" title={task.lotCount ? `${task.lotCount} lot × ${task.rowsPerLot} hàng` : ''}>
              {task.quantity} hàng
            </Badge>
          )}
          <button
            onClick={() => onEdit(task)}
            className="rounded-md p-0.5 focus:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            aria-label={task.note ? `Sửa ghi chú việc ${task.name}` : `Thêm ghi chú việc ${task.name}`}
            title="Ghi chú / sửa việc"
          >
            <StickyNote className={`h-3.5 w-3.5 ${task.note ? 'text-amber-500' : 'text-muted-foreground/40 group-hover:text-muted-foreground'}`} />
          </button>
          {!done && !passed && (
            <Button
              variant="ghost"
              size="sm"
              className="h-6 gap-1 px-1.5 text-[11px] text-amber-600 hover:text-amber-600 dark:text-amber-400"
              onClick={() => onPass(task)}
              title="Bỏ qua — không làm được (kèm lý do)"
            >
              <XCircle className="h-3 w-3" /> Bỏ qua
            </Button>
          )}
          <button
            type="button"
            onClick={() => onAddChild(task)}
            className="shrink-0 rounded-md p-0.5 text-muted-foreground/40 opacity-0 transition-opacity hover:text-primary focus:opacity-100 focus:outline-none focus-visible:ring-2 focus-visible:ring-ring group-hover:opacity-100"
            aria-label={`Thêm việc con vào ${task.name}`}
            title="Thêm việc con (việc này sẽ thành nhóm)"
          >
            <Plus className="h-3 w-3" />
          </button>
        </div>
        {task.note && (
          <p className="mt-0.5 break-words text-[11px] leading-snug text-amber-600/90 dark:text-amber-400/90">
            {passed && task.note !== AUTO_PASS_NOTE ? `— ${task.note}` : task.note}
          </p>
        )}
      </div>
    </div>
  )
}
