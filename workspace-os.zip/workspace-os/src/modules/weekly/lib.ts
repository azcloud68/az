/**
 * MODULE: Weekly Work — helpers dùng chung (client + server, pure functions)
 * Ngày làm việc luôn là chuỗi 'YYYY-MM-DD' (local, không phụ thuộc time-zone).
 */

/** Note chuẩn khi auto-pass việc do ngày nghỉ offline */
export const AUTO_PASS_NOTE = 'Nghỉ làm — auto pass'

export const WEEKDAY_SHORT = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN']
export const WEEKDAY_FULL = ['Thứ Hai', 'Thứ Ba', 'Thứ Tư', 'Thứ Năm', 'Thứ Sáu', 'Thứ Bảy', 'Chủ Nhật']

/** Date → 'YYYY-MM-DD' theo giờ local */
export function fmtISODate(d: Date): string {
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

/** Kiểm tra chuỗi ngày hợp lệ 'YYYY-MM-DD' */
export function isISODate(v: unknown): v is string {
  if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(v)) return false
  const [y, m, d] = v.split('-').map(Number)
  return m >= 1 && m <= 12 && d >= 1 && d <= 31 && y >= 2000
}

/** 'YYYY-MM-DD' → Date giờ local (giữa trưa, an toàn DST) */
export function parseISO(iso: string): Date {
  const [y, m, d] = iso.split('-').map(Number)
  return new Date(y || 2026, (m || 1) - 1, d || 1, 12, 0, 0, 0)
}

/** Cộng/trừ ngày trên chuỗi ISO */
export function addDaysISO(iso: string, days: number): string {
  const d = parseISO(iso)
  d.setDate(d.getDate() + days)
  return fmtISODate(d)
}

/** Thứ 2 (đầu tuần) của tuần chứa iso */
export function weekStartISO(iso: string): string {
  const wd = (parseISO(iso).getDay() + 6) % 7 // 0 = Thứ 2 … 6 = CN
  return addDaysISO(iso, -wd)
}

/** 0 = Thứ 2 … 6 = Chủ nhật */
export function weekdayOfISO(iso: string): number {
  return (parseISO(iso).getDay() + 6) % 7
}

/** 7 ngày của tuần bắt đầu từ startISO (Thứ 2 → CN) */
export function weekDates(startISO: string): string[] {
  return Array.from({ length: 7 }, (_, i) => addDaysISO(startISO, i))
}

/** '2026-09-10' → '10/09' */
export function fmtDM(iso: string): string {
  const [, m, d] = iso.split('-')
  return `${d}/${m}`
}

/** '2026-09-10' → 'Thứ Ba, 10/09/2026' */
export function fmtFullDate(iso: string): string {
  return `${WEEKDAY_FULL[weekdayOfISO(iso)]}, ${fmtDM(iso)}/${iso.slice(0, 4)}`
}

/** '2026-09-10' → 'Thứ Ba 10/09' */
export function fmtDayShort(iso: string): string {
  return `${WEEKDAY_SHORT[weekdayOfISO(iso)]} ${fmtDM(iso)}`
}

/** Số nguyên dương an toàn từ input */
export function toPosInt(v: unknown, fallback = 1): number {
  const n = Number(v)
  return Number.isFinite(n) && n > 0 ? Math.floor(n) : fallback
}

// ---------------------------------------------------------------------
// Parser body cho API quy trình (dùng ở server, pure — không phụ thuộc DB)
// ---------------------------------------------------------------------

export interface StepInput {
  name?: unknown
  lotCount?: unknown
  rowsPerLot?: unknown
  note?: unknown
  id?: unknown // id tạm do client sinh ("tmp-1"… hoặc id thật khi PATCH)
  parentId?: unknown // id tạm của bước cha (flat) — HOẶC dùng children lồng
  children?: unknown // cấu trúc lồng: [{ name, children: [...] }]
}
export interface PrepInput {
  name?: unknown
  offsetDays?: unknown
  detail?: unknown
}

/** 1 hàng bước sau chuẩn hoá: phẳng theo thứ tự depth-first (cha trước con) */
export interface StepTreeRow {
  name: string
  lotCount: number
  rowsPerLot: number
  note: string
  order: number
  tmpId: string
  parentTmpId: string | null
}

let tmpSeq = 0
function nextTmpId(): string {
  tmpSeq += 1
  return `tmp-${Date.now().toString(36)}-${tmpSeq}`
}

/**
 * Chuẩn hoá mảng bước gửi lên → hàng phẳng depth-first (cha ngay trước con).
 * Chấp nhận CẢ HAI dạng:
 *  (a) phẳng kèm id/parentId tạm:  [{id:'tmp-1',…},{id:'tmp-2',parentId:'tmp-1',…}]
 *  (b) lồng children:               [{…,children:[{…,children:[…]}]}]
 * parentId trỏ id không tồn tại / tham chiếu tới bước chưa xuất hiện → coi là gốc.
 */
export function parseStepTree(steps: unknown[]): StepTreeRow[] {
  const rows: StepTreeRow[] = []
  const seen = new Set<string>()

  const walk = (arr: unknown[], parentTmpId: string | null) => {
    for (const s of arr) {
      if (!s || typeof s !== 'object') continue
      const item = s as StepInput
      const name = String(item.name || '').trim()
      if (!name) {
        // bước rỗng nhưng có children → vẫn duyệt con (không mất bước con)
        if (Array.isArray(item.children)) walk(item.children, parentTmpId)
        continue
      }
      const tmpId =
        typeof item.id === 'string' && item.id.trim() ? item.id.trim() : nextTmpId()
      rows.push({
        name,
        lotCount: toPosInt(item.lotCount, 1),
        rowsPerLot: toPosInt(item.rowsPerLot, 1),
        note: String(item.note || ''),
        order: rows.length,
        tmpId,
        parentTmpId,
      })
      seen.add(tmpId)
      if (Array.isArray(item.children) && item.children.length) {
        walk(item.children, tmpId)
      }
    }
  }

  // Dạng (b) lồng children → ưu tiên xử lý cấu trúc lồng
  const hasNested = steps.some(
    (s) => s && typeof s === 'object' && Array.isArray((s as StepInput).children),
  )
  if (hasNested) {
    walk(steps, null)
  } else {
    // Dạng (a) phẳng kèm parentId tạm
    for (const s of steps) {
      if (!s || typeof s !== 'object') continue
      const item = s as StepInput
      const name = String(item.name || '').trim()
      if (!name) continue
      const tmpId = typeof item.id === 'string' && item.id.trim() ? item.id.trim() : nextTmpId()
      const pid =
        typeof item.parentId === 'string' && item.parentId.trim() ? item.parentId.trim() : null
      rows.push({
        name,
        lotCount: toPosInt(item.lotCount, 1),
        rowsPerLot: toPosInt(item.rowsPerLot, 1),
        note: String(item.note || ''),
        order: rows.length,
        tmpId,
        parentTmpId: pid,
      })
      seen.add(tmpId)
    }
    // parentId trỏ tới id không có trong danh sách → hạ xuống gốc
    for (const r of rows) {
      if (r.parentTmpId && !seen.has(r.parentTmpId)) r.parentTmpId = null
    }
  }

  // Tham chiếu vòng / parentId trỏ chính mình → hạ xuống gốc
  for (const r of rows) {
    if (r.parentTmpId === r.tmpId) r.parentTmpId = null
  }
  return rows
}

/** @deprecated dùng parseStepTree (bước con nhiều cấp) — giữ cho client cũ */
export function parseStepRows(steps: unknown[]): {
  name: string
  lotCount: number
  rowsPerLot: number
  note: string
  order: number
}[] {
  return parseStepTree(steps).map((r) => ({
    name: r.name,
    lotCount: r.lotCount,
    rowsPerLot: r.rowsPerLot,
    note: r.note,
    order: r.order,
  }))
}

// ---------------------------------------------------------------------
// Helper cây (client) — dựng cây từ danh sách phẳng kèm parentId
// ---------------------------------------------------------------------

export interface FlatNode {
  id: string
  parentId?: string | null
  order?: number
}
export interface TreeNode<T extends FlatNode> {
  data: T
  children: TreeNode<T>[]
}

/** Dựng cây từ danh sách phẳng (phải sort theo order trước); mồ côi → gốc */
export function buildTree<T extends FlatNode>(items: T[]): TreeNode<T>[] {
  const byId = new Map<string, TreeNode<T>>()
  for (const it of items) byId.set(it.id, { data: it, children: [] })
  const roots: TreeNode<T>[] = []
  for (const node of byId.values()) {
    const pid = node.data.parentId
    const parent = pid ? byId.get(pid) : undefined
    if (parent && parent !== node) parent.children.push(node)
    else roots.push(node)
  }
  return roots
}

/** Duyệt cây depth-first → danh sách phẳng (node kèm depth) */
export function flattenTree<T extends FlatNode>(
  nodes: TreeNode<T>[],
  depth = 0,
): { node: TreeNode<T>; depth: number }[] {
  const out: { node: TreeNode<T>; depth: number }[] = []
  for (const n of nodes) {
    out.push({ node: n, depth })
    if (n.children.length) out.push(...flattenTree(n.children, depth + 1))
  }
  return out
}

/** Chuẩn hoá mảng điều kiện chuẩn bị → hàng WorkPrep */
export function parsePrepRows(preps: unknown[]): {
  name: string
  offsetDays: number
  detail: string
  order: number
}[] {
  const rows: { name: string; offsetDays: number; detail: string; order: number }[] = []
  for (const p of preps) {
    if (!p || typeof p !== 'object') continue
    const item = p as PrepInput
    const name = String(item.name || '').trim()
    if (!name) continue
    rows.push({
      name,
      offsetDays: toPosInt(item.offsetDays, 1),
      detail: String(item.detail || ''),
      order: rows.length,
    })
  }
  return rows
}
