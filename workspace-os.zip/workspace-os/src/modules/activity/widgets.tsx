'use client'

import { useEffect, useState, useCallback } from 'react'
import { api, timeAgo } from '@/core/client/api'
import { bus } from '@/core/client/event-bus'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Activity, Loader2 } from 'lucide-react'

interface LogRow {
  id: string
  userName: string
  module: string
  action: string
  detail: string
  createdAt: string
}

/** Widget: Activity Log (BOTTOM) */
export function ActivityFeedWidget() {
  const [logs, setLogs] = useState<LogRow[] | null>(null)

  const load = useCallback(async () => {
    try {
      const data = await api<{ logs: LogRow[] }>('/api/core/activity?limit=8')
      setLogs(data.logs)
    } catch {
      setLogs([])
    }
  }, [])

  useEffect(() => {
    load()
    return bus.onAny(() => load())
  }, [load])

  return (
    <Card className="wos-glass border-0">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="flex items-center gap-2 text-sm font-semibold">
          <Activity className="h-4 w-4 text-cyan-500" /> Activity Log
        </CardTitle>
        <span className="text-[11px] text-muted-foreground">24h qua</span>
      </CardHeader>
      <CardContent>
        {logs === null ? (
          <div className="flex h-24 items-center justify-center">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        ) : logs.length === 0 ? (
          <p className="py-6 text-center text-sm text-muted-foreground">Chưa có log nào</p>
        ) : (
          <div className="space-y-1">
            {logs.slice(0, 6).map((l) => (
              <div key={l.id} className="flex items-center gap-2 rounded-lg px-2 py-1 text-sm hover:bg-muted">
                <span className="rounded bg-muted px-1.5 py-0.5 text-[10px] font-medium uppercase">{l.module}</span>
                <span className="min-w-0 flex-1 truncate">
                  <span className="font-medium">{l.userName}</span> {l.detail}
                </span>
                <span className="shrink-0 text-[11px] text-muted-foreground">{timeAgo(l.createdAt)}</span>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
