'use client'

import { useEffect, useState, useCallback } from 'react'
import { useWos } from '@/core/client/wos-store'
import { api, timeAgo } from '@/core/client/api'
import { bus } from '@/core/client/event-bus'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Activity, Loader2, Search, Filter, RefreshCw, User, Layers, Zap, Clock3, Copy, Trash2, Eraser } from 'lucide-react'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Label } from '@/components/ui/label'
import { toast as sonner } from 'sonner'

interface LogRow {
  id: string
  userId: string | null
  userName: string
  module: string
  action: string
  detail: string
  createdAt: string
}

/** Activity Log — lọc theo người dùng / module / thời gian / loại hành động */
export default function ActivityPage() {
  const { modules, user } = useWos()
  const [logs, setLogs] = useState<LogRow[] | null>(null)
  const [showCleanup, setShowCleanup] = useState(false)
  const [cleanupMode, setCleanupMode] = useState('30')
  const [cleaning, setCleaning] = useState(false)
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [moduleFilter, setModuleFilter] = useState('all')
  const [userFilter, setUserFilter] = useState('all')
  const [actionFilter, setActionFilter] = useState('all')
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')
  const [query, setQuery] = useState('')
  const [loading, setLoading] = useState(false)
  const [showFilters, setShowFilters] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams({
        page: String(page),
        limit: '50',
        module: moduleFilter,
        userId: userFilter,
        action: actionFilter,
        ...(from ? { from: new Date(from).toISOString() } : {}),
        ...(to ? { to: new Date(to + 'T23:59:59').toISOString() } : {}),
        ...(query ? { q: query } : {}),
      })
      const data = await api<{ logs: LogRow[]; total: number; modules: string[] }>(`/api/core/activity?${params}`)
      setLogs(data.logs)
      setTotal(data.total)
    } catch {
      setLogs([])
    } finally {
      setLoading(false)
    }
  }, [page, moduleFilter, userFilter, actionFilter, from, to, query])

  useEffect(() => {
    load()
  }, [load])

  useEffect(() => {
    return bus.onAny(() => {
      // Co giãn nhẹ: chỉ refetch khi đứng ở trang 1
      if (page === 1) setTimeout(load, 800)
    })
  }, [load, page])

  const totalPages = Math.max(1, Math.ceil(total / 50))

  /** Click 1 dòng → copy thông tin (user yêu cầu) */
  function copyRow(l: LogRow) {
    const text = `[${new Date(l.createdAt).toLocaleString('vi-VN')}] ${l.userName || '—'} · ${l.module} · ${l.action} · ${l.detail}`
    navigator.clipboard.writeText(text).then(
      () => sonner.success('Đã copy thông tin', { description: text.slice(0, 90) }),
      () => sonner.error('Không copy được'),
    )
  }

  async function runCleanup() {
    setCleaning(true)
    try {
      const body = cleanupMode === 'all' ? { all: true } : { olderThan: Number(cleanupMode) }
      const r = await api<{ deleted: number }>('/api/core/activity', { method: 'DELETE', body })
      sonner.success('Đã dọn dẹp Activity', { description: `${r.deleted} bản ghi đã xoá` })
      setShowCleanup(false)
      load()
    } catch (err) {
      sonner.error('Dọn dẹp thất bại', { description: err instanceof Error ? err.message : '' })
    } finally {
      setCleaning(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <h1 className="flex items-center gap-2.5 text-xl font-bold">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-cyan-500 text-white">
            <Activity className="h-5 w-5" />
          </span>
          Activity
          <Badge variant="secondary" className="font-normal">{total} bản ghi</Badge>
        </h1>
        <div className="ml-auto flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Tìm trong log…" className="h-9 w-44 pl-8" />
          </div>
          <Button variant="outline" size="sm" className="h-9 gap-1.5" onClick={() => setShowFilters(!showFilters)}>
            <Filter className="h-4 w-4" /> Bộ lọc
          </Button>
          <Button variant="outline" size="sm" className="h-9" onClick={load} disabled={loading}>
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </Button>
          {user?.role === 'admin' && (
            <Button variant="outline" size="sm" className="h-9 gap-1.5 text-rose-600" onClick={() => setShowCleanup(true)}>
              <Eraser className="h-4 w-4" /> Dọn dẹp
            </Button>
          )}
        </div>
      </div>

      {showFilters && (
        <Card className="wos-glass border-0">
          <CardContent className="grid grid-cols-2 gap-3 py-4 md:grid-cols-5">
            <div>
              <p className="mb-1.5 flex items-center gap-1 text-[11px] font-medium text-muted-foreground"><Layers className="h-3 w-3" /> Module</p>
              <Select value={moduleFilter} onValueChange={(v) => { setModuleFilter(v); setPage(1) }}>
                <SelectTrigger className="h-9 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tất cả</SelectItem>
                  {[...new Set(logs?.map((l) => l.module) || [])].map((m) => (
                    <SelectItem key={m} value={m}>{m}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <p className="mb-1.5 flex items-center gap-1 text-[11px] font-medium text-muted-foreground"><User className="h-3 w-3" /> Người dùng</p>
              <Select value={userFilter} onValueChange={(v) => { setUserFilter(v); setPage(1) }}>
                <SelectTrigger className="h-9 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tất cả</SelectItem>
                  {[...new Set(logs?.map((l) => l.userName).filter(Boolean) || [])].slice(0, 20).map((u) => (
                    <SelectItem key={u} value={logs?.find((l) => l.userName === u)?.userId || 'all'}>{u}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <p className="mb-1.5 flex items-center gap-1 text-[11px] font-medium text-muted-foreground"><Zap className="h-3 w-3" /> Hành động</p>
              <Select value={actionFilter} onValueChange={(v) => { setActionFilter(v); setPage(1) }}>
                <SelectTrigger className="h-9 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tất cả</SelectItem>
                  {[...new Set(logs?.map((l) => l.action) || [])].slice(0, 30).map((a) => (
                    <SelectItem key={a} value={a}>{a}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <p className="mb-1.5 flex items-center gap-1 text-[11px] font-medium text-muted-foreground"><Clock3 className="h-3 w-3" /> Từ ngày</p>
              <Input type="date" value={from} onChange={(e) => { setFrom(e.target.value); setPage(1) }} className="h-9" />
            </div>
            <div>
              <p className="mb-1.5 flex items-center gap-1 text-[11px] font-medium text-muted-foreground"><Clock3 className="h-3 w-3" /> Đến ngày</p>
              <Input type="date" value={to} onChange={(e) => { setTo(e.target.value); setPage(1) }} className="h-9" />
            </div>
          </CardContent>
        </Card>
      )}

      <Card className="wos-glass overflow-hidden border-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[130px]">Thời gian</TableHead>
              <TableHead className="w-[130px]">Người dùng</TableHead>
              <TableHead className="w-[90px]">Module</TableHead>
              <TableHead className="w-[130px]">Hành động</TableHead>
              <TableHead>Chi tiết</TableHead>
              <TableHead className="w-8" />
            </TableRow>
          </TableHeader>
          <TableBody>
            {logs === null ? (
              <TableRow>
                <TableCell colSpan={6} className="py-16 text-center">
                  <Loader2 className="mx-auto h-6 w-6 animate-spin text-muted-foreground" />
                </TableCell>
              </TableRow>
            ) : logs.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="py-16 text-center text-sm text-muted-foreground">
                  Không có log khớp bộ lọc
                </TableCell>
              </TableRow>
            ) : (
              logs.map((l) => (
                <TableRow key={l.id} className="cursor-copy" onClick={() => copyRow(l)} title="Bấm để copy dòng này">
                  <TableCell className="text-xs tabular-nums text-muted-foreground">
                    {new Date(l.createdAt).toLocaleString('vi-VN', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}
                  </TableCell>
                  <TableCell className="font-medium">{l.userName || '—'}</TableCell>
                  <TableCell>
                    <Badge variant="secondary" className="text-[10px] uppercase">{modules.find((m) => m.id === l.module)?.name || l.module}</Badge>
                  </TableCell>
                  <TableCell className="font-mono text-[11px] text-muted-foreground">{l.action}</TableCell>
                  <TableCell className="text-sm">{l.detail}</TableCell>
                  <TableCell className="w-8 text-muted-foreground/50"><Copy className="h-3.5 w-3.5" /></TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </Card>

      {total > 50 && (
        <div className="flex items-center justify-center gap-3">
          <Button variant="outline" size="sm" className="h-8" disabled={page <= 1} onClick={() => setPage(page - 1)}>
            Trang trước
          </Button>
          <span className="text-sm tabular-nums text-muted-foreground">{page} / {totalPages}</span>
          <Button variant="outline" size="sm" className="h-8" disabled={page >= totalPages} onClick={() => setPage(page + 1)}>
            Trang sau
          </Button>
        </div>
      )}
      {/* Dialog dọn dẹp dữ liệu */}
      <Dialog open={showCleanup} onOpenChange={setShowCleanup}>
        <DialogContent className="wos-glass-strong sm:max-w-[380px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><Eraser className="h-4 w-4" /> Dọn dẹp Activity Log</DialogTitle>
          </DialogHeader>
          <RadioGroup value={cleanupMode} onValueChange={setCleanupMode} className="gap-2">
            {[
              ['7', 'Giữ 7 ngày gần nhất'],
              ['30', 'Giữ 30 ngày gần nhất'],
              ['90', 'Giữ 90 ngày gần nhất'],
              ['all', 'Xoá TOÀN BỘ log'],
            ].map(([v, label]) => (
              <div key={v} className="flex items-center gap-2.5 rounded-xl bg-muted/50 px-3 py-2.5">
                <RadioGroupItem value={v} id={`cl-${v}`} />
                <Label htmlFor={`cl-${v}`} className="cursor-pointer text-sm font-normal">{label}</Label>
              </div>
            ))}
          </RadioGroup>
          <div className="flex justify-end gap-2">
            <Button variant="outline" size="sm" onClick={() => setShowCleanup(false)}>Huỷ</Button>
            <Button variant="destructive" size="sm" className="gap-1.5" onClick={runCleanup} disabled={cleaning}>
              {cleaning ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />} Dọn dẹp
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
