'use client'

import { useEffect, useState, useCallback } from 'react'
import { useWos } from '@/core/client/wos-store'
import { api, fmtDate } from '@/core/client/api'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { useToast } from '@/hooks/use-toast'
import { Users, Plus, Trash2, Pencil, Loader2, Shield, UserPlus, KeyRound, LogIn, FolderLock } from 'lucide-react'

interface UserRow {
  id: string
  username: string
  email: string | null
  displayName: string
  role: string
  avatarColor: string
  active: boolean
  group: { id: string; name: string } | null
  sessionCount: number
  createdAt: string
  permissions?: { modules?: string[] | null; allowFiles?: boolean } | null
}
interface GroupRow { id: string; name: string; description: string; userCount: number }
interface ResetCodeRow { code: string; username: string; displayName: string; expiresAt: string }

const ROLE_LABEL: Record<string, string> = { admin: 'Quản trị', member: 'Thành viên', viewer: 'Chỉ xem' }
const ROLE_COLOR: Record<string, string> = { admin: 'bg-rose-500', member: 'bg-emerald-500', viewer: 'bg-slate-400' }

/** Trạng thái quyền trong form — all = được dùng mọi module */
interface PermForm {
  all: boolean
  modules: string[]
  allowFiles: boolean
}

const EMPTY_PERM: PermForm = { all: true, modules: [], allowFiles: true }

/** Editor quyền hạn riêng của tài khoản (dùng chung dialog tạo + sửa) */
function PermissionsEditor({
  modules,
  value,
  onChange,
  disabled,
}: {
  modules: { id: string; name: string; color: string }[]
  value: PermForm
  onChange: (v: PermForm) => void
  disabled?: boolean
}) {
  return (
    <div className={`rounded-xl border border-border bg-muted/40 p-3 ${disabled ? 'opacity-50' : ''}`}>
      <p className="mb-2 flex items-center gap-1.5 text-xs font-semibold">
        <Shield className="h-3.5 w-3.5 text-primary" /> Quyền hạn của tài khoản này
      </p>
      {disabled ? (
        <p className="text-[11px] text-muted-foreground">Tài khoản Quản trị luôn có toàn quyền.</p>
      ) : (
        <div className="space-y-2.5">
          <label className="flex cursor-pointer items-center gap-2 text-[12.5px]">
            <input
              type="checkbox"
              checked={value.all}
              onChange={(e) => onChange({ ...value, all: e.target.checked })}
              className="h-3.5 w-3.5 accent-emerald-600"
            />
            <span className="font-medium">Cho phép dùng TẤT CẢ module</span>
          </label>
          {!value.all && (
            <div className="grid max-h-44 grid-cols-2 gap-1 overflow-y-auto rounded-lg bg-background/60 p-2">
              {modules.map((m) => {
                const on = value.modules.includes(m.id)
                return (
                  <label
                    key={m.id}
                    className="flex cursor-pointer items-center gap-1.5 rounded-md px-1.5 py-1 text-[12px] hover:bg-muted"
                  >
                    <input
                      type="checkbox"
                      checked={on}
                      onChange={(e) => {
                        const next = e.target.checked
                          ? [...value.modules, m.id]
                          : value.modules.filter((x) => x !== m.id)
                        onChange({ ...value, modules: next })
                      }}
                      className="h-3.5 w-3.5 accent-emerald-600"
                    />
                    <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: m.color }} />
                    <span className="truncate">{m.name}</span>
                  </label>
                )
              })}
            </div>
          )}
          <label className="flex cursor-pointer items-center gap-2 rounded-lg bg-background/60 px-2.5 py-1.5 text-[12.5px]">
            <input
              type="checkbox"
              checked={value.allowFiles}
              onChange={(e) => onChange({ ...value, allowFiles: e.target.checked })}
              className="h-3.5 w-3.5 accent-emerald-600"
            />
            <FolderLock className="h-3.5 w-3.5 text-muted-foreground" />
            <span>
              Cho phép dùng <b>File Manager</b>
              <span className="text-muted-foreground"> — bỏ chọn để khoá icon file, upload, thùng rác, xem tệp</span>
            </span>
          </label>
          {!value.allowFiles && (
            <p className="text-[11px] text-amber-600 dark:text-amber-400">File Manager sẽ bị khoá hoàn toàn cho tài khoản này (kể cả API + desktop).</p>
          )}
        </div>
      )}
    </div>
  )
}

export default function UsersPage() {
  const { user, emit } = useWos()
  const { toast } = useToast()
  const [tab, setTab] = useState<'users' | 'groups' | 'permissions'>('users')
  const [users, setUsers] = useState<UserRow[] | null>(null)
  const [groups, setGroups] = useState<GroupRow[]>([])
  const [resetCodes, setResetCodes] = useState<ResetCodeRow[]>([])
  const [modules, setModules] = useState<{ id: string; name: string; color: string }[]>([])
  const [editing, setEditing] = useState<UserRow | null>(null)
  const [creating, setCreating] = useState(false)
  const [newUsername, setNewUsername] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [newDisplayName, setNewDisplayName] = useState('')
  const [newRole, setNewRole] = useState('member')
  const [newPerm, setNewPerm] = useState<PermForm>(EMPTY_PERM)
  const [editName, setEditName] = useState('')
  const [editEmail, setEditEmail] = useState('')
  const [editRole, setEditRole] = useState('member')
  const [editPassword, setEditPassword] = useState('')
  const [editPerm, setEditPerm] = useState<PermForm>(EMPTY_PERM)
  const [groupCreating, setGroupCreating] = useState(false)
  const [newGroupName, setNewGroupName] = useState('')

  const load = useCallback(async () => {
    try {
      const data = await api<{ users: UserRow[]; groups: GroupRow[]; resetCodes?: ResetCodeRow[] }>('/api/core/users')
      setUsers(data.users)
      setGroups(data.groups)
      setResetCodes(data.resetCodes || [])
      const mods = await api<{ modules: { id: string; name: string; color: string; enabled: boolean; permissions: Record<string, string[]> }[] }>('/api/core/modules')
      setModules(mods.modules.map((m) => ({ id: m.id, name: m.name, color: m.color })))
    } catch {
      setUsers([])
    }
  }, [])

  useEffect(() => {
    load()
  }, [load])

  async function createUser() {
    try {
      await api('/api/core/users', {
        method: 'POST',
        body: {
          username: newUsername,
          password: newPassword,
          displayName: newDisplayName,
          role: newRole,
          permissions: newRole === 'admin' || newPerm.all ? null : { modules: newPerm.modules, allowFiles: newPerm.allowFiles },
        },
      })
      emit('user.created', 'core', { name: newUsername })
      setCreating(false)
      setNewUsername(''); setNewPassword(''); setNewDisplayName(''); setNewRole('member'); setNewPerm(EMPTY_PERM)
      load()
      toast({ title: 'Đã tạo người dùng' })
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  async function saveUser() {
    if (!editing) return
    try {
      const body: Record<string, unknown> = {
        displayName: editName,
        email: editEmail,
        role: editRole,
        permissions: editRole === 'admin' || editPerm.all ? null : { modules: editPerm.modules, allowFiles: editPerm.allowFiles },
      }
      if (editPassword) body.password = editPassword
      await api(`/api/core/users/${editing.id}`, { method: 'PATCH', body })
      emit('user.updated', 'core', { name: editing.username })
      setEditing(null)
      load()
      toast({ title: 'Đã cập nhật' })
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  async function toggleActive(u: UserRow) {
    try {
      await api(`/api/core/users/${u.id}`, { method: 'PATCH', body: { active: !u.active } })
      emit('user.updated', 'core', { name: u.username })
      load()
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  async function deleteUser(u: UserRow) {
    if (!confirm(`Xoá người dùng "${u.username}"?`)) return
    try {
      await api(`/api/core/users/${u.id}`, { method: 'DELETE' })
      emit('user.deleted', 'core', { name: u.username })
      load()
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  async function createGroup() {
    if (!newGroupName.trim()) return
    try {
      await api('/api/core/groups', { method: 'POST', body: { name: newGroupName.trim() } })
      emit('group.created', 'core', { name: newGroupName })
      setGroupCreating(false)
      setNewGroupName('')
      load()
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  if (users === null) {
    return <div className="flex h-64 items-center justify-center"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <h1 className="flex items-center gap-2.5 text-xl font-bold">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-pink-500 text-white">
            <Users className="h-5 w-5" />
          </span>
          Administration
        </h1>
        <div className="ml-auto flex items-center gap-2">
          {tab === 'users' && (
            <Button size="sm" className="h-9 gap-1.5" onClick={() => setCreating(true)}>
              <UserPlus className="h-4 w-4" /> Người dùng mới
            </Button>
          )}
          {tab === 'groups' && (
            <Button size="sm" className="h-9 gap-1.5" onClick={() => setGroupCreating(true)}>
              <Plus className="h-4 w-4" /> Nhóm mới
            </Button>
          )}
        </div>
      </div>

      <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)}>
        <TabsList className="h-9">
          <TabsTrigger value="users" className="gap-1.5 px-4"><Users className="h-4 w-4" /> Users</TabsTrigger>
          <TabsTrigger value="groups" className="gap-1.5 px-4">Groups</TabsTrigger>
          <TabsTrigger value="permissions" className="gap-1.5 px-4"><Shield className="h-4 w-4" /> Permissions</TabsTrigger>
        </TabsList>
      </Tabs>

      {tab === 'users' && resetCodes.length > 0 && (
        <Card className="wos-glass border-amber-500/30 bg-amber-500/5">
          <CardContent className="flex flex-wrap items-center gap-x-6 gap-y-2 p-4 text-sm">
            <div className="flex items-center gap-2 font-medium text-amber-600 dark:text-amber-300">
              <KeyRound className="h-4 w-4" /> Mã đặt lại đang hiệu lực
            </div>
            {resetCodes.map((r) => (
              <div key={r.code} className="flex items-center gap-2 text-muted-foreground">
                <span className="font-semibold text-foreground">{r.displayName}</span>
                <code className="rounded-md bg-amber-500/15 px-2 py-0.5 font-mono tracking-widest text-amber-700 dark:text-amber-300">{r.code}</code>
                <span className="text-xs">đến {new Date(r.expiresAt).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}</span>
              </div>
            ))}
            <p className="w-full text-xs text-muted-foreground">
              Mã chỉ hiển thị cho quản trị viên — đưa mã cho người dùng qua kênh tin cậy (trò chuyện trực tiếp/email). Hết hạn sau 15 phút.
            </p>
          </CardContent>
        </Card>
      )}

      {tab === 'users' && (
        <Card className="wos-glass overflow-hidden border-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Người dùng</TableHead>
                <TableHead className="w-28">Vai trò</TableHead>
                <TableHead className="w-32">Trạng thái</TableHead>
                <TableHead className="w-28">Phiên</TableHead>
                <TableHead className="w-32">Tạo</TableHead>
                <TableHead className="w-28 text-right">Thao tác</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.map((u) => (
                <TableRow key={u.id}>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-sm font-semibold text-white" style={{ background: u.avatarColor }}>
                        {u.displayName.slice(0, 1).toUpperCase()}
                      </div>
                      <div className="min-w-0">
                        <p className="flex items-center gap-1.5 truncate text-sm font-medium">
                          {u.displayName} {u.id === user?.id && <Badge variant="secondary" className="h-4 text-[9px]">bạn</Badge>}
                          {u.role !== 'admin' && u.permissions?.modules && (
                            <Badge variant="secondary" className="h-4 bg-sky-500/15 text-[9px] text-sky-600 dark:text-sky-300" title={`Chỉ được dùng ${u.permissions.modules.length} module`}>
                              giới hạn {u.permissions.modules.length} module
                            </Badge>
                          )}
                          {u.role !== 'admin' && u.permissions?.allowFiles === false && (
                            <Badge variant="secondary" className="h-4 bg-amber-500/15 text-[9px] text-amber-600 dark:text-amber-300" title="File Manager bị khoá">
                              khoá file
                            </Badge>
                          )}
                        </p>
                        <p className="truncate text-xs text-muted-foreground">@{u.username}{u.email ? ` · ${u.email}` : ''}</p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <span className={`inline-flex rounded-full px-2.5 py-0.5 text-[11px] font-medium text-white ${ROLE_COLOR[u.role]}`}>
                      {ROLE_LABEL[u.role]}
                    </span>
                  </TableCell>
                  <TableCell>
                    <button onClick={() => toggleActive(u)} disabled={u.id === user?.id} className="disabled:cursor-not-allowed">
                      <Badge variant={u.active ? 'default' : 'secondary'} className="cursor-pointer">
                        {u.active ? 'Hoạt động' : 'Vô hiệu'}
                      </Badge>
                    </button>
                  </TableCell>
                  <TableCell className="text-sm tabular-nums">
                    <span className="flex items-center gap-1"><LogIn className="h-3 w-3 text-muted-foreground" />{u.sessionCount}</span>
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">{fmtDate(u.createdAt)}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      <Button
                        size="sm" variant="ghost" className="h-8 w-8 p-0"
                        onClick={() => {
                          setEditing(u)
                          setEditName(u.displayName)
                          setEditEmail(u.email || '')
                          setEditRole(u.role)
                          setEditPassword('')
                          setEditPerm({
                            all: !u.permissions?.modules,
                            modules: u.permissions?.modules || [],
                            allowFiles: u.permissions?.allowFiles !== false,
                          })
                        }}
                        aria-label="Sửa"
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm" variant="ghost" className="h-8 w-8 p-0 text-rose-500"
                        onClick={() => deleteUser(u)}
                        disabled={u.id === user?.id}
                        aria-label="Xoá"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}

      {tab === 'groups' && (
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
          {groups.length === 0 && (
            <div className="wos-glass col-span-full flex flex-col items-center gap-2 rounded-2xl py-12 text-muted-foreground">
              <Users className="h-10 w-10 opacity-30" />
              <p className="text-sm">Chưa có nhóm nào</p>
            </div>
          )}
          {groups.map((g) => (
            <Card key={g.id} className="wos-glass border-0">
              <CardContent className="flex items-center justify-between py-4">
                <div>
                  <p className="font-semibold">{g.name}</p>
                  <p className="text-xs text-muted-foreground">{g.description || 'Không mô tả'} · {g.userCount} thành viên</p>
                </div>
                <Button
                  size="sm" variant="ghost" className="h-8 w-8 p-0 text-rose-500"
                  onClick={async () => {
                    if (!confirm(`Xoá nhóm "${g.name}"?`)) return
                    await api(`/api/core/groups/${g.id}`, { method: 'DELETE' })
                    load()
                  }}
                  aria-label="Xoá nhóm"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {tab === 'permissions' && (
        <Card className="wos-glass overflow-hidden border-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Module</TableHead>
                <TableHead className="w-32 text-center">Quản trị</TableHead>
                <TableHead className="w-32 text-center">Thành viên</TableHead>
                <TableHead className="w-32 text-center">Chỉ xem</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {modules.map((m) => (
                <TableRow key={m.id}>
                  <TableCell>
                    <div className="flex items-center gap-2.5">
                      <span className="h-2.5 w-2.5 rounded-full" style={{ background: m.color }} />
                      <span className="text-sm font-medium">{m.name}</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-center text-xs text-emerald-600 font-medium">Toàn quyền</TableCell>
                  <TableCell className="text-center text-xs text-amber-600 font-medium">Đọc + Ghi</TableCell>
                  <TableCell className="text-center text-xs text-muted-foreground">Chỉ đọc</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <CardContent className="border-t px-4 py-3">
            <p className="text-xs text-muted-foreground">
              Ma trận quyền theo vai trò (RBAC). Tinh chỉnh chi tiết từng module trong Settings → Modules → Permissions.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Dialog tạo user */}
      <Dialog open={creating} onOpenChange={setCreating}>
        <DialogContent className="wos-glass-strong max-h-[88vh] overflow-y-auto sm:max-w-[440px]">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><UserPlus className="h-4 w-4" /> Người dùng mới</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <p className="text-xs text-muted-foreground">Mỗi tài khoản có dữ liệu và giao diện hoàn toàn riêng biệt</p>
            <Input value={newUsername} onChange={(e) => setNewUsername(e.target.value)} placeholder="Tên đăng nhập (a-z, 0-9)" autoCapitalize="none" />
            <Input value={newDisplayName} onChange={(e) => setNewDisplayName(e.target.value)} placeholder="Tên hiển thị" />
            <Input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} placeholder="Mật khẩu (≥ 6 ký tự)" />
            <Select value={newRole} onValueChange={setNewRole}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {Object.entries(ROLE_LABEL).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
              </SelectContent>
            </Select>
            <PermissionsEditor modules={modules} value={newPerm} onChange={setNewPerm} disabled={newRole === 'admin'} />
            <div className="flex justify-end gap-2">
              <Button variant="outline" size="sm" onClick={() => setCreating(false)}>Huỷ</Button>
              <Button
                size="sm"
                onClick={createUser}
                disabled={!newUsername.trim() || newPassword.length < 6 || (newRole !== 'admin' && !newPerm.all && newPerm.modules.length === 0)}
              >
                Tạo
              </Button>
            </div>
            {newRole !== 'admin' && !newPerm.all && newPerm.modules.length === 0 && (
              <p className="text-[11px] text-amber-600">Chọn ít nhất 1 module hoặc bật "TẤT CẢ module".</p>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Dialog sửa user */}
      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="wos-glass-strong max-h-[88vh] overflow-y-auto sm:max-w-[440px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-full text-sm font-semibold text-white" style={{ background: editing?.avatarColor }}>
                {editing?.displayName.slice(0, 1).toUpperCase()}
              </div>
              @{editing?.username}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Input value={editName} onChange={(e) => setEditName(e.target.value)} placeholder="Tên hiển thị" />
            <Input value={editEmail} onChange={(e) => setEditEmail(e.target.value)} placeholder="Email" />
            <Select value={editRole} onValueChange={setEditRole}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {Object.entries(ROLE_LABEL).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
              </SelectContent>
            </Select>
            <div className="flex items-center gap-2">
              <KeyRound className="h-4 w-4 shrink-0 text-muted-foreground" />
              <Input type="password" value={editPassword} onChange={(e) => setEditPassword(e.target.value)} placeholder="Đặt lại mật khẩu (để trống giữ nguyên)" />
            </div>
            <PermissionsEditor modules={modules} value={editPerm} onChange={setEditPerm} disabled={editRole === 'admin'} />
            <p className="text-[11px] text-muted-foreground">Đổi quyền hạn áp dụng gần như ngay lập tức (tối đa 30 giây).</p>
            <div className="flex justify-end gap-2">
              <Button variant="outline" size="sm" onClick={() => setEditing(null)}>Huỷ</Button>
              <Button
                size="sm"
                onClick={saveUser}
                disabled={editRole !== 'admin' && !editPerm.all && editPerm.modules.length === 0}
              >
                Lưu
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Dialog tạo group */}
      <Dialog open={groupCreating} onOpenChange={setGroupCreating}>
        <DialogContent className="wos-glass-strong sm:max-w-[360px]">
          <DialogHeader><DialogTitle>Nhóm mới</DialogTitle></DialogHeader>
          <Input value={newGroupName} onChange={(e) => setNewGroupName(e.target.value)} placeholder="Tên nhóm" autoFocus />
          <div className="flex justify-end gap-2">
            <Button variant="outline" size="sm" onClick={() => setGroupCreating(false)}>Huỷ</Button>
            <Button size="sm" onClick={createGroup} disabled={!newGroupName.trim()}>Tạo</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
