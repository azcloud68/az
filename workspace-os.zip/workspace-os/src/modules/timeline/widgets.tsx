'use client'

import { useEffect, useState, useCallback } from 'react'
import { useWos } from '@/core/client/wos-store'
import { api, timeAgo } from '@/core/client/api'
import { eventLabel } from '@/core/client/event-bus'
import { bus } from '@/core/client/event-bus'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { GitCommitHorizontal, Loader2 } from 'lucide-react'

interface EventRow {
  id: string
  type: string
  module: string
  actorName: string
  payload: { title?: string; name?: string }
  createdAt: string
}

/** Widget: Hoạt động gần đây — đọc từ Event Bus (CENTER) */
export function TimelineFeedWidget() {
  const { navigate } = useWos()
  const [events, setEvents] = useState<EventRow[] | null>(null)

  const load = useCallback(async () => {
    try {
      const data = await api<{ events: EventRow[] }>('/api/core/timeline?limit=8')
      setEvents(data.events)
    } catch {
      setEvents([])
    }
  }, [])

  useEffect(() => {
    load()
    return bus.onAny(() => load())
  }, [load])

  return (
    <Card className="wos-glass border-0">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="flex items-center gap-2 text-sm font-semibold">
          <GitCommitHorizontal className="h-4 w-4 text-teal-500" /> Hoạt động gần đây
        </CardTitle>
        <button onClick={() => navigate('timeline')} className="text-xs text-primary hover:underline">
          Timeline
        </button>
      </CardHeader>
      <CardContent>
        {events === null ? (
          <div className="flex h-24 items-center justify-center">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        ) : events.length === 0 ? (
          <p className="py-6 text-center text-sm text-muted-foreground">Chưa có hoạt động nào được ghi</p>
        ) : (
          <div className="relative space-y-3 pl-4">
            <div className="absolute bottom-2 left-[5px] top-2 w-px bg-border" />
            {events.slice(0, 6).map((e) => (
              <div key={e.id} className="relative flex items-center gap-2 text-sm">
                <span className="absolute -left-4 h-2.5 w-2.5 rounded-full border-2 border-background bg-primary" />
                <span className="font-medium">{e.actorName || 'Hệ thống'}</span>
                <span className="text-muted-foreground">{eventLabel(e.type)}</span>
                {e.payload?.title && <span className="truncate font-medium text-primary/90">"{e.payload.title}"</span>}
                <span className="ml-auto shrink-0 text-[11px] text-muted-foreground">{timeAgo(e.createdAt)}</span>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
