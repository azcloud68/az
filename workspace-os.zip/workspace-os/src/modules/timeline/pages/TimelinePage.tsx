'use client'

import { useEffect, useState, useCallback } from 'react'
import { useWos } from '@/core/client/wos-store'
import { api, timeAgo } from '@/core/client/api'
import { eventLabel } from '@/core/client/event-bus'
import { bus } from '@/core/client/event-bus'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { GitCommitHorizontal, Loader2, RefreshCw, Copy, Trash2, Eraser } from 'lucide-react'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Label } from '@/components/ui/label'
import { toast as sonner } from 'sonner'

interface EventRow {
  id: string
  type: string
  module: string
  actorId: string | null
  actorName: string
  payload: { title?: string; name?: string; username?: string }
  createdAt: string
}

const MODULE_LABEL: Record<string, string> = {
  core: 'Hệ thống', tasks: 'Tasks', calendar: 'Calendar', notes: 'Notes',
  wiki: 'Wiki', files: 'Files', projects: 'Projects', notifications: 'Notifications',
}

/** Timeline — toàn bộ hoạt động theo thời gian, đọc từ Event Bus */
export default function TimelinePage() {
  const { modules, user } = useWos()
  const [events, setEvents] = useState<EventRow[] | null>(null)
  const [moduleFilter, setModuleFilter] = useState('all')
  const [loading, setLoading] = useState(false)
  const [showCleanup, setShowCleanup] = useState(false)
  const [cleanupMode, setCleanupMode] = useState('30')
  const [cleaning, setCleaning] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const data = await api<{ events: EventRow[] }>(`/api/core/timeline?limit=150&module=${moduleFilter}`)
      setEvents(data.events)
    } catch {
      setEvents([])
    } finally {
      setLoading(false)
    }
  }, [moduleFilter])

  useEffect(() => {
    load()
    return bus.onAny(() => {
      // refetch sau 1s để server ghi event xong
      setTimeout(load, 800)
    })
  }, [load])

  // Nhóm theo ngày
  const groups = new Map<string, EventRow[]>()
  for (const e of events || []) {
    const key = new Date(e.createdAt).toLocaleDateString('vi-VN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })
    if (!groups.has(key)) groups.set(key, [])
    groups.get(key)!.push(e)
  }

  const availableModules = [...new Set(['all', ...(events || []).map((e) => e.module)])].filter((m) =>
    m === 'all' || modules.find((x) => x.id === m)?.enabled !== false
  )

  /** Click sự kiện → copy (user yêu cầu) */
  function copyEvent(e: EventRow) {
    const text = `[${new Date(e.createdAt).toLocaleString('vi-VN')}] ${e.actorName || 'Hệ thống'} ${eventLabel(e.type)} "${e.payload?.title || e.payload?.name || ''}" (${e.module})`
    navigator.clipboard.writeText(text).then(
      () => sonner.success('Đã copy sự kiện', { description: text.slice(0, 90) }),
      () => sonner.error('Không copy được'),
    )
  }

  async function runCleanup() {
    setCleaning(true)
    try {
      const body = cleanupMode === 'all' ? { all: true } : { olderThan: Number(cleanupMode) }
      const r = await api<{ deleted: number }>('/api/core/timeline', { method: 'DELETE', body })
      sonner.success('Đã dọn dẹp Timeline', { description: `${r.deleted} sự kiện đã xoá` })
      setShowCleanup(false)
      load()
    } catch (err) {
      sonner.error('Dọn dẹp thất bại', { description: err instanceof Error ? err.message : '' })
    } finally {
      setCleaning(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <h1 className="flex items-center gap-2.5 text-xl font-bold">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-teal-500 text-white">
            <GitCommitHorizontal className="h-5 w-5" />
          </span>
          Timeline
          <Badge variant="secondary" className="font-normal">{events?.length || 0} sự kiện</Badge>
        </h1>
        <div className="ml-auto flex items-center gap-2">
          <Select value={moduleFilter} onValueChange={setModuleFilter}>
            <SelectTrigger className="h-9 w-36 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent>
              {availableModules.map((m) => (
                <SelectItem key={m} value={m}>{m === 'all' ? 'Mọi module' : MODULE_LABEL[m] || m}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm" className="h-9 gap-1.5" onClick={load} disabled={loading}>
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} /> Làm mới
          </Button>
          {user?.role === 'admin' && (
            <Button variant="outline" size="sm" className="h-9 gap-1.5 text-rose-600" onClick={() => setShowCleanup(true)}>
              <Eraser className="h-4 w-4" /> Dọn dẹp
            </Button>
          )}
        </div>
      </div>

      {events === null ? (
        <div className="flex h-64 items-center justify-center">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </div>
      ) : events.length === 0 ? (
        <div className="wos-glass flex flex-col items-center gap-2 rounded-2xl py-14 text-muted-foreground">
          <GitCommitHorizontal className="h-10 w-10 opacity-30" />
          <p className="text-sm">Chưa có sự kiện nào được ghi vào Event Bus</p>
        </div>
      ) : (
        <div className="space-y-6">
          {[...groups.entries()].map(([day, evs]) => (
            <div key={day}>
              <h2 className="mb-2 px-1 text-sm font-semibold capitalize text-muted-foreground">{day}</h2>
              <Card className="wos-glass border-0">
                <CardContent className="p-0">
                  <div className="relative pl-8">
                    <div className="absolute bottom-3 left-[19px] top-3 w-px bg-border" />
                    {evs.map((e) => (
                      <div key={e.id} className="group relative flex cursor-copy items-start gap-3 border-b py-3 pr-4 last:border-0" onClick={() => copyEvent(e)} title="Bấm để copy sự kiện">
                        <span className="absolute -left-2.5 top-4 h-2.5 w-2.5 rounded-full border-2 border-background bg-primary" />
                        <span className="w-14 shrink-0 pt-0.5 text-xs font-medium tabular-nums text-muted-foreground">
                          {new Date(e.createdAt).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}
                        </span>
                        <div className="min-w-0 flex-1">
                          <p className="text-sm">
                            <span className="font-semibold">{e.actorName || 'Hệ thống'}</span>{' '}
                            <span className="text-muted-foreground">{eventLabel(e.type)}</span>
                            {e.payload?.title && <span className="font-medium"> "{e.payload.title}"</span>}
                          </p>
                          <div className="mt-0.5 flex items-center gap-2">
                            <Badge variant="secondary" className="h-4 px-1.5 text-[9px] uppercase">{MODULE_LABEL[e.module] || e.module}</Badge>
                            <span className="text-[10px] text-muted-foreground">{e.type}</span>
                          </div>
                        </div>
                        <Copy className="h-3.5 w-3.5 shrink-0 text-muted-foreground/0 transition-colors group-hover:text-muted-foreground/60" />
                        <span className="shrink-0 text-[11px] text-muted-foreground">{timeAgo(e.createdAt)}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>
      )}

      {/* Dialog dọn dẹp dữ liệu */}
      <Dialog open={showCleanup} onOpenChange={setShowCleanup}>
        <DialogContent className="wos-glass-strong sm:max-w-[380px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><Eraser className="h-4 w-4" /> Dọn dẹp Timeline</DialogTitle>
          </DialogHeader>
          <RadioGroup value={cleanupMode} onValueChange={setCleanupMode} className="gap-2">
            {[
              ['7', 'Giữ 7 ngày gần nhất'],
              ['30', 'Giữ 30 ngày gần nhất'],
              ['90', 'Giữ 90 ngày gần nhất'],
              ['all', 'Xoá TOÀN BỘ sự kiện'],
            ].map(([v, label]) => (
              <div key={v} className="flex items-center gap-2.5 rounded-xl bg-muted/50 px-3 py-2.5">
                <RadioGroupItem value={v} id={`tl-${v}`} />
                <Label htmlFor={`tl-${v}`} className="cursor-pointer text-sm font-normal">{label}</Label>
              </div>
            ))}
          </RadioGroup>
          <div className="flex justify-end gap-2">
            <Button variant="outline" size="sm" onClick={() => setShowCleanup(false)}>Huỷ</Button>
            <Button variant="destructive" size="sm" className="gap-1.5" onClick={runCleanup} disabled={cleaning}>
              {cleaning ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />} Dọn dẹp
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
