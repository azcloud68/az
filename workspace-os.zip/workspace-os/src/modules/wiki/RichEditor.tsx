'use client'

/**
 * WOS RichEditor — trình soạn thảo rich text cho module Wiki.
 * contentEditable + document.execCommand (pragmatic, chạy tốt mọi browser hiện đại).
 *
 * Đồng bộ innerHTML: chỉ set MỘT LẦN khi mount hoặc khi `value` đổi khác với html
 * mà editor vừa tự emit (đổi trang / reload) — KHÔNG re-render khi parent re-render
 * (tránh caret nhảy + vòng lặp controlled).
 */

import { useEffect, useRef, useState, useCallback, type ReactNode } from 'react'
import { api } from '@/core/client/api'
import { useToast } from '@/hooks/use-toast'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Undo2, Redo2, AlignLeft, AlignCenter, AlignRight, AlignJustify,
  List, ListOrdered, Table, Link2, ImagePlus, TextQuote, Code, Minus, Eraser, Loader2,
} from 'lucide-react'

interface RichEditorProps {
  value: string
  onChange: (html: string) => void
}

const FONT_STACKS: { label: string; css: string }[] = [
  { label: 'Arial', css: 'Arial, Helvetica, sans-serif' },
  { label: 'Georgia', css: 'Georgia, serif' },
  { label: 'Times New Roman', css: "'Times New Roman', Times, serif" },
  { label: 'Courier New', css: "'Courier New', Courier, monospace" },
  { label: 'Verdana', css: 'Verdana, Geneva, sans-serif' },
  { label: 'Tahoma', css: 'Tahoma, Geneva, sans-serif' },
  { label: 'Inter', css: 'Inter, system-ui, sans-serif' },
  { label: 'Hệ thống', css: "system-ui, -apple-system, 'Segoe UI', sans-serif" },
]

const FONT_SIZES = [12, 13, 14, 15, 16, 18, 20, 22, 24, 26, 28]

const BLOCKS: { label: string; tag: string }[] = [
  { label: 'Đoạn', tag: 'p' },
  { label: 'Tiêu đề 1', tag: 'h1' },
  { label: 'Tiêu đề 2', tag: 'h2' },
  { label: 'Tiêu đề 3', tag: 'h3' },
]

function escapeHtml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
}

function escapeAttr(s: string): string {
  return escapeHtml(s).replace(/"/g, '&quot;')
}

/** Chuẩn hoá đường dẫn ảnh từ response upload — chịu nhiều shape (files:[{name,path}] / files:[name] / paths / urls) */
function extractUploadPaths(data: unknown, dir: string): string[] {
  const out: string[] = []
  const d = (data || {}) as Record<string, unknown>
  if (Array.isArray(d.files)) {
    for (const f of d.files) {
      if (typeof f === 'string') out.push(dir ? `${dir}/${f}` : f)
      else if (f && typeof f === 'object') {
        const o = f as Record<string, unknown>
        if (typeof o.url === 'string' && o.url) out.push(o.url)
        else if (typeof o.path === 'string' && o.path) out.push(o.path)
        else if (typeof o.name === 'string' && o.name) out.push(dir ? `${dir}/${o.name}` : o.name)
      }
    }
  }
  if (out.length === 0 && Array.isArray(d.paths)) {
    for (const p of d.paths) if (typeof p === 'string' && p) out.push(p)
  }
  if (out.length === 0 && Array.isArray(d.urls)) {
    for (const u of d.urls) if (typeof u === 'string' && u) out.push(u)
  }
  return out
}

export default function RichEditor({ value, onChange }: RichEditorProps) {
  const editorRef = useRef<HTMLDivElement>(null)
  const lastHtml = useRef('')
  const savedRange = useRef<Range | null>(null)
  const textColorRef = useRef<HTMLInputElement>(null)
  const hiliteColorRef = useRef<HTMLInputElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const onChangeRef = useRef(onChange)
  onChangeRef.current = onChange

  const [block, setBlock] = useState('p')
  const [font, setFont] = useState(FONT_STACKS[0].css)
  const [fontSize, setFontSize] = useState('16')
  const [textColor, setTextColor] = useState('#e11d48')
  const [hiliteColor, setHiliteColor] = useState('#fef08a')

  const [showTable, setShowTable] = useState(false)
  const [tableRows, setTableRows] = useState(3)
  const [tableCols, setTableCols] = useState(3)
  const [imgMenu, setImgMenu] = useState(false)
  const [uploading, setUploading] = useState(false)

  const { toast } = useToast()

  /* ---------- Sync innerHTML: mount + đổi nội dung từ ngoài (đổi trang) ---------- */
  useEffect(() => {
    const editor = editorRef.current
    if (!editor) return
    if (value !== lastHtml.current) {
      editor.innerHTML = value || ''
      lastHtml.current = value
    }
  }, [value])

  /* ---------- Giữ selection khi focus rời editor (toolbar/select/popover) ---------- */
  useEffect(() => {
    const onSelectionChange = () => {
      const sel = window.getSelection()
      const editor = editorRef.current
      if (sel && sel.rangeCount > 0 && editor && editor.contains(sel.anchorNode)) {
        savedRange.current = sel.getRangeAt(0).cloneRange()
      }
    }
    document.addEventListener('selectionchange', onSelectionChange)
    return () => document.removeEventListener('selectionchange', onSelectionChange)
  }, [])

  const restoreSelection = useCallback(() => {
    const editor = editorRef.current
    const sel = window.getSelection()
    if (!editor || !sel) return
    const inEditor = sel.rangeCount > 0 && editor.contains(sel.anchorNode)
    if (!inEditor && savedRange.current) {
      sel.removeAllRanges()
      sel.addRange(savedRange.current)
    }
  }, [])

  const emitChange = useCallback(() => {
    const editor = editorRef.current
    if (!editor) return
    lastHtml.current = editor.innerHTML
    onChangeRef.current(editor.innerHTML)
  }, [])

  const exec = useCallback(
    (cmd: string, val?: string) => {
      const editor = editorRef.current
      if (!editor) return
      editor.focus()
      restoreSelection()
      try {
        document.execCommand('styleWithCSS', false, 'true')
        document.execCommand(cmd, false, val)
      } catch {
        /* execCommand deprecated nhưng vẫn hỗ trợ đầy đủ — bỏ qua lỗi hiếm gặp */
      }
      emitChange()
    },
    [restoreSelection, emitChange]
  )

  const insertHTML = useCallback(
    (html: string) => {
      const editor = editorRef.current
      if (!editor) return
      editor.focus()
      restoreSelection()
      try {
        document.execCommand('insertHTML', false, html)
      } catch {
        /* ignore */
      }
      emitChange()
    },
    [restoreSelection, emitChange]
  )

  /* ---------- Font size: execCommand fontSize 7 (marker) rồi quy đổi sang px ---------- */
  const applyFontSize = useCallback(
    (px: number) => {
      const editor = editorRef.current
      if (!editor) return
      editor.focus()
      restoreSelection()
      try {
        document.execCommand('styleWithCSS', false, 'true')
        document.execCommand('fontSize', false, '7')
        // styleWithCSS → <span style="font-size: xxx-large">; fallback → <font size="7">
        editor.querySelectorAll('font[size="7"], span[style*="xxx-large"], span[style*="XXX-LARGE"]').forEach((el) => {
          if (el instanceof HTMLElement) {
            el.style.fontSize = `${px}px`
            if (el.tagName === 'FONT') el.removeAttribute('size')
            // bỏ font-size lồng nhau để size mới thắng (CSS inner override)
            el.querySelectorAll<HTMLElement>('*').forEach((child) => {
              if (child.style.fontSize) child.style.fontSize = ''
            })
          }
        })
      } catch {
        /* ignore */
      }
      emitChange()
    },
    [restoreSelection, emitChange]
  )

  /* ---------- Bảng ---------- */
  const insertTable = useCallback(() => {
    const rows = Math.min(50, Math.max(1, tableRows || 1))
    const cols = Math.min(20, Math.max(1, tableCols || 1))
    let html = '<table><tbody>'
    for (let r = 0; r < rows; r++) {
      html += '<tr>'
      for (let c = 0; c < cols; c++) html += '<td><br></td>'
      html += '</tr>'
    }
    html += '</tbody></table><p><br></p>'
    insertHTML(html)
    setShowTable(false)
  }, [tableRows, tableCols, insertHTML])

  /* ---------- Link ---------- */
  const insertLink = useCallback(() => {
    const selText = window.getSelection()?.toString() || ''
    const url = prompt('Nhập liên kết (URL):', 'https://')
    if (!url || url === 'https://') return
    const safe = escapeAttr(url)
    if (selText.trim()) exec('createLink', url)
    else insertHTML(`<a href="${safe}">${escapeHtml(url)}</a><p><br></p>`)
  }, [exec, insertHTML])

  /* ---------- Ảnh: URL hoặc upload ---------- */
  const insertImageFromUrl = useCallback(() => {
    const url = prompt('Đường dẫn ảnh (URL):', 'https://')
    if (!url || url === 'https://') return
    setImgMenu(false)
    insertHTML(`<img src="${escapeAttr(url)}" alt="${escapeAttr(url.split('/').pop() || 'ảnh')}"><p><br></p>`)
  }, [insertHTML])

  const uploadImage = useCallback(
    async (file: File) => {
      setUploading(true)
      try {
        const form = new FormData()
        form.append('files', file)
        const data = await api<Record<string, unknown>>('/api/modules/files/upload?dir=Wiki', {
          method: 'POST',
          formData: form,
        })
        const paths = extractUploadPaths(data, 'Wiki')
        if (paths.length === 0) throw new Error('Không đọc được đường dẫn ảnh từ phản hồi')
        setImgMenu(false)
        const imgs = paths
          .map((p) => `<img src="/api/modules/files/download?path=${encodeURIComponent(p)}&inline=1" alt="${escapeAttr(p.split('/').pop() || 'ảnh')}">`)
          .join('<br>')
        insertHTML(`${imgs}<p><br></p>`)
        toast({ title: 'Đã chèn ảnh', description: file.name })
      } catch (err) {
        toast({
          title: 'Tải ảnh lên thất bại',
          description: err instanceof Error ? err.message : '',
          variant: 'destructive',
        })
      } finally {
        setUploading(false)
        if (fileInputRef.current) fileInputRef.current.value = ''
      }
    },
    [insertHTML, toast]
  )

  const insertCodeBlock = useCallback(() => {
    const sel = window.getSelection()?.toString() || ''
    insertHTML(`<pre>${escapeHtml(sel) || '<br>'}</pre><p><br></p>`)
  }, [insertHTML])

  const applyColor = useCallback(
    (cmd: 'foreColor' | 'hiliteColor', color: string) => {
      exec(cmd, color)
    },
    [exec]
  )

  const btn = (title: string, onClick: () => void, children: ReactNode, ariaLabel?: string) => (
    <button type="button" className="wos-rte-btn" title={title} aria-label={ariaLabel || title} onClick={onClick}>
      {children}
    </button>
  )

  return (
    <div className="flex h-full min-h-[400px] flex-col overflow-hidden rounded-xl">
      {/* Thanh công cụ */}
      <div className="wos-rte-toolbar" role="toolbar" aria-label="Thanh công cụ soạn thảo">
        {btn('Hoàn tác', () => exec('undo'), <Undo2 className="h-3.5 w-3.5" />)}
        {btn('Làm lại', () => exec('redo'), <Redo2 className="h-3.5 w-3.5" />)}
        <span className="wos-rte-sep" aria-hidden />
        {btn('Đậm (Ctrl+B)', () => exec('bold'), <strong>B</strong>)}
        {btn('Nghiêng (Ctrl+I)', () => exec('italic'), <em>I</em>)}
        {btn('Gạch chân (Ctrl+U)', () => exec('underline'), <u>U</u>)}
        {btn('Gạch ngang chữ', () => exec('strikeThrough'), <s>S</s>)}
        <span className="wos-rte-sep" aria-hidden />

        {/* Đoạn / Headings */}
        <select
          className="h-7 rounded-md border border-border bg-background px-1.5 text-xs outline-none"
          title="Kiểu đoạn"
          aria-label="Kiểu đoạn"
          value={block}
          onChange={(e) => {
            const tag = e.target.value
            setBlock(tag)
            exec('formatBlock', tag)
          }}
        >
          {BLOCKS.map((b) => (
            <option key={b.tag} value={b.tag}>
              {b.label}
            </option>
          ))}
        </select>

        {/* Font chữ */}
        <select
          className="h-7 max-w-[120px] rounded-md border border-border bg-background px-1.5 text-xs outline-none"
          title="Phông chữ"
          aria-label="Phông chữ"
          value={font}
          onChange={(e) => {
            const css = e.target.value
            setFont(css)
            exec('fontName', css)
          }}
        >
          {FONT_STACKS.map((f) => (
            <option key={f.label} value={f.css}>
              {f.label}
            </option>
          ))}
        </select>

        {/* Cỡ chữ */}
        <select
          className="h-7 rounded-md border border-border bg-background px-1.5 text-xs outline-none"
          title="Cỡ chữ"
          aria-label="Cỡ chữ"
          value={fontSize}
          onChange={(e) => {
            const px = Number(e.target.value)
            setFontSize(String(px))
            if (px > 0) applyFontSize(px)
          }}
        >
          {FONT_SIZES.map((s) => (
            <option key={s} value={String(s)}>
              {s}px
            </option>
          ))}
        </select>

        <span className="wos-rte-sep" aria-hidden />

        {/* Màu chữ + màu nền — native picker qua input color ẩn */}
        <button
          type="button"
          className="wos-rte-btn"
          title="Màu chữ"
          aria-label="Màu chữ"
          onClick={() => textColorRef.current?.click()}
        >
          <span className="flex flex-col items-center leading-none">
            <span className="text-[11px] font-bold">A</span>
            <span className="mt-0.5 h-[3px] w-3.5 rounded-full" style={{ background: 'var(--foreground)' }} />
          </span>
        </button>
        <input
          ref={textColorRef}
          type="color"
          value={textColor}
          aria-hidden
          tabIndex={-1}
          className="pointer-events-none absolute h-0 w-0 opacity-0"
          onChange={(e) => {
            setTextColor(e.target.value)
            applyColor('foreColor', e.target.value)
          }}
        />
        <button
          type="button"
          className="wos-rte-btn"
          title="Màu nền chữ"
          aria-label="Màu nền chữ"
          onClick={() => hiliteColorRef.current?.click()}
        >
          <span
            className="flex h-5 min-w-5 items-center justify-center rounded px-1 text-[11px] font-bold"
            style={{ background: 'var(--muted)' }}
          >
            A
          </span>
        </button>
        <input
          ref={hiliteColorRef}
          type="color"
          value={hiliteColor}
          aria-hidden
          tabIndex={-1}
          className="pointer-events-none absolute h-0 w-0 opacity-0"
          onChange={(e) => {
            setHiliteColor(e.target.value)
            applyColor('hiliteColor', e.target.value)
          }}
        />

        <span className="wos-rte-sep" aria-hidden />
        {btn('Căn trái', () => exec('justifyLeft'), <AlignLeft className="h-3.5 w-3.5" />)}
        {btn('Căn giữa', () => exec('justifyCenter'), <AlignCenter className="h-3.5 w-3.5" />)}
        {btn('Căn phải', () => exec('justifyRight'), <AlignRight className="h-3.5 w-3.5" />)}
        {btn('Căn đều 2 biên', () => exec('justifyFull'), <AlignJustify className="h-3.5 w-3.5" />)}
        <span className="wos-rte-sep" aria-hidden />
        {btn('Danh sách chấm đầu dòng', () => exec('insertUnorderedList'), <List className="h-3.5 w-3.5" />)}
        {btn('Danh sách đánh số', () => exec('insertOrderedList'), <ListOrdered className="h-3.5 w-3.5" />)}
        <span className="wos-rte-sep" aria-hidden />
        {btn('Chèn bảng', () => setShowTable(true), <Table className="h-3.5 w-3.5" />)}
        {btn('Chèn liên kết', insertLink, <Link2 className="h-3.5 w-3.5" />)}

        {/* Ảnh: menu nhỏ 2 lựa chọn */}
        <Popover open={imgMenu} onOpenChange={setImgMenu}>
          <PopoverTrigger asChild>
            <button type="button" className="wos-rte-btn" title="Chèn ảnh" aria-label="Chèn ảnh">
              <ImagePlus className="h-3.5 w-3.5" />
            </button>
          </PopoverTrigger>
          <PopoverContent className="w-44 p-1" align="start">
            <button
              type="button"
              className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-xs hover:bg-accent"
              onClick={insertImageFromUrl}
            >
              <ImagePlus className="h-3.5 w-3.5" /> Từ URL
            </button>
            <button
              type="button"
              className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-xs hover:bg-accent disabled:opacity-50"
              disabled={uploading}
              onClick={() => fileInputRef.current?.click()}
            >
              {uploading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <ImagePlus className="h-3.5 w-3.5" />}
              {uploading ? 'Đang tải lên…' : 'Tải ảnh lên'}
            </button>
          </PopoverContent>
        </Popover>

        <span className="wos-rte-sep" aria-hidden />
        {btn('Trích dẫn', () => exec('formatBlock', 'blockquote'), <TextQuote className="h-3.5 w-3.5" />)}
        {btn('Khối mã', insertCodeBlock, <Code className="h-3.5 w-3.5" />)}
        {btn('Đường kẻ ngang', () => exec('insertHorizontalRule'), <Minus className="h-3.5 w-3.5" />)}
        {btn('Xoá định dạng', () => exec('removeFormat'), <Eraser className="h-3.5 w-3.5" />)}
      </div>

      {/* Input file đặt NGOÀI popover để không bị unmount khi popover đóng giữa chừng */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        aria-label="Chọn tệp ảnh"
        onChange={(e) => {
          const f = e.target.files?.[0]
          if (f) uploadImage(f)
        }}
      />

      {/* Vùng soạn thảo */}
      <div
        ref={editorRef}
        className="wos-rte flex-1"
        contentEditable
        suppressContentEditableWarning
        role="textbox"
        aria-multiline="true"
        aria-label="Nội dung trang"
        data-placeholder="Soạn nội dung trang…"
        onInput={emitChange}
      />

      {/* Dialog tạo bảng */}
      <Dialog open={showTable} onOpenChange={setShowTable}>
        <DialogContent className="wos-glass-strong sm:max-w-[320px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base">
              <Table className="h-4 w-4" /> Chèn bảng
            </DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-3">
            <label className="space-y-1.5 text-xs text-muted-foreground">
              Số hàng
              <Input
                type="number"
                min={1}
                max={50}
                value={tableRows}
                onChange={(e) => setTableRows(Number(e.target.value))}
                className="h-8"
              />
            </label>
            <label className="space-y-1.5 text-xs text-muted-foreground">
              Số cột
              <Input
                type="number"
                min={1}
                max={20}
                value={tableCols}
                onChange={(e) => setTableCols(Number(e.target.value))}
                className="h-8"
              />
            </label>
          </div>
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => setShowTable(false)}>
              Huỷ
            </Button>
            <Button size="sm" onClick={insertTable}>
              Chèn bảng
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
