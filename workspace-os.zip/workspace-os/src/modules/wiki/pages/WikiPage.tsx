'use client'

import { useEffect, useState, useCallback, useMemo } from 'react'
import { useWos } from '@/core/client/wos-store'
import { useRoute } from '@/core/client/route-context'
import { api, timeAgo, fmtDateTime } from '@/core/client/api'
import { bus } from '@/core/client/event-bus'
import ReactMarkdown from 'react-markdown'
import RichEditor from '@/modules/wiki/RichEditor'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'
import { useToast } from '@/hooks/use-toast'
import {
  BookOpen, Plus, Trash2, Search, Loader2, RotateCcw, FileText, ChevronRight,
  History, Save, Eye, PenLine, GitCompareArrows, X, Check,
} from 'lucide-react'

interface PageRow {
  id: string
  parentId: string | null
  title: string
  icon: string
  position: number
  version: number
  trashedAt: string | null
  createdAt: string
  updatedAt: string
}

interface VersionRow {
  id: string
  version: number
  title: string
  authorName: string
  createdAt: string
  content: string
}

interface TreeNode extends PageRow {
  children: TreeNode[]
}

/* ---------- Utils nội dung: nhận diện HTML / strip tag / diff theo từ ---------- */

/** Nội dung chứa HTML (soạn bằng RichEditor) hay Markdown thuần (trang cũ) */
function isHtmlContent(c: string): boolean {
  return /^\s*<|<\w+[\s>]/i.test(c)
}

/** Strip thẻ HTML → plain text (gữi xuống dòng của khối, decode entity) */
function htmlToText(html: string): string {
  return html
    .replace(/<\s*(script|style)\b[^>]*>[\s\S]*?<\s*\/\s*\1\s*>/gi, ' ')
    .replace(/<\s*br\s*\/?\s*>/gi, '\n')
    .replace(/<\s*\/\s*(p|div|li|tr|h[1-6]|blockquote|pre|table)\s*>/gi, '\n')
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#0?39;/gi, "'")
    .replace(/&amp;/gi, '&')
    .replace(/&[a-z#0-9]+;/gi, ' ')
}

/** Tách chuỗi thành "từ" (kèm khoảng trắng phía sau để giữ nhịp đoạn khi render) */
function tokenizeWords(text: string): string[] {
  const raw = text.split(/(\s+)/)
  const tokens: string[] = []
  for (const part of raw) {
    if (!part) continue
    if (/^\s+$/.test(part)) {
      if (tokens.length > 0) tokens[tokens.length - 1] += part
    } else {
      tokens.push(part)
    }
  }
  return tokens
}

type DiffOp = { t: 'same' | 'del' | 'add'; s: string }

/**
 * Diff 2 plain-text theo TỪ bằng LCS (DP, không dependency).
 * del = có ở bản A (phiên bản cũ) nhưng bị xoá ở bản B (hiện tại); add = thêm ở bản hiện tại.
 * Nội dung quá lớn (sau khi trim đầu/cuối chung) → fallback diff khối để tránh nổ DP.
 */
function diffWords(a: string, b: string): DiffOp[] {
  const A = tokenizeWords(a)
  const B = tokenizeWords(b)
  const n = A.length
  const m = B.length

  // Trim tiền tố / hậu tố chung
  let start = 0
  while (start < n && start < m && A[start] === B[start]) start++
  let endA = n
  let endB = m
  while (endA > start && endB > start && A[endA - 1] === B[endB - 1]) {
    endA--
    endB--
  }

  const ops: DiffOp[] = []
  if (start > 0) ops.push({ t: 'same', s: A.slice(0, start).join('') })

  const midA = A.slice(start, endA)
  const midB = B.slice(start, endB)
  const na = midA.length
  const nb = midB.length

  if (na === 0 && nb === 0) {
    // không khác nhau ở phần giữa
  } else if (na * nb > 6_250_000) {
    // guard bộ nhớ (~2500×2500 ô DP): hiển thị thay đổi theo khối
    if (na > 0) ops.push({ t: 'del', s: midA.join('') })
    if (nb > 0) ops.push({ t: 'add', s: midB.join('') })
  } else {
    const width = nb + 1
    const dp = new Int32Array((na + 1) * width)
    for (let i = na - 1; i >= 0; i--) {
      for (let j = nb - 1; j >= 0; j--) {
        dp[i * width + j] =
          midA[i] === midB[j]
            ? dp[(i + 1) * width + j + 1] + 1
            : Math.max(dp[(i + 1) * width + j], dp[i * width + j + 1])
      }
    }
    let i = 0
    let j = 0
    while (i < na && j < nb) {
      if (midA[i] === midB[j]) {
        ops.push({ t: 'same', s: midA[i] })
        i++
        j++
      } else if (dp[(i + 1) * width + j] >= dp[i * width + j + 1]) {
        ops.push({ t: 'del', s: midA[i] })
        i++
      } else {
        ops.push({ t: 'add', s: midB[j] })
        j++
      }
    }
    while (i < na) ops.push({ t: 'del', s: midA[i++] })
    while (j < nb) ops.push({ t: 'add', s: midB[j++] })
  }

  if (endA < n) ops.push({ t: 'same', s: A.slice(endA).join('') })

  // Gộp op liên tiếp cùng loại → ít span hơn khi render
  const merged: DiffOp[] = []
  for (const op of ops) {
    const last = merged[merged.length - 1]
    if (last && last.t === op.t) last.s += op.s
    else merged.push({ t: op.t, s: op.s })
  }
  return merged
}

export default function WikiPage() {
  const { emit } = useWos()
  const { route, navigate } = useRoute()
  const { toast } = useToast()
  const [pages, setPages] = useState<PageRow[] | null>(null)
  const [trash, setTrash] = useState<PageRow[]>([])
  const [query, setQuery] = useState('')
  const [showTrash, setShowTrash] = useState(false)
  const [content, setContent] = useState('')
  const [versions, setVersions] = useState<VersionRow[]>([])
  const [saving, setSaving] = useState(false)
  const [dirty, setDirty] = useState(false)
  const [mode, setMode] = useState<'edit' | 'preview'>('preview')
  const [showVersions, setShowVersions] = useState(false)
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set())
  /** Đang "Xem thử" một phiên bản cũ (read-only + banner + diff) */
  const [viewing, setViewing] = useState<VersionRow | null>(null)
  const [diffMode, setDiffMode] = useState(false)

  const selectedId = route.includes(':') ? route.split(':')[1] : null

  const load = useCallback(async () => {
    try {
      const [p, t] = await Promise.all([
        api<{ pages: PageRow[] }>('/api/modules/wiki'),
        api<{ pages: PageRow[] }>('/api/modules/wiki?trash=1'),
      ])
      setPages(p.pages)
      setTrash(t.pages)
    } catch {
      setPages([])
    }
  }, [])

  useEffect(() => {
    load()
    return bus.onAny((ev) => {
      if (ev.module === 'wiki') load()
    })
  }, [load])

  // Đổi trang → thoát chế độ xem thử
  useEffect(() => {
    setViewing(null)
    setDiffMode(false)
  }, [selectedId])

  // Load nội dung trang đang chọn
  useEffect(() => {
    if (!selectedId) {
      setContent('')
      setVersions([])
      return
    }
    api<{ page: { content: string; versions: VersionRow[] } }>(`/api/modules/wiki/${selectedId}`)
      .then((d) => {
        setContent(d.page.content)
        setVersions(d.page.versions)
        setDirty(false)
      })
      .catch(() => setContent(''))
  }, [selectedId, pages])

  const tree = useMemo(() => buildTree(pages || []), [pages])
  const selected = useMemo(() => (pages || []).find((p) => p.id === selectedId) || null, [pages, selectedId])
  const breadcrumb = useMemo(() => {
    const chain: PageRow[] = []
    let cur = selected
    const map = new Map((pages || []).map((p) => [p.id, p]))
    while (cur) {
      chain.unshift(cur)
      cur = cur.parentId ? map.get(cur.parentId) ?? null : null
    }
    return chain
  }, [selected, pages])

  function buildTree(rows: PageRow[]): TreeNode[] {
    const map = new Map<string, TreeNode>()
    for (const r of rows) map.set(r.id, { ...r, children: [] })
    const roots: TreeNode[] = []
    for (const node of map.values()) {
      if (node.parentId && map.has(node.parentId)) map.get(node.parentId)!.children.push(node)
      else roots.push(node)
    }
    return roots
  }

  async function createPage(parentId: string | null) {
    const title = prompt('Tiêu đề trang mới:')
    if (!title?.trim()) return
    try {
      const data = await api<{ page: PageRow }>('/api/modules/wiki', {
        method: 'POST',
        body: { title: title.trim(), parentId, icon: '📄' },
      })
      emit('wiki.created', 'wiki', { title: title.trim() })
      await load()
      navigate(`wiki:${data.page.id}`)
      setMode('edit')
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : 'Không tạo được', variant: 'destructive' })
    }
  }

  async function createFolder(parentId: string | null) {
    const title = prompt('Tên thư mục (chính là trang cha):')
    if (!title?.trim()) return
    await api('/api/modules/wiki', { method: 'POST', body: { title: title.trim(), parentId, icon: '📁' } })
    emit('wiki.created', 'wiki', { title: title.trim() })
    load()
  }

  async function save() {
    if (!selected || saving) return
    setSaving(true)
    try {
      await api(`/api/modules/wiki/${selected.id}`, { method: 'PATCH', body: { content } })
      setDirty(false)
      await load()
      toast({ title: 'Đã lưu', description: `Phiên bản ${selected.version + (dirty ? 1 : 0)}` })
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : 'Không lưu được', variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  async function trashPage(p: PageRow) {
    if (!confirm(`Chuyển "${p.title}" vào thùng rác?`)) return
    await api(`/api/modules/wiki/${p.id}`, { method: 'PATCH', body: { trashed: true } })
    emit('wiki.deleted', 'wiki', { title: p.title })
    if (selectedId === p.id) navigate('wiki')
    load()
  }

  async function restorePage(p: PageRow) {
    await api(`/api/modules/wiki/${p.id}`, { method: 'PATCH', body: { trashed: false } })
    load()
  }

  async function deleteForever(p: PageRow) {
    if (!confirm(`Xoá vĩnh viễn "${p.title}" cùng mọi phiên bản?`)) return
    await api(`/api/modules/wiki/${p.id}`, { method: 'DELETE' })
    load()
  }

  async function restoreVersion(version: number) {
    if (!selected) return
    await api(`/api/modules/wiki/${selected.id}`, { method: 'PUT', body: { version } })
    setShowVersions(false)
    setViewing(null)
    setDiffMode(false)
    load()
    toast({ title: `Đã khôi phục phiên bản ${version}` })
  }

  /** Xem thử phiên bản: hiện nội dung cũ read-only + banner hành động */
  function previewVersion(v: VersionRow) {
    setViewing(v)
    setDiffMode(false)
    setShowVersions(false)
  }

  const filteredTree = (nodes: TreeNode[]): TreeNode[] => {
    if (!query.trim()) return nodes
    const q = query.toLowerCase()
    return nodes
      .map((n) => {
        const children = filteredTree(n.children)
        if (n.title.toLowerCase().includes(q) || children.length > 0) return { ...n, children }
        return null
      })
      .filter((n): n is TreeNode => n !== null)
  }

  if (pages === null) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <h1 className="flex items-center gap-2.5 text-xl font-bold">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-lime-600 text-white">
            <BookOpen className="h-5 w-5" />
          </span>
          Wiki
          <Badge variant="secondary" className="font-normal">{pages.length} trang</Badge>
        </h1>
        <div className="ml-auto flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Tìm trang…" className="h-9 w-40 pl-8" />
          </div>
          <Button variant="outline" size="sm" className="h-9 gap-1.5" onClick={() => setShowTrash(!showTrash)}>
            <RotateCcw className="h-4 w-4" /> {showTrash ? 'Thoát rác' : `Rác${trash.length ? ` (${trash.length})` : ''}`}
          </Button>
          <Button size="sm" className="h-9 gap-1.5" onClick={() => createPage(null)}>
            <Plus className="h-4 w-4" /> Trang mới
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-[260px_1fr]">
        {/* Cây trang */}
        <Card className="wos-glass max-h-[calc(100vh-220px)] overflow-y-auto border-0 p-2">
          {!showTrash ? (
            <>
              <TreeNodes
                nodes={filteredTree(tree)}
                selectedId={selectedId}
                collapsed={collapsed}
                setCollapsed={setCollapsed}
                onSelect={(id) => navigate(`wiki:${id}`)}
                onAddChild={(parentId) => createPage(parentId)}
                onTrash={trashPage}
              />
              <Button variant="ghost" size="sm" className="mt-2 w-full justify-start gap-2 text-xs text-muted-foreground" onClick={() => createPage(null)}>
                <Plus className="h-3.5 w-3.5" /> Trang gốc mới
              </Button>
            </>
          ) : (
            <div className="space-y-2 p-2">
              {trash.length === 0 && <p className="py-6 text-center text-sm text-muted-foreground">Thùng rác trống</p>}
              {trash.map((p) => (
                <div key={p.id} className="rounded-xl bg-muted/50 p-3">
                  <p className="text-sm font-medium">{p.icon} {p.title}</p>
                  <div className="mt-2 flex gap-2">
                    <Button size="sm" variant="outline" className="h-7 flex-1 text-xs" onClick={() => restorePage(p)}>
                      <RotateCcw className="mr-1 h-3 w-3" /> Khôi phục
                    </Button>
                    <Button size="sm" variant="destructive" className="h-7 flex-1 text-xs" onClick={() => deleteForever(p)}>
                      Xoá vĩnh viễn
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        {/* Nội dung trang */}
        <Card className="wos-glass flex min-h-[calc(100vh-220px)] flex-col border-0">
          {selected && !showTrash ? (
            <>
              <div className="flex flex-wrap items-center gap-2 border-b px-4 py-3">
                <nav className="flex min-w-0 flex-1 items-center gap-1 text-sm text-muted-foreground" aria-label="Breadcrumb">
                  {breadcrumb.map((b, i) => (
                    <span key={b.id} className="flex min-w-0 items-center gap-1">
                      {i > 0 && <ChevronRight className="h-3.5 w-3.5 shrink-0" />}
                      <button onClick={() => navigate(`wiki:${b.id}`)} className={`min-w-0 truncate ${b.id === selected.id ? 'font-semibold text-foreground' : 'hover:text-foreground'}`}>
                        {b.icon} {b.title}
                      </button>
                    </span>
                  ))}
                  <Badge variant="secondary" className="ml-2 h-5 shrink-0 px-1.5 text-[10px]">v{viewing ? viewing.version : selected.version}</Badge>
                </nav>
                <Button variant="outline" size="sm" className="h-8 gap-1.5 text-xs" onClick={() => setShowVersions(true)}>
                  <History className="h-3.5 w-3.5" /> {versions.length} phiên bản
                </Button>
                {!viewing && (
                  <>
                    <div className="flex items-center rounded-lg bg-muted p-0.5">
                      <button
                        onClick={() => setMode('edit')}
                        className={`flex h-7 items-center gap-1.5 rounded-md px-2.5 text-xs font-medium ${mode === 'edit' ? 'bg-background shadow-sm' : 'text-muted-foreground'}`}
                        aria-label="Chế độ soạn thảo"
                      >
                        <PenLine className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={() => setMode('preview')}
                        className={`flex h-7 items-center gap-1.5 rounded-md px-2.5 text-xs font-medium ${mode === 'preview' ? 'bg-background shadow-sm' : 'text-muted-foreground'}`}
                        aria-label="Chế độ xem"
                      >
                        <Eye className="h-3.5 w-3.5" />
                      </button>
                    </div>
                    <Button size="sm" className="h-8 gap-1.5" onClick={save} disabled={saving || !dirty}>
                      {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} {dirty ? 'Lưu' : 'Đã lưu'}
                    </Button>
                  </>
                )}
                <Button variant="ghost" size="icon" className="h-8 w-8 text-rose-500" onClick={() => trashPage(selected)} aria-label="Xoá trang">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>

              {/* Banner: đang xem phiên bản cũ */}
              {viewing && (
                <div className="flex flex-wrap items-center gap-2 border-b border-amber-500/30 bg-amber-500/10 px-4 py-2.5 text-xs">
                  <History className="h-4 w-4 shrink-0 text-amber-600 dark:text-amber-400" />
                  <span className="font-semibold text-amber-700 dark:text-amber-300">Đang xem phiên bản v{viewing.version}</span>
                  <span className="text-muted-foreground">— {fmtDateTime(viewing.createdAt)} · {viewing.authorName}</span>
                  <span className="ml-auto flex flex-wrap items-center gap-1.5">
                    <Button
                      size="sm"
                      variant={diffMode ? 'default' : 'outline'}
                      className="h-7 gap-1.5 text-xs"
                      onClick={() => setDiffMode(!diffMode)}
                      disabled={viewing.version === selected.version}
                      title={viewing.version === selected.version ? 'Đây chính là bản hiện tại' : 'So sánh phiên bản này với bản hiện tại'}
                    >
                      <GitCompareArrows className="h-3.5 w-3.5" /> {diffMode ? 'Đóng so sánh' : 'So sánh với bản hiện tại'}
                    </Button>
                    {viewing.version !== selected.version && (
                      <Button size="sm" variant="outline" className="h-7 gap-1.5 text-xs" onClick={() => restoreVersion(viewing.version)}>
                        <RotateCcw className="h-3.5 w-3.5" /> Khôi phục phiên bản này
                      </Button>
                    )}
                    <Button size="sm" variant="ghost" className="h-7 gap-1.5 text-xs" onClick={() => { setViewing(null); setDiffMode(false) }}>
                      <X className="h-3.5 w-3.5" /> Thoát xem thử
                    </Button>
                  </span>
                </div>
              )}

              <CardContent className="flex-1 p-0">
                {viewing ? (
                  // Xem thử phiên bản (read-only)
                  <div className="h-full min-h-[400px] overflow-y-auto">
                    {diffMode ? (
                      <DiffView viewing={viewing} current={content} currentVersion={selected.version} />
                    ) : isHtmlContent(viewing.content) ? (
                      <div className="wos-html p-6" dangerouslySetInnerHTML={{ __html: viewing.content || '<p><em>Phiên bản trống</em></p>' }} />
                    ) : (
                      <div className="wos-md p-6">
                        <ReactMarkdown>{viewing.content || '*Phiên bản trống*'}</ReactMarkdown>
                      </div>
                    )}
                  </div>
                ) : mode === 'edit' ? (
                  <RichEditor
                    value={content}
                    onChange={(h) => {
                      setContent(h)
                      setDirty(true)
                    }}
                  />
                ) : isHtmlContent(content) ? (
                  <div className="wos-html h-full min-h-[400px] overflow-y-auto p-6" dangerouslySetInnerHTML={{ __html: content }} />
                ) : (
                  <div className="wos-md h-full min-h-[400px] overflow-y-auto p-6">
                    <ReactMarkdown>{content || '*Trang trống — bấm biểu tượng bút để soạn nội dung*'}</ReactMarkdown>
                  </div>
                )}
              </CardContent>
              <div className="border-t px-4 py-2 text-[11px] text-muted-foreground">
                {viewing
                  ? `Bản xem thử v${viewing.version} · bản hiện tại là v${selected.version} (cập nhật ${timeAgo(selected.updatedAt)})`
                  : `Cập nhật ${timeAgo(selected.updatedAt)} · ${versions.length} phiên bản được lưu`}
              </div>
            </>
          ) : (
            <div className="flex flex-1 flex-col items-center justify-center gap-3 py-20 text-muted-foreground">
              <BookOpen className="h-10 w-10 opacity-30" />
              <p className="text-sm">Chọn một trang trong cây bên trái</p>
            </div>
          )}
        </Card>
      </div>

      {/* Dialog phiên bản */}
      <Dialog open={showVersions} onOpenChange={setShowVersions}>
        <DialogContent className="wos-glass-strong sm:max-w-[480px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <History className="h-4 w-4" /> Lịch sử phiên bản — {selected?.title}
            </DialogTitle>
          </DialogHeader>
          <ScrollArea className="max-h-[360px]">
            <div className="space-y-2">
              {versions.map((v) => (
                <div key={v.id} className="flex items-center gap-3 rounded-xl bg-muted/50 px-3 py-2.5">
                  <Badge variant="outline" className="shrink-0">v{v.version}</Badge>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{v.title}</p>
                    <p className="text-[11px] text-muted-foreground">{v.authorName} · {fmtDateTime(v.createdAt)}</p>
                  </div>
                  <div className="flex shrink-0 gap-1.5">
                    <Button size="sm" variant="outline" className="h-7 gap-1 text-xs" onClick={() => previewVersion(v)}>
                      <Eye className="h-3 w-3" /> Xem thử
                    </Button>
                    {selected && v.version !== selected.version && (
                      <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => restoreVersion(v.version)}>
                        Khôi phục
                      </Button>
                    )}
                  </div>
                </div>
              ))}
              {versions.length === 0 && <p className="py-6 text-center text-sm text-muted-foreground">Chưa có phiên bản nào được lưu</p>}
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  )
}

/** Khung nhìn so sánh: phiên bản đang xem (base) ↔ bản hiện tại */
function DiffView({ viewing, current, currentVersion }: { viewing: VersionRow; current: string; currentVersion: number }) {
  const ops = useMemo(() => diffWords(htmlToText(viewing.content), htmlToText(current)), [viewing, current])
  const identical = ops.every((o) => o.t === 'same')

  return (
    <div className="p-5">
      <div className="mb-3 flex items-start gap-2 rounded-lg bg-muted/60 px-3 py-2 text-[11px] leading-relaxed text-muted-foreground">
        <GitCompareArrows className="mt-0.5 h-3.5 w-3.5 shrink-0" />
        <p>
          So sánh phiên bản <strong>v{viewing.version}</strong> với bản hiện tại <strong>v{currentVersion}</strong> —{' '}
          <span className="font-medium text-emerald-600 dark:text-emerald-400">Xanh = thêm ở bản hiện tại</span>,{' '}
          <span className="font-medium text-rose-600 dark:text-rose-400">Đỏ = có ở v{viewing.version} nhưng đã bị xoá</span>
        </p>
      </div>
      {identical ? (
        <div className="flex items-center gap-2 rounded-xl bg-emerald-500/10 px-4 py-3 text-sm text-emerald-700 dark:text-emerald-300">
          <Check className="h-4 w-4" /> Không có khác biệt — hai bản giống hệt nhau.
        </div>
      ) : (
        <div className="wos-diff whitespace-pre-wrap break-words">
          {ops.map((op, i) =>
            op.t === 'same' ? (
              <span key={i}>{op.s}</span>
            ) : (
              <span key={i} className={op.t === 'del' ? 'wos-diff-del' : 'wos-diff-add'}>
                {op.s}
              </span>
            )
          )}
        </div>
      )}
    </div>
  )
}

function TreeNodes({
  nodes, selectedId, collapsed, setCollapsed, onSelect, onAddChild, onTrash, depth = 0,
}: {
  nodes: TreeNode[]
  selectedId: string | null
  collapsed: Set<string>
  setCollapsed: (s: Set<string>) => void
  onSelect: (id: string) => void
  onAddChild: (parentId: string) => void
  onTrash: (p: PageRow) => void
  depth?: number
}) {
  return (
    <div className="space-y-0.5" style={{ paddingLeft: depth * 14 }}>
      {nodes.map((n) => {
        const hasChildren = n.children.length > 0
        const isCollapsed = collapsed.has(n.id)
        return (
          <div key={n.id}>
            <div className={`group flex items-center gap-1 rounded-lg px-2 py-1.5 transition-colors hover:bg-muted ${
              n.id === selectedId ? 'bg-primary/10 ring-1 ring-primary/30' : ''
            }`}>
              {hasChildren ? (
                <button
                  onClick={() => {
                    const next = new Set(collapsed)
                    if (isCollapsed) next.delete(n.id)
                    else next.add(n.id)
                    setCollapsed(next)
                  }}
                  className="h-4 w-4 shrink-0 text-muted-foreground"
                  aria-label={isCollapsed ? 'Mở rộng' : 'Thu gọn'}
                >
                  <ChevronRight className={`h-3.5 w-3.5 transition-transform ${isCollapsed ? '' : 'rotate-90'}`} />
                </button>
              ) : (
                <FileText className="h-3.5 w-3.5 shrink-0 text-muted-foreground/50" />
              )}
              <button onClick={() => onSelect(n.id)} className="min-w-0 flex-1 truncate text-left text-sm">
                {n.icon} {n.title}
              </button>
              <div className="hidden items-center gap-0.5 group-hover:flex">
                <button onClick={() => onAddChild(n.id)} className="rounded p-1 text-muted-foreground hover:text-primary" aria-label="Thêm trang con">
                  <Plus className="h-3 w-3" />
                </button>
                <button onClick={() => onTrash(n)} className="rounded p-1 text-muted-foreground hover:text-rose-500" aria-label="Xoá">
                  <Trash2 className="h-3 w-3" />
                </button>
              </div>
            </div>
            {hasChildren && !isCollapsed && (
              <TreeNodes
                nodes={n.children}
                selectedId={selectedId}
                collapsed={collapsed}
                setCollapsed={setCollapsed}
                onSelect={onSelect}
                onAddChild={onAddChild}
                onTrash={onTrash}
                depth={depth + 1}
              />
            )}
          </div>
        )
      })}
    </div>
  )
}
