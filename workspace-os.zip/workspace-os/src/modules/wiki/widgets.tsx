'use client'

import { useEffect, useState, useCallback } from 'react'
import { useWos } from '@/core/client/wos-store'
import { api, timeAgo } from '@/core/client/api'
import { bus } from '@/core/client/event-bus'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { BookOpen, Loader2 } from 'lucide-react'

interface PageRow {
  id: string
  title: string
  icon: string
  version: number
  updatedAt: string
}

/** Widget: Wiki mới cập nhật (CENTER) */
export function WikiRecentWidget() {
  const { navigate } = useWos()
  const [pages, setPages] = useState<PageRow[] | null>(null)

  const load = useCallback(async () => {
    try {
      const data = await api<{ pages: PageRow[] }>('/api/modules/wiki')
      setPages(
        [...data.pages]
          .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
          .slice(0, 5)
      )
    } catch {
      setPages([])
    }
  }, [])

  useEffect(() => {
    load()
    return bus.onAny((ev) => {
      if (ev.module === 'wiki') load()
    })
  }, [load])

  return (
    <Card className="wos-glass border-0">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="flex items-center gap-2 text-sm font-semibold">
          <BookOpen className="h-4 w-4 text-lime-600" /> Wiki mới cập nhật
        </CardTitle>
        <button onClick={() => navigate('wiki')} className="text-xs text-primary hover:underline">
          Mở Wiki
        </button>
      </CardHeader>
      <CardContent>
        {pages === null ? (
          <div className="flex h-24 items-center justify-center">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        ) : pages.length === 0 ? (
          <p className="py-6 text-center text-sm text-muted-foreground">Chưa có trang wiki nào</p>
        ) : (
          <div className="space-y-0.5">
            {pages.map((p) => (
              <button
                key={p.id}
                onClick={() => navigate(`wiki:${p.id}`)}
                className="flex w-full items-center gap-3 rounded-lg px-2 py-1.5 text-left transition-colors hover:bg-muted"
              >
                <span className="text-base">{p.icon}</span>
                <span className="min-w-0 flex-1 truncate text-sm">{p.title}</span>
                <span className="shrink-0 rounded bg-muted px-1.5 py-0.5 text-[10px] text-muted-foreground">v{p.version}</span>
                <span className="hidden shrink-0 text-[11px] text-muted-foreground sm:block">{timeAgo(p.updatedAt)}</span>
              </button>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
