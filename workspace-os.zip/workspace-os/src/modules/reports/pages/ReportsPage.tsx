'use client'

import { useEffect, useState, useCallback } from 'react'
import { useWos } from '@/core/client/wos-store'
import { api, formatBytes } from '@/core/client/api'
import { bus } from '@/core/client/event-bus'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Progress } from '@/components/ui/progress'
import { useToast } from '@/hooks/use-toast'
import { BarChart3, FileDown, Loader2, Printer, TrendingUp, Folder, HardDrive } from 'lucide-react'

interface ReportData {
  days: number
  totalDone: number
  daily: { date: string; count: number }[]
  byPriority: Record<string, number>
  projects: { name: string; status: string; milestones: number; milestoneDone: number; progress: number }[]
  counters: { notes: number; wiki: number; files: number; events: number }
  storageBytes: number
  storageByFolder: { folder: string; count: number; bytes: number }[]
}

const PRIORITY_LABEL: Record<string, string> = { low: 'Thấp', medium: 'Vừa', high: 'Cao', urgent: 'Khẩn' }
const PRIORITY_COLOR: Record<string, string> = { low: '#94a3b8', medium: '#f59e0b', high: '#f97316', urgent: '#f43f5e' }

export default function ReportsPage() {
  const { emit } = useWos()
  const { toast } = useToast()
  const [days, setDays] = useState('30')
  const [data, setData] = useState<ReportData | null>(null)

  const load = useCallback(async () => {
    try {
      const d = await api<ReportData>(`/api/modules/reports?days=${days}`)
      setData(d)
    } catch {
      setData(null)
    }
  }, [days])

  useEffect(() => {
    load()
    return bus.onAny((ev) => {
      if (ev.module === 'tasks') load()
    })
  }, [load])

  function exportReport(format: 'csv' | 'excel' | 'json', report: string) {
    emit('settings.updated', 'reports', { name: `xuất ${report}` })
    window.open(`/api/modules/reports/export?type=${format}&report=${report}`, '_blank')
    toast({ title: `Đang xuất ${report} (${format.toUpperCase()})` })
  }

  function printReport() {
    window.print()
  }

  if (!data) {
    return <div className="flex h-64 items-center justify-center"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
  }

  const max = Math.max(1, ...data.daily.map((d) => d.count))
  const priorityTotal = Object.values(data.byPriority).reduce((a, b) => a + b, 0)

  return (
    <div className="space-y-4 print:space-y-2">
      <div className="flex flex-wrap items-center gap-3 print:hidden">
        <h1 className="flex items-center gap-2.5 text-xl font-bold">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-cyan-600 text-white">
            <BarChart3 className="h-5 w-5" />
          </span>
          Reports
        </h1>
        <div className="ml-auto flex flex-wrap items-center gap-2">
          <Select value={days} onValueChange={setDays}>
            <SelectTrigger className="h-9 w-36 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="7">7 ngày qua</SelectItem>
              <SelectItem value="30">30 ngày qua</SelectItem>
              <SelectItem value="90">90 ngày qua</SelectItem>
              <SelectItem value="365">1 năm qua</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm" className="h-9 gap-1.5" onClick={printReport}>
            <Printer className="h-4 w-4" /> In / PDF
          </Button>
        </div>
      </div>

      {/* Tổng quan */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
        <StatCard title="Việc hoàn thành" value={data.totalDone} sub={`${days} ngày qua`} icon={<TrendingUp className="h-4 w-4" />} />
        <StatCard title="Ghi chú" value={data.counters.notes} icon="📝" />
        <StatCard title="Trang wiki" value={data.counters.wiki} icon="📖" />
        <StatCard title="Tệp tin" value={data.counters.files} icon="📄" />
        <StatCard title="Dung lượng" value={formatBytes(data.storageBytes)} displayRaw icon={<HardDrive className="h-4 w-4" />} />
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {/* Công việc theo ngày */}
        <Card className="wos-glass border-0 print:break-inside-avoid">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">Công việc hoàn thành theo ngày</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex h-40 items-end gap-[3px]">
              {data.daily.map((d) => (
                <div key={d.date} className="group relative flex-1">
                  <div
                    className="w-full rounded-t bg-gradient-to-t from-primary/50 to-primary transition-all"
                    style={{ height: `${Math.max(3, (d.count / max) * 140)}px` }}
                  />
                  <span className="pointer-events-none absolute -top-6 left-1/2 hidden -translate-x-1/2 rounded bg-foreground px-1.5 py-0.5 text-[10px] text-background group-hover:block">
                    {d.date.slice(5)}: {d.count}
                  </span>
                </div>
              ))}
            </div>
            <p className="mt-2 text-center text-[11px] text-muted-foreground">
              {data.daily[0]?.date.slice(0, 10)} → {data.daily[data.daily.length - 1]?.date.slice(0, 10)}
            </p>
          </CardContent>
        </Card>

        {/* Theo ưu tiên */}
        <Card className="wos-glass border-0 print:break-inside-avoid">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">Phân bổ theo mức ưu tiên</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {Object.entries(data.byPriority).map(([p, count]) => (
              <div key={p}>
                <div className="mb-1 flex justify-between text-xs">
                  <span className="flex items-center gap-1.5">
                    <span className="h-2.5 w-2.5 rounded-full" style={{ background: PRIORITY_COLOR[p] }} />
                    {PRIORITY_LABEL[p]}
                  </span>
                  <span className="tabular-nums text-muted-foreground">
                    {count} · {priorityTotal ? Math.round((count / priorityTotal) * 100) : 0}%
                  </span>
                </div>
                <div className="h-2.5 overflow-hidden rounded-full bg-muted">
                  <div className="h-full rounded-full" style={{ width: `${priorityTotal ? (count / priorityTotal) * 100 : 0}%`, background: PRIORITY_COLOR[p] }} />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Tiến độ dự án */}
      <Card className="wos-glass border-0 print:break-inside-avoid">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">Tiến độ dự án</CardTitle>
        </CardHeader>
        <CardContent>
          {data.projects.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted-foreground">Chưa có dự án</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Dự án</TableHead>
                  <TableHead className="w-24">Trạng thái</TableHead>
                  <TableHead className="w-40">Mốc</TableHead>
                  <TableHead className="w-32">Tiến độ</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.projects.map((p) => (
                  <TableRow key={p.name}>
                    <TableCell className="font-medium">{p.name}</TableCell>
                    <TableCell><Badge variant="secondary">{p.status}</Badge></TableCell>
                    <TableCell className="text-xs text-muted-foreground">{p.milestoneDone}/{p.milestones} mốc</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Progress value={p.progress} className="h-2 flex-1" />
                        <span className="w-9 text-right text-xs tabular-nums">{p.progress}%</span>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Lưu trữ theo thư mục */}
      <Card className="wos-glass border-0 print:break-inside-avoid">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-sm font-semibold">
            <Folder className="h-4 w-4" /> Lưu trữ theo thư mục
          </CardTitle>
        </CardHeader>
        <CardContent>
          {data.storageByFolder.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted-foreground">Chưa có dữ liệu tệp</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Thư mục</TableHead>
                  <TableHead className="text-right">Số tệp</TableHead>
                  <TableHead className="text-right">Dung lượng</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.storageByFolder.sort((a, b) => b.bytes - a.bytes).map((f) => (
                  <TableRow key={f.folder}>
                    <TableCell className="font-medium">{f.folder}</TableCell>
                    <TableCell className="text-right tabular-nums">{f.count}</TableCell>
                    <TableCell className="text-right tabular-nums">{formatBytes(f.bytes)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Xuất báo cáo */}
      <Card className="wos-glass border-0 print:hidden">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">Xuất báo cáo</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 gap-2 sm:grid-cols-3">
          {[
            { id: 'tasks', label: 'Báo cáo công việc' },
            { id: 'projects', label: 'Báo cáo dự án' },
            { id: 'storage', label: 'Báo cáo lưu trữ' },
          ].map((r) => (
            <div key={r.id} className="flex items-center justify-between gap-2 rounded-xl bg-muted/50 px-3 py-2.5">
              <span className="text-sm font-medium">{r.label}</span>
              <div className="flex items-center gap-1">
                <Button size="sm" variant="ghost" className="h-7 gap-1 px-2 text-xs" onClick={() => exportReport('csv', r.id)}>
                  <FileDown className="h-3.5 w-3.5" /> CSV
                </Button>
                <Button size="sm" variant="ghost" className="h-7 gap-1 px-2 text-xs" onClick={() => exportReport('excel', r.id)}>
                  <FileDown className="h-3.5 w-3.5" /> Excel
                </Button>
                <Button size="sm" variant="ghost" className="h-7 gap-1 px-2 text-xs" onClick={() => exportReport('json', r.id)}>
                  <FileDown className="h-3.5 w-3.5" /> JSON
                </Button>
              </div>
            </div>
          ))}
          <p className="col-span-full pt-1 text-center text-[11px] text-muted-foreground">
            PDF: dùng nút "In / PDF" ở đầu trang (trình duyệt hỗ trợ lưu PDF khi in).
          </p>
        </CardContent>
      </Card>
    </div>
  )
}

function StatCard({ title, value, sub, icon, displayRaw }: { title: string; value: number | string; sub?: string; icon?: React.ReactNode; displayRaw?: boolean }) {
  return (
    <Card className="wos-glass border-0 print:break-inside-avoid">
      <CardContent className="py-3.5">
        <p className="flex items-center gap-1.5 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
          {icon} {title}
        </p>
        <p className="mt-1 text-2xl font-bold tabular-nums">{displayRaw ? value : value.toLocaleString('vi-VN')}</p>
        {sub && <p className="text-[11px] text-muted-foreground">{sub}</p>}
      </CardContent>
    </Card>
  )
}
