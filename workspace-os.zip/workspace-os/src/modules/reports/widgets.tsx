'use client'

import { useEffect, useState, useCallback } from 'react'
import { useWos } from '@/core/client/wos-store'
import { api, formatBytes } from '@/core/client/api'
import { bus } from '@/core/client/event-bus'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { BarChart3, HardDrive, Bell, Sparkles, Loader2 } from 'lucide-react'

interface ReportData {
  totalDone: number
  daily: { date: string; count: number }[]
  counters: { notes: number; wiki: number; files: number; events: number }
  storageBytes: number
}

/** Widget: Statistics (BOTTOM) — cột công việc hoàn thành 14 ngày */
export function StatisticsWidget() {
  const [data, setData] = useState<ReportData | null>(null)

  const load = useCallback(async () => {
    try {
      const d = await api<ReportData>('/api/modules/reports?days=14')
      setData(d)
    } catch {
      setData(null)
    }
  }, [])

  useEffect(() => {
    load()
    return bus.onAny((ev) => {
      if (ev.module === 'tasks') load()
    })
  }, [load])

  const max = data ? Math.max(1, ...data.daily.map((d) => d.count)) : 1

  return (
    <Card className="wos-glass border-0">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-sm font-semibold">
          <BarChart3 className="h-4 w-4 text-cyan-600" /> Statistics
        </CardTitle>
      </CardHeader>
      <CardContent>
        {!data ? (
          <div className="flex h-24 items-center justify-center">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <>
            <div className="flex h-24 items-end gap-1">
              {data.daily.map((d) => (
                <div key={d.date} className="group relative flex-1">
                  <div
                    className="w-full rounded-t bg-gradient-to-t from-primary/60 to-primary transition-all"
                    style={{ height: `${Math.max(4, (d.count / max) * 88)}px` }}
                  />
                  <span className="pointer-events-none absolute -top-6 left-1/2 -translate-x-1/2 rounded bg-foreground px-1.5 py-0.5 text-[10px] text-background opacity-0 transition-opacity group-hover:opacity-100">
                    {d.count}
                  </span>
                </div>
              ))}
            </div>
            <div className="mt-2 flex items-center justify-between text-[11px] text-muted-foreground">
              <span>{data.daily[0]?.date.slice(5)}</span>
              <span>{data.totalDone} việc hoàn thành / 14 ngày</span>
              <span>Hôm nay</span>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  )
}

/** Widget: AI Summary (BOTTOM) — tổng hợp nhanh dữ liệu workspace */
export function AiSummaryWidget() {
  const { settings } = useWos()
  const [data, setData] = useState<ReportData | null>(null)

  const load = useCallback(async () => {
    try {
      const d = await api<ReportData>('/api/modules/reports?days=7')
      setData(d)
    } catch {
      setData(null)
    }
  }, [])

  useEffect(() => {
    load()
  }, [load])

  if (settings.ai_summary === 'off') {
    return (
      <Card className="wos-glass border-0">
        <CardContent className="flex flex-col items-center gap-2 py-8 text-muted-foreground">
          <Sparkles className="h-6 w-6 opacity-40" />
          <p className="text-sm">AI Summary đang tắt (Settings → General)</p>
        </CardContent>
      </Card>
    )
  }

  const week = data?.daily.slice(-7).reduce((a, b) => a + b.count, 0) || 0
  const hour = new Date().getHours()
  const greet = hour < 12 ? 'sáng' : hour < 18 ? 'chiều' : 'tối'

  return (
    <Card className="wos-glass border-0">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-sm font-semibold">
          <Sparkles className="h-4 w-4 text-violet-500" /> AI Summary
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2 text-sm leading-relaxed">
        <p>
          📌 Tuần này bạn đã hoàn thành <b>{week} việc</b>, workspace đang lưu{' '}
          <b>{data?.counters.notes || 0} ghi chú</b>, <b>{data?.counters.wiki || 0} trang wiki</b> và{' '}
          <b>{data?.counters.files || 0} tệp</b> ({formatBytes(data?.storageBytes || 0)}).
        </p>
        <p>
          💡 Gợi ý buổi {greet}: mở <b>Tasks</b> dọn các việc đến hạn, xem <b>Timeline</b> để nắm hoạt động gần nhất và
          kiểm tra <b>Reports</b> cuối tuần.
        </p>
        <p className="text-[11px] text-muted-foreground">Tổng hợp tự động từ Event Bus của Workspace OS.</p>
      </CardContent>
    </Card>
  )
}

/** Widget: Disk Usage (TOP zone — nằm trong hàng chip) */
export function DiskUsageChip() {
  const [stats, setStats] = useState<{ disk: { percent: number; used: number; total: number }; storageBytes: number } | null>(null)

  useEffect(() => {
    const load = () => {
      api<{ disk: { percent: number; used: number; total: number }; storageBytes: number }>('/api/core/stats')
        .then(setStats)
        .catch(() => {})
    }
    load()
    const t = setInterval(load, 30000)
    return () => clearInterval(t)
  }, [])

  if (!stats) return <Loader2 className="h-4 w-4 animate-spin text-white/60" />

  return (
    <div className="flex items-center gap-2">
      <HardDrive className="h-4 w-4 text-white/70" />
      <div>
        <p className="text-xs font-semibold leading-none text-white">Disk {stats.disk.percent}%</p>
        <div className="mt-1 h-1 w-16 overflow-hidden rounded-full bg-white/25">
          <div className="h-full rounded-full bg-amber-400" style={{ width: `${stats.disk.percent}%` }} />
        </div>
      </div>
    </div>
  )
}

/** Widget: Thông báo mới (TOP zone) */
export function RecentNotificationsChip() {
  const { navigate } = useWos()
  const [items, setItems] = useState<{ id: string; title: string; createdAt: string }[]>([])

  useEffect(() => {
    const load = () => {
      api<{ notifications: { id: string; title: string; createdAt: string }[] }>('/api/core/notifications?filter=unread')
        .then((d) => setItems(d.notifications.slice(0, 1)))
        .catch(() => {})
    }
    load()
    return bus.onAny((ev) => {
      if (ev.module === 'core' || ev.type.startsWith('module.')) load()
    })
  }, [])

  if (items.length === 0) {
    return (
      <div className="flex items-center gap-2">
        <Bell className="h-4 w-4 text-white/70" />
        <p className="text-xs font-medium text-white/90">Không có thông báo mới</p>
      </div>
    )
  }

  return (
    <button onClick={() => navigate('notifications')} className="flex items-center gap-2">
      <span className="relative">
        <Bell className="h-4 w-4 text-white/70" />
        <span className="absolute -right-1 -top-1 h-2 w-2 rounded-full bg-rose-400" />
      </span>
      <p className="max-w-[220px] truncate text-xs font-medium text-white/90">{items[0].title}</p>
    </button>
  )
}

