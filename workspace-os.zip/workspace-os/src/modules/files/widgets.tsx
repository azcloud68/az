'use client'

import { useEffect, useState, useCallback } from 'react'
import { useWos } from '@/core/client/wos-store'
import { api, timeAgo, formatBytes } from '@/core/client/api'
import { bus } from '@/core/client/event-bus'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { File as FileIcon, Folder, Star, Loader2 } from 'lucide-react'

interface EntryRow {
  name: string
  path: string
  isDir: boolean
  size: number
  mtime: string
  mime: string
  favorite: boolean
}

/** Widget: Tệp gần đây (CENTER) */
export function RecentFilesWidget() {
  const { navigate } = useWos()
  const [entries, setEntries] = useState<EntryRow[] | null>(null)

  const load = useCallback(async () => {
    try {
      const data = await api<{ entries: EntryRow[] }>('/api/modules/files/list?dir=')
      const files = data.entries.filter((e) => !e.isDir).sort((a, b) => b.mtime.localeCompare(a.mtime))
      setEntries(files.slice(0, 6))
    } catch {
      setEntries([])
    }
  }, [])

  useEffect(() => {
    load()
    return bus.onAny((ev) => {
      if (ev.module === 'files' && ev.type !== 'file.downloaded') load()
    })
  }, [load])

  return (
    <Card className="wos-glass border-0">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="flex items-center gap-2 text-sm font-semibold">
          <Folder className="h-4 w-4 text-green-500" /> Tệp gần đây
        </CardTitle>
        <button onClick={() => navigate('files')} className="text-xs text-primary hover:underline">
          Mở Files
        </button>
      </CardHeader>
      <CardContent>
        {entries === null ? (
          <div className="flex h-24 items-center justify-center">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        ) : entries.length === 0 ? (
          <p className="py-6 text-center text-sm text-muted-foreground">Chưa có tệp nào trong storage</p>
        ) : (
          <div className="space-y-0.5">
            {entries.map((e) => (
              <button
                key={e.path}
                onClick={() => navigate(`files:${encodeURIComponent(e.path)}`)}
                className="flex w-full items-center gap-3 rounded-lg px-2 py-1.5 text-left transition-colors hover:bg-muted"
              >
                {e.favorite ? (
                  <Star className="h-4 w-4 shrink-0 fill-amber-400 text-amber-400" />
                ) : (
                  <FileIcon className="h-4 w-4 shrink-0 text-muted-foreground" />
                )}
                <span className="min-w-0 flex-1 truncate text-sm">{e.name}</span>
                <span className="shrink-0 text-[11px] tabular-nums text-muted-foreground">{formatBytes(e.size)}</span>
                <span className="hidden shrink-0 text-[11px] text-muted-foreground sm:block">{timeAgo(e.mtime)}</span>
              </button>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
