'use client'

import { useEffect, useState, useCallback, useRef, useMemo } from 'react'
import { useWos } from '@/core/client/wos-store'
import { useRoute } from '@/core/client/route-context'
import { api, formatBytes, timeAgo, fmtDateTime } from '@/core/client/api'
import { bus } from '@/core/client/event-bus'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Progress } from '@/components/ui/progress'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ContextMenu, openCtx, type CtxMenuState } from '@/components/wos/ContextMenu'
import { ImageLightbox } from '../ImageLightbox'
import { useToast } from '@/hooks/use-toast'
import {
  Folder, File as FileIcon, Upload, Search, Loader2, Trash2, Star, Download, Share2,
  Pencil, Copy, Scissors, FolderPlus, Archive, FileArchive, ChevronRight, Grid3x3, List,
  HardDrive, Link2, Home, ArrowUpDown, Info, FilePlus2, Maximize2, ClipboardCopy, ClipboardPaste,
} from 'lucide-react'
import { openFile } from '@/core/client/applications'
import { startFileDownload } from '@/core/client/downloads'
import { useClipboard } from '@/core/client/clipboard'
import ReactMarkdown from 'react-markdown'

interface Entry {
  name: string
  path: string
  isDir: boolean
  size: number
  mtime: string
  mime: string
  favorite: boolean
  tags: string[]
  version: number
  viewedAt?: string | null
}

/** Kiểu sắp xếp danh sách */
type SortKey = 'name-asc' | 'name-desc' | 'size-desc' | 'size-asc' | 'mtime-desc' | 'mtime-asc' | 'viewed-desc'
const SORT_LABEL: Record<SortKey, string> = {
  'name-asc': 'Tên A → Z',
  'name-desc': 'Tên Z → A',
  'size-desc': 'Dung lượng lớn → nhỏ',
  'size-asc': 'Dung lượng nhỏ → lớn',
  'mtime-desc': 'Sửa đổi mới nhất',
  'mtime-asc': 'Sửa đổi cũ nhất',
  'viewed-desc': 'Xem gần nhất',
}

const CATEGORY_ICONS: Record<string, string> = {
  Documents: '📄', Downloads: '⬇️', Pictures: '🖼️', Videos: '🎬',
  Projects: '🗂️', AI: '✨', Backups: '💾', Shared: '👥',
}

function fileIcon(entry: Entry): string {
  if (entry.isDir) return '📁'
  const ext = entry.name.split('.').pop()?.toLowerCase() || ''
  if (['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'bmp', 'ico'].includes(ext)) return '🖼️'
  if (['mp4', 'webm', 'mov', 'mkv'].includes(ext)) return '🎬'
  if (['mp3', 'wav', 'ogg', 'flac'].includes(ext)) return '🎵'
  if (['pdf'].includes(ext)) return '📕'
  if (['doc', 'docx'].includes(ext)) return '📘'
  if (['xls', 'xlsx', 'csv'].includes(ext)) return '📗'
  if (['ppt', 'pptx'].includes(ext)) return '📙'
  if (['zip', 'tar', 'gz'].includes(ext)) return '🗜️'
  if (['md', 'markdown'].includes(ext)) return '📝'
  if (['js', 'ts', 'tsx', 'jsx', 'json', 'py', 'sh', 'css', 'html', 'yml', 'yaml'].includes(ext)) return '📜'
  return '📄'
}

export default function FilesPage() {
  const { emit } = useWos()
  const { route, navigate, seq } = useRoute()
  const { toast } = useToast()
  const [dir, setDir] = useState('')
  const [entries, setEntries] = useState<Entry[] | null>(null)
  const [usage, setUsage] = useState<{ usage: number; quota: number } | null>(null)
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [query, setQuery] = useState('')
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [preview, setPreview] = useState<Entry | null>(null)
  const [uploading, setUploading] = useState(false)
  const [uploadPct, setUploadPct] = useState(0)
  const [shareOpen, setShareOpen] = useState<Entry | null>(null)
  const [shareLink, setShareLink] = useState<string | null>(null)
  const [renaming, setRenaming] = useState<Entry | null>(null)
  const [renameValue, setRenameValue] = useState('')
  const [moving, setMoving] = useState<Entry | null>(null)
  const [moveTarget, setMoveTarget] = useState('')
  const [showTrash, setShowTrash] = useState(false)
  const [trashItems, setTrashItems] = useState<{ path: string; name: string; size: number; trashedAt: string }[]>([])
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [dragOver, setDragOver] = useState(false)
  /** Sort + search toàn hệ thống + context menu + lightbox */
  const [sortBy, setSortBy] = useState<SortKey>('name-asc')
  const [searchResults, setSearchResults] = useState<Entry[] | null>(null)
  const [menu, setMenu] = useState<CtxMenuState | null>(null)
  const [infoEntry, setInfoEntry] = useState<Entry | null>(null)
  const [lightbox, setLightbox] = useState<{ images: Entry[]; index: number } | null>(null)

  // Deep link: files:<path> — "files:trash" mở thùng rác
  // (đặt SAU khai báo loadTrash — deps cần tham chiếu nó an toàn)

  const load = useCallback(async () => {
    try {
      const data = await api<{ entries: Entry[] }>(`/api/modules/files/list?dir=${encodeURIComponent(dir)}`)
      setEntries(data.entries)
      const u = await api<{ usage: number; quota: number }>('/api/modules/files/usage?quota=20').catch(() => null)
      if (u) setUsage(u)
    } catch (err) {
      setEntries([])
      toast({ title: 'Không đọc được thư mục', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }, [dir, toast])

  const loadTrash = useCallback(async () => {
    try {
      const data = await api<{ trash: { path: string; name: string; size: number; trashedAt: string }[] }>('/api/modules/files/trash')
      setTrashItems(data.trash)
    } catch {
      setTrashItems([])
    }
  }, [])

  // Deep-link files:<path> ("files:trash" = thùng rác) — dùng SEQ làm dependency:
  // seq tăng mỗi lần route được GÁN (kể cả cùng giá trị) nên click lại CÙNG thư mục
  // vẫn mở đúng; KHÔNG reset route sau khi đọc → hết race "về Home lúc đúng lúc sai"
  // (review #1). Điều hướng bên trong app gọi go() — đồng bộ cả route + title cửa sổ.
  useEffect(() => {
    if (!route.startsWith('files:')) return
    const p = decodeURIComponent(route.slice(6))
    if (p === 'trash' || p === '__trash__') {
      setShowTrash(true)
      void loadTrash()
    } else if (p) {
      setShowTrash(false)
      setDir(p.endsWith('/') ? p.slice(0, -1) : p)
    }
  }, [seq, route, loadTrash])

  /** Điều hướng bên trong Files: đổi thư mục + đồng bộ route (title cửa sổ đúng thư mục) */
  const go = useCallback(
    (path: string) => {
      setQuery('')
      setShowTrash(false)
      setDir(path)
      navigate(`files:${encodeURIComponent(path)}`)
    },
    [navigate],
  )

  useEffect(() => {
    load()
  }, [load])

  useEffect(() => {
    if (showTrash) loadTrash()
  }, [showTrash, loadTrash])

  useEffect(() => {
    return bus.onAny((ev) => {
      if (ev.module === 'files' && ev.type !== 'file.downloaded') load()
    })
  }, [load])

  // ==== CLIPBOARD PC (Ctrl+C / Ctrl+X / Ctrl+V) — tệp đang chọn ====
  const clipPayload = useClipboard((s) => s.payload)
  useEffect(() => {
    const onKey = (ev: KeyboardEvent) => {
      // không chặn khi đang gõ trong ô nhập
      const t = ev.target as HTMLElement | null
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return
      if (showTrash) return
      const mod = ev.ctrlKey || ev.metaKey
      if (!mod) return
      if (ev.key === 'c' || ev.key === 'C') {
        if (selected.size > 0) {
          useClipboard.getState().copyFiles([...selected], dir)
          toast({ title: `Đã sao chép ${selected.size} mục` })
        }
      } else if (ev.key === 'x' || ev.key === 'X') {
        if (selected.size > 0) {
          useClipboard.getState().cutFiles([...selected], dir)
          toast({ title: `Đã cắt ${selected.size} mục — dán vào thư mục đích` })
        }
      } else if (ev.key === 'v' || ev.key === 'V') {
        const p = useClipboard.getState().payload
        if (p) {
          ev.preventDefault()
          void (async () => {
            const r = await useClipboard.getState().pasteInto(dir)
            if (r.ok > 0) {
              toast({ title: `Đã dán ${r.ok} mục vào ${dir || 'thư mục gốc'}` })
              setSelected(new Set())
            } else if (r.failed[0]) {
              toast({ title: 'Dán không thành công', description: r.failed[0], variant: 'destructive' })
            }
          })()
        }
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [selected, dir, showTrash, toast])

  async function uploadFiles(files: FileList | File[]) {
    const arr = Array.from(files)
    if (arr.length === 0) return
    setUploading(true)
    setUploadPct(0)
    try {
      const form = new FormData()
      for (const f of arr) form.append('files', f)
      // XMLHttpRequest để có tiến độ
      await new Promise<void>((resolve, reject) => {
        const xhr = new XMLHttpRequest()
        xhr.open('POST', `/api/modules/files/upload?dir=${encodeURIComponent(dir)}`)
        xhr.upload.onprogress = (e) => {
          if (e.lengthComputable) setUploadPct(Math.round((e.loaded / e.total) * 100))
        }
        xhr.onload = () => (xhr.status < 300 ? resolve() : reject(new Error(JSON.parse(xhr.responseText || '{}').error || `HTTP ${xhr.status}`)))
        xhr.onerror = () => reject(new Error('Lỗi mạng khi tải lên'))
        xhr.send(form)
      })
      emit('file.uploaded', 'files', { name: arr.length === 1 ? arr[0].name : `${arr.length} tệp` })
      await load()
      toast({ title: 'Tải lên hoàn tất', description: `${arr.length} tệp → ${dir || 'thư mục gốc'}` })
    } catch (err) {
      toast({ title: 'Tải lên thất bại', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setUploading(false)
      setUploadPct(0)
    }
  }

  async function op(opName: string, body: Record<string, unknown>, successMsg?: string) {
    try {
      const result = await api<Record<string, unknown>>(`/api/modules/files/${opName}`, { method: 'POST', body })
      if (successMsg) toast({ title: successMsg })
      await load()
      return result
    } catch (err) {
      toast({ title: 'Thao tác thất bại', description: err instanceof Error ? err.message : '', variant: 'destructive' })
      return null
    }
  }

  async function trashSelected() {
    const paths = [...selected]
    if (paths.length === 0) return
    if (!confirm(`Chuyển ${paths.length} mục vào thùng rác?`)) return
    await op('trash', { paths }, 'Đã chuyển vào thùng rác')
    emit('file.deleted', 'files', { name: paths[0] })
    setSelected(new Set())
  }

  const crumbs = useMemo(() => {
    const parts = dir ? dir.split('/') : []
    return [{ label: 'Home', path: '' }, ...parts.map((p, i) => ({ label: p, path: parts.slice(0, i + 1).join('/') }))]
  }, [dir])

  // Tìm kiếm TOÀN HỆ THỐNG (đệ quy mọi thư mục, server-side) — debounce 300ms
  useEffect(() => {
    const q = query.trim()
    if (!q) {
      setSearchResults(null)
      return
    }
    const t = setTimeout(() => {
      api<{ results: Entry[] }>(`/api/modules/files/search?q=${encodeURIComponent(q)}`)
        .then((d) => setSearchResults(d.results || []))
        .catch(() => setSearchResults([]))
    }, 300)
    return () => clearTimeout(t)
  }, [query])

  const sorted = useMemo(() => {
    const list = [...(entries || [])]
    const num = (v: number) => (Number.isFinite(v) ? v : 0)
    switch (sortBy) {
      case 'name-asc': return list.sort((a, b) => (a.isDir === b.isDir ? a.name.localeCompare(b.name, 'vi') : a.isDir ? -1 : 1))
      case 'name-desc': return list.sort((a, b) => (a.isDir === b.isDir ? b.name.localeCompare(a.name, 'vi') : a.isDir ? -1 : 1))
      case 'size-desc': return list.sort((a, b) => num(b.size) - num(a.size))
      case 'size-asc': return list.sort((a, b) => num(a.size) - num(b.size))
      case 'mtime-desc': return list.sort((a, b) => new Date(b.mtime).getTime() - new Date(a.mtime).getTime())
      case 'mtime-asc': return list.sort((a, b) => new Date(a.mtime).getTime() - new Date(b.mtime).getTime())
      case 'viewed-desc':
        return list.sort(
          (a, b) =>
            new Date(b.viewedAt || 0).getTime() - new Date(a.viewedAt || 0).getTime() ||
            new Date(b.mtime).getTime() - new Date(a.mtime).getTime(),
        )
    }
  }, [entries, sortBy])

  /** Đang tìm → danh sách kết quả toàn hệ thống; không → thư mục hiện tại đã sort */
  const filtered = query.trim() ? searchResults || [] : sorted
  const quotaPct = usage && usage.quota ? Math.min(100, (usage.usage / usage.quota) * 100) : 0

  const images = useMemo(
    () => filtered.filter((e) => !e.isDir && e.mime.startsWith('image/')),
    [filtered],
  )

  function isImage(e: Entry): boolean {
    return !e.isDir && e.mime.startsWith('image/')
  }

  function openPreview(e: Entry) {
    setPreview(e)
    void api('/api/modules/files/view', { method: 'POST', body: { path: e.path } }).catch(() => {})
  }

  /** Mở tệp bằng app phù hợp (Application System V3) — PDF→Documents, video→Media… */
  function openWith(e: Entry) {
    if (e.isDir) {
      go(e.path)
      return
    }
    openFile(e.path)
  }

  function openLightbox(e: Entry) {
    const i = images.findIndex((img) => img.path === e.path)
    setLightbox(i >= 0 ? { images, index: i } : { images: [e], index: 0 })
  }

  /** Menu chuột phải kiểu macOS cho 1 entry (grid + list + search) */
  function menuFor(e: Entry): CtxMenuState['items'] {
    const targetPaths = selected.has(e.path) && selected.size > 1 ? [...selected] : [e.path]
    return [
      {
        label: 'Mở',
        icon: Folder,
        onClick: () => (e.isDir ? go(e.path) : openWith(e)),
      },
      ...(e.isDir
        ? []
        : [
            {
              label: 'Xem nhanh',
              icon: Maximize2,
              onClick: () => openPreview(e),
            },
            ...(isImage(e) ? [{ label: 'Xem ảnh toàn màn hình', icon: Maximize2, onClick: () => openLightbox(e) }] : []),
          ]),
      ...(query.trim() && e.isDir
        ? [{ label: 'Mở thư mục này', icon: Folder, onClick: () => go(e.path) }]
        : []),
      { separator: true, label: '' },
      { label: 'Sao chép (Ctrl+C)', icon: ClipboardCopy, onClick: () => { useClipboard.getState().copyFiles(targetPaths, dir); toast({ title: `Đã sao chép ${targetPaths.length} mục` }) } },
      { label: 'Cắt (Ctrl+X)', icon: Scissors, onClick: () => { useClipboard.getState().cutFiles(targetPaths, dir); toast({ title: `Đã cắt ${targetPaths.length} mục` }) } },
      ...(clipPayload
        ? [
            {
              label: `Dán vào ${e.isDir ? e.name : 'thư mục này'} (Ctrl+V)`,
              icon: ClipboardPaste,
              onClick: () => {
                void (async () => {
                  const r = await useClipboard.getState().pasteInto(e.isDir ? e.path : dir)
                  if (r.ok > 0) toast({ title: `Đã dán ${r.ok} mục` })
                  else if (r.failed[0]) toast({ title: 'Dán không thành công', description: r.failed[0], variant: 'destructive' })
                })()
              },
            },
          ]
        : []),
      { separator: true, label: '' },
      { label: 'Tải xuống', icon: Download, disabled: e.isDir, onClick: () => startFileDownload(e.path, e.name) },
      { label: 'Đổi tên', icon: Pencil, onClick: () => { setRenaming(e); setRenameValue(e.name) } },
      { label: 'Di chuyển / Sao chép', icon: Copy, onClick: () => { setMoving(e); setMoveTarget('') } },
      { label: 'Chia sẻ', icon: Share2, disabled: e.isDir, onClick: () => setShareOpen(e) },
      { label: e.favorite ? 'Bỏ yêu thích' : 'Yêu thích', icon: Star, onClick: () => op('favorite', { path: e.path, favorite: !e.favorite }).then(() => emit('file.updated', 'files', { name: e.name })) },
      ...(e.name.endsWith('.zip') ? [{ label: 'Giải nén', icon: FileArchive, onClick: () => op('extract', { path: e.path }, 'Giải nén xong').then(() => emit('file.updated', 'files', { name: e.name })) }] : []),
      { separator: true, label: '' },
      { label: 'Xem thông tin', icon: Info, onClick: () => setInfoEntry(e) },
      { label: 'Xoá (thùng rác)', icon: Trash2, danger: true, onClick: () => { void op('trash', { paths: [e.path] }, 'Đã chuyển vào thùng rác'); emit('file.deleted', 'files', { name: e.name }) } },
    ]
  }

  return (
    <div
      className="space-y-4"
      onDragOver={(e) => {
        e.preventDefault()
        setDragOver(true)
      }}
      onDragLeave={() => setDragOver(false)}
      onDrop={(e) => {
        e.preventDefault()
        setDragOver(false)
        if (e.dataTransfer.files.length) uploadFiles(e.dataTransfer.files)
      }}
    >
      {/* Header */}
      <div className="flex flex-wrap items-center gap-3">
        <h1 className="flex items-center gap-2.5 text-xl font-bold">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-green-500 text-white">
            <Folder className="h-5 w-5" />
          </span>
          Files
        </h1>
        <div className="ml-auto flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Tìm tệp toàn hệ thống…" className="h-9 w-52 pl-8" />
          </div>
          <Select value={sortBy} onValueChange={(v) => setSortBy(v as SortKey)}>
            <SelectTrigger className="h-9 w-[190px] text-xs" aria-label="Sắp xếp theo">
              <ArrowUpDown className="mr-1 h-3.5 w-3.5 shrink-0 text-muted-foreground" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {(Object.keys(SORT_LABEL) as SortKey[]).map((k) => (
                <SelectItem key={k} value={k}>{SORT_LABEL[k]}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm" className="h-9 gap-1.5" onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}>
            {viewMode === 'grid' ? <List className="h-4 w-4" /> : <Grid3x3 className="h-4 w-4" />}
          </Button>
          <Button variant="outline" size="sm" className="h-9 gap-1.5" onClick={() => setShowTrash(!showTrash)}>
            <Trash2 className="h-4 w-4" /> {showTrash ? 'Thoát rác' : 'Thùng rác'}
          </Button>
          <Button size="sm" className="h-9 gap-1.5" onClick={() => fileInputRef.current?.click()} disabled={uploading}>
            {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />} Tải lên
          </Button>
          <input
            ref={fileInputRef}
            type="file"
            multiple
            className="hidden"
            onChange={(e) => {
              if (e.target.files) uploadFiles(e.target.files)
              e.target.value = ''
            }}
          />
        </div>
      </div>

      {/* Storage quota */}
      {usage && (
        <Card className="wos-glass border-0 py-2">
          <CardContent className="flex items-center gap-4 px-4">
            <HardDrive className="h-4 w-4 shrink-0 text-muted-foreground" />
            <div className="min-w-0 flex-1">
              <div className="mb-1 flex justify-between text-[11px] text-muted-foreground">
                <span>Storage đã dùng</span>
                <span className="tabular-nums">{formatBytes(usage.usage)} / {formatBytes(usage.quota)} ({quotaPct.toFixed(1)}%)</span>
              </div>
              <Progress value={quotaPct} className="h-1.5" />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Upload progress */}
      {uploading && (
        <Card className="wos-glass border-0 py-3">
          <CardContent className="space-y-2 px-4">
            <div className="flex justify-between text-xs font-medium">
              <span>Đang tải lên…</span>
              <span className="tabular-nums">{uploadPct}%</span>
            </div>
            <Progress value={uploadPct} className="h-2" />
          </CardContent>
        </Card>
      )}

      {showTrash ? (
        /* ===== RECYCLE BIN ===== */
        <Card className="wos-glass border-0">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-base font-semibold">
              <Trash2 className="h-4 w-4" /> Recycle Bin — {trashItems.length} mục
            </CardTitle>
            {trashItems.length > 0 && (
              <Button size="sm" variant="outline" className="h-8" onClick={() => op('empty-trash', {}, 'Đã dọn sạch thùng rác').then(() => loadTrash())}>
                Dọn sạch
              </Button>
            )}
          </CardHeader>
          <CardContent className="space-y-1.5">
            {trashItems.length === 0 && <p className="py-8 text-center text-sm text-muted-foreground">Thùng rác trống</p>}
            {trashItems.map((t) => (
              <div key={t.path} className="flex items-center gap-3 rounded-xl bg-muted/50 px-3 py-2.5">
                <span className="text-lg">{t.path.endsWith('/') ? '📁' : '📄'}</span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{t.name}</p>
                  <p className="text-[11px] text-muted-foreground">{t.path} · {formatBytes(t.size)} · xoá {timeAgo(t.trashedAt)}</p>
                </div>
                <Button size="sm" variant="outline" className="h-8 gap-1 text-xs" onClick={() => op('restore', { path: t.path }, 'Đã khôi phục').then(() => loadTrash())}>
                  Khôi phục
                </Button>
                <Button size="sm" variant="destructive" className="h-8 gap-1 text-xs" onClick={() => op('delete', { path: t.path }, 'Đã xoá vĩnh viễn').then(() => loadTrash())}>
                  Xoá
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      ) : (
        <>
          {/* Breadcrumb + actions */}
          <Card className="wos-glass border-0 py-2.5">
            <CardContent className="flex flex-wrap items-center gap-2 px-3">
              <div className="flex min-w-0 flex-1 flex-wrap items-center gap-1">
                {crumbs.map((c, i) => (
                  <span key={c.path} className="flex items-center gap-1">
                    {i > 0 && <ChevronRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />}
                    <button
                      onClick={() => go(c.path)}
                      className={`rounded-md px-1.5 py-0.5 text-sm ${i === crumbs.length - 1 ? 'font-semibold' : 'text-muted-foreground hover:text-foreground'}`}
                    >
                      {i === 0 ? <Home className="inline h-4 w-4" /> : c.label}
                    </button>
                  </span>
                ))}
              </div>
              <div className="flex items-center gap-1">
                <Button variant="ghost" size="sm" className="h-8 gap-1 text-xs" onClick={() => {
                  const name = prompt('Tên thư mục mới:')
                  if (name?.trim()) op('mkdir', { path: dir, name }, 'Đã tạo thư mục')
                }}>
                  <FolderPlus className="h-3.5 w-3.5" /> Thư mục
                </Button>
                {clipPayload && !showTrash ? (
                  <Button variant="ghost" size="sm" className="h-8 gap-1 text-xs text-primary" title={
                    clipPayload.kind === 'files'
                      ? `${clipPayload.paths.length} mục ${clipPayload.cut ? 'đã cắt' : 'đã sao chép'} — dán vào ${dir || 'thư mục gốc'}`
                      : 'Dán văn bản trong bảng tạm thành tệp .txt'
                  } onClick={() => {
                    void (async () => {
                      const r = await useClipboard.getState().pasteInto(dir)
                      if (r.ok > 0) toast({ title: `Đã dán ${r.ok} mục vào ${dir || 'thư mục gốc'}` })
                      else if (r.failed[0]) toast({ title: 'Dán không thành công', description: r.failed[0], variant: 'destructive' })
                    })()
                  }}>
                    <ClipboardPaste className="h-3.5 w-3.5" /> Dán
                    {clipPayload.kind === 'files' ? ` (${clipPayload.paths.length})` : ''}
                  </Button>
                ) : null}
                <Button variant="ghost" size="sm" className="h-8 gap-1 text-xs" onClick={() => {
                  const name = prompt('Tên tệp văn bản mới (vd ghi-chu.md):')
                  if (name?.trim()) op('newfile', { path: dir, name: name.trim() }, 'Đã tạo tệp').then(() => emit('file.uploaded', 'files', { name: name.trim() }))
                }}>
                  <FilePlus2 className="h-3.5 w-3.5" /> Tệp mới
                </Button>
                {selected.size > 0 && (
                  <>
                    <Badge variant="secondary" className="h-8 px-2 text-xs">{selected.size} chọn</Badge>
                    <Button variant="ghost" size="sm" className="h-8 gap-1 text-xs" onClick={() => {
                      const paths = [...selected]
                      const name = paths[0].split('/').pop() || ''
                      const zipName = name.replace(/\.[^.]+$/, '') + '.zip'
                      op('compress', { paths }, `Đã nén thành ${zipName}`).then((r) => { if (r && r.path) emit('file.updated', 'files', { name: zipName }) })
                      setSelected(new Set())
                    }}>
                      <Archive className="h-3.5 w-3.5" /> Nén
                    </Button>
                    <Button variant="ghost" size="sm" className="h-8 gap-1 text-xs text-rose-600" onClick={trashSelected}>
                      <Trash2 className="h-3.5 w-3.5" /> Xoá
                    </Button>
                  </>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Drop zone hint */}
          {dragOver && (
            <div className="rounded-2xl border-2 border-dashed border-primary bg-primary/5 py-8 text-center">
              <Upload className="mx-auto mb-2 h-8 w-8 text-primary" />
              <p className="text-sm font-medium text-primary">Thả tệp để tải lên {dir || 'thư mục gốc'}</p>
            </div>
          )}

          {/* Entries */}
          {entries === null && !query.trim() ? (
            <div className="flex h-64 items-center justify-center">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : filtered.length === 0 ? (
            <div className="wos-glass flex flex-col items-center gap-2 rounded-2xl py-14 text-muted-foreground">
              <Folder className="h-10 w-10 opacity-30" />
              <p className="text-sm">{query.trim() ? (searchResults === null ? 'Đang tìm…' : `Không tìm thấy "${query.trim()}" trong toàn bộ tệp`) : 'Thư mục trống — kéo thả tệp vào đây để tải lên'}</p>
            </div>
          ) : query.trim() ? (
            /* ===== KẾT QUẢ TÌM KIẾM TOÀN HỆ THỐNG ===== */
            <div className="wos-glass overflow-hidden rounded-2xl">
              <div className="border-b bg-muted/40 px-4 py-2 text-xs font-semibold text-muted-foreground">
                {filtered.length} kết quả cho "{query.trim()}" — toàn bộ thư mục
              </div>
              {filtered.map((e) => (
                <div
                  key={e.path}
                  className="flex items-center gap-3 px-4 py-2.5 transition-colors hover:bg-muted/50"
                  onContextMenu={(ev) => openCtx(ev, setMenu, menuFor(e))}
                >
                  <span className="text-lg shrink-0">{fileIcon(e)}</span>
                  <button
                    className="flex min-w-0 flex-1 items-center gap-2 text-left"
                    onClick={() => (e.isDir ? go(e.path) : setSelected(new Set([e.path])))}
                    onDoubleClick={() => (e.isDir ? go(e.path) : openWith(e))}
                  >
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-medium">{e.name}</span>
                      <span className="block truncate text-[11px] text-muted-foreground">{e.path}</span>
                    </span>
                  </button>
                  <span className="shrink-0 text-xs tabular-nums text-muted-foreground">{e.isDir ? '—' : formatBytes(e.size)}</span>
                  <span className="shrink-0 text-xs text-muted-foreground">{timeAgo(e.mtime)}</span>
                </div>
              ))}
            </div>
          ) : viewMode === 'grid' ? (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-6">
              {filtered.map((e) => (
                <div
                  key={e.path}
                  className={`wos-glass group relative flex cursor-pointer flex-col items-center gap-2 rounded-2xl p-4 transition-all hover:-translate-y-0.5 hover:shadow-lg ${
                    selected.has(e.path) ? 'ring-2 ring-primary' : ''
                  }`}
                  onContextMenu={(ev) => openCtx(ev, setMenu, menuFor(e))}
                  onClick={(ev) => {
                    if (ev.metaKey || ev.ctrlKey) {
                      const next = new Set(selected)
                      if (next.has(e.path)) next.delete(e.path)
                      else next.add(e.path)
                      setSelected(next)
                    } else if (e.isDir) {
                      go(e.path)
                    } else {
                      // PC-like: 1 click = chọn, double click = mở bằng app phù hợp
                      setSelected(new Set([e.path]))
                    }
                  }}
                  onDoubleClick={() => openWith(e)}
                >
                  <span className="absolute right-2 top-2 flex items-center gap-1">
                    {e.favorite && <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />}
                  </span>
                  <span className="text-4xl">{fileIcon(e)}</span>
                  <p className="w-full truncate text-center text-xs font-medium">{e.name}</p>
                  <p className="text-[10px] text-muted-foreground">{e.isDir ? 'Thư mục' : formatBytes(e.size)}</p>
                  <button
                    className="absolute right-1.5 top-1.5 hidden rounded-lg bg-background/90 p-1 shadow group-hover:block"
                    onClick={(ev) => {
                      ev.stopPropagation()
                      setShareOpen(e)
                    }}
                    aria-label="Chia sẻ"
                  >
                    <Share2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="wos-glass overflow-hidden rounded-2xl">
              <div className="grid grid-cols-[1fr_90px_110px_150px] border-b bg-muted/40 px-4 py-2 text-xs font-semibold text-muted-foreground">
                <span>Tên</span>
                <span className="text-right">Dung lượng</span>
                <span className="text-right">Sửa đổi</span>
                <span className="text-right">Thao tác</span>
              </div>
              {filtered.map((e) => (
                <div
                  key={e.path}
                  className={`grid grid-cols-[1fr_90px_110px_150px] items-center px-4 py-2.5 transition-colors hover:bg-muted/50 ${
                    selected.has(e.path) ? 'bg-primary/5' : ''
                  }`}
                  onContextMenu={(ev) => openCtx(ev, setMenu, menuFor(e))}
                >
                  <button
                    className="flex min-w-0 items-center gap-2.5 text-left"
                    onClick={() => (e.isDir ? go(e.path) : setSelected(new Set([e.path])))}
                    onDoubleClick={() => (e.isDir ? go(e.path) : openWith(e))}
                  >
                    <span className="text-lg">{fileIcon(e)}</span>
                    <span className="truncate text-sm font-medium">{e.name}</span>
                    {e.tags.length > 0 && <Badge variant="secondary" className="h-4 px-1.5 text-[9px]">{e.tags[0]}</Badge>}
                  </button>
                  <span className="text-right text-xs tabular-nums text-muted-foreground">{e.isDir ? '—' : formatBytes(e.size)}</span>
                  <span className="text-right text-xs text-muted-foreground">{timeAgo(e.mtime)}</span>
                  <div className="flex items-center justify-end gap-1">
                    <IconBtn title="Yêu thích" onClick={() => op('favorite', { path: e.path, favorite: !e.favorite }).then(() => emit('file.updated', 'files', { name: e.name }))}>
                      <Star className={`h-3.5 w-3.5 ${e.favorite ? 'fill-amber-400 text-amber-400' : ''}`} />
                    </IconBtn>
                    <IconBtn title="Đổi tên" onClick={() => { setRenaming(e); setRenameValue(e.name) }}>
                      <Pencil className="h-3.5 w-3.5" />
                    </IconBtn>
                    <IconBtn title="Di chuyển / Sao chép" onClick={() => { setMoving(e); setMoveTarget('') }}>
                      <Copy className="h-3.5 w-3.5" />
                    </IconBtn>
                    {e.name.endsWith('.zip') && (
                      <IconBtn title="Giải nén" onClick={() => op('extract', { path: e.path }, 'Giải nén xong').then(() => emit('file.updated', 'files', { name: e.name }))}>
                        <FileArchive className="h-3.5 w-3.5" />
                      </IconBtn>
                    )}
                    <IconBtn title="Chia sẻ" onClick={() => setShareOpen(e)}>
                      <Share2 className="h-3.5 w-3.5" />
                    </IconBtn>
                    <IconBtn title="Tải xuống (có tiến trình)" onClick={() => startFileDownload(e.path, e.name)}>
                      <Download className="h-3.5 w-3.5" />
                    </IconBtn>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Category gợi ý khi ở root */}
          {dir === '' && !query && (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-8">
              {Object.entries(CATEGORY_ICONS).map(([name, icon]) => (
                <button
                  key={name}
                  onClick={() => go(name)}
                  className="wos-glass flex flex-col items-center gap-1.5 rounded-xl px-2 py-3 transition-shadow hover:shadow-md"
                >
                  <span className="text-2xl">{icon}</span>
                  <span className="text-xs font-medium">{name}</span>
                </button>
              ))}
            </div>
          )}
        </>
      )}

      {/* ===== Dialogs ===== */}
      {preview && (
        <PreviewDialog
          entry={preview}
          onClose={() => setPreview(null)}
          onOpenDir={(p) => { setPreview(null); go(p) }}
          onLightbox={isImage(preview) ? () => openLightbox(preview) : undefined}
        />
      )}
      {menu ? <ContextMenu state={menu} onClose={() => setMenu(null)} /> : null}
      {lightbox ? (
        <ImageLightbox
          images={lightbox.images}
          index={lightbox.index}
          onIndex={(i) => setLightbox({ ...lightbox, index: i })}
          onClose={() => setLightbox(null)}
        />
      ) : null}
      {infoEntry && <FileInfoDialog entry={infoEntry} onClose={() => setInfoEntry(null)} />}
      {renaming && (
        <Dialog open onOpenChange={(o) => !o && setRenaming(null)}>
          <DialogContent className="wos-glass-strong sm:max-w-[380px]">
            <DialogHeader><DialogTitle>Đổi tên</DialogTitle></DialogHeader>
            <Input value={renameValue} onChange={(e) => setRenameValue(e.target.value)} autoFocus />
            <div className="flex justify-end gap-2">
              <Button variant="outline" size="sm" onClick={() => setRenaming(null)}>Huỷ</Button>
              <Button size="sm" onClick={async () => {
                await op('rename', { path: renaming.path, name: renameValue }, 'Đã đổi tên')
                emit('file.updated', 'files', { name: renameValue })
                setRenaming(null)
              }}>Lưu</Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
      {moving && (
        <Dialog open onOpenChange={(o) => !o && setMoving(null)}>
          <DialogContent className="wos-glass-strong sm:max-w-[420px]">
            <DialogHeader><DialogTitle>Di chuyển / Sao chép — {moving.name}</DialogTitle></DialogHeader>
            <p className="text-sm text-muted-foreground">Nhập thư mục đích (tương đối, ví dụ: Documents hoặc Documents/2026)</p>
            <Input value={moveTarget} onChange={(e) => setMoveTarget(e.target.value)} placeholder="Documents" autoFocus />
            <div className="flex justify-end gap-2">
              <Button variant="outline" size="sm" onClick={async () => {
                const name = moving.name
                await op('copy', { path: moving.path, to: moveTarget ? `${moveTarget}/${name}` : `Copy of ${name}` }, 'Đã sao chép')
                emit('file.updated', 'files', { name })
                setMoving(null)
              }}><Copy className="mr-1 h-4 w-4" /> Sao chép</Button>
              <Button size="sm" onClick={async () => {
                const name = moving.name
                await op('move', { path: moving.path, to: moveTarget ? `${moveTarget}/${name}` : name }, 'Đã di chuyển')
                emit('file.updated', 'files', { name })
                setMoving(null)
              }}><Scissors className="mr-1 h-4 w-4" /> Di chuyển</Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
      {shareOpen && (
        <Dialog open onOpenChange={(o) => { if (!o) { setShareOpen(null); setShareLink(null) } }}>
          <DialogContent className="wos-glass-strong sm:max-w-[440px]">
            <DialogHeader><DialogTitle className="flex items-center gap-2"><Link2 className="h-4 w-4" /> Chia sẻ — {shareOpen.name}</DialogTitle></DialogHeader>
            {shareLink ? (
              <div className="space-y-3">
                <div className="flex items-center gap-2 rounded-xl bg-muted px-3 py-2.5">
                  <code className="min-w-0 flex-1 truncate text-xs">{shareLink}</code>
                  <Button size="sm" variant="secondary" className="h-7 shrink-0 text-xs" onClick={() => navigator.clipboard.writeText(shareLink).then(() => toast({ title: 'Đã sao chép link' }))}>
                    Copy
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">Ai có link đều tải được tệp này. Link không tự hết hạn.</p>
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-sm">Tạo link công khai để chia sẻ tệp (không cần đăng nhập)?</p>
                <Button size="sm" onClick={async () => {
                  const r = await op('share', { path: shareOpen.path }, undefined)
                  if (r && r.url) {
                    setShareLink(`${window.location.origin}${r.url}`)
                    emit('file.shared', 'files', { name: shareOpen.name })
                  }
                }}>
                  <Share2 className="mr-1.5 h-4 w-4" /> Tạo link chia sẻ
                </Button>
              </div>
            )}
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}

function IconBtn({ children, title, onClick }: { children: React.ReactNode; title: string; onClick: () => void }) {
  return (
    <button
      onClick={(e) => { e.stopPropagation(); onClick() }}
      title={title}
      className="rounded-lg p-1.5 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
    >
      {children}
    </button>
  )
}

/** Preview: text/markdown JSON; ảnh/video/pdf/audio qua inline URL */
function PreviewDialog({ entry, onClose, onOpenDir, onLightbox }: { entry: Entry; onClose: () => void; onOpenDir: (path: string) => void; onLightbox?: () => void }) {
  const [data, setData] = useState<{ type: string; content?: string; mime?: string; size?: number; url?: string } | null>(null)
  const isMd = entry.name.endsWith('.md') || entry.name.endsWith('.markdown')

  useEffect(() => {
    api<{ type: string; content?: string; mime?: string; size?: number; url?: string }>(
      `/api/modules/files/preview?path=${encodeURIComponent(entry.path)}`
    )
      .then(setData)
      .catch(() => setData(null))
  }, [entry.path])

  const download = `/api/modules/files/download?path=${encodeURIComponent(entry.path)}`

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="wos-glass-strong flex max-h-[85vh] flex-col overflow-hidden sm:max-w-[760px]">
        <DialogHeader className="flex-row items-center gap-3 border-b">
          <DialogTitle className="flex min-w-0 items-center gap-2.5 text-base">
            <span className="text-2xl">{fileIcon(entry)}</span>
            <span className="truncate">{entry.name}</span>
            <Badge variant="secondary" className="shrink-0">{formatBytes(entry.size)}</Badge>
          </DialogTitle>
          <div className="ml-auto flex items-center gap-1">
            {onLightbox && (
              <Button variant="secondary" size="sm" className="h-8 gap-1.5" onClick={onLightbox}>
                <Maximize2 className="h-3.5 w-3.5" /> Toàn màn hình
              </Button>
            )}
            <Button variant="secondary" size="sm" className="h-8 gap-1.5" onClick={() => startFileDownload(entry.path, entry.name)}>
              <Download className="h-3.5 w-3.5" /> Tải xuống
            </Button>
          </div>
        </DialogHeader>
        <div className="wos-scroll min-h-[300px] flex-1 overflow-auto p-4">
          {!data ? (
            <div className="flex h-full items-center justify-center">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : data.type === 'text' ? (
            isMd ? (
              <div className="wos-md">
                <ReactMarkdown>{data.content || ''}</ReactMarkdown>
              </div>
            ) : (
              <pre className="whitespace-pre-wrap break-all font-mono text-xs leading-relaxed">{data.content}</pre>
            )
          ) : data.type === 'binary' && data.mime?.startsWith('image/') ? (
             
            <img src={data.url} alt={entry.name} className="mx-auto max-h-[60vh] rounded-xl object-contain" />
          ) : data.type === 'binary' && data.mime?.startsWith('video/') ? (
            <video controls src={data.url} className="mx-auto max-h-[60vh] rounded-xl" />
          ) : data.type === 'binary' && data.mime?.startsWith('audio/') ? (
            <audio controls src={data.url} className="w-full" />
          ) : data.type === 'binary' && data.mime === 'application/pdf' ? (
            <iframe src={data.url} title={entry.name} className="h-[60vh] w-full rounded-xl" />
          ) : data.type === 'binary' && entry.name.endsWith('.zip') ? (
            <div className="flex flex-col items-center gap-2 py-12 text-muted-foreground">
              <FileArchive className="h-10 w-10 opacity-40" />
              <p className="text-sm">Tệp nén — tải xuống để xem nội dung</p>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-2 py-12 text-muted-foreground">
              <FileIcon className="h-10 w-10 opacity-40" />
              <p className="text-sm">Không xem trước được loại tệp này ({data.mime || 'không rõ'})</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}

/** Dialog "Xem thông tin" — gộp metadata DB + fs stat */
function FileInfoDialog({ entry, onClose }: { entry: Entry; onClose: () => void }) {
  interface NodeRow {
    favorite: boolean; tags: string; version: number; viewedAt: string | null;
    createdAt: string; updatedAt: string; mime: string
  }
  const [node, setNode] = useState<NodeRow | null>(null)
  const [fs, setFs] = useState<{ size: number; mtime: string; birthtime: string; isDir: boolean } | null>(null)
  useEffect(() => {
    api<{ node: NodeRow | null; fs: { size: number; mtime: string; birthtime: string; isDir: boolean } | null }>(
      `/api/modules/files/info?path=${encodeURIComponent(entry.path)}`,
    )
      .then((d) => { setNode(d.node); setFs(d.fs) })
      .catch(() => {})
  }, [entry.path])
  const tags = node ? (() => { try { return JSON.parse(node.tags || '[]') as string[] } catch { return [] } })() : []
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="wos-glass-strong sm:max-w-[400px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-base">
            <span className="text-2xl">{fileIcon(entry)}</span>
            <span className="truncate">Thông tin — {entry.name}</span>
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-2 text-[13px]">
          <Row k="Đường dẫn" v={entry.path} mono />
          <Row k="Loại" v={entry.isDir ? 'Thư mục' : (fs?.isDir === false ? node?.mime || entry.mime || 'Tệp' : entry.mime || 'Tệp')} />
          {!entry.isDir && <Row k="Dung lượng" v={formatBytes(fs?.size ?? entry.size)} />}
          <Row k="Phiên bản tải lên" v={`v${node?.version ?? 1}`} />
          <Row k="Yêu thích" v={node?.favorite ? 'Có' : 'Không'} />
          {tags.length > 0 && <Row k="Tags" v={tags.join(', ')} />}
          <Row k="Tạo" v={fs?.birthtime ? fmtDateTime(fs.birthtime) : node ? fmtDateTime(node.createdAt) : '—'} />
          <Row k="Sửa đổi" v={fs?.mtime ? fmtDateTime(fs.mtime) : node ? fmtDateTime(node.updatedAt) : '—'} />
          <Row k="Xem gần nhất" v={node?.viewedAt ? fmtDateTime(node.viewedAt) : 'chưa từng mở'} />
        </div>
      </DialogContent>
    </Dialog>
  )
}

function Row({ k, v, mono }: { k: string; v: string; mono?: boolean }) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-border/60 pb-1.5 last:border-0">
      <span className="shrink-0 text-muted-foreground">{k}</span>
      <span className={`min-w-0 break-all text-right ${mono ? 'font-mono text-[11.5px]' : ''}`}>{v}</span>
    </div>
  )
}
