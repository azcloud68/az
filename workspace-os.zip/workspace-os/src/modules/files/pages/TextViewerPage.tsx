'use client'

/**
 * MODULE: Files → TextViewerPage — trình xem/sửa tệp văn bản trong cửa sổ riêng.
 * Mở từ Desktop (double-click .txt/.md/…) hoặc Files ("Mở cửa sổ riêng").
 * Route: 'viewer:<encodedPath>' — mỗi tệp 1 cửa sổ (key v:<path>).
 * Ảnh: hiển thị preview + zoom; PDF: nhúng inline; text: xem + sửa + lưu (op write).
 */
import { useCallback, useEffect, useMemo, useState } from 'react'
import { useRoute } from '@/core/client/route-context'
import { api, formatBytes, timeAgo } from '@/core/client/api'
import { startFileDownload } from '@/core/client/downloads'
import { bus } from '@/core/client/event-bus'
import { useWindows } from '@/core/client/window-store'
import { setDynamicTitle } from '@/components/wos/app-registry'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import {
  Download, Eye, FileText, Loader2, Pencil, RotateCcw, Save, ExternalLink, ZoomIn, ZoomOut,
} from 'lucide-react'
import ReactMarkdown from 'react-markdown'

interface FileData {
  path: string
  name: string
  content: string
  size: number
  mtime: string
  mime: string
}

const TEXT_EXTS = ['txt', 'md', 'markdown', 'json', 'csv', 'xml', 'yml', 'yaml', 'log', 'sh', 'js', 'ts', 'css', 'html', 'ini', 'conf', 'env']
const IMAGE_EXTS = ['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'bmp', 'avif']

function extOf(name: string): string {
  return name.split('.').pop()?.toLowerCase() || ''
}

export default function TextViewerPage() {
  const { route, navigate } = useRoute()
  const { toast } = useToast()
  const closeWindow = useWindows((s) => s.closeWindow)

  // route = 'viewer:<encodedPath>'
  const encoded = route.startsWith('viewer:') ? route.slice('viewer:'.length) : ''
  let path = ''
  try {
    path = decodeURIComponent(encoded)
  } catch {
    path = encoded
  }
  // key cửa sổ 'v:<encodedPath>' — dùng để đặt title động
  const winKey = useMemo(() => `v:${encoded}`, [encoded])

  const [data, setData] = useState<FileData | null>(null)
  const [error, setError] = useState('')
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState('')
  const [dirty, setDirty] = useState(false)
  const [saving, setSaving] = useState(false)
  const [zoom, setZoom] = useState(1)

  const ext = extOf(path)
  const isText = TEXT_EXTS.includes(ext)
  const isImage = IMAGE_EXTS.includes(ext)
  const isMd = ext === 'md' || ext === 'markdown'
  const inlineUrl = path ? `/api/modules/files/download?path=${encodeURIComponent(path)}&inline=1` : ''

  const load = useCallback(async () => {
    setError('')
    setData(null)
    if (!path) {
      setError('Không có tệp để mở')
      return
    }
    if (isText) {
      try {
        const d = await api<FileData>(`/api/modules/files/read?path=${encodeURIComponent(path)}`)
        setData(d)
        setDraft(d.content)
        setDirty(false)
        setDynamicTitle(winKey, d.name)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Không đọc được tệp')
      }
    } else {
      // ảnh/pdf/binary — chỉ cần metadata tồn tại qua preview
      try {
        await api(`/api/modules/files/preview?path=${encodeURIComponent(path)}`)
        setData({ path, name: path.split('/').pop() || path, content: '', size: 0, mtime: '', mime: '' })
        setDynamicTitle(winKey, path.split('/').pop() || path)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Không mở được tệp')
      }
    }
    void api('/api/modules/files/view', { method: 'POST', body: { path } }).catch(() => {})
  }, [path, isText, winKey])

  useEffect(() => {
    load()
    return bus.onAny((ev) => {
      if (ev.module === 'files') load()
    })
  }, [load])

  async function save() {
    if (!data || saving) return
    setSaving(true)
    try {
      await api('/api/modules/files/write', { method: 'POST', body: { path: data.path, content: draft } })
      setDirty(false)
      await load()
      toast({ title: 'Đã lưu', description: data.name })
      bus.emit('file.updated', 'files', { name: data.name })
    } catch (err) {
      toast({ title: 'Lỗi lưu tệp', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  // ===== Ảnh =====
  if (isImage) {
    return (
      <div className="flex h-full min-h-0 flex-1 flex-col">
        <div className="flex flex-wrap items-center gap-2 border-b px-3 py-2">
          <FileText className="h-4 w-4 text-muted-foreground" />
          <p className="min-w-0 flex-1 truncate text-sm font-semibold">{path.split('/').pop()}</p>
          <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setZoom((z) => Math.max(0.25, z - 0.25))} aria-label="Thu nhỏ"><ZoomOut className="h-4 w-4" /></Button>
          <Badge variant="secondary" className="tabular-nums">{Math.round(zoom * 100)}%</Badge>
          <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setZoom((z) => Math.min(4, z + 0.25))} aria-label="Phóng to"><ZoomIn className="h-4 w-4" /></Button>
          <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setZoom(1)} aria-label="Về 100%"><RotateCcw className="h-4 w-4" /></Button>
          <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => window.open(inlineUrl)} aria-label="Mở tab mới"><ExternalLink className="h-4 w-4" /></Button>
        </div>
        <div className="wos-scroll flex flex-1 items-center justify-center overflow-auto bg-neutral-100 p-4 dark:bg-black/40">
          { }
          <img
            src={inlineUrl}
            alt={path.split('/').pop() || 'Tệp ảnh'}
            className="max-h-full max-w-full object-contain shadow-lg transition-transform"
            style={{ transform: `scale(${zoom})` }}
          />
        </div>
      </div>
    )
  }

  // ===== PDF =====
  if (ext === 'pdf') {
    return (
      <div className="flex h-full min-h-0 flex-1 flex-col">
        <div className="flex items-center gap-2 border-b px-3 py-2">
          <FileText className="h-4 w-4 text-muted-foreground" />
          <p className="min-w-0 flex-1 truncate text-sm font-semibold">{path.split('/').pop()}</p>
          <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => window.open(inlineUrl)} aria-label="Mở tab mới"><ExternalLink className="h-4 w-4" /></Button>
        </div>
        <object data={inlineUrl} type="application/pdf" className="h-full min-h-0 flex-1" aria-label="Xem PDF">
          <div className="flex h-full items-center justify-center gap-3 p-6 text-muted-foreground">
            <p className="text-sm">Trình duyệt không nhúng được PDF.</p>
            <Button size="sm" onClick={() => startFileDownload(path)}><Download className="mr-1.5 h-4 w-4" /> Tải xuống</Button>
          </div>
        </object>
      </div>
    )
  }

  // ===== Text =====
  if (error) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center gap-3 py-16 text-muted-foreground">
        <FileText className="h-10 w-10 opacity-30" />
        <p className="text-sm">{error}</p>
        <Button size="sm" variant="outline" onClick={() => navigate('files')}>Mở trong Files</Button>
      </div>
    )
  }
  if (!data) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    )
  }

  return (
    <div className="flex h-full min-h-0 flex-1 flex-col">
      {/* Thanh công cụ */}
      <div className="flex flex-wrap items-center gap-2 border-b px-3 py-2">
        <FileText className="h-4 w-4 shrink-0 text-muted-foreground" />
        <p className="min-w-0 flex-1 truncate text-sm font-semibold">{data.name}</p>
        <Badge variant="secondary" className="shrink-0">{formatBytes(data.size)}</Badge>
        {data.mtime ? <span className="hidden shrink-0 text-[11px] text-muted-foreground sm:inline">Sửa {timeAgo(data.mtime)}</span> : null}
        <div className="flex items-center gap-1">
          {isMd && !editing ? (
            <Button variant="outline" size="sm" className="h-8 gap-1.5" onClick={() => setEditing(true)}>
              <Pencil className="h-3.5 w-3.5" /> Sửa
            </Button>
          ) : isMd && editing ? (
            <>
              <Button variant="ghost" size="sm" className="h-8 gap-1.5" onClick={() => { setEditing(false); setDraft(data.content); setDirty(false) }}>
                <Eye className="h-3.5 w-3.5" /> Xem
              </Button>
              <Button size="sm" className="h-8 gap-1.5" disabled={!dirty || saving} onClick={save}>
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-3.5 w-3.5" />} Lưu
              </Button>
            </>
          ) : (
            <>
              {editing ? (
                <>
                  <Button variant="ghost" size="sm" className="h-8 gap-1.5" onClick={() => { setEditing(false); setDraft(data.content); setDirty(false) }}>
                    <Eye className="h-3.5 w-3.5" /> Xem
                  </Button>
                  <Button size="sm" className="h-8 gap-1.5" disabled={!dirty || saving} onClick={save}>
                    {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-3.5 w-3.5" />} Lưu
                  </Button>
                </>
              ) : (
                <Button variant="outline" size="sm" className="h-8 gap-1.5" onClick={() => setEditing(true)}>
                  <Pencil className="h-3.5 w-3.5" /> Sửa
                </Button>
              )}
            </>
          )}
          <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => startFileDownload(path)} aria-label="Tải xuống (có tiến trình)"><Download className="h-4 w-4" /></Button>
        </div>
      </div>

      {/* Nội dung — fill toàn khung cửa sổ (flex-1 + min-h-0) */}
      {editing ? (
        <textarea
          value={draft}
          onChange={(e) => { setDraft(e.target.value); setDirty(true) }}
          onKeyDown={(e) => {
            if ((e.ctrlKey || e.metaKey) && e.key === 's') {
              e.preventDefault()
              void save()
            }
          }}
          spellCheck={false}
          className="wos-scroll h-full min-h-0 flex-1 w-full resize-none bg-transparent p-4 font-mono text-[13.5px] leading-relaxed outline-none"
          aria-label="Nội dung tệp"
        />
      ) : isMd ? (
        <div className="wos-scroll wos-md min-h-0 flex-1 overflow-y-auto p-5">
          <ReactMarkdown>{data.content || '*Tệp trống*'}</ReactMarkdown>
        </div>
      ) : (
        <pre className="wos-scroll m-0 min-h-0 flex-1 overflow-auto rounded-lg bg-muted/40 p-4 font-mono text-[13px] leading-relaxed whitespace-pre-wrap break-words">
          {data.content || '(Tệp trống)'}
        </pre>
      )}

      {/* Thanh trạng thái */}
      <div className="flex items-center gap-3 border-t px-3 py-1.5 text-[11px] text-muted-foreground">
        <span className="truncate">{data.path}</span>
        <span className="ml-auto shrink-0 tabular-nums">
          {editing ? `${draft.length} ký tự${dirty ? ' • chưa lưu' : ''}` : `${data.content.split('\n').length} dòng`}
        </span>
      </div>
    </div>
  )
}
