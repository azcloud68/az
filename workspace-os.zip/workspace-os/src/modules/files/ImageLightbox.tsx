'use client'

/**
 * ImageLightbox — xem ảnh toàn màn hình kiểu macOS Quick Look:
 * zoom (nút / cuộn), xoay, kéo di chuyển, ← → chuyển ảnh, Esc đóng.
 */
import { useEffect, useRef, useState } from 'react'
import { formatBytes } from '@/core/client/api'
import { X, ZoomIn, ZoomOut, RotateCw, ChevronLeft, ChevronRight } from 'lucide-react'

interface Entry {
  name: string
  path: string
  isDir: boolean
  size: number
}

export function ImageLightbox({
  images,
  index,
  onClose,
  onIndex,
}: {
  images: Entry[]
  index: number
  onClose: () => void
  onIndex: (i: number) => void
}) {
  const [zoom, setZoom] = useState(1)
  const [rot, setRot] = useState(0)
  const [pan, setPan] = useState({ x: 0, y: 0 })
  const dragRef = useRef<{ sx: number; sy: number; x: number; y: number } | null>(null)
  const entry = images[index]

  useEffect(() => {
    setZoom(1)
    setRot(0)
    setPan({ x: 0, y: 0 })
  }, [index])

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
      if (e.key === 'ArrowRight' && index < images.length - 1) onIndex(index + 1)
      if (e.key === 'ArrowLeft' && index > 0) onIndex(index - 1)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [index, images.length, onClose, onIndex])

  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      const d = dragRef.current
      if (!d) return
      setPan({ x: d.x + (e.clientX - d.sx), y: d.y + (e.clientY - d.sy) })
    }
    const onUp = () => (dragRef.current = null)
    window.addEventListener('pointermove', onMove)
    window.addEventListener('pointerup', onUp)
    return () => {
      window.removeEventListener('pointermove', onMove)
      window.removeEventListener('pointerup', onUp)
    }
  }, [])

  if (!entry) return null
  const src = `/api/modules/files/download?path=${encodeURIComponent(entry.path)}&inline=1`

  return (
    <div className="wos-lightbox" role="dialog" aria-label={`Xem ảnh ${entry.name}`}>
      <img
        src={src}
        alt={entry.name}
        draggable={false}
        style={{ transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom}) rotate(${rot}deg)` }}
        onPointerDown={(e) => (dragRef.current = { sx: e.clientX, sy: e.clientY, x: pan.x, y: pan.y })}
        onWheel={(e) => setZoom((z) => Math.max(0.2, Math.min(8, z - e.deltaY * 0.002)))}
      />

      {/* Thanh công cụ */}
      <div className="wos-glass-strong absolute bottom-6 left-1/2 flex -translate-x-1/2 items-center gap-1 rounded-2xl px-2 py-1.5">
        <LbBtn label="Thu nhỏ" onClick={() => setZoom((z) => Math.max(0.2, z / 1.3))}><ZoomOut className="h-4 w-4" /></LbBtn>
        <span className="w-11 text-center text-[11px] font-medium tabular-nums text-foreground/80">{Math.round(zoom * 100)}%</span>
        <LbBtn label="Phóng to" onClick={() => setZoom((z) => Math.min(8, z * 1.3))}><ZoomIn className="h-4 w-4" /></LbBtn>
        <LbBtn label="Xoay" onClick={() => setRot((r) => (r + 90) % 360)}><RotateCw className="h-4 w-4" /></LbBtn>
        <span className="mx-1 h-5 w-px bg-foreground/15" />
        <LbBtn label="Ảnh trước" disabled={index === 0} onClick={() => onIndex(index - 1)}><ChevronLeft className="h-4 w-4" /></LbBtn>
        <span className="text-[11px] font-medium tabular-nums text-foreground/80">{index + 1}/{images.length}</span>
        <LbBtn label="Ảnh sau" disabled={index === images.length - 1} onClick={() => onIndex(index + 1)}><ChevronRight className="h-4 w-4" /></LbBtn>
      </div>

      {/* Tên + kích thước */}
      <p className="absolute left-1/2 top-5 max-w-[70vw] -translate-x-1/2 truncate rounded-full bg-black/40 px-4 py-1.5 text-[12.5px] font-medium text-white">
        {entry.name} · {formatBytes(entry.size)}
      </p>

      <button
        onClick={onClose}
        className="absolute right-4 top-4 flex h-10 w-10 items-center justify-center rounded-full bg-white/15 text-white transition hover:bg-white/30"
        aria-label="Đóng"
      >
        <X className="h-5 w-5" />
      </button>
    </div>
  )
}

function LbBtn({ children, onClick, disabled, label }: { children: React.ReactNode; onClick: () => void; disabled?: boolean; label: string }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      title={label}
      aria-label={label}
      className="flex h-8 w-8 items-center justify-center rounded-xl text-foreground/85 transition hover:bg-black/10 disabled:opacity-30 dark:hover:bg-white/15"
    >
      {children}
    </button>
  )
}
