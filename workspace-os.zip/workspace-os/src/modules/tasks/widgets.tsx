'use client'

import { useEffect, useState, useCallback } from 'react'
import { useWos } from '@/core/client/wos-store'
import { api, fmtDate } from '@/core/client/api'
import { bus } from '@/core/client/event-bus'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import { CheckSquare, Flag, Loader2 } from 'lucide-react'
import { toast } from 'sonner'

interface TaskRow {
  id: string
  title: string
  status: string
  priority: string
  dueAt: string | null
}

const PRIORITY_COLOR: Record<string, string> = {
  low: 'bg-slate-400',
  medium: 'bg-amber-500',
  high: 'bg-orange-500',
  urgent: 'bg-rose-500',
}

/** Widget: Công việc hôm nay */
export function TasksTodayWidget() {
  const { navigate, emit } = useWos()
  const [tasks, setTasks] = useState<TaskRow[] | null>(null)

  const load = useCallback(async () => {
    try {
      const data = await api<{ tasks: (TaskRow & { subtasks: { done: boolean }[] })[] }>('/api/modules/tasks?status=all')
      const today = new Date().toISOString().slice(0, 10)
      setTasks(
        data.tasks.filter(
          (t) => t.status !== 'archived' && t.status !== 'done' && (t.dueAt?.slice(0, 10) || '9999') <= today
        )
      )
    } catch {
      setTasks([])
    }
  }, [])

  useEffect(() => {
    load()
    return bus.onAny((ev) => {
      if (ev.module === 'tasks') load()
    })
  }, [load])

  async function complete(id: string, title: string) {
    await api(`/api/modules/tasks/${id}`, { method: 'PATCH', body: { status: 'done' } })
    toast.success('Hoàn thành!', { description: title })
    emit('task.completed', 'tasks', { title })
    load()
  }

  return (
    <Card className="wos-glass border-0">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="flex items-center gap-2 text-sm font-semibold">
          <CheckSquare className="h-4 w-4 text-amber-500" /> Công việc hôm nay
        </CardTitle>
        <button onClick={() => navigate('tasks')} className="text-xs text-primary hover:underline">
          Xem tất cả
        </button>
      </CardHeader>
      <CardContent>
        {tasks === null ? (
          <div className="flex h-24 items-center justify-center">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        ) : tasks.length === 0 ? (
          <p className="py-6 text-center text-sm text-muted-foreground">🎉 Không có việc đến hạn — tận hưởng ngày nào!</p>
        ) : (
          <div className="space-y-1.5">
            {tasks.slice(0, 5).map((t) => (
              <div key={t.id} className="flex items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-muted">
                <Checkbox onCheckedChange={() => complete(t.id, t.title)} aria-label={`Hoàn thành ${t.title}`} />
                <span className="min-w-0 flex-1 truncate text-sm">{t.title}</span>
                <span className={`h-2 w-2 shrink-0 rounded-full ${PRIORITY_COLOR[t.priority] || 'bg-slate-400'}`} title={t.priority} />
                {t.dueAt && <span className="shrink-0 text-[11px] text-muted-foreground">{fmtDate(t.dueAt)}</span>}
              </div>
            ))}
            {tasks.length > 5 && (
              <button onClick={() => navigate('tasks')} className="w-full pt-1 text-center text-xs text-muted-foreground hover:text-primary">
                +{tasks.length - 5} việc khác…
              </button>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

/** Widget: Thống kê công việc (BOTTOM) */
export function TasksStatsWidget() {
  const [stats, setStats] = useState<{ done: number; doing: number; todo: number } | null>(null)

  const load = useCallback(async () => {
    try {
      const data = await api<{ tasks: { status: string }[] }>('/api/modules/tasks?status=all')
      const stats = { done: 0, doing: 0, todo: 0 }
      for (const t of data.tasks) {
        if (t.status in stats) stats[t.status as keyof typeof stats]++
      }
      setStats(stats)
    } catch {
      setStats({ done: 0, doing: 0, todo: 0 })
    }
  }, [])

  useEffect(() => {
    load()
    return bus.onAny((ev) => {
      if (ev.module === 'tasks') load()
    })
  }, [load])

  const total = stats ? stats.done + stats.doing + stats.todo : 0
  const bars = [
    { key: 'done', label: 'Hoàn thành', value: stats?.done || 0, color: '#10b981' },
    { key: 'doing', label: 'Đang làm', value: stats?.doing || 0, color: '#f59e0b' },
    { key: 'todo', label: 'Cần làm', value: stats?.todo || 0, color: '#94a3b8' },
  ]

  return (
    <Card className="wos-glass border-0">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-sm font-semibold">
          <Flag className="h-4 w-4 text-amber-500" /> Thống kê công việc
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="mb-3 flex h-2.5 overflow-hidden rounded-full bg-muted">
          {bars.map((b) => (
            <div key={b.key} style={{ width: total ? `${(b.value / total) * 100}%` : 0, background: b.color }} />
          ))}
        </div>
        <div className="grid grid-cols-3 gap-2 text-center">
          {bars.map((b) => (
            <div key={b.key} className="rounded-xl bg-muted/60 py-2">
              <p className="text-xl font-bold tabular-nums" style={{ color: b.color }}>
                {b.value}
              </p>
              <p className="text-[11px] text-muted-foreground">{b.label}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

