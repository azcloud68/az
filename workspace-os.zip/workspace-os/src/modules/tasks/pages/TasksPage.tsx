'use client'

import { useEffect, useState, useCallback, useMemo } from 'react'
import { useWos } from '@/core/client/wos-store'
import { api, fmtDate, timeAgo } from '@/core/client/api'
import { bus } from '@/core/client/event-bus'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Checkbox } from '@/components/ui/checkbox'
import { Card, CardContent } from '@/components/ui/card'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { useToast } from '@/hooks/use-toast'
import {
  CheckSquare, Plus, Trash2, MessageSquare, History, Flag, Calendar as CalIcon,
  Repeat, Loader2, LayoutList, Columns3, Clock, Archive, X, Search,
} from 'lucide-react'

interface Subtask { id: string; title: string; done: boolean }
interface Comment { id: string; authorName: string; content: string; createdAt: string }
interface HistoryRow { id: string; userName: string; action: string; detail: string; createdAt: string }
interface Task {
  id: string
  title: string
  description: string
  status: string
  priority: string
  labels: string
  dueAt: string | null
  reminderAt: string | null
  repeat: string
  projectId: string | null
  createdAt: string
  completedAt: string | null
  subtasks: Subtask[]
  comments: Comment[]
  histories: HistoryRow[]
}

interface ProjectOpt { id: string; name: string }

const PRIORITIES = [
  { v: 'low', label: 'Thấp', color: 'bg-slate-400' },
  { v: 'medium', label: 'Vừa', color: 'bg-amber-500' },
  { v: 'high', label: 'Cao', color: 'bg-orange-500' },
  { v: 'urgent', label: 'Khẩn', color: 'bg-rose-500' },
]
const STATUS_LABEL: Record<string, string> = { todo: 'Cần làm', doing: 'Đang làm', done: 'Hoàn thành', archived: 'Lưu trữ' }
const REPEAT_LABEL: Record<string, string> = { none: 'Không lặp', daily: 'Hàng ngày', weekly: 'Hàng tuần', monthly: 'Hàng tháng' }
const COLUMNS = ['todo', 'doing', 'done']

export default function TasksPage() {
  const { emit, navigate, loadSettings } = useWos()
  const { toast } = useToast()
  const [tasks, setTasks] = useState<Task[] | null>(null)
  const [projects, setProjects] = useState<ProjectOpt[]>([])
  const [view, setView] = useState<'list' | 'kanban' | 'timeline' | 'archive'>('list')
  const [query, setQuery] = useState('')
  const [quickTitle, setQuickTitle] = useState('')
  const [quickPriority, setQuickPriority] = useState('medium')
  const [detail, setDetail] = useState<Task | null>(null)
  const [saving, setSaving] = useState(false)
  /** Cấu hình Timeline từ Settings module Tasks (hiện việc đã xong / không có hạn / gộp nhóm) */
  const [tlSettings, setTlSettings] = useState<Record<string, string>>({})
  const [tlFilter, setTlFilter] = useState<'all' | 'active' | 'doing' | 'done'>('all')

  useEffect(() => {
    loadSettings('tasks')
      .then((s) => {
        setTlSettings(s)
        // filter mặc định theo cấu hình: ẩn việc đã xong → 'active'
        setTlFilter(s.timeline_show_done === 'off' ? 'active' : 'all')
      })
      .catch(() => {})
  }, [loadSettings])

  const load = useCallback(async () => {
    try {
      const data = await api<{ tasks: Task[] }>('/api/modules/tasks?status=all')
      setTasks(data.tasks)
      const p = await api<{ projects: ProjectOpt[] }>('/api/modules/projects').catch(() => ({ projects: [] }))
      setProjects(p.projects.map((x) => ({ id: x.id, name: x.name })))
    } catch {
      setTasks([])
    }
  }, [])

  useEffect(() => {
    load()
    return bus.onAny((ev) => {
      if (ev.module === 'tasks' && ev.type !== 'task.updated') load()
    })
  }, [load])

  async function quickAdd() {
    const title = quickTitle.trim()
    if (!title) return
    setSaving(true)
    try {
      const data = await api<{ task: { id: string } }>('/api/modules/tasks', {
        method: 'POST',
        body: { title, priority: quickPriority },
      })
      emit('task.created', 'tasks', { title })
      setQuickTitle('')
      await load()
      // Mở chi tiết bằng bản đầy đủ (có subtasks/comments/history)
      const fresh = await api<{ task: Task }>(`/api/modules/tasks/${data.task.id}`)
      setDetail(fresh.task)
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : 'Không tạo được', variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  async function patch(id: string, body: Record<string, unknown>, event = 'task.updated') {
    try {
      await api(`/api/modules/tasks/${id}`, { method: 'PATCH', body })
      if (event === 'task.completed') emit('task.completed', 'tasks', { title: body.title })
      load()
      if (detail?.id === id) {
        const fresh = await api<{ task: Task }>(`/api/modules/tasks/${id}`)
        setDetail(fresh.task)
      }
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : 'Cập nhật thất bại', variant: 'destructive' })
    }
  }

  async function remove(id: string) {
    if (!confirm('Xoá công việc này? Hành động không thể hoàn tác.')) return
    await api(`/api/modules/tasks/${id}`, { method: 'DELETE' })
    emit('task.deleted', 'tasks', {})
    setDetail(null)
    load()
  }

  const filtered = useMemo(() => {
    if (!tasks) return null
    const q = query.trim().toLowerCase()
    return tasks.filter((t) => {
      if (view === 'archive') return t.status === 'archived'
      if (t.status === 'archived') return false
      if (!q) return true
      return t.title.toLowerCase().includes(q) || t.description.toLowerCase().includes(q)
    })
  }, [tasks, view, query])

  /** Timeline: lọc theo cấu hình Settings (hiện đã xong / không hạn) + chip lọc nhanh */
  function tlTasksFilter(t: Task): boolean {
    // cấu hình mặc định từ Settings → Tasks
    if (tlSettings.timeline_show_done === 'off' && t.status === 'done') return false
    if (tlSettings.timeline_show_no_due !== 'on' && !t.dueAt) return false
    // chip lọc nhanh đè lên
    if (tlFilter === 'active' && (t.status === 'done' || t.status === 'archived')) return false
    if (tlFilter === 'doing' && t.status !== 'doing') return false
    if (tlFilter === 'done' && t.status !== 'done') return false
    return true
  }

  const tlTimelineTasks = () =>
    (filtered || [])
      .filter(tlTasksFilter)
      .sort((a, b) => (a.dueAt || '9999').localeCompare(b.dueAt || '9999'))

  const projectName = (id: string | null) => (id ? projects.find((p) => p.id === id)?.name ?? null : null)

  if (tasks === null) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-wrap items-center gap-3">
        <h1 className="flex items-center gap-2.5 text-xl font-bold">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-500 text-white">
            <CheckSquare className="h-5 w-5" />
          </span>
          Tasks
          <Badge variant="secondary" className="font-normal">{tasks.filter((t) => t.status !== 'archived').length} việc</Badge>
        </h1>
        <div className="ml-auto flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Tìm công việc…" className="h-9 w-48 pl-8" />
          </div>
          <Tabs value={view} onValueChange={(v) => setView(v as typeof view)}>
            <TabsList className="h-9">
              <TabsTrigger value="list" className="gap-1.5 px-3"><LayoutList className="h-4 w-4" />List</TabsTrigger>
              <TabsTrigger value="kanban" className="gap-1.5 px-3"><Columns3 className="h-4 w-4" />Kanban</TabsTrigger>
              <TabsTrigger value="timeline" className="gap-1.5 px-3"><Clock className="h-4 w-4" />Timeline</TabsTrigger>
              <TabsTrigger value="archive" className="gap-1.5 px-3"><Archive className="h-4 w-4" />Archive</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>

      {/* Quick add */}
      {view !== 'archive' && (
        <Card className="wos-glass border-0">
          <CardContent className="flex flex-wrap items-center gap-2 py-3">
            <Plus className="h-4 w-4 text-muted-foreground" />
            <Input
              value={quickTitle}
              onChange={(e) => setQuickTitle(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && quickAdd()}
              placeholder="Thêm công việc nhanh… (Enter)"
              className="h-9 min-w-[220px] flex-1"
            />
            <Select value={quickPriority} onValueChange={setQuickPriority}>
              <SelectTrigger className="h-9 w-28"><Flag className="mr-1 h-3.5 w-3.5" /><SelectValue /></SelectTrigger>
              <SelectContent>
                {PRIORITIES.map((p) => (
                  <SelectItem key={p.v} value={p.v}>{p.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button size="sm" className="h-9" onClick={quickAdd} disabled={saving || !quickTitle.trim()}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Thêm'}
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Views */}
      {view === 'list' && filtered && (
        <div className="space-y-1.5">
          {filtered.length === 0 && <EmptyHint text="Không có công việc nào" />}
          {filtered.map((t) => (
            <TaskRowView key={t.id} task={t} projectName={projectName(t.projectId)} onOpen={() => setDetail(t)} onToggle={() => patch(t.id, { status: t.status === 'done' ? 'todo' : 'done', title: t.title }, t.status === 'done' ? 'task.updated' : 'task.completed')} />
          ))}
        </div>
      )}

      {view === 'kanban' && filtered && (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
          {COLUMNS.map((col) => {
            const items = filtered.filter((t) => t.status === col)
            return (
              <div key={col} className="wos-glass flex min-h-[300px] flex-col rounded-2xl p-3">
                <div className="mb-2 flex items-center justify-between px-1">
                  <p className="text-sm font-semibold">{STATUS_LABEL[col]}</p>
                  <Badge variant="secondary" className="font-normal">{items.length}</Badge>
                </div>
                <div className="wos-scroll flex-1 space-y-2 overflow-y-auto">
                  {items.map((t) => (
                    <button
                      key={t.id}
                      onClick={() => setDetail(t)}
                      draggable
                      onDragStart={(e) => e.dataTransfer.setData('task', t.id)}
                      onDragOver={(e) => e.preventDefault()}
                      onDrop={(e) => {
                        const id = e.dataTransfer.getData('task')
                        if (id && id !== t.id) patch(id, { status: col, title: undefined })
                      }}
                      className="w-full rounded-xl bg-card p-3 text-left shadow-sm transition-shadow hover:shadow-md"
                    >
                      <div className="flex items-start gap-2">
                        <span className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${PRIORITIES.find((p) => p.v === t.priority)?.color}`} />
                        <div className="min-w-0 flex-1">
                          <p className={`text-sm font-medium leading-snug ${t.status === 'done' ? 'line-through opacity-60' : ''}`}>{t.title}</p>
                          <div className="mt-1.5 flex flex-wrap items-center gap-2 text-[11px] text-muted-foreground">
                            {t.dueAt && <span className="flex items-center gap-1"><CalIcon className="h-3 w-3" />{fmtDate(t.dueAt)}</span>}
                            {t.subtasks.length > 0 && <span>{t.subtasks.filter((s) => s.done).length}/{t.subtasks.length} sub</span>}
                            {t.comments.length > 0 && <span className="flex items-center gap-0.5"><MessageSquare className="h-3 w-3" />{t.comments.length}</span>}
                            {projectName(t.projectId) && <span className="rounded bg-muted px-1.5 py-0.5">{projectName(t.projectId)}</span>}
                          </div>
                        </div>
                      </div>
                    </button>
                  ))}
                  <div
                    className="rounded-xl border-2 border-dashed p-3 text-center text-xs text-muted-foreground"
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={(e) => {
                      const id = e.dataTransfer.getData('task')
                      if (id) patch(id, { status: col })
                    }}
                  >
                    Kéo thả vào cột {STATUS_LABEL[col]}
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      )}

      {view === 'timeline' && filtered && (
        <div className="space-y-3">
          {/* Bộ lọc nhanh Timeline — cấu hình mặc định lấy từ Settings module Tasks */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1 rounded-lg bg-muted p-0.5">
              {([
                { id: 'all', label: 'Tất cả' },
                { id: 'active', label: 'Chưa xong' },
                { id: 'doing', label: 'Đang làm' },
                { id: 'done', label: 'Đã hoàn thành' },
              ] as const).map((f) => (
                <button
                  key={f.id}
                  onClick={() => setTlFilter(f.id)}
                  className={`h-7 rounded-md px-2.5 text-xs font-medium transition-colors ${
                    tlFilter === f.id ? 'bg-background shadow-sm' : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
            <span className="text-xs text-muted-foreground">
              {filtered.filter((t) => tlTasksFilter(t)).length} việc · cấu hình mặc định trong Settings → Tasks
            </span>
          </div>

          <div className="space-y-1">
            {tlTimelineTasks()
              .map((t, i, arr) => {
                const prev = i > 0 ? arr[i - 1] : null
                const showDateHead = tlSettings.timeline_group !== 'off' && t.dueAt && (!prev || !prev.dueAt || fmtDate(prev.dueAt) !== fmtDate(t.dueAt))
                return (
                  <div key={t.id}>
                    {showDateHead && (
                      <p className="mt-2 px-3 pb-1 pt-1 text-[10.5px] font-semibold uppercase tracking-wide text-muted-foreground">
                        {fmtDate(t.dueAt)}
                      </p>
                    )}
                    <button onClick={() => setDetail(t)} className="flex w-full items-center gap-4 rounded-xl px-3 py-2 text-left hover:bg-muted">
                      <span className={`w-24 shrink-0 text-xs tabular-nums text-muted-foreground ${!t.dueAt ? 'italic' : ''}`}>{t.dueAt ? fmtDate(t.dueAt) : '— không hạn —'}</span>
                      <span className={`h-1.5 w-1.5 shrink-0 rounded-full ${PRIORITIES.find((p) => p.v === t.priority)?.color}`} />
                      <span className={`min-w-0 flex-1 truncate text-sm ${t.status === 'done' ? 'line-through opacity-60' : ''}`}>{t.title}</span>
                      <Badge variant="outline" className="shrink-0 text-[10px]">{STATUS_LABEL[t.status]}</Badge>
                    </button>
                  </div>
                )
              })}
            {tlTimelineTasks().length === 0 && (
              <EmptyHint
                text={
                  tlFilter === 'done'
                    ? 'Chưa có việc nào đã hoàn thành'
                    : tlSettings.timeline_show_no_due !== 'on'
                      ? 'Không có việc nào có ngày đến hạn — bật "hiện việc không có hạn" trong Settings → Tasks'
                      : 'Không có công việc phù hợp bộ lọc'
                }
              />
            )}
          </div>
        </div>
      )}

      {view === 'archive' && filtered && (
        <div className="space-y-1.5">
          {filtered.length === 0 && <EmptyHint text="Lưu trữ trống" />}
          {filtered.map((t) => (
            <TaskRowView key={t.id} task={t} projectName={projectName(t.projectId)} onOpen={() => setDetail(t)} onToggle={() => patch(t.id, { status: 'todo', title: t.title })} />
          ))}
        </div>
      )}

      {/* Chi tiết task */}
      {detail && (
        <TaskDetailDialog
          task={detail}
          projects={projects}
          onClose={() => setDetail(null)}
          onPatch={(body, ev) => patch(detail.id, body, ev)}
          onRemove={() => remove(detail.id)}
          onRefreshDetail={async () => {
            const fresh = await api<{ task: Task }>(`/api/modules/tasks/${detail.id}`).catch(() => null)
            if (fresh) setDetail(fresh.task)
          }}
          onNavigate={(r) => navigate(r)}
        />
      )}
    </div>
  )
}

function TaskRowView({ task, projectName, onOpen, onToggle }: { task: Task; projectName: string | null; onOpen: () => void; onToggle: () => void }) {
  return (
    <div className="wos-glass flex items-center gap-3 rounded-xl px-3 py-2.5 transition-shadow hover:shadow-md">
      <Checkbox
        checked={task.status === 'done'}
        onCheckedChange={onToggle}
        aria-label={`Hoàn thành ${task.title}`}
      />
      <button onClick={onOpen} className="min-w-0 flex-1 text-left">
        <p className={`truncate text-sm font-medium ${task.status === 'done' ? 'line-through opacity-60' : ''}`}>{task.title}</p>
        <div className="mt-0.5 flex flex-wrap items-center gap-2 text-[11px] text-muted-foreground">
          <span className={`flex items-center gap-1 rounded px-1.5 py-0.5 font-medium text-white ${PRIORITIES.find((p) => p.v === task.priority)?.color}`}>
            {PRIORITIES.find((p) => p.v === task.priority)?.label}
          </span>
          {task.dueAt && <span className="flex items-center gap-1"><CalIcon className="h-3 w-3" />{fmtDate(task.dueAt)}</span>}
          {task.repeat !== 'none' && <span className="flex items-center gap-1"><Repeat className="h-3 w-3" />{REPEAT_LABEL[task.repeat]}</span>}
          {task.subtasks.length > 0 && <span>{task.subtasks.filter((s) => s.done).length}/{task.subtasks.length} subtask</span>}
          {task.comments.length > 0 && <span className="flex items-center gap-0.5"><MessageSquare className="h-3 w-3" />{task.comments.length}</span>}
          {projectName && <span className="rounded bg-muted px-1.5 py-0.5">{projectName}</span>}
        </div>
      </button>
    </div>
  )
}

function EmptyHint({ text }: { text: string }) {
  return (
    <div className="wos-glass flex flex-col items-center gap-2 rounded-2xl py-10 text-muted-foreground">
      <CheckSquare className="h-8 w-8 opacity-30" />
      <p className="text-sm">{text}</p>
    </div>
  )
}

/* ================= Chi tiết task — Priority/Label/Reminder/Repeat/Subtask/Comment/History ================= */
function TaskDetailDialog({
  task, projects, onClose, onPatch, onRemove, onRefreshDetail, onNavigate,
}: {
  task: Task
  projects: ProjectOpt[]
  onClose: () => void
  onPatch: (body: Record<string, unknown>, event?: string) => void
  onRemove: () => void
  onRefreshDetail: () => Promise<void>
  onNavigate: (route: string) => void
}) {
  const { toast } = useToast()
  const [title, setTitle] = useState(task.title)
  const [description, setDescription] = useState(task.description)
  const [labels, setLabels] = useState<string[]>(JSON.parse(task.labels || '[]'))
  const [newLabel, setNewLabel] = useState('')
  const [newSubtask, setNewSubtask] = useState('')
  const [newComment, setNewComment] = useState('')
  const [tab, setTab] = useState<'subtasks' | 'comments' | 'history'>('subtasks')
  const { emit } = useWos()

  async function addSubtask() {
    if (!newSubtask.trim()) return
    await api(`/api/modules/tasks/${task.id}/subtasks`, { method: 'POST', body: { title: newSubtask.trim() } })
    setNewSubtask('')
    onRefreshDetail()
  }

  async function toggleSubtask(st: Subtask) {
    await api(`/api/modules/tasks/${task.id}/subtasks`, { method: 'PATCH', body: { subtaskId: st.id, done: !st.done } })
    onRefreshDetail()
  }

  async function deleteSubtask(st: Subtask) {
    await api(`/api/modules/tasks/${task.id}/subtasks?subtaskId=${st.id}`, { method: 'DELETE' })
    onRefreshDetail()
  }

  async function addComment() {
    if (!newComment.trim()) return
    await api(`/api/modules/tasks/${task.id}/comments`, { method: 'POST', body: { content: newComment.trim() } })
    setNewComment('')
    onRefreshDetail()
  }

  async function saveFields() {
    await onPatch({ title, description, labels })
    toast({ title: 'Đã lưu' })
  }

  const subDone = task.subtasks.filter((s) => s.done).length

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="wos-glass-strong max-h-[85vh] overflow-y-auto p-0 sm:max-w-[720px]">
        <DialogTitle className="sr-only">Chi tiết công việc</DialogTitle>
        <DialogHeader className="border-b px-5 py-4">
          <div className="flex items-start gap-3">
            <Checkbox
              checked={task.status === 'done'}
              onCheckedChange={() => onPatch({ status: task.status === 'done' ? 'todo' : 'done', title }, task.status === 'done' ? 'task.updated' : 'task.completed')}
              className="mt-1"
              aria-label="Đánh dấu hoàn thành"
            />
            <div className="min-w-0 flex-1">
              <Input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                onBlur={saveFields}
                className="h-9 border-0 bg-transparent px-0 text-lg font-semibold focus-visible:ring-0"
              />
              <div className="mt-1 flex flex-wrap items-center gap-2 text-[11px] text-muted-foreground">
                <span>Tạo {timeAgo(task.createdAt)}</span>
                {task.completedAt && <span>· Hoàn thành {timeAgo(task.completedAt)}</span>}
                {task.projectId && (
                  <button className="rounded bg-muted px-1.5 py-0.5 hover:bg-muted/70" onClick={() => onNavigate(`projects:${task.projectId}`)}>
                    {projects.find((p) => p.id === task.projectId)?.name}
                  </button>
                )}
              </div>
            </div>
          </div>
        </DialogHeader>

        <div className="grid gap-0 md:grid-cols-[220px_1fr]">
          {/* Sidebar fields */}
          <div className="space-y-4 border-b p-4 md:border-b-0 md:border-r">
            <div>
              <p className="mb-1.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Trạng thái</p>
              <Select value={task.status} onValueChange={(v) => onPatch({ status: v, title })}>
                <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(STATUS_LABEL).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <p className="mb-1.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Ưu tiên</p>
              <Select value={task.priority} onValueChange={(v) => onPatch({ priority: v })}>
                <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PRIORITIES.map((p) => <SelectItem key={p.v} value={p.v}>{p.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <p className="mb-1.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Dự án</p>
              <Select value={task.projectId || 'none'} onValueChange={(v) => onPatch({ projectId: v === 'none' ? null : v })}>
                <SelectTrigger className="h-9"><SelectValue placeholder="Không gán" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Không gán</SelectItem>
                  {projects.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <p className="mb-1.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Đến hạn</p>
              <Input
                type="date"
                defaultValue={task.dueAt?.slice(0, 10) || ''}
                onChange={(e) => onPatch({ dueAt: e.target.value ? new Date(e.target.value).toISOString() : null })}
                className="h-9"
              />
            </div>
            <div>
              <p className="mb-1.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Nhắc việc</p>
              <Input
                type="datetime-local"
                defaultValue={task.reminderAt ? task.reminderAt.slice(0, 16) : ''}
                onChange={(e) => onPatch({ reminderAt: e.target.value ? new Date(e.target.value).toISOString() : null })}
                className="h-9"
              />
            </div>
            <div>
              <p className="mb-1.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Lặp lại</p>
              <Select value={task.repeat} onValueChange={(v) => onPatch({ repeat: v })}>
                <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(REPEAT_LABEL).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <p className="mb-1.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Nhãn</p>
              <div className="flex flex-wrap gap-1.5">
                {labels.map((l) => (
                  <Badge key={l} variant="secondary" className="gap-1 pr-1">
                    {l}
                    <button onClick={() => { const next = labels.filter((x) => x !== l); setLabels(next); onPatch({ labels: next, title }) }} aria-label={`Xoá nhãn ${l}`}>
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
              </div>
              <div className="mt-2 flex gap-1.5">
                <Input value={newLabel} onChange={(e) => setNewLabel(e.target.value)} placeholder="Nhãn mới" className="h-8 text-xs"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && newLabel.trim()) {
                      const next = [...labels, newLabel.trim()]
                      setLabels(next)
                      onPatch({ labels: next, title })
                      setNewLabel('')
                    }
                  }}
                />
              </div>
            </div>
            <Button variant="destructive" size="sm" className="w-full gap-1.5" onClick={onRemove}>
              <Trash2 className="h-4 w-4" /> Xoá công việc
            </Button>
          </div>

          {/* Main: description + tabs */}
          <div className="flex flex-col p-4">
            <p className="mb-1.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Mô tả</p>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              onBlur={saveFields}
              placeholder="Thêm mô tả chi tiết…"
              className="min-h-[100px] resize-y"
            />

            <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)} className="mt-4">
              <TabsList className="h-9 w-full justify-start">
                <TabsTrigger value="subtasks" className="gap-1.5 text-xs">
                  Subtask {task.subtasks.length > 0 && <Badge variant="secondary" className="ml-1 h-4 px-1.5 text-[10px]">{subDone}/{task.subtasks.length}</Badge>}
                </TabsTrigger>
                <TabsTrigger value="comments" className="gap-1.5 text-xs">
                  Bình luận {task.comments.length > 0 && <Badge variant="secondary" className="ml-1 h-4 px-1.5 text-[10px]">{task.comments.length}</Badge>}
                </TabsTrigger>
                <TabsTrigger value="history" className="gap-1.5 text-xs"><History className="h-3.5 w-3.5" /></TabsTrigger>
              </TabsList>

              {tab === 'subtasks' && (
                <div className="mt-3 space-y-2">
                  {task.subtasks.map((st) => (
                    <div key={st.id} className="flex items-center gap-2.5 rounded-lg bg-muted/50 px-3 py-2">
                      <Checkbox checked={st.done} onCheckedChange={() => toggleSubtask(st)} aria-label={st.title} />
                      <span className={`min-w-0 flex-1 text-sm ${st.done ? 'line-through opacity-60' : ''}`}>{st.title}</span>
                      <button onClick={() => deleteSubtask(st)} className="text-muted-foreground hover:text-rose-500" aria-label="Xoá subtask">
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  ))}
                  <div className="flex gap-2">
                    <Input
                      value={newSubtask}
                      onChange={(e) => setNewSubtask(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && addSubtask()}
                      placeholder="Thêm công việc con…"
                      className="h-9 text-sm"
                    />
                    <Button size="sm" variant="secondary" className="h-9" onClick={addSubtask}><Plus className="h-4 w-4" /></Button>
                  </div>
                </div>
              )}

              {tab === 'comments' && (
                <div className="mt-3 space-y-3">
                  <ScrollArea className="max-h-[220px] pr-3">
                    {task.comments.map((c) => (
                      <div key={c.id} className="mb-3">
                        <div className="flex items-baseline gap-2">
                          <span className="text-xs font-semibold">{c.authorName}</span>
                          <span className="text-[11px] text-muted-foreground">{timeAgo(c.createdAt)}</span>
                        </div>
                        <p className="mt-0.5 rounded-lg bg-muted/60 px-3 py-2 text-sm">{c.content}</p>
                      </div>
                    ))}
                    {task.comments.length === 0 && <p className="py-4 text-center text-sm text-muted-foreground">Chưa có bình luận</p>}
                  </ScrollArea>
                  <div className="flex gap-2">
                    <Input
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && addComment()}
                      placeholder="Bình luận…"
                      className="h-9 text-sm"
                    />
                    <Button size="sm" className="h-9" onClick={addComment}>Gửi</Button>
                  </div>
                </div>
              )}

              {tab === 'history' && (
                <div className="mt-3 space-y-2">
                  {task.histories.map((h) => (
                    <div key={h.id} className="flex items-center gap-2 text-sm">
                      <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                      <span className="font-medium">{h.userName}</span>
                      <span className="text-muted-foreground">{h.detail || h.action}</span>
                      <span className="ml-auto text-[11px] text-muted-foreground">{timeAgo(h.createdAt)}</span>
                    </div>
                  ))}
                  {task.histories.length === 0 && <p className="py-4 text-center text-sm text-muted-foreground">Chưa có lịch sử</p>}
                </div>
              )}
            </Tabs>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
