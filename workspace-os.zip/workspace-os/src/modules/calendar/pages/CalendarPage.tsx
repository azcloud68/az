'use client'

import { useEffect, useState, useCallback } from 'react'
import { useWos } from '@/core/client/wos-store'
import { api } from '@/core/client/api'
import { bus } from '@/core/client/event-bus'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useToast } from '@/hooks/use-toast'
import { Calendar, ChevronLeft, ChevronRight, Plus, Loader2, MapPin, Repeat as RepeatIcon, Trash2 } from 'lucide-react'

interface EventRow {
  id: string
  title: string
  description: string
  location: string
  category: string
  color: string
  allDay: boolean
  start: string
  end: string
  recurring: string
  reminderMinutes: number | null
  projectId: string | null
  occurrenceStart?: string
  isOccurrence?: boolean
}

const CATEGORY_COLORS: Record<string, string> = {
  general: '#f97316',
  work: '#0891b2',
  personal: '#84cc16',
  meeting: '#f43f5e',
  holiday: '#eab308',
}
const CATEGORY_LABEL: Record<string, string> = {
  general: 'Chung',
  work: 'Công việc',
  personal: 'Cá nhân',
  meeting: 'Họp',
  holiday: 'Ngày lễ',
}
const RECUR_LABEL: Record<string, string> = { none: 'Không lặp', daily: 'Hàng ngày', weekly: 'Hàng tuần', monthly: 'Hàng tháng', yearly: 'Hàng năm' }
const DOW = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN']
const vnDateKey = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`

export default function CalendarPage() {
  const { emit } = useWos()
  const { toast } = useToast()
  const [view, setView] = useState<'month' | 'week' | 'day' | 'year'>('month')
  const [cursor, setCursor] = useState(() => new Date())
  const [events, setEvents] = useState<EventRow[] | null>(null)
  const [holidays, setHolidays] = useState<{ title: string; date: string }[]>([])
  const [editing, setEditing] = useState<EventRow | null>(null)
  const [creating, setCreating] = useState<{ dateKey: string } | null>(null)

  const load = useCallback(async () => {
    const from = new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1)
    const to = new Date(cursor.getFullYear(), cursor.getMonth() + 2, 0)
    try {
      const data = await api<{ events: EventRow[]; holidays: { title: string; date: string }[] }>(
        `/api/modules/calendar?from=${from.toISOString()}&to=${to.toISOString()}`
      )
      setEvents(data.events)
      setHolidays(data.holidays)
    } catch {
      setEvents([])
    }
  }, [cursor])

  useEffect(() => {
    load()
    return bus.onAny((ev) => {
      if (ev.module === 'calendar') load()
    })
  }, [load])

  const eventsOf = useCallback((day: Date): EventRow[] => {
    if (!events) return []
    const key = vnDateKey(day)
    const withOcc = events.map((e) => ({
      ...e,
      start: e.occurrenceStart && vnDateKey(new Date(e.occurrenceStart)) === key ? e.occurrenceStart : e.start,
    }))
    // So sánh theo NGÀY LOCAL của trình duyệt (không phải UTC-date trong chuỗi ISO)
    // — sự kiện sáng sớm (00:00–06:59) hiện đúng ô ngày của nó
    return withOcc
      .filter((e) => vnDateKey(new Date(e.start)) === key)
      .sort((a, b) => a.start.localeCompare(b.start))
  }, [events])

  async function removeEvent(ev: EventRow) {
    const realId = ev.id.includes('#') ? ev.id.split('#')[0] : ev.id
    const dateKey = vnDateKey(new Date(ev.occurrenceStart || ev.start))
    if (ev.id.includes('#') || ev.isOccurrence) {
      // Sự kiện lặp — 2 bước rõ ràng: 1 lần này, rồi mới tới cả chuỗi
      if (confirm(`Xoá CHỈ lần này (${dateKey})?\nCác lần khác của chuỗi vẫn giữ nguyên.`)) {
        await api(`/api/modules/calendar/${realId}?occurrence=${dateKey}`, { method: 'DELETE' })
        emit('event.updated', 'calendar', { title: `${ev.title} (bỏ lần ${dateKey})` })
        setEditing(null)
        load()
        return
      }
      if (!confirm(`Xoá TOÀN BỘ chuỗi sự kiện "${ev.title}"?`)) return
      await api(`/api/modules/calendar/${realId}`, { method: 'DELETE' })
      emit('event.deleted', 'calendar', { title: ev.title })
      setEditing(null)
      load()
      return
    }
    if (!confirm(`Xoá sự kiện "${ev.title}"?`)) return
    await api(`/api/modules/calendar/${realId}`, { method: 'DELETE' })
    emit('event.deleted', 'calendar', { title: ev.title })
    setEditing(null)
    load()
  }

  const year = cursor.getFullYear()
  const month = cursor.getMonth()

  // ==== YEAR VIEW ====
  if (view === 'year') {
    return (
      <div className="space-y-4">
        <Header
          title={`${year}`}
          view={view}
          setView={setView}
          onPrev={() => setCursor(new Date(year - 1, 0, 1))}
          onNext={() => setCursor(new Date(year + 1, 0, 1))}
          onToday={() => setCursor(new Date())}
        />
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {Array.from({ length: 12 }, (_, m) => {
            const firstDow = (new Date(year, m, 1).getDay() + 6) % 7
            const days = new Date(year, m + 1, 0).getDate()
            const monthEvents = events?.filter((e) => {
              const d = new Date(e.start)
              return d.getFullYear() === year && d.getMonth() === m
            }) || []
            return (
              <button
                key={m}
                onClick={() => {
                  setCursor(new Date(year, m, 1))
                  setView('month')
                }}
                className="wos-glass rounded-2xl p-3 text-left transition-shadow hover:shadow-md"
              >
                <p className="mb-2 text-sm font-semibold">Tháng {m + 1}</p>
                <div className="grid grid-cols-7 gap-y-0.5 text-center text-[9px] text-muted-foreground">
                  {Array.from({ length: firstDow }, (_, i) => (
                    <span key={`e${i}`} />
                  ))}
                  {Array.from({ length: days }, (_, i) => {
                    const day = i + 1
                    const d = new Date(year, m, day)
                    const isToday = vnDateKey(d) === vnDateKey(new Date())
                    const has = eventsOf(d).length > 0
                    return (
                      <span
                        key={day}
                        className={`mx-auto flex h-4 w-4 items-center justify-center rounded-full ${
                          isToday ? 'bg-primary font-bold text-primary-foreground' : has ? 'font-semibold text-foreground' : ''
                        }`}
                      >
                        {day}
                      </span>
                    )
                  })}
                </div>
                {monthEvents.length > 0 && (
                  <p className="mt-1.5 text-[10px] text-muted-foreground">{monthEvents.length} sự kiện</p>
                )}
              </button>
            )
          })}
        </div>
      </div>
    )
  }

  // ==== DAY VIEW ====
  if (view === 'day') {
    const hours = Array.from({ length: 16 }, (_, i) => i + 7) // 7h → 22h
    return (
      <div className="space-y-4">
        <Header
          title={cursor.toLocaleDateString('vi-VN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
          view={view}
          setView={setView}
          onPrev={() => setCursor(new Date(cursor.setDate(cursor.getDate() - 1)))}
          onNext={() => setCursor(new Date(cursor.setDate(cursor.getDate() + 1)))}
          onToday={() => setCursor(new Date())}
        />
        <Card className="wos-glass border-0">
          <CardContent className="p-0">
            {hours.map((h) => {
              const slotEvents = eventsOf(cursor).filter((e) => new Date(e.start).getHours() === h)
              return (
                <div key={h} className="flex border-b last:border-0">
                  <div className="w-16 shrink-0 border-r py-2 text-center text-xs tabular-nums text-muted-foreground">
                    {String(h).padStart(2, '0')}:00
                  </div>
                  <div className="min-h-[44px] flex-1 p-1.5">
                    {slotEvents.length === 0 ? (
                      <button
                        className="h-full w-full rounded-lg text-left text-xs text-muted-foreground opacity-0 transition-opacity hover:bg-muted hover:opacity-100"
                        onClick={() => setCreating({ dateKey: `${vnDateKey(cursor)}T${String(h).padStart(2, '0')}:00` })}
                      >
                        + Thêm
                      </button>
                    ) : (
                      slotEvents.map((e) => (
                        <button
                          key={e.id}
                          onClick={() => setEditing(e)}
                          className="mb-1 flex w-full items-center gap-2 rounded-lg px-3 py-1.5 text-left text-sm font-medium text-white"
                          style={{ background: e.color || CATEGORY_COLORS[e.category] }}
                        >
                          <span className="text-xs opacity-90">
                            {new Date(e.start).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}
                          </span>
                          {e.title}
                        </button>
                      ))
                    )}
                  </div>
                </div>
              )
            })}
          </CardContent>
        </Card>
        <EventDialog
          event={editing}
          creating={creating ? { start: creating.dateKey } : null}
          onClose={() => {
            setEditing(null)
            setCreating(null)
          }}
          onSaved={() => {
            load()
            setEditing(null)
            setCreating(null)
          }}
          onRemove={removeEvent}
        />
      </div>
    )
  }

  // ==== WEEK VIEW ====
  if (view === 'week') {
    const monday = new Date(cursor)
    monday.setDate(cursor.getDate() - ((cursor.getDay() + 6) % 7))
    const days = Array.from({ length: 7 }, (_, i) => {
      const d = new Date(monday)
      d.setDate(monday.getDate() + i)
      return d
    })
    return (
      <div className="space-y-4">
        <Header
          title={`Tuần ${monday.toLocaleDateString('vi-VN')} – ${days[6].toLocaleDateString('vi-VN')}`}
          view={view}
          setView={setView}
          onPrev={() => setCursor(new Date(cursor.setDate(cursor.getDate() - 7)))}
          onNext={() => setCursor(new Date(cursor.setDate(cursor.getDate() + 7)))}
          onToday={() => setCursor(new Date())}
        />
        <div className="grid grid-cols-1 gap-2 md:grid-cols-7">
          {days.map((d) => {
            const isToday = vnDateKey(d) === vnDateKey(new Date())
            return (
              <div key={d.toISOString()} className={`wos-glass min-h-[180px] rounded-xl p-2 ${isToday ? 'ring-2 ring-primary' : ''}`}>
                <div className="mb-1.5 text-center">
                  <p className="text-[10px] uppercase text-muted-foreground">{DOW[(d.getDay() + 6) % 7]}</p>
                  <p className={`text-lg font-bold tabular-nums ${isToday ? 'text-primary' : ''}`}>{d.getDate()}</p>
                </div>
                <div className="space-y-1">
                  {eventsOf(d).slice(0, 5).map((e) => (
                    <button
                      key={e.id}
                      onClick={() => setEditing(e)}
                      className="block w-full truncate rounded-md px-2 py-1 text-left text-[11px] font-medium text-white"
                      style={{ background: e.color || CATEGORY_COLORS[e.category] }}
                    >
                      {e.allDay ? '' : `${new Date(e.start).getHours()}:00 `}
                      {e.title}
                    </button>
                  ))}
                  {eventsOf(d).length > 5 && <p className="text-center text-[10px] text-muted-foreground">+{eventsOf(d).length - 5} nữa</p>}
                  <button
                    className="w-full rounded-md py-1 text-center text-[11px] text-muted-foreground opacity-0 hover:bg-muted hover:opacity-100"
                    onClick={() => setCreating({ dateKey: `${vnDateKey(d)}T09:00` })}
                  >
                    + Thêm
                  </button>
                </div>
              </div>
            )
          })}
        </div>
        <EventDialog
          event={editing}
          creating={creating ? { start: creating.dateKey } : null}
          onClose={() => {
            setEditing(null)
            setCreating(null)
          }}
          onSaved={() => {
            load()
            setEditing(null)
            setCreating(null)
          }}
          onRemove={removeEvent}
        />
      </div>
    )
  }

  // ==== MONTH VIEW (mặc định) ====
  const firstDow = (new Date(year, month, 1).getDay() + 6) % 7
  const daysInMonth = new Date(year, month + 1, 0).getDate()
  const cells: (Date | null)[] = [
    ...Array.from({ length: firstDow }, () => null),
    ...Array.from({ length: daysInMonth }, (_, i) => new Date(year, month, i + 1)),
  ]
  while (cells.length % 7 !== 0) cells.push(null)

  const holidayOf = (d: Date) => holidays.find((h) => h.date === vnDateKey(d))

  return (
    <div className="space-y-4">
      <Header
        title={cursor.toLocaleDateString('vi-VN', { month: 'long', year: 'numeric' })}
        view={view}
        setView={setView}
        onPrev={() => setCursor(new Date(year, month - 1, 1))}
        onNext={() => setCursor(new Date(year, month + 1, 1))}
        onToday={() => setCursor(new Date())}
        onNew={() => setCreating({ dateKey: `${vnDateKey(cursor)}T09:00` })}
      />
      <Card className="wos-glass overflow-hidden border-0">
        <div className="grid grid-cols-7 border-b bg-muted/40">
          {DOW.map((d) => (
            <div key={d} className="py-2 text-center text-xs font-semibold text-muted-foreground">
              {d}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7">
          {cells.map((d, i) => {
            if (!d) return <div key={`e${i}`} className="min-h-[92px] border-b border-r bg-muted/20 last:border-r-0" />
            const isToday = vnDateKey(d) === vnDateKey(new Date())
            const evs = eventsOf(d)
            const holiday = holidayOf(d)
            return (
              <button
                key={d.toISOString()}
                onClick={() => {
                  setCursor(d)
                  setCreating({ dateKey: `${vnDateKey(d)}T09:00` })
                }}
                className="min-h-[92px] border-b border-r p-1.5 text-left align-top transition-colors hover:bg-muted/50 last:border-r-0 md:[&:nth-child(7)]:border-r-0"
              >
                <span
                  className={`inline-flex h-6 w-6 items-center justify-center rounded-full text-xs font-semibold tabular-nums ${
                    isToday ? 'bg-primary text-primary-foreground' : holiday ? 'text-amber-600' : ''
                  }`}
                >
                  {d.getDate()}
                </span>
                {holiday && <p className="truncate text-[9px] font-medium text-amber-600">{holiday.title}</p>}
                <div className="mt-0.5 space-y-0.5">
                  {evs.slice(0, 3).map((e) => (
                    <span
                      key={e.id}
                      onClick={(ev) => {
                        ev.stopPropagation()
                        setEditing(e)
                      }}
                      className="block truncate rounded px-1.5 py-0.5 text-[10px] font-medium text-white"
                      style={{ background: e.color || CATEGORY_COLORS[e.category] }}
                    >
                      {e.allDay ? '🌐 ' : `${new Date(e.start).getHours()}:${String(new Date(e.start).getMinutes()).padStart(2, '0')} `}
                      {e.title}
                      {e.recurring !== 'none' && ' ↻'}
                    </span>
                  ))}
                  {evs.length > 3 && <span className="block px-1 text-[10px] text-muted-foreground">+{evs.length - 3} nữa</span>}
                </div>
              </button>
            )
          })}
        </div>
      </Card>

      {/* Chú thích category */}
      <div className="flex flex-wrap gap-3 px-1">
        {Object.entries(CATEGORY_LABEL).map(([k, label]) => (
          <span key={k} className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <span className="h-2.5 w-2.5 rounded-full" style={{ background: CATEGORY_COLORS[k] }} />
            {label}
          </span>
        ))}
      </div>

      <EventDialog
        event={editing}
        creating={creating ? { start: creating.dateKey } : null}
        onClose={() => {
          setEditing(null)
          setCreating(null)
        }}
        onSaved={() => {
          load()
          setEditing(null)
          setCreating(null)
        }}
        onRemove={removeEvent}
      />
    </div>
  )
}

function Header({
  title, view, setView, onPrev, onNext, onToday, onNew,
}: {
  title: string
  view: string
  setView: (v: 'month' | 'week' | 'day' | 'year') => void
  onPrev: () => void
  onNext: () => void
  onToday: () => void
  onNew?: () => void
}) {
  return (
    <div className="flex flex-wrap items-center gap-3">
      <h1 className="flex items-center gap-2.5 text-xl font-bold">
        <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-500 text-white">
          <Calendar className="h-5 w-5" />
        </span>
        <span className="capitalize">{title}</span>
      </h1>
      <div className="flex items-center gap-1">
        <Button variant="outline" size="icon" className="h-9 w-9" onClick={onPrev} aria-label="Trước"><ChevronLeft className="h-4 w-4" /></Button>
        <Button variant="outline" size="sm" className="h-9" onClick={onToday}>Hôm nay</Button>
        <Button variant="outline" size="icon" className="h-9 w-9" onClick={onNext} aria-label="Sau"><ChevronRight className="h-4 w-4" /></Button>
      </div>
      <Tabs value={view} onValueChange={(v) => setView(v as 'month' | 'week' | 'day' | 'year')} className="ml-auto">
        <TabsList className="h-9">
          <TabsTrigger value="day" className="px-3">Day</TabsTrigger>
          <TabsTrigger value="week" className="px-3">Week</TabsTrigger>
          <TabsTrigger value="month" className="px-3">Month</TabsTrigger>
          <TabsTrigger value="year" className="px-3">Year</TabsTrigger>
        </TabsList>
      </Tabs>
      {onNew && (
        <Button size="sm" className="h-9 gap-1.5" onClick={onNew}>
          <Plus className="h-4 w-4" /> Sự kiện
        </Button>
      )}
    </div>
  )
}

function EventDialog({
  event, creating, onClose, onSaved, onRemove,
}: {
  event: EventRow | null
  creating: { start: string } | null
  onClose: () => void
  onSaved: () => void
  onRemove: (ev: EventRow) => void
}) {
  const { emit } = useWos()
  const { toast } = useToast()
  const isNew = !!creating && !event
  const open = !!event || !!creating
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [location, setLocation] = useState('')
  const [category, setCategory] = useState('general')
  const [color, setColor] = useState('')
  const [allDay, setAllDay] = useState(false)
  const [start, setStart] = useState('')
  const [end, setEnd] = useState('')
  const [recurring, setRecurring] = useState('none')
  const [reminder, setReminder] = useState('')
  const [saving, setSaving] = useState(false)
  const [initialized, setInitialized] = useState('')

  const initState = `${event?.id || ''}|${creating?.start || ''}`
  useEffect(() => {
    if (initState === initialized) return
    setInitialized(initState)
    if (event) {
      setTitle(event.title)
      setDescription(event.description)
      setLocation(event.location)
      setCategory(event.category)
      setColor(event.color)
      setAllDay(event.allDay)
      setStart(event.start.slice(0, 16))
      setEnd(event.end.slice(0, 16))
      setRecurring(event.recurring)
      setReminder(event.reminderMinutes != null ? String(event.reminderMinutes) : '')
    } else if (creating) {
      setTitle('')
      setDescription('')
      setLocation('')
      setCategory('general')
      setColor('')
      setAllDay(false)
      setStart(creating.start)
      setEnd(creating.start)
      setRecurring('none')
      setReminder('')
    }
  }, [event, creating, initState, initialized])

  async function save() {
    if (!title.trim()) {
      toast({ title: 'Nhập tiêu đề sự kiện', variant: 'destructive' })
      return
    }
    setSaving(true)
    try {
      const body = {
        title: title.trim(),
        description,
        location,
        category,
        color,
        allDay,
        start: new Date(start).toISOString(),
        end: new Date(end || start).toISOString(),
        recurring,
        reminderMinutes: reminder ? Number(reminder) : null,
      }
      if (event && !event.id.includes('#')) {
        await api(`/api/modules/calendar/${event.id}`, { method: 'PATCH', body })
        emit('event.updated', 'calendar', { title })
      } else {
        await api('/api/modules/calendar', { method: 'POST', body })
        emit('event.created', 'calendar', { title })
      }
      onSaved()
    } catch (err) {
      toast({ title: 'Lỗi', description: err instanceof Error ? err.message : 'Không lưu được', variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  if (!open) return null

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="wos-glass-strong sm:max-w-[480px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-lg">
            <span className="h-3 w-3 rounded-full" style={{ background: color || CATEGORY_COLORS[category] }} />
            {isNew ? 'Sự kiện mới' : 'Chỉnh sửa sự kiện'}
            {event?.recurring && event.recurring !== 'none' && (
              <Badge variant="secondary" className="gap-1"><RepeatIcon className="h-3 w-3" />{RECUR_LABEL[event.recurring]}</Badge>
            )}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Tiêu đề sự kiện" autoFocus className="h-10 font-medium" />
          <div className="grid grid-cols-2 gap-2">
            <div>
              <p className="mb-1 text-[11px] font-medium text-muted-foreground">Bắt đầu</p>
              <Input type="datetime-local" value={start} onChange={(e) => setStart(e.target.value)} className="h-9" />
            </div>
            <div>
              <p className="mb-1 text-[11px] font-medium text-muted-foreground">Kết thúc</p>
              <Input type="datetime-local" value={end} onChange={(e) => setEnd(e.target.value)} className="h-9" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <p className="mb-1 text-[11px] font-medium text-muted-foreground">Danh mục</p>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(CATEGORY_LABEL).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <p className="mb-1 text-[11px] font-medium text-muted-foreground">Màu riêng</p>
              <div className="flex h-9 items-center gap-2">
                {['', ...Object.values(CATEGORY_COLORS)].map((c) => (
                  <button
                    key={c || 'default'}
                    onClick={() => setColor(c)}
                    className={`h-6 w-6 rounded-full border-2 ${color === c ? 'border-foreground' : 'border-transparent'}`}
                    style={{ background: c || 'var(--muted)' }}
                    aria-label={c || 'Mặc định'}
                  />
                ))}
              </div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <p className="mb-1 text-[11px] font-medium text-muted-foreground">Lặp lại</p>
              <Select value={recurring} onValueChange={setRecurring}>
                <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(RECUR_LABEL).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <p className="mb-1 text-[11px] font-medium text-muted-foreground">Nhắc trước</p>
              <Select value={reminder} onValueChange={setReminder}>
                <SelectTrigger className="h-9"><SelectValue placeholder="Không nhắc" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Không nhắc</SelectItem>
                  <SelectItem value="5">5 phút</SelectItem>
                  <SelectItem value="15">15 phút</SelectItem>
                  <SelectItem value="30">30 phút</SelectItem>
                  <SelectItem value="60">1 giờ</SelectItem>
                  <SelectItem value="1440">1 ngày</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4 text-muted-foreground" />
            <Input value={location} onChange={(e) => setLocation(e.target.value)} placeholder="Địa điểm (tuỳ chọn)" className="h-9" />
          </div>
          <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Mô tả…" className="min-h-[70px]" />
        </div>
        <div className="flex items-center gap-2">
          {event && (
            <Button variant="destructive" size="sm" className="gap-1.5" onClick={() => onRemove(event)}>
              <Trash2 className="h-4 w-4" /> {(event.id.includes('#') || event.isOccurrence) ? 'Xoá lần này…' : 'Xoá'}
            </Button>
          )}
          <div className="flex-1" />
          <Button variant="outline" size="sm" onClick={onClose}>Huỷ</Button>
          <Button size="sm" onClick={save} disabled={saving}>
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Lưu'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

