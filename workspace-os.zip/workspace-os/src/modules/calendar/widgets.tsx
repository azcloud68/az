'use client'

import { useEffect, useState, useCallback } from 'react'
import { useWos } from '@/core/client/wos-store'
import { api } from '@/core/client/api'
import { bus } from '@/core/client/event-bus'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { CalendarDays, Loader2 } from 'lucide-react'

interface EventRow {
  id: string
  title: string
  start: string
  end: string
  allDay: boolean
  category: string
  color: string
}

const CATEGORY_COLORS: Record<string, string> = {
  general: '#f97316',
  work: '#0891b2',
  personal: '#84cc16',
  meeting: '#f43f5e',
  holiday: '#eab308',
}

/** Widget: Mini Calendar — lịch tháng + chấm sự kiện */
export function MiniCalendarWidget() {
  const { navigate } = useWos()
  const [cursor, setCursor] = useState(() => new Date())
  const [events, setEvents] = useState<EventRow[] | null>(null)

  const load = useCallback(async () => {
    try {
      const first = new Date(cursor.getFullYear(), cursor.getMonth(), 1)
      const last = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0)
      const data = await api<{ events: EventRow[] }>(
        `/api/modules/calendar?from=${first.toISOString()}&to=${last.toISOString()}`
      )
      setEvents(data.events)
    } catch {
      setEvents([])
    }
  }, [cursor])

  useEffect(() => {
    load()
    return bus.onAny((ev) => {
      if (ev.module === 'calendar') load()
    })
  }, [load])

  const today = new Date()
  const year = cursor.getFullYear()
  const month = cursor.getMonth()
  const firstDow = (new Date(year, month, 1).getDay() + 6) % 7 // Monday-first
  const daysInMonth = new Date(year, month + 1, 0).getDate()
  const cells: (number | null)[] = [
    ...Array.from({ length: firstDow }, () => null),
    ...Array.from({ length: daysInMonth }, (_, i) => i + 1),
  ]

  function eventsOfDay(day: number): EventRow[] {
    if (!events) return []
    const key = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`
    return events.filter((e) => e.start.slice(0, 10) === key)
  }

  return (
    <Card className="wos-glass border-0">
      <CardHeader className="flex flex-row items-center justify-between pb-1">
        <CardTitle className="flex items-center gap-2 text-sm font-semibold">
          <CalendarDays className="h-4 w-4 text-emerald-500" /> Lịch
        </CardTitle>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setCursor(new Date(year, month - 1, 1))}
            className="h-6 w-6 rounded-md text-muted-foreground hover:bg-muted"
            aria-label="Tháng trước"
          >
            ‹
          </button>
          <span className="text-xs font-medium tabular-nums">
            Tháng {month + 1}/{year}
          </span>
          <button
            onClick={() => setCursor(new Date(year, month + 1, 1))}
            className="h-6 w-6 rounded-md text-muted-foreground hover:bg-muted"
            aria-label="Tháng sau"
          >
            ›
          </button>
        </div>
      </CardHeader>
      <CardContent>
        {events === null ? (
          <div className="flex h-40 items-center justify-center">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <>
            <div className="grid grid-cols-7 text-center text-[10px] font-medium text-muted-foreground">
              {['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'].map((d) => (
                <span key={d} className="py-1">{d}</span>
              ))}
            </div>
            <div className="grid grid-cols-7 gap-y-0.5 text-center">
              {cells.map((day, i) => {
                if (day === null) return <span key={`e${i}`} />
                const isToday =
                  today.getFullYear() === year && today.getMonth() === month && today.getDate() === day
                const evs = eventsOfDay(day)
                return (
                  <button
                    key={day}
                    onClick={() => navigate(`calendar:${year}-${month + 1}-${day}`)}
                    className={`relative mx-auto flex h-8 w-8 flex-col items-center justify-center rounded-full text-xs transition-colors hover:bg-muted ${
                      isToday ? 'bg-primary font-semibold text-primary-foreground' : ''
                    }`}
                  >
                    <span className={isToday ? 'text-white' : ''}>{day}</span>
                    {evs.length > 0 && !isToday && (
                      <span className="absolute bottom-0.5 flex gap-0.5">
                        {evs.slice(0, 3).map((e) => (
                          <span
                            key={e.id}
                            className="h-1 w-1 rounded-full"
                            style={{ background: e.color || CATEGORY_COLORS[e.category] || '#f97316' }}
                          />
                        ))}
                      </span>
                    )}
                  </button>
                )
              })}
            </div>
            <div className="mt-2 space-y-1 border-t pt-2">
              {eventsOfDay(today.getDate())
                .slice(0, 3)
                .map((e) => (
                  <div key={e.id} className="flex items-center gap-2 text-xs">
                    <span className="h-1.5 w-1.5 rounded-full" style={{ background: e.color || CATEGORY_COLORS[e.category] }} />
                    <span className="truncate">{e.title}</span>
                    <span className="ml-auto shrink-0 text-muted-foreground">
                      {new Date(e.start).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                ))}
            </div>
          </>
        )}
      </CardContent>
    </Card>
  )
}
