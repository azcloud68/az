// =====================================================================
//  CORE ENGINE — Authentication & Session
//  scrypt hashing (node:crypto) + session cookie httpOnly
// =====================================================================
import { randomBytes, scryptSync, timingSafeEqual, createHash } from 'crypto'
import { cookies } from 'next/headers'
import { db } from '@/lib/db'

export const SESSION_COOKIE = 'wos_session'
const SESSION_HOURS = 12
const REMEMBER_DAYS = 30

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex')
  const hash = scryptSync(password, salt, 64).toString('hex')
  return `${salt}:${hash}`
}

export function verifyPassword(password: string, stored: string): boolean {
  try {
    const [salt, hash] = stored.split(':')
    if (!salt || !hash) return false
    const test = scryptSync(password, salt, 64)
    const target = Buffer.from(hash, 'hex')
    return test.length === target.length && timingSafeEqual(test, target)
  } catch {
    return false
  }
}

export type SessionUser = {
  id: string
  username: string
  displayName: string
  role: string
  avatarColor: string
  email: string | null
}

export async function createSession(userId: string, remember: boolean, ua = '', ip = '') {
  const token = randomBytes(32).toString('hex')
  const ms = remember
    ? REMEMBER_DAYS * 24 * 3600 * 1000
    : SESSION_HOURS * 3600 * 1000
  const expiresAt = new Date(Date.now() + ms)
  await db.session.create({ data: { token, userId, expiresAt, userAgent: ua, ip } })
  const jar = await cookies()
  jar.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production' && process.env.WOS_INSECURE_COOKIE !== '1',
    maxAge: Math.floor(ms / 1000),
    path: '/',
  })
  return token
}

export async function destroySession() {
  const jar = await cookies()
  const token = jar.get(SESSION_COOKIE)?.value
  if (token) {
    await db.session.deleteMany({ where: { token } })
    jar.delete(SESSION_COOKIE)
  }
}

export async function getSessionUser(): Promise<SessionUser | null> {
  const jar = await cookies()
  const token = jar.get(SESSION_COOKIE)?.value
  if (!token) return null
  const session = await db.session.findUnique({
    where: { token },
    include: { user: true },
  })
  if (!session) return null
  if (session.expiresAt < new Date()) {
    await db.session.delete({ where: { id: session.id } }).catch(() => {})
    return null
  }
  if (!session.user.active) return null
  const u = session.user
  return {
    id: u.id,
    username: u.username,
    displayName: u.displayName,
    role: u.role,
    avatarColor: u.avatarColor,
    email: u.email,
  }
}

export async function listSessions(userId: string) {
  return db.session.findMany({
    where: { userId, expiresAt: { gt: new Date() } },
    orderBy: { createdAt: 'desc' },
  })
}

// ---- Permission Engine ------------------------------------------------
export type Perm = 'view' | 'edit' | 'manage'

const ROLE_DEFAULTS: Record<string, Record<string, Perm[]>> = {
  admin: { '*': ['view', 'edit', 'manage'] },
  member: {
    '*': ['view', 'edit'],
    users: ['view'],
    settings: ['view'],
    core: ['view'],
  },
  viewer: { '*': ['view'] },
}

export async function getModulePermission(moduleId: string, role: string): Promise<Perm[]> {
  const state = await db.moduleState.findUnique({ where: { moduleId } })
  if (state) {
    try {
      const cfg = JSON.parse(state.config) as { permissions?: Record<string, Perm[]> }
      const per = cfg.permissions?.[role]
      if (per) return per
    } catch { /* fallthrough */ }
  }
  return ROLE_DEFAULTS[role]?.[moduleId] ?? ROLE_DEFAULTS[role]?.['*'] ?? []
}

export async function can(moduleId: string, perm: Perm): Promise<SessionUser | null> {
  const user = await getSessionUser()
  if (!user) return null
  const perms = await getModulePermission(moduleId, user.role)
  if (!perms.includes(perm)) return null
  return user
}

export function permDenied() {
  return Response.json({ error: 'Không đủ quyền thực hiện thao tác này' }, { status: 403 })
}

export function authDenied() {
  return Response.json({ error: 'Chưa đăng nhập' }, { status: 401 })
}

export function avatarSeedColor(name: string): string {
  const palette = ['#f97316', '#10b981', '#e11d48', '#8b5cf6', '#0ea5e9', '#d946ef', '#84cc16', '#f59e0b']
  const h = createHash('md5').update(name).digest()
  return palette[h[0] % palette.length]
}

export function makeResetCode(): string {
  return randomBytes(4).toString('hex').toUpperCase()
}
