// =====================================================================
//  CORE ENGINE — Module State + Settings Engine (server)
// =====================================================================
import { db } from '@/lib/db'

export type ModuleConfig = {
  permissions?: Record<string, string[]>
  widgets?: Record<string, { visible?: boolean; zone?: string; order?: number }>
  [key: string]: unknown
}

export async function getModuleStates() {
  const rows = await db.moduleState.findMany()
  const map: Record<string, { enabled: boolean; config: ModuleConfig; version: string }> = {}
  for (const r of rows) {
    let cfg: ModuleConfig = {}
    try { cfg = JSON.parse(r.config) as ModuleConfig } catch { /* ignore */ }
    map[r.moduleId] = { enabled: r.enabled, config: cfg, version: r.version }
  }
  return map
}

export async function setModuleEnabled(moduleId: string, enabled: boolean) {
  await db.moduleState.upsert({
    where: { moduleId },
    update: { enabled },
    create: { moduleId, enabled },
  })
}

export async function getModuleConfig(moduleId: string): Promise<ModuleConfig> {
  const state = await db.moduleState.findUnique({ where: { moduleId } })
  if (!state) return {}
  try { return JSON.parse(state.config) as ModuleConfig } catch { return {} }
}

export async function setModuleConfig(moduleId: string, config: ModuleConfig) {
  await db.moduleState.upsert({
    where: { moduleId },
    update: { config: JSON.stringify(config) },
    create: { moduleId, config: JSON.stringify(config) },
  })
}

// ---- Settings Engine --------------------------------------------------
export async function getSettings(module: string): Promise<Record<string, string>> {
  const rows = await db.setting.findMany({ where: { module } })
  const out: Record<string, string> = {}
  for (const r of rows) out[r.key] = r.value
  return out
}

export async function getAllSettings(): Promise<Record<string, Record<string, string>>> {
  const rows = await db.setting.findMany()
  const out: Record<string, Record<string, string>> = {}
  for (const r of rows) {
    if (!out[r.module]) out[r.module] = {}
    out[r.module][r.key] = r.value
  }
  return out
}

export async function saveSettings(module: string, values: Record<string, string>) {
  const ops = Object.entries(values).map(([key, value]) =>
    db.setting.upsert({
      where: { module_key: { module, key } },
      update: { value },
      create: { id: `${module}:${key}`, module, key, value },
    })
  )
  await Promise.all(ops)
}

export async function getSetting(module: string, key: string, fallback = ''): Promise<string> {
  const row = await db.setting.findUnique({ where: { module_key: { module, key } } })
  return row?.value ?? fallback
}
