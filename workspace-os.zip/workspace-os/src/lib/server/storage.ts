// =====================================================================
//  CORE ENGINE — Storage (Filesystem abstraction cho Module Files)
//  STORAGE_ROOT = thư mục dữ liệu thật; SQLite chỉ lưu index (FileNode)
// =====================================================================
import { promises as fs } from 'fs'
import path from 'path'
import { randomBytes } from 'crypto'

export const STORAGE_ROOT = process.env.STORAGE_ROOT
  ? path.resolve(process.env.STORAGE_ROOT)
  : path.join(process.cwd(), 'storage')

const FORBIDDEN = /[\0\x00]/
// path an toàn: không cho thoát ra ngoài STORAGE_ROOT
export function safeJoin(relPath: string): string {
  if (FORBIDDEN.test(relPath)) throw new Error('Đường dẫn không hợp lệ')
  const clean = relPath.replace(/^[/\\]+/, '').replace(/\\/g, '/')
  const abs = path.resolve(STORAGE_ROOT, clean)
  if (abs !== STORAGE_ROOT && !abs.startsWith(STORAGE_ROOT + path.sep)) {
    throw new Error('Đường dẫn nằm ngoài vùng lưu trữ')
  }
  return abs
}

export function normRel(p: string): string {
  return p.replace(/^[/\\]+/, '').replace(/\\/g, '/')
}

export async function ensureStorage() {
  await fs.mkdir(STORAGE_ROOT, { recursive: true })
  await fs.mkdir(path.join(STORAGE_ROOT, '.wos-versions'), { recursive: true })
  await fs.mkdir(path.join(STORAGE_ROOT, '.trash'), { recursive: true })
}

export async function duDir(dir: string): Promise<number> {
  let total = 0
  const walk = async (d: string) => {
    let entries: import('fs').Dirent[] = []
    try { entries = await fs.readdir(d, { withFileTypes: true }) } catch { return }
    for (const e of entries) {
      const full = path.join(d, e.name)
      if (e.isDirectory()) await walk(full)
      else {
        try { total += (await fs.stat(full)).size } catch { /* skip */ }
      }
    }
  }
  await walk(dir)
  return total
}

export async function makeShareToken(): Promise<string> {
  return randomBytes(16).toString('hex')
}

export function guessMime(name: string): string {
  const ext = path.extname(name).toLowerCase()
  const map: Record<string, string> = {
    '.txt': 'text/plain', '.md': 'text/markdown', '.markdown': 'text/markdown',
    '.json': 'application/json', '.csv': 'text/csv', '.log': 'text/plain',
    '.pdf': 'application/pdf',
    '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
    '.gif': 'image/gif', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.bmp': 'image/bmp',
    '.mp4': 'video/mp4', '.webm': 'video/webm', '.mov': 'video/quicktime',
    '.mp3': 'audio/mpeg', '.wav': 'audio/wav', '.ogg': 'audio/ogg', '.flac': 'audio/flac',
    '.doc': 'application/msword', '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    '.xls': 'application/vnd.ms-excel', '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    '.ppt': 'application/vnd.ms-powerpoint', '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    '.zip': 'application/zip', '.tar': 'application/x-tar', '.gz': 'application/gzip', '.7z': 'application/x-7z-compressed',
    '.html': 'text/html', '.css': 'text/css', '.js': 'text/javascript', '.ts': 'text/typescript',
    '.sh': 'text/x-shellscript', '.py': 'text/x-python',
  }
  return map[ext] ?? 'application/octet-stream'
}

export function isPreviewable(mime: string): 'image' | 'pdf' | 'text' | 'video' | 'audio' | 'office' | null {
  if (mime.startsWith('image/')) return 'image'
  if (mime === 'application/pdf') return 'pdf'
  if (mime.startsWith('text/') || /json|javascript|xml/.test(mime)) return 'text'
  if (mime.startsWith('video/')) return 'video'
  if (mime.startsWith('audio/')) return 'audio'
  if (/msword|officedocument|ms-excel|ms-powerpoint/.test(mime)) return 'office'
  return null
}
