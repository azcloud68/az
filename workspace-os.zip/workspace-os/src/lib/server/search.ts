// =====================================================================
//  CORE ENGINE — Search Engine (server)
//  Mỗi module tự đăng ký hàm tìm kiếm dữ liệu của mình vào registry.
//  Thêm module mới không cần sửa mã nguồn của công cụ tìm kiếm.
// =====================================================================
import { db } from '@/lib/db'

export type SearchHit = {
  module: string
  id: string
  title: string
  detail?: string
  icon?: string
  action: string // deep-link "wos://<module>?id=..."
}

export type SearchProvider = (q: string, limit: number) => Promise<SearchHit[]>

const REGISTRY = new Map<string, SearchProvider>()

export function registerSearchProvider(moduleId: string, provider: SearchProvider) {
  REGISTRY.set(moduleId, provider)
}

// ---------------- Các module built-in tự đăng ký ----------------
registerSearchProvider('tasks', async (q, limit) => {
  const rows = await db.task.findMany({
    where: { OR: [{ title: { contains: q } }, { description: { contains: q } }], status: { not: 'archived' } },
    take: limit,
    orderBy: { updatedAt: 'desc' },
  })
  return rows.map(r => ({
    module: 'tasks', id: r.id, title: r.title,
    detail: r.status === 'done' ? 'Hoàn thành' : r.status === 'doing' ? 'Đang làm' : 'Cần làm',
    icon: 'circle-check', action: `wos://tasks?id=${r.id}`,
  }))
})

registerSearchProvider('calendar', async (q, limit) => {
  const rows = await db.calendarEvent.findMany({
    where: { title: { contains: q } },
    take: limit,
    orderBy: { start: 'desc' },
  })
  return rows.map(r => ({
    module: 'calendar', id: r.id, title: r.title,
    detail: new Date(r.start).toLocaleString('vi-VN'),
    icon: 'calendar', action: `wos://calendar?id=${r.id}`,
  }))
})

registerSearchProvider('notes', async (q, limit) => {
  const rows = await db.note.findMany({
    where: { OR: [{ title: { contains: q } }, { content: { contains: q } }], trashedAt: null },
    take: limit,
    orderBy: { updatedAt: 'desc' },
  })
  return rows.map(r => ({
    module: 'notes', id: r.id, title: r.title,
    detail: r.content.slice(0, 80), icon: 'note', action: `wos://notes?id=${r.id}`,
  }))
})

registerSearchProvider('wiki', async (q, limit) => {
  const rows = await db.wikiPage.findMany({
    where: { OR: [{ title: { contains: q } }, { content: { contains: q } }], trashedAt: null },
    take: limit,
    orderBy: { updatedAt: 'desc' },
  })
  return rows.map(r => ({
    module: 'wiki', id: r.id, title: r.title,
    detail: r.content.slice(0, 80), icon: 'book', action: `wos://wiki?id=${r.id}`,
  }))
})

registerSearchProvider('files', async (q, limit) => {
  const rows = await db.fileNode.findMany({
    where: { name: { contains: q }, trashedAt: null },
    take: limit,
    orderBy: { updatedAt: 'desc' },
  })
  return rows.map(r => ({
    module: 'files', id: r.id, title: r.name,
    detail: r.isDir ? 'Thư mục' : `${(r.size / 1024).toFixed(1)} KB`,
    icon: r.isDir ? 'folder' : 'file', action: `wos://files?path=${encodeURIComponent(r.path)}`,
  }))
})

registerSearchProvider('projects', async (q, limit) => {
  const rows = await db.project.findMany({
    where: { OR: [{ name: { contains: q } }, { description: { contains: q } }], status: { not: 'archived' } },
    take: limit,
    orderBy: { updatedAt: 'desc' },
  })
  return rows.map(r => ({
    module: 'projects', id: r.id, title: r.name,
    detail: r.status === 'active' ? 'Đang hoạt động' : r.status,
    icon: 'folder-kanban', action: `wos://projects?id=${r.id}`,
  }))
})

registerSearchProvider('activity', async (q, limit) => {
  const rows = await db.activityLog.findMany({
    where: { OR: [{ detail: { contains: q } }, { action: { contains: q } }, { userName: { contains: q } }] },
    take: limit,
    orderBy: { createdAt: 'desc' },
  })
  return rows.map(r => ({
    module: 'activity', id: r.id, title: `${r.userName || 'Hệ thống'} — ${r.action}`,
    detail: `${r.module} · ${r.detail}`.slice(0, 90), icon: 'activity', action: `wos://activity`,
  }))
})

export async function globalSearch(q: string, enabledModules: Set<string>): Promise<SearchHit[]> {
  if (!q.trim()) return []
  const tasks: Promise<SearchHit[]>[] = []
  for (const [moduleId, provider] of REGISTRY) {
    if (!enabledModules.has(moduleId)) continue // module tắt → không tìm
    tasks.push(provider(q, 8).catch(() => [] as SearchHit[]))
  }
  const results = await Promise.all(tasks)
  return results.flat().slice(0, 50)
}
