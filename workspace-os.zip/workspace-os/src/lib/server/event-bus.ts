// =====================================================================
//  CORE ENGINE — Event Bus (server side)
//  Module KHÔNG gọi module khác. Mọi module chỉ phát Event vào đây.
//  Event Bus ghi EventRecord → Timeline / Dashboard đọc; Activity Log
//  và Notification được ghi kèm tuỳ theo cấu hình sự kiện.
// =====================================================================
import { db } from '@/lib/db'

export type WosEvent = {
  type: string // "task.completed", "file.uploaded", ...
  module: string
  actorId?: string | null
  actorName?: string
  payload?: Record<string, unknown>
  notify?: { title: string; content?: string; action?: string; type?: string } | false
}

export async function emitEvent(ev: WosEvent) {
  try {
    await db.eventRecord.create({
      data: {
        type: ev.type,
        module: ev.module,
        actorId: ev.actorId ?? null,
        actorName: ev.actorName ?? '',
        payload: JSON.stringify(ev.payload ?? {}),
      },
    })
    if (ev.notify) {
      await db.notification.create({
        data: {
          userId: ev.actorId ?? null,
          title: ev.notify.title,
          content: ev.notify.content ?? '',
          module: ev.module,
          type: ev.notify.type ?? 'info',
          action: ev.notify.action ?? '',
        },
      })
    }
  } catch (e) {
    console.error('[EventBus] emit failed:', e)
  }
}

export async function logActivity(params: {
  userId?: string | null
  userName?: string
  module?: string
  action: string
  targetType?: string
  targetId?: string
  detail?: string
}) {
  try {
    await db.activityLog.create({
      data: {
        userId: params.userId ?? null,
        userName: params.userName ?? '',
        module: params.module ?? 'core',
        action: params.action,
        targetType: params.targetType ?? '',
        targetId: params.targetId ?? '',
        detail: params.detail ?? '',
      },
    })
  } catch (e) {
    console.error('[Activity] log failed:', e)
  }
}
