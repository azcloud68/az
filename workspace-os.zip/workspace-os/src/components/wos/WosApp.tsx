'use client'

import { useEffect, useRef } from 'react'
import { useWos } from '@/core/client/wos-store'
import { useWindows } from '@/core/client/window-store'
import { loadSession, saveSession, sessionAge } from '@/core/client/session-store'
import { bus } from '@/core/client/event-bus'
import { LoginScreen } from './LoginScreen'
import { Desktop } from './Desktop'
import { CommandPalette } from './CommandPalette'
import { Loader2 } from 'lucide-react'
import { toast } from 'sonner'
import { Toaster } from '@/components/ui/sonner'

/** WOS root — boot kernel, chọn Login hoặc Desktop, nối Event Bus → Toast.
 *  V3: DESKTOP SESSION — lưu cửa sổ đang mở (vị trí/kích thước/route) và mở lại
 *  khi đăng nhập / reload trang — WOS có tính bền vững của một PC thật. */
export function WosApp() {
  const { booted, user, boot, onUnauthorized, refreshNotifications, modules, plugins } = useWos()
  const restoredFor = useRef<string | null>(null)

  useEffect(() => {
    boot()
  }, [boot])

  // ==== DESKTOP SESSION (Window Persistence V3) ====
  // Phục hồi cửa sổ phiên trước: chạy MỘT lần cho mỗi tài khoản sau khi modules load,
  // chỉ mở lại app còn được bật (module enabled / plugin enabled / app hệ thống)
  useEffect(() => {
    if (!user || modules.length === 0) return
    if (restoredFor.current === user.id) return
    restoredFor.current = user.id
    try {
      const sess = loadSession(user.id)
      if (!sess || sess.length === 0) return
      if (sessionAge(sess) > 7 * 24 * 60 * 60 * 1000) return // quá 7 ngày không phục hồi
      const enabledModules = new Set(modules.filter((m) => m.enabled).map((m) => m.id))
      const enabledPlugins = new Set(plugins.filter((p) => p.enabled).map((p) => p.slug))
      const restorable = sess
        .filter(
          (w) =>
            enabledModules.has(w.moduleId) ||
            enabledPlugins.has(w.moduleId) ||
            w.moduleId === 'viewer' || // viewer không phải module DB — luôn cho phục hồi
            w.moduleId === 'note',
        )
        .slice(0, 12)
      if (restorable.length > 0) {
        useWindows
          .getState()
          .restoreWindows(restorable.map(({ savedAt: _savedAt, ...w }) => w))
      }
    } catch {
      /* phiên hỏng — bỏ qua, desktop vẫn boot */
    }
  }, [user, modules, plugins])

  // Tự động lưu phiên (debounce 900ms) mỗi khi cửa sổ thêm/xoá/di chuyển/đổi route
  useEffect(() => {
    const uid = user?.id
    if (!uid) return
    let timer: ReturnType<typeof setTimeout> | null = null
    const unsub = useWindows.subscribe((state) => {
      if (timer) clearTimeout(timer)
      timer = setTimeout(() => saveSession(uid, state.windows), 900)
    })
    return () => {
      unsub()
      if (timer) clearTimeout(timer)
    }
  }, [user?.id])

  // Hết phiên → đẩy về login
  useEffect(() => {
    const handler = () => onUnauthorized()
    window.addEventListener('wos:unauthorized', handler)
    return () => window.removeEventListener('wos:unauthorized', handler)
  }, [onUnauthorized])

  // Event Bus → toast + refetch notification (mọi module hưởng lợi không cần biết nhau)
  useEffect(() => {
    if (!user) return
    const labels: Record<string, string> = {
      'task.completed': '✅ Hoàn thành công việc',
      'task.created': '🆕 Công việc mới',
      'note.created': '📝 Ghi chú mới',
      'wiki.updated': '📖 Wiki cập nhật',
      'file.uploaded': '📤 Đã tải lên tệp',
      'file.shared': '🔗 Đã chia sẻ tệp',
      'project.created': '🗂 Dự án mới',
      'milestone.completed': '🏁 Hoàn thành mốc',
      'module.enabled': '🟢 Module đã bật',
      'module.disabled': '⚪ Module đã tắt',
      'event.created': '📅 Sự kiện mới',
      'backup.imported': '💾 Nhập sao lưu',
      'weekly.process.created': '🧪 Quy trình mới',
      'weekly.task.completed': '✅ Hoàn thành việc tuần',
      'weekly.day.offline': '🏖 Đánh dấu ngày nghỉ',
      'sync.backup.ok': '☁️ Backup Drive thành công',
      'sync.backup.error': '⚠️ Backup Drive lỗi',
    }
    const off = bus.onAny((ev) => {
      const title = labels[ev.type]
      if (title && ev.payload?.title) toast(title, { description: String(ev.payload.title) })
      if (ev.type.startsWith('module.')) refreshNotifications().catch(() => {})
    })
    return off
  }, [user, refreshNotifications])

  // Reminder check mỗi phút (task reminderAt)
  useEffect(() => {
    if (!user) return
    const t = setInterval(() => {
      const key = 'wos_reminded'
      const reminded: string[] = JSON.parse(localStorage.getItem(key) || '[]')
      void import('@/core/client/api').then(({ api }) => {
        api<{ tasks: { id: string; title: string; reminderAt: string | null }[] }>('/api/modules/tasks?status=all')
          .then((data) => {
            const now = Date.now()
            for (const task of data.tasks) {
              if (!task.reminderAt || reminded.includes(task.id)) continue
              const at = new Date(task.reminderAt).getTime()
              if (at <= now && now - at < 3600000) {
                toast('⏰ Nhắc việc', { description: task.title, duration: 8000 })
                reminded.push(task.id)
              }
            }
            localStorage.setItem(key, JSON.stringify(reminded.slice(-100)))
          })
          .catch(() => {})
      })
    }, 60000)
    return () => clearInterval(t)
  }, [user])

  if (!booted) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4">
        <div className="wos-wallpaper" />
        <Loader2 className="h-8 w-8 animate-spin text-white/80" />
        <p className="text-sm font-medium text-white/80">Đang khởi động Workspace OS…</p>
      </div>
    )
  }

  return (
    <>
      {user ? <Desktop /> : <LoginScreen />}
      <Toaster position="bottom-right" richColors closeButton />
    </>
  )
}
