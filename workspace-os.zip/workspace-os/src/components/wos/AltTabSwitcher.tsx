'use client'

/**
 * AltTabSwitcher — overlay chuyển cửa sổ như Alt+Tab của PC:
 * giữ Alt, bấm Tab vòng lặp, thả Alt → focus cửa sổ đang chọn.
 * Overlay render danh sách cửa sổ (icon app + tiêu đề).
 */
import { useWindows } from '@/core/client/window-store'
import { useWos } from '@/core/client/wos-store'
import { AppIcon } from './ModuleIcon'
import { windowTitleSuffix } from './app-registry'

export function AltTabSwitcher() {
  const switcherOpen = useWindows((s) => s.switcherOpen)
  const switcherIds = useWindows((s) => s.switcherIds)
  const switcherIndex = useWindows((s) => s.switcherIndex)
  const windows = useWindows((s) => s.windows)
  const modules = useWos((s) => s.modules)

  if (!switcherOpen || switcherIds.length === 0) return null

  const list = switcherIds
    .map((id) => windows.find((w) => w.id === id))
    .filter((w): w is NonNullable<typeof w> => Boolean(w))

  return (
    <div className="wos-switcher" role="dialog" aria-label="Chuyển cửa sổ (Alt Tab)">
      <div className="wos-switcher-panel">
        {list.map((w, i) => {
          const m = modules.find((mod) => mod.id === w.moduleId)
          const title = (m?.name || w.moduleId) + windowTitleSuffix(w.moduleId, w.route)
          return (
            <div
              key={w.id}
              className={`wos-switcher-item ${i === switcherIndex ? 'active' : ''}`}
              aria-current={i === switcherIndex}
            >
              <span
                className="flex h-14 w-14 items-center justify-center rounded-[26%] text-white shadow-lg"
                style={{ background: `linear-gradient(145deg, ${m?.color || '#f97316'}, ${m?.color || '#f97316'}cc)` }}
              >
                <AppIcon moduleId={w.moduleId} icon={m?.icon || 'box'} px={30} className="h-8 w-8" />
              </span>
              <span className="w-full truncate text-center text-[11.5px] font-medium text-foreground/90">{title}</span>
            </div>
          )
        })}
      </div>
      <p className="absolute bottom-12 text-[11.5px] font-medium text-white/70">
        Giữ Alt · Tab để chuyển · thả Alt để chọn
      </p>
    </div>
  )
}
