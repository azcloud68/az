'use client'

/**
 * Dock — Dock Manager (review #5/#6):
 * - Danh sách app GHIM theo THỨ TỰ do người dùng sắp xếp, lưu per-account
 *   (wos-store.dockPinned — null = mặc định tự động theo module như cũ)
 * - KÉO icon ngang để đổi thứ tự (live), KÉO XUỐNG khỏi dock để bỏ ghim
 * - App đang chạy nhưng chưa ghim hiển thị sau vùng ngăn cách
 * - Icon 36px trong ô 44px (82%) — tỷ lệ macOS thật (review #6)
 * - THÙNG RÁC cố định bên phải nhất (v6.1 — như macOS): badge số mục,
 *   click mở Files → Trash, right-click mở/dọn sạch
 * - Click mở/focus/thu nhỏ, right-click menu (ghim/bỏ ghim/di chuyển/đóng)
 */
import { useCallback, useEffect, useRef, useState } from 'react'
import { useWindows } from '@/core/client/window-store'
import { useWos } from '@/core/client/wos-store'
import { AppIcon, useAppOverrides } from './ModuleIcon'
import { ContextMenu, openCtx, type CtxItem, type CtxMenuState } from './ContextMenu'
import { useDockCandidates } from './dock-utils'
import { system } from '@/core/client/desktop'
import { api } from '@/core/client/api'
import { bus } from '@/core/client/event-bus'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { toast } from 'sonner'
import {
  LayoutGrid, X, Minus, ChevronUp, Pin, PinOff, ArrowLeft, ArrowRight, Trash2, FolderOpen, Loader2,
  ArrowDownAZ, RotateCcw,
} from 'lucide-react'

/** Thùng rác trên Dock — cố định bên phải nhất (không kéo/ghim như app) */
function DockTrash() {
  const [count, setCount] = useState<number | null>(null)
  const [menu, setMenu] = useState<CtxMenuState | null>(null)
  const [confirmEmpty, setConfirmEmpty] = useState(false)
  const [emptying, setEmptying] = useState(false)

  const load = useCallback(async () => {
    try {
      const data = await api<{ trash: unknown[] }>('/api/modules/files/trash')
      setCount(data.trash?.length ?? 0)
    } catch {
      setCount(0)
    }
  }, [])

  useEffect(() => {
    load()
    const off = bus.onAny((ev) => {
      if (ev.module === 'files') load()
    })
    const t = setInterval(load, 60000)
    return () => {
      off()
      clearInterval(t)
    }
  }, [load])

  async function empty() {
    setEmptying(true)
    try {
      await api('/api/modules/files/empty-trash', { method: 'POST', body: {} })
      bus.emit('file.deleted', 'files', { name: 'empty-trash' })
      toast.success('Đã dọn sạch thùng rác')
    } catch (err) {
      toast.error('Không dọn được thùng rác', { description: err instanceof Error ? err.message : '' })
    } finally {
      setEmptying(false)
      setConfirmEmpty(false)
      await load()
    }
  }

  const items: CtxItem[] = [
    { label: 'Mở thùng rác', icon: FolderOpen, onClick: () => system.openTrash() },
    { label: 'Dọn sạch thùng rác', danger: true, icon: Trash2, disabled: !count, onClick: () => setConfirmEmpty(true) },
  ]

  return (
    <>
      <button
        onClick={() => system.openTrash()}
        onPointerDown={(e) => e.stopPropagation()}
        onContextMenu={(e) => {
          e.preventDefault()
          e.stopPropagation()
          openCtx(e, setMenu, items)
        }}
        className="wos-dock-item group relative flex flex-col items-center"
        aria-label={`Thùng rác${count ? ` — ${count} mục` : ''}`}
        title="Thùng rác"
      >
        <span
          className="flex h-11 w-11 items-center justify-center rounded-[26%] text-white shadow-md transition-shadow group-hover:shadow-lg"
          style={{
            background: count && count > 0
              ? 'linear-gradient(145deg, #c9a35c, #a67c3d)'
              : 'linear-gradient(145deg, #b6bcc7, #8b93a1)',
            boxShadow: '0 5px 14px rgba(0,0,0,0.3), inset 0 1px 1px rgba(255,255,255,0.4)',
          }}
        >
          <Trash2 className="h-9 w-9" strokeWidth={1.6} />
        </span>
        {count !== null && count > 0 ? (
          <span
            className="absolute -right-1 -top-1 flex items-center justify-center rounded-full bg-rose-500 px-1 text-[10px] font-bold text-white shadow"
            style={{ height: 18, minWidth: 18 }}
            aria-label={`${count} mục trong thùng rác`}
          >
            {count > 99 ? '99+' : count}
          </span>
        ) : null}
        <span className="pointer-events-none absolute -top-9 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-lg bg-black/75 px-2.5 py-1 text-[11.5px] font-medium text-white opacity-0 transition-opacity group-hover:opacity-100">
          Thùng rác{count ? ` (${count})` : ''}
        </span>
      </button>

      {menu ? <ContextMenu state={menu} onClose={() => setMenu(null)} /> : null}

      {confirmEmpty ? (
        <Dialog open onOpenChange={(o) => !o && setConfirmEmpty(false)}>
          <DialogContent className="wos-glass-strong sm:max-w-[340px]">
            <DialogHeader><DialogTitle>Dọn sạch thùng rác?</DialogTitle></DialogHeader>
            <p className="text-sm text-muted-foreground">
              {count ? `${count} mục sẽ bị xoá vĩnh viễn.` : 'Mọi mục trong thùng rác sẽ bị xoá vĩnh viễn.'}
            </p>
            <div className="flex justify-end gap-2">
              <Button variant="outline" size="sm" onClick={() => setConfirmEmpty(false)}>Huỷ</Button>
              <Button variant="destructive" size="sm" disabled={emptying} onClick={() => void empty()}>
                {emptying ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : null} Dọn sạch
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      ) : null}
    </>
  )
}

/** Dialog "Tuỳ chỉnh Dock" (v6.3) — thêm/bớt TẤT CẢ app (module + plugin),
 *  sắp xếp thứ tự, đặt lại mặc định. Mở từ right-click nút Launchpad trên Dock
 *  hoặc mục "Tuỳ chỉnh Dock…" trong menu phải của từng icon Dock. */
function DockCustomize({ open, onClose }: { open: boolean; onClose: () => void }) {
  const candidates = useDockCandidates()
  const dockPinned = useWos((s) => s.dockPinned)
  const saveDockPinned = useWos((s) => s.saveDockPinned)
  const { iconOverrides, iconColors } = useAppOverrides()
  const [q, setQ] = useState('')
  const pinned = dockPinned ?? candidates.filter((c) => c.defaultDock).map((c) => c.id)

  const filtered = candidates.filter((c) => !q || c.name.toLowerCase().includes(q.toLowerCase()))
  const move = (id: string, dir: -1 | 1) => {
    const idx = pinned.indexOf(id)
    const to = idx + dir
    if (idx < 0 || to < 0 || to >= pinned.length) return
    const next = [...pinned]
    next.splice(idx, 1)
    next.splice(to, 0, id)
    void saveDockPinned(next)
  }
  const toggle = (id: string) => {
    const isPinned = pinned.includes(id)
    void saveDockPinned(isPinned ? pinned.filter((x) => x !== id) : [...pinned, id])
  }

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="wos-glass-strong sm:max-w-[460px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <LayoutGrid className="h-4 w-4 text-primary" /> Tuỳ chỉnh Dock
          </DialogTitle>
        </DialogHeader>
        <p className="text-[12px] text-muted-foreground">
          Ghim / bỏ ghim <b>mọi ứng dụng</b> ({candidates.length} app: module + plugin). Thứ tự hiện tại của
          {pinned.length} app đang ghim được giữ nguyên khi thêm app mới.
        </p>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Tìm ứng dụng…"
          className="h-9 w-full rounded-lg border bg-background px-3 text-[13px] outline-none focus:ring-1 focus:ring-primary"
        />
        <div className="wos-scroll -mx-1 max-h-[46vh] space-y-1 overflow-y-auto px-1">
          {filtered.map((c) => {
            const isPinned = pinned.includes(c.id)
            const idx = pinned.indexOf(c.id)
            const color = iconColors[c.id] || c.color
            const hasEmoji = iconOverrides[c.id]?.type === 'emoji'
            return (
              <div
                key={c.id}
                className={`flex items-center gap-2.5 rounded-xl border px-2.5 py-2 transition ${
                  isPinned ? 'border-amber-500/40 bg-amber-500/[0.07]' : 'border-transparent hover:bg-muted/60'
                }`}
              >
                <span
                  className="flex h-8 w-8 shrink-0 items-center justify-center rounded-[22%] text-white"
                  style={{
                    background: hasEmoji ? 'rgba(127,127,127,0.15)' : `linear-gradient(145deg, ${color}, ${color}cc)`,
                  }}
                >
                  <AppIcon moduleId={c.id} icon={c.icon} px={20} className="h-5 w-5" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13px] font-medium">
                    {c.name}
                    {c.isPlugin ? <span className="ml-1.5 text-[9.5px] font-normal text-violet-500">plugin</span> : null}
                  </p>
                  {isPinned ? (
                    <p className="text-[10.5px] text-muted-foreground">vị trí {idx + 1}/{pinned.length}</p>
                  ) : (
                    <p className="text-[10.5px] text-muted-foreground">chưa ghim</p>
                  )}
                </div>
                {isPinned ? (
                  <div className="flex items-center gap-0.5">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7"
                      disabled={idx <= 0}
                      onClick={() => move(c.id, -1)}
                      aria-label={`Chuyển ${c.name} lên trước`}
                      title="Sang trái"
                    >
                      <ArrowLeft className="h-3.5 w-3.5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7"
                      disabled={idx >= pinned.length - 1}
                      onClick={() => move(c.id, 1)}
                      aria-label={`Chuyển ${c.name} xuống sau`}
                      title="Sang phải"
                    >
                      <ArrowRight className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                ) : null}
                <Button
                  variant={isPinned ? 'outline' : 'default'}
                  size="sm"
                  className="h-7 gap-1 px-2.5 text-[11.5px]"
                  onClick={() => toggle(c.id)}
                >
                  {isPinned ? <PinOff className="h-3.5 w-3.5" /> : <Pin className="h-3.5 w-3.5" />}
                  {isPinned ? 'Bỏ ghim' : 'Ghim'}
                </Button>
              </div>
            )
          })}
          {filtered.length === 0 ? (
            <p className="py-6 text-center text-[12.5px] text-muted-foreground">Không có ứng dụng nào khớp.</p>
          ) : null}
        </div>
        <div className="flex items-center justify-between gap-2 border-t pt-3">
          <Button
            variant="ghost"
            size="sm"
            className="gap-1.5 text-[12px] text-muted-foreground"
            onClick={() => void saveDockPinned(null)}
            title="Quay lại danh sách mặc định tự động theo module"
          >
            <RotateCcw className="h-3.5 w-3.5" /> Mặc định
          </Button>
          <Button size="sm" onClick={onClose} className="gap-1.5">Xong</Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

export function Dock() {
  const windows = useWindows((s) => s.windows)
  const zTop = useWindows((s) => s.zTop)
  const openApp = useWindows((s) => s.openApp)
  const toggleMinimize = useWindows((s) => s.toggleMinimize)
  const closeModule = useWindows((s) => s.closeModule)
  const focusWindow = useWindows((s) => s.focusWindow)
  const setLaunchpad = useWindows((s) => s.setLaunchpad)
  const { iconOverrides, iconColors } = useAppOverrides()
  const dockPinned = useWos((s) => s.dockPinned)
  const saveDockPinned = useWos((s) => s.saveDockPinned)
  const candidates = useDockCandidates()
  const [menu, setMenu] = useState<CtxMenuState | null>(null)
  const [customizeOpen, setCustomizeOpen] = useState(false)
  // File manager bị khoá cho tài khoản → ẩn thùng rác trên Dock
  const canFiles = useWos((s) =>
    s.user?.role === 'admin' ||
    (s.user?.permissions?.allowFiles !== false &&
      (!Array.isArray(s.user?.permissions?.modules) || s.user.permissions.modules.includes('files'))),
  )

  // Danh sách hiển thị: app ghim (theo thứ tự lưu) + app đang chạy chưa ghim
  // v6.3: mặc định (dockPinned === null) = app có cờ showDock; người dùng có thể
  // ghim MỌI app (kể cả module ẩn dock + plugin) qua dialog Tuỳ chỉnh Dock.
  const byId = new Map(candidates.map((c) => [c.id, c]))
  const pinnedIds = (dockPinned ?? candidates.filter((c) => c.defaultDock).map((c) => c.id)).filter((id) => byId.has(id))
  const runningIds = windows
    .map((w) => w.moduleId)
    .filter((id, i, arr) => arr.indexOf(id) === i && byId.has(id) && !pinnedIds.includes(id))

  // ===== Kéo để sắp xếp / kéo xuống để bỏ ghim =====
  const [order, setOrder] = useState<string[] | null>(null) // thứ tự tạm trong lúc kéo
  const [dragId, setDragId] = useState<string | null>(null)
  const [dragRemove, setDragRemove] = useState(false) // con trỏ dưới dock → bỏ ghim
  const dragRef = useRef<{ id: string; sx: number; sy: number; moved: boolean } | null>(null)
  const navRef = useRef<HTMLElement | null>(null)
  const pinnedRef = useRef(pinnedIds)
  const orderRef = useRef<string[] | null>(null)
  const removeRef = useRef(false)
  useEffect(() => {
    pinnedRef.current = pinnedIds
  }, [pinnedIds])
  const displayIds = order ?? pinnedIds

  useEffect(() => {
    setOrder(null)
    orderRef.current = null
  }, [dockPinned])

  // Listener kéo toàn cục (chỉ có hiệu lực khi dragRef có dữ liệu — luôn gắn 1 lần)
  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      const d = dragRef.current
      if (!d) return
      if (!d.moved && (Math.abs(e.clientX - d.sx) > 5 || Math.abs(e.clientY - d.sy) > 5)) {
        d.moved = true
        setDragId(d.id)
      }
      if (!d.moved) return
      // kéo XUỐNG khỏi dock → hiện gợi ý bỏ ghim
      const nav = navRef.current
      const below = Boolean(nav && e.clientY > nav.getBoundingClientRect().bottom + 46)
      removeRef.current = below
      setDragRemove(below)
      if (below) return
      // kéo NGANG qua icon khác → đổi chỗ live (ref + state đồng bộ)
      const base = orderRef.current ?? pinnedRef.current
      const from = base.indexOf(d.id)
      if (from < 0) return
      const items = Array.from(navRef.current?.querySelectorAll<HTMLElement>('[data-dock-id]') || [])
      let insertAt = -1
      for (const el of items) {
        const r = el.getBoundingClientRect()
        if (e.clientX >= r.left && e.clientX <= r.right) {
          insertAt = Number(el.getAttribute('data-dock-index') || 0)
          break
        }
      }
      if (insertAt >= 0 && insertAt !== from) {
        const next = [...base]
        next.splice(from, 1)
        next.splice(insertAt, 0, d.id)
        orderRef.current = next
        setOrder(next)
      }
    }
    const onUp = () => {
      const d = dragRef.current
      dragRef.current = null
      setDragId(null)
      setDragRemove(false)
      if (!d || !d.moved) return
      if (removeRef.current) {
        void saveDockPinned(pinnedRef.current.filter((x) => x !== d.id))
      } else if (orderRef.current && orderRef.current.length) {
        void saveDockPinned(orderRef.current)
      }
      orderRef.current = null
    }
    window.addEventListener('pointermove', onMove)
    window.addEventListener('pointerup', onUp)
    return () => {
      window.removeEventListener('pointermove', onMove)
      window.removeEventListener('pointerup', onUp)
    }
  }, [saveDockPinned])

  /** Hành vi click chuột trái kiểu macOS */
  function dockClick(moduleId: string) {
    const win = windows.find((w) => w.moduleId === moduleId)
    if (!win) {
      openApp(moduleId)
      return
    }
    if (win.minimized) {
      openApp(moduleId) // focus + bỏ thu nhỏ
      return
    }
    if (win.z === zTop) {
      toggleMinimize(win.id) // đang trên cùng → thu nhỏ
    } else {
      focusWindow(win.id)
    }
  }

  function dockMenu(moduleId: string, name: string, idx: number, pinnedCount: number): CtxMenuState['items'] {
    const win = windows.find((w) => w.moduleId === moduleId)
    const pinned = displayIds.includes(moduleId)
    return [
      { label: `Mở ${name}`, icon: ChevronUp, onClick: () => openApp(moduleId) },
      ...(win ? [{ label: win.minimized ? 'Hiện lại cửa sổ' : 'Thu nhỏ', icon: Minus, onClick: () => (win.minimized ? openApp(moduleId) : toggleMinimize(win.id)) }] : []),
      ...(win ? [{ separator: true, label: '' }, { label: 'Đóng cửa sổ', icon: X, danger: true, onClick: () => closeModule(moduleId) }] : []),
      { separator: true, label: '' },
      ...(pinned
        ? [
            {
              label: 'Sang trái',
              icon: ArrowLeft,
              disabled: idx <= 0,
              onClick: () => moveDockItem(moduleId, idx, idx - 1),
            },
            {
              label: 'Sang phải',
              icon: ArrowRight,
              disabled: idx >= pinnedCount - 1,
              onClick: () => moveDockItem(moduleId, idx, idx + 1),
            },
            {
              label: 'Bỏ ghim khỏi Dock',
              icon: PinOff,
              onClick: () => void saveDockPinned(pinnedIds.filter((x) => x !== moduleId)),
            },
          ]
        : [
            {
              label: 'Ghim vào Dock',
              icon: Pin,
              onClick: () => void saveDockPinned([...pinnedIds, moduleId]),
            },
          ]),
      { separator: true, label: '' },
      {
        label: 'Tuỳ chỉnh Dock…',
        icon: LayoutGrid,
        onClick: () => setCustomizeOpen(true),
      },
    ]
  }

  function moveDockItem(id: string, from: number, to: number) {
    const next = [...pinnedIds]
    const [item] = next.splice(from, 1)
    next.splice(Math.max(0, Math.min(next.length, to)), 0, item)
    void saveDockPinned(next)
  }

  if (candidates.length === 0 && runningIds.length === 0) return null

  const renderDockButton = (id: string, idx: number, pinnedCount: number, pinnedSection: boolean) => {
    const m = byId.get(id)!
    const win = windows.find((w) => w.moduleId === id)
    const running = Boolean(win)
    const color = iconColors[id] || m.color
    const hasEmojiOverride = iconOverrides[id]?.type === 'emoji'
    const dragging = dragId === id
    return (
      <button
        key={id}
        data-dock-id={id}
        data-dock-index={idx}
        onClick={() => {
          if (dragRef.current?.moved) return
          dockClick(id)
        }}
        onPointerDown={(e) => {
          e.stopPropagation() // không kích hoạt marquee desktop (review #3)
          if (e.button !== 0) return
          // chỉ app ĐÃ GHIM mới kéo sắp xếp được
          dragRef.current = pinnedSection ? { id, sx: e.clientX, sy: e.clientY, moved: false } : null
        }}
        onContextMenu={(e) => openCtx(e, setMenu, dockMenu(id, m.name, idx, pinnedCount))}
        className={`wos-dock-item group relative flex flex-col items-center ${dragging ? 'wos-dock-dragging' : ''} ${
          dragging && dragRemove ? 'wos-dock-drop-remove' : ''
        }`}
        style={{ cursor: dragging ? 'grabbing' : undefined }}
        aria-label={`Mở ${m.name}`}
        aria-pressed={running}
        title={`${m.name}${dragging ? ' — kéo ngang để sắp xếp, kéo xuống để bỏ ghim' : ''}`}
      >
        {/* Review #6: icon 36px trong ô 44px (82%) — tỷ lệ macOS */}
        <span
          className="flex h-11 w-11 items-center justify-center rounded-[26%] text-white shadow-md transition-shadow group-hover:shadow-lg"
          style={{
            background: hasEmojiOverride ? 'rgba(255,255,255,0.22)' : `linear-gradient(145deg, ${color}, ${color}cc)`,
            boxShadow: hasEmojiOverride ? 'none' : '0 5px 14px rgba(0,0,0,0.3), inset 0 1px 1px rgba(255,255,255,0.35)',
          }}
        >
          <AppIcon moduleId={id} icon={m.icon} px={36} className="h-9 w-9" />
        </span>
        {/* Chấm đang chạy */}
        <span
          className="absolute -bottom-1 h-1 rounded-full bg-neutral-600 transition-all dark:bg-neutral-200"
          style={{ opacity: running ? 0.85 : 0, width: running ? (win?.minimized ? 6 : 14) : 4 }}
          aria-hidden
        />
        {/* Nhãn hover */}
        <span className="pointer-events-none absolute -top-9 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-lg bg-black/75 px-2.5 py-1 text-[11.5px] font-medium text-white opacity-0 transition-opacity group-hover:opacity-100">
          {m.name}
        </span>
        {/* Gợi ý bỏ ghim khi kéo xuống */}
        {dragging && dragRemove ? <span className="wos-dock-remove-hint">Thả để bỏ ghim</span> : null}
      </button>
    )
  }

  return (
    <div className="pointer-events-none fixed bottom-2.5 left-0 right-0 z-[40] flex justify-center" aria-hidden={false}>
      <nav
        ref={navRef}
        className="wos-dock pointer-events-auto flex items-end gap-1.5 rounded-2xl px-2.5 pb-2 pt-2"
        aria-label="Dock ứng dụng"
      >
        {displayIds.map((id, idx) => renderDockButton(id, idx, displayIds.length, true))}

        {/* App đang chạy nhưng chưa ghim */}
        {runningIds.length > 0 ? (
          <span className="mx-1 h-10 w-px self-center bg-neutral-500/30" aria-hidden />
        ) : null}
        {runningIds.map((id) => renderDockButton(id, -1, 0, false))}

        {/* Ngăn cách + Launchpad (right-click → Tuỳ chỉnh Dock) */}
        <span className="mx-1 h-10 w-px self-center bg-neutral-500/30" aria-hidden />
        <button
          onClick={() => setLaunchpad(true)}
          onPointerDown={(e) => e.stopPropagation()}
          onContextMenu={(e) => {
            e.preventDefault()
            e.stopPropagation()
            openCtx(e, setMenu, [
              { label: 'Mở Launchpad', icon: LayoutGrid, onClick: () => setLaunchpad(true) },
              { label: 'Tuỳ chỉnh Dock…', icon: ArrowDownAZ, onClick: () => setCustomizeOpen(true) },
            ])
          }}
          className="wos-dock-item group relative flex flex-col items-center"
          aria-label="Mở Launchpad"
          title="Launchpad (F4) — right-click để tuỳ chỉnh Dock"
        >
          <span
            className="flex h-11 w-11 items-center justify-center rounded-[26%] text-neutral-700 shadow-md dark:text-neutral-200"
            style={{
              background: 'linear-gradient(145deg, #f3f4f6, #cbd5e1)',
              boxShadow: '0 5px 14px rgba(0,0,0,0.25), inset 0 1px 1px rgba(255,255,255,0.6)',
            }}
          >
            <LayoutGrid className="h-9 w-9" />
          </span>
          <span className="pointer-events-none absolute -top-9 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-lg bg-black/75 px-2.5 py-1 text-[11.5px] font-medium text-white opacity-0 transition-opacity group-hover:opacity-100">
            Launchpad
          </span>
        </button>

        {/* v6.1: Thùng rác — cố định bên phải nhất (như macOS), ẩn khi File Manager bị khoá */}
        {canFiles ? (
          <>
            <span className="mx-1 h-10 w-px self-center bg-neutral-500/30" aria-hidden />
            <DockTrash />
          </>
        ) : null}
      </nav>

      {menu ? <ContextMenu state={menu} onClose={() => setMenu(null)} /> : null}
      <DockCustomize open={customizeOpen} onClose={() => setCustomizeOpen(false)} />
    </div>
  )
}
