'use client'

/**
 * App Registry — mọi module đăng ký trang + meta cửa sổ tại đây.
 * WindowFrame/Launchpad/DesktopIcons/Dock đều đọc từ registry duy nhất này.
 * Plugin app đăng ký động vào PAGES lúc runtime (registerPluginApp).
 */
import dynamic from 'next/dynamic'
import { create } from 'zustand'
import { Loader2 } from 'lucide-react'
import { WINDOW_SIZE } from '@/core/client/window-store'
import { getPluginApp, runPlugin, resetPlugin, type PluginMeta } from './plugin-runtime'
import { registerWindowSize } from '@/core/client/window-store'
import { PluginAppHost } from './PluginAppHost'

const Loading = () => (
  <div className="flex h-64 w-full items-center justify-center">
    <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
  </div>
)

/** Cache tên dự án (đặt từ ProjectsPage) — hiển thị title cửa sổ 'projects:<id>' */
export const projectNameCache = new Map<string, string>()
export function setProjectName(id: string, name: string) {
  projectNameCache.set(id, name)
}

/** Cache tiêu đề động (đặt từ TextViewerPage / NoteWindow) — title 'viewer:path' / 'note:id' */
export const dynamicTitleCache = new Map<string, string>()
/** Store phiên bản tiêu đề — WindowFrame đăng ký để title cập nhật tức thì khi cache đổi */
const useTitleVersion = create<{ v: number; bump: () => void }>((set) => ({
  v: 0,
  bump: () => set((s) => ({ v: s.v + 1 })),
}))
export function setDynamicTitle(key: string, title: string) {
  dynamicTitleCache.set(key, title)
  useTitleVersion.getState().bump()
}
/** Hook nội bộ cho WindowFrame */
export function useTitleTick(): number {
  return useTitleVersion((s) => s.v)
}

/** Lazy import mọi module page — mỗi module độc lập */
export const PAGES: Record<string, React.ComponentType> = {
  dashboard: dynamic(() => import('@/modules/dashboard/pages/DashboardPage'), { loading: Loading }),
  projects: dynamic(() => import('@/modules/projects/pages/ProjectsPage'), { loading: Loading }),
  tasks: dynamic(() => import('@/modules/tasks/pages/TasksPage'), { loading: Loading }),
  calendar: dynamic(() => import('@/modules/calendar/pages/CalendarPage'), { loading: Loading }),
  weekly: dynamic(() => import('@/modules/weekly/pages/WeeklyPage'), { loading: Loading }),
  notes: dynamic(() => import('@/modules/notes/pages/NotesPage'), { loading: Loading }),
  wiki: dynamic(() => import('@/modules/wiki/pages/WikiPage'), { loading: Loading }),
  files: dynamic(() => import('@/modules/files/pages/FilesPage'), { loading: Loading }),
  timeline: dynamic(() => import('@/modules/timeline/pages/TimelinePage'), { loading: Loading }),
  activity: dynamic(() => import('@/modules/activity/pages/ActivityPage'), { loading: Loading }),
  reports: dynamic(() => import('@/modules/reports/pages/ReportsPage'), { loading: Loading }),
  notifications: dynamic(() => import('@/modules/notifications/pages/NotificationsPage'), { loading: Loading }),
  users: dynamic(() => import('@/modules/users/pages/UsersPage'), { loading: Loading }),
  settings: dynamic(() => import('@/modules/settings/pages/SettingsPage'), { loading: Loading }),
  /** Trình xem tệp (text/ảnh) — mở từ Desktop .txt/.md, Files */
  viewer: dynamic(() => import('@/modules/files/pages/TextViewerPage'), { loading: Loading }),
  /** ===== Application System V3 — Web PC ===== */
  browser: dynamic(() => import('@/apps/browser/BrowserApp'), { loading: Loading }),
  terminal: dynamic(() => import('@/apps/terminal/TerminalApp'), { loading: Loading }),
  monitor: dynamic(() => import('@/apps/monitor/MonitorApp'), { loading: Loading }),
  downloads: dynamic(() => import('@/apps/downloads/DownloadsApp'), { loading: Loading }),
  /** Document Engine — PDF/DOCX/XLSX/PPTX (route 'doc:<path>') */
  doc: dynamic(() => import('@/apps/document/DocumentApp'), { loading: Loading }),
  /** Media Player — video/audio (route 'media:<path>') */
  media: dynamic(() => import('@/apps/media/MediaPlayerApp'), { loading: Loading }),
}

/** Đánh dấu plugin-host đã đăng ký để không đăng ký lại */
type PluginHostPage = React.ComponentType & { __wos_plugin_slug?: string }

/**
 * Đăng ký app plugin vào PAGES (gọi từ Desktop khi load danh sách plugin).
 * Idempotent: chỉ đăng ký 1 lần; meta thay đổi → reset rồi đăng ký lại.
 */
export function syncPluginApps(plugins: PluginMeta[]) {
  const appPlugins = plugins.filter((p) => p.kind === 'app' && p.enabled)
  for (const p of appPlugins) {
    const existing = PAGES[p.slug] as PluginHostPage | undefined
    if (existing && existing.__wos_plugin_slug === p.slug) continue // đã đăng ký
    // chạy entry → registerApp vào registry runtime
    runPlugin(p)
    const app = getPluginApp(p.slug)
    if (app) {
      if (app.windowSize) registerWindowSize(p.slug, app.windowSize)
      else registerWindowSize(p.slug, p.windowSize)
      const host = (() => <PluginAppHost meta={p} />) as PluginHostPage
      host.__wos_plugin_slug = p.slug
      PAGES[p.slug] = host
    }
  }
  // gỡ app đã bị remove/disable
  for (const key of Object.keys(PAGES)) {
    const slug = (PAGES[key] as PluginHostPage).__wos_plugin_slug
    if (slug && !appPlugins.find((p) => p.slug === slug)) {
      delete PAGES[key]
      resetPlugin(slug)
    }
  }
}

/** Tiêu đề phụ theo route (vd Files hiện tên thư mục, Projects hiện tên dự án) */
export function windowTitleSuffix(moduleId: string, route: string, key?: string): string {
  if (moduleId === 'files' && route.startsWith('files:')) {
    try {
      const p = decodeURIComponent(route.slice(6)).replace(/\/$/, '')
      return p ? ` — ${p.split('/').pop()}` : ''
    } catch {
      return ''
    }
  }
  if (moduleId === 'projects' && route.startsWith('projects:')) {
    const id = route.slice('projects:'.length)
    return projectNameCache.get(id) ? ` — ${projectNameCache.get(id)}` : ' — Chi tiết'
  }
  if (moduleId === 'viewer' && key?.startsWith('v:')) {
    const title = dynamicTitleCache.get(key)
    if (title) return ` — ${title}`
    try {
      const p = decodeURIComponent(key.slice(2))
      return p ? ` — ${p.split('/').pop()}` : ''
    } catch {
      return ''
    }
  }
  if (moduleId === 'notes' && key?.startsWith('n:')) {
    const title = dynamicTitleCache.get(key)
    return title ? ` — ${title}` : ' — Ghi chú'
  }
  if (moduleId === 'settings' && route.startsWith('settings:')) {
    return ''
  }
  // ===== Application System V3 =====
  if (moduleId === 'doc' && route.startsWith('doc:')) {
    try {
      const p = decodeURIComponent(route.slice(4))
      return p ? ` — ${p.split('/').pop()}` : ''
    } catch {
      return ''
    }
  }
  if (moduleId === 'media' && route.startsWith('media:')) {
    try {
      const p = decodeURIComponent(route.slice(6))
      return p ? ` — ${p.split('/').pop()}` : ''
    } catch {
      return ''
    }
  }
  if (moduleId === 'browser' && route.startsWith('browser:')) {
    try {
      const u = decodeURIComponent(route.slice('browser:'.length))
      if (!u) return ''
      return ` — ${u.replace(/^https?:\/\//, '').split('/')[0].replace(/^www\./, '')}`
    } catch {
      return ''
    }
  }
  return ''
}

export function windowSizeOf(moduleId: string, key?: string) {
  const sizeKey = key && WINDOW_SIZE[`${moduleId}-detail`] ? `${moduleId}-detail` : moduleId
  return WINDOW_SIZE[sizeKey] || WINDOW_SIZE.settings
}
