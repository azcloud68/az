'use client'

/**
 * WallpaperPicker (v3) — chọn hình nền nâng cao:
 * - Presets gradient/màu + HÌNH NỀN ĐỘNG (animated CSS) + VIDEO (mp4/webm)
 * - BỘ SƯU TẬP: lưu nhiều hình nền, tự ĐỔI THEO THỜI GIAN (1m → 1 ngày, tuần tự/ngẫu nhiên)
 * - Tải ảnh/video lên (qua API upload → Wallpapers) hoặc URL
 * Lưu Setting module 'appearance': wallpaper, wallpaper_collection, wallpaper_rotation.
 */
import { useRef, useState } from 'react'
import { useWos, type WallpaperConfig, type WallpaperItem } from '@/core/client/wos-store'
import { WALLPAPER_PRESETS, ANIMATED_PRESETS, wallpaperStyle, isVideoUrl } from './wallpaper'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import {
  Check, ImagePlus, Link2, Loader2, Wallpaper as WallpaperIcon, Trash2, Plus, RefreshCw,
  Shuffle, Video as VideoIcon, Sparkles, Layers, X,
} from 'lucide-react'

const INTERVALS: { v: number; label: string }[] = [
  { v: 1, label: 'Mỗi phút' },
  { v: 5, label: '5 phút' },
  { v: 15, label: '15 phút' },
  { v: 30, label: '30 phút' },
  { v: 60, label: 'Mỗi giờ' },
  { v: 180, label: '3 giờ' },
  { v: 720, label: '12 giờ' },
  { v: 1440, label: 'Mỗi ngày' },
]

function uid(): string {
  return `wp-${Date.now().toString(36)}-${Math.floor(Math.random() * 1e4).toString(36)}`
}

export function WallpaperPicker({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { wallpaper, wallpaperCollection, wallpaperRotation, saveAppearance } = useWos()
  const { toast } = useToast()
  const [urlValue, setUrlValue] = useState('')
  const [uploading, setUploading] = useState(false)
  const [tab, setTab] = useState<'library' | 'collection'>('library')
  const fileRef = useRef<HTMLInputElement>(null)

  async function apply(wp: WallpaperConfig, close = true) {
    try {
      await saveAppearance({ wallpaper: JSON.stringify(wp) })
      toast({
        title: 'Đã đổi hình nền',
        description: wp.kind === 'default' ? 'Sonoma mặc định' : wp.kind === 'animated' ? 'Hình nền động' : '',
      })
      if (close) onClose()
    } catch (err) {
      toast({ title: 'Không lưu được hình nền', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    }
  }

  /** Thêm hình hiện tại vào bộ sưu tập */
  async function saveCurrentToCollection() {
    if (!wallpaper.value || wallpaper.kind === 'default') {
      toast({ title: 'Hình nền mặc định không cần lưu', description: 'Chọn gradient/ảnh/động rồi lưu lại.' })
      return
    }
    const item: WallpaperItem = {
      id: uid(),
      label:
        wallpaper.kind === 'image'
          ? decodeURIComponent(wallpaper.value.split('/').pop() || 'Ảnh').split('?')[0]
          : wallpaper.kind === 'animated'
            ? `Động · ${wallpaper.value}`
            : wallpaper.value.slice(0, 40),
      kind: wallpaper.kind as WallpaperItem['kind'],
      value: wallpaper.value,
    }
    if (wallpaperCollection.some((c) => c.value === item.value && c.kind === item.kind)) {
      toast({ title: 'Đã có trong bộ sưu tập' })
      return
    }
    await saveAppearance({ wallpaper_collection: JSON.stringify([...wallpaperCollection, item]) })
    toast({ title: 'Đã lưu vào bộ sưu tập', description: `${wallpaperCollection.length + 1} hình nền` })
  }

  function removeFromCollection(id: string) {
    void saveAppearance({ wallpaper_collection: JSON.stringify(wallpaperCollection.filter((c) => c.id !== id)) })
  }

  async function saveRotation(patch: Partial<typeof wallpaperRotation>) {
    const next = { ...wallpaperRotation, ...patch }
    await saveAppearance({ wallpaper_rotation: JSON.stringify(next) })
  }

  async function uploadWallpaper(file: File) {
    const isVideo = file.type.startsWith('video/')
    if (!isVideo && !file.type.startsWith('image/')) {
      toast({ title: 'Chọn tệp ảnh hoặc video (png, jpg, webp, mp4…)' })
      return
    }
    setUploading(true)
    try {
      const form = new FormData()
      form.append('files', file)
      const res = await fetch('/api/modules/files/upload?dir=Wallpapers', { method: 'POST', body: form })
      if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || `HTTP ${res.status}`)
      const data = (await res.json()) as { files?: { name?: string; path?: string }[] }
      const f = data.files?.[0]
      const rel = f?.path || `Wallpapers/${f?.name || file.name}`
      const url = `/api/modules/files/download?path=${encodeURIComponent(rel)}&inline=1`
      await apply({ kind: isVideo ? 'video' : 'image', value: url })
    } catch (err) {
      toast({ title: 'Tải lên thất bại', description: err instanceof Error ? err.message : '', variant: 'destructive' })
    } finally {
      setUploading(false)
    }
  }

  function applyUrl() {
    const url = urlValue.trim()
    if (!url) return
    const kind: WallpaperConfig['kind'] = isVideoUrl(url) ? 'video' : 'image'
    void apply({ kind, value: url })
    setUrlValue('')
  }

  function isActive(cfg: WallpaperConfig): boolean {
    return wallpaper.kind === cfg.kind && wallpaper.value === cfg.value
  }

  const isDefault = wallpaper.kind === 'default' || !wallpaper.value

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="wos-glass-strong flex max-h-[88vh] flex-col overflow-y-auto sm:max-w-[620px]">
        <DialogHeader className="flex-row items-center gap-3">
          <DialogTitle className="flex items-center gap-2">
            <WallpaperIcon className="h-4 w-4" /> Đổi hình nền Desktop
          </DialogTitle>
          <div className="ml-auto flex items-center gap-1">
            <button
              onClick={() => setTab('library')}
              className={`flex h-7 items-center gap-1.5 rounded-lg px-2.5 text-xs font-medium ${tab === 'library' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground'}`}
            >
              <Layers className="h-3.5 w-3.5" /> Thư viện
            </button>
            <button
              onClick={() => setTab('collection')}
              className={`flex h-7 items-center gap-1.5 rounded-lg px-2.5 text-xs font-medium ${tab === 'collection' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground'}`}
            >
              <RefreshCw className="h-3.5 w-3.5" /> Bộ sưu tập {wallpaperCollection.length > 0 ? `(${wallpaperCollection.length})` : ''}
            </button>
          </div>
        </DialogHeader>

        {tab === 'library' ? (
          <div className="space-y-4">
            {/* Gradient + màu */}
            <div className="grid grid-cols-3 gap-3 sm:grid-cols-4">
              {WALLPAPER_PRESETS.map((p) => {
                const cfg: WallpaperConfig =
                  p.id === 'sonoma' ? { kind: 'default', value: '' } : { kind: p.kind, value: p.value }
                const active = p.id === 'sonoma' ? isDefault : isActive(cfg)
                return (
                  <button
                    key={p.id}
                    onClick={() => apply(cfg)}
                    className="group relative overflow-hidden rounded-xl border border-border transition-all hover:scale-[1.03] hover:shadow-md"
                    aria-label={p.label}
                  >
                    <div
                      className="wos-wallpaper h-20"
                      style={p.id === 'sonoma' ? { position: 'relative' } : { ...wallpaperStyle(cfg), animation: 'none' }}
                    />
                    <span className="block bg-background/70 px-1.5 py-1 text-[10.5px] font-medium">{p.label}</span>
                    {active && (
                      <span className="absolute right-1.5 top-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-white shadow">
                        <Check className="h-3 w-3" />
                      </span>
                    )}
                  </button>
                )
              })}
            </div>

            {/* Hình nền ĐỘNG */}
            <div>
              <p className="mb-2 flex items-center gap-1.5 text-xs font-semibold text-muted-foreground">
                <Sparkles className="h-3.5 w-3.5" /> Hình nền động (animated)
              </p>
              <div className="grid grid-cols-3 gap-3 sm:grid-cols-5">
                {ANIMATED_PRESETS.map((p) => {
                  const cfg: WallpaperConfig = { kind: 'animated', value: p.id }
                  const active = isActive(cfg)
                  return (
                    <button
                      key={p.id}
                      onClick={() => apply(cfg, false)}
                      className="group relative overflow-hidden rounded-xl border border-border transition-all hover:scale-[1.03] hover:shadow-md"
                      aria-label={p.label}
                    >
                      <div
                        className="h-16"
                        style={{ background: p.value, backgroundSize: '320% 320%', animation: p.animation }}
                      />
                      <span className="block bg-background/70 px-1 py-1 text-[9.5px] font-medium leading-tight">{p.label}</span>
                      {active && (
                        <span className="absolute right-1 top-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-white shadow">
                          <Check className="h-2.5 w-2.5" />
                        </span>
                      )}
                    </button>
                  )
                })}
              </div>
            </div>

            {/* Tải lên / URL */}
            <div className="space-y-2 border-t pt-3">
              <p className="text-xs font-medium text-muted-foreground">Hình nền riêng (ảnh hoặc video)</p>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="h-9 gap-1.5" onClick={() => fileRef.current?.click()} disabled={uploading}>
                  {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <ImagePlus className="h-4 w-4" />} Tải lên
                </Button>
                <div className="relative flex-1">
                  <Link2 className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    value={urlValue}
                    onChange={(e) => setUrlValue(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && applyUrl()}
                    placeholder="Hoặc dán URL ảnh/video (.mp4, .webm…)"
                    className="h-9 pl-8"
                  />
                </div>
                <Button size="sm" className="h-9" disabled={!urlValue.trim()} onClick={applyUrl}>
                  Dùng URL
                </Button>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" className="h-8 gap-1.5" onClick={saveCurrentToCollection}>
                  <Plus className="h-3.5 w-3.5" /> Lưu hình hiện tại vào bộ sưu tập
                </Button>
                {isDefault ? null : (
                  <Button variant="ghost" size="sm" className="h-8 text-xs" onClick={() => apply({ kind: 'default', value: '' }, false)}>
                    Về mặc định
                  </Button>
                )}
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Cài đặt tự đổi */}
            <div className="wos-glass space-y-3 rounded-2xl p-4">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="flex items-center gap-1.5 text-sm font-semibold">
                    <RefreshCw className="h-4 w-4 text-primary" /> Tự đổi hình nền theo thời gian
                  </p>
                  <p className="text-xs text-muted-foreground">Đổi luân phiên giữa các hình trong bộ sưu tập</p>
                </div>
                <Switch
                  checked={wallpaperRotation.enabled}
                  onCheckedChange={(v) => saveRotation({ enabled: v, lastAt: v ? Date.now() : 0 })}
                  aria-label="Bật tự đổi hình nền"
                />
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <Select
                  value={String(wallpaperRotation.intervalMin)}
                  onValueChange={(v) => saveRotation({ intervalMin: Number(v) })}
                  disabled={!wallpaperRotation.enabled}
                >
                  <SelectTrigger className="h-9 w-[130px]"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {INTERVALS.map((i) => (
                      <SelectItem key={i.v} value={String(i.v)}>{i.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select
                  value={wallpaperRotation.order}
                  onValueChange={(v) => saveRotation({ order: v as 'sequential' | 'random' })}
                  disabled={!wallpaperRotation.enabled}
                >
                  <SelectTrigger className="h-9 w-[150px]">
                    {wallpaperRotation.order === 'random' ? <Shuffle className="h-3.5 w-3.5" /> : null}
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sequential">Tuần tự</SelectItem>
                    <SelectItem value="random">Ngẫu nhiên</SelectItem>
                  </SelectContent>
                </Select>
                <span className="text-xs text-muted-foreground">
                  {wallpaperRotation.enabled ? `Còn ${Math.max(0, Math.ceil((wallpaperRotation.intervalMin * 60000 - (Date.now() - (wallpaperRotation.lastAt || Date.now()))) / 60000))} phút nữa đổi` : 'Đang tắt'}
                </span>
              </div>
              {wallpaperRotation.enabled && wallpaperCollection.length < 2 && (
                <p className="rounded-lg bg-amber-500/10 px-3 py-2 text-xs text-amber-600 dark:text-amber-400">
                  Cần ít nhất 2 hình trong bộ sưu tập — chuyển sang tab Thư viện, chọn hình rồi bấm "Lưu hình hiện tại vào bộ sưu tập".
                </p>
              )}
            </div>

            {/* Danh sách bộ sưu tập */}
            {wallpaperCollection.length === 0 ? (
              <div className="flex flex-col items-center gap-2 rounded-2xl border border-dashed py-10 text-muted-foreground">
                <Layers className="h-8 w-8 opacity-30" />
                <p className="text-sm">Bộ sưu tập trống</p>
                <p className="max-w-xs text-center text-xs">Thêm gradient/ảnh/động từ tab Thư viện bằng nút "Lưu hình hiện tại vào bộ sưu tập"</p>
                <Button size="sm" variant="outline" className="h-8" onClick={() => setTab('library')}>Mở Thư viện</Button>
              </div>
            ) : (
              <div className="grid grid-cols-3 gap-3 sm:grid-cols-4">
                {wallpaperCollection.map((c) => (
                  <div key={c.id} className="group relative overflow-hidden rounded-xl border border-border">
                    <button
                      className="block w-full"
                      onClick={() => apply({ kind: c.kind, value: c.value }, false)}
                      aria-label={`Dùng ${c.label}`}
                    >
                      {c.kind === 'video' ? (
                        <div className="flex h-20 items-center justify-center bg-neutral-900">
                          <VideoIcon className="h-6 w-6 text-white/70" />
                        </div>
                      ) : (
                        <div
                          className="h-20"
                          style={{
                            ...(c.kind === 'animated'
                              ? { background: ANIMATED_PRESETS.find((p) => p.id === c.value)?.value || c.value, backgroundSize: '320% 320%', animation: 'wos-wp-pan 12s linear infinite' }
                              : wallpaperStyle({ kind: c.kind, value: c.value })),
                            animation: c.kind === 'animated' ? 'wos-wp-pan 12s linear infinite' : 'none',
                          }}
                        />
                      )}
                      <span className="block truncate bg-background/70 px-1.5 py-1 text-[10px] font-medium">{c.label}</span>
                    </button>
                    <Badge variant="secondary" className="absolute left-1.5 top-1.5 h-4 px-1.5 text-[8.5px] uppercase">
                      {c.kind === 'animated' ? 'động' : c.kind === 'video' ? 'video' : c.kind === 'image' ? 'ảnh' : 'màu'}
                    </Badge>
                    <button
                      onClick={() => removeFromCollection(c.id)}
                      className="absolute right-1.5 top-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-black/50 text-white opacity-0 transition-opacity group-hover:opacity-100"
                      aria-label="Xoá khỏi bộ sưu tập"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        <input
          ref={fileRef}
          type="file"
          accept="image/*,video/mp4,video/webm,video/ogg"
          className="hidden"
          onChange={(e) => {
            if (e.target.files?.[0]) void uploadWallpaper(e.target.files[0])
            e.target.value = ''
          }}
          aria-hidden
        />
      </DialogContent>
    </Dialog>
  )
}
