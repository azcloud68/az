'use client'

/**
 * WeatherEngine — Hiệu ứng thời tiết THẬT trên desktop (canvas, per-account):
 * - Chế độ AUTO: poll /api/core/weather (open-meteo) đúng vị trí đã chọn mỗi 10 phút,
 *   map weathercode + cloudcover + windspeed → hiệu ứng (nắng/mây/mưa/bão/tuyết/gió)
 *   → widget và hiệu ứng DÙNG CHUNG 1 nguồn dữ liệu, luôn khớp nhau.
 * - Chế độ thủ công: chọn hiệu ứng trực tiếp (sunny/clouds/rain/storm/snow/wind).
 * - Độ mạnh light/normal/strong. Tab ẩn → tạm dừng (visibilitychange).
 * - Canvas nằm trên wallpaper, dưới icon/pet/cửa sổ → KHÔNG chặn tương tác chuột.
 */
import { useEffect, useRef, useState } from 'react'
import { useWos, type AtmosEffect } from '@/core/client/wos-store'

interface WeatherData {
  ok: boolean
  temperature: number | null
  windspeed: number
  weathercode: number
  cloudcover: number | null
  precipitation: number
  isday: boolean
}

/** Map số liệu open-meteo → hiệu ứng hiển thị (có thể kết hợp nhiều lớp) */
function resolveAuto(d: WeatherData | null): { effect: Exclude<AtmosEffect, 'auto' | 'off'>; label: string } {
  if (!d || d.ok === false) return { effect: 'sunny', label: 'Trời quang' }
  const code = d.weathercode || 0
  const wind = d.windspeed || 0
  const cloud = d.cloudcover
  let effect: Exclude<AtmosEffect, 'auto' | 'off'> = 'sunny'
  let label = 'Trời quang'
  if (code === 0 || code === 1) {
    effect = 'sunny'
    label = code === 0 ? 'Trời quang' : 'Ít mây'
    // "ít mây" + độ phủ cao → thêm mây
    if (code === 1 && cloud !== null && cloud >= 40) {
      effect = 'clouds'
      label = 'Ít mây'
    }
  } else if (code === 2 || code === 3 || code === 45 || code === 48) {
    effect = 'clouds'
    label = code === 2 ? 'Có mây' : code === 3 ? 'Nhiều mây' : 'Sương mù'
  } else if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82)) {
    const heavy = code >= 63 || code === 65 || code >= 82 || (d.precipitation || 0) >= 4
    effect = heavy ? 'storm' : 'rain'
    label = heavy ? 'Mưa to' : 'Mưa'
  } else if ((code >= 71 && code <= 77) || code === 85 || code === 86) {
    effect = 'snow'
    label = 'Tuyết rơi'
  } else if (code >= 95) {
    effect = 'storm'
    label = 'Dông bão'
  } else {
    // phòng hờ: dùng cloudcover
    if (cloud !== null && cloud >= 70) {
      effect = 'clouds'
      label = 'Nhiều mây'
    }
  }
  // Gió mạnh → trộn hiệu ứng gió vào mọi thời tiết
  if (wind >= 35 && effect !== 'storm') label += ` · gió ${Math.round(wind)}km/h`
  return { effect, label }
}

const INTENSITY_MULT: Record<string, number> = { light: 0.55, normal: 1, strong: 1.6 }

interface Drop { x: number; y: number; l: number; v: number; w: number; o: number }
interface Flake { x: number; y: number; r: number; v: number; sway: number; phase: number; o: number }
interface Cloud { x: number; y: number; s: number; v: number; o: number; seed: number }
interface Leaf { x: number; y: number; r: number; vx: number; vy: number; rot: number; vr: number; hue: number }
interface Splash { x: number; y: number; r: number; o: number }

export function WeatherEngine() {
  const atmos = useWos((s) => s.atmosphere)
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const [autoInfo, setAutoInfo] = useState<{ label: string; temp: number | null; wind: number } | null>(null)
  // dữ liệu + cấu hình mới nhất cho vòng rAF (tránh restart engine khi re-render)
  const live = useRef({ atmos, weather: null as WeatherData | null, effect: 'sunny' as Exclude<AtmosEffect, 'auto' | 'off'> })
  live.current.atmos = atmos

  // ---- Chế độ AUTO: fetch thời tiết theo vị trí (poll 10 phút, pause khi tab ẩn) ----
  useEffect(() => {
    if (!atmos.enabled || atmos.effect !== 'auto') return
    let alive = true
    let timer: ReturnType<typeof setTimeout> | null = null

    async function fetchWeather() {
      if (document.hidden) {
        // tab ẩn → thử lại sau 1 phút
        timer = setTimeout(fetchWeather, 60_000)
        return
      }
      try {
        const res = await fetch(`/api/core/weather?lat=${atmos.lat}&lon=${atmos.lon}`)
        if (!res.ok) throw new Error(String(res.status))
        const data = (await res.json()) as WeatherData
        if (!alive) return
        live.current.weather = data
        const { effect, label } = resolveAuto(data)
        live.current.effect = effect
        setAutoInfo({ label, temp: data.temperature, wind: data.windspeed })
      } catch {
        /* giữ dữ liệu cũ */
      } finally {
        if (alive) timer = setTimeout(fetchWeather, 10 * 60_000)
      }
    }

    function onVisible() {
      if (!document.hidden) {
        if (timer) clearTimeout(timer)
        timer = setTimeout(fetchWeather, 400)
      }
    }
    document.addEventListener('visibilitychange', onVisible)
    fetchWeather()
    return () => {
      alive = false
      if (timer) clearTimeout(timer)
      document.removeEventListener('visibilitychange', onVisible)
    }
  }, [atmos.enabled, atmos.effect, atmos.lat, atmos.lon])

  // Hiệu ứng đang hiển thị (kèm nhãn góc màn hình khi auto)
  const showing = atmos.enabled && atmos.effect !== 'off' ? (atmos.effect === 'auto' ? live.current.effect : atmos.effect) : null

  // ---- Vòng render canvas ----
  useEffect(() => {
    const canvas = canvasRef.current
    if (!showing) return
    const ctx = canvas?.getContext('2d')
    if (!canvas || !ctx) return

    let raf = 0
    let running = true
    let W = window.innerWidth
    let H = window.innerHeight
    let dpr = Math.min(2, window.devicePixelRatio || 1)

    const rain: Drop[] = []
    const snow: Flake[] = []
    const clouds: Cloud[] = []
    const leaves: Leaf[] = []
    const splashes: Splash[] = []
    let windGust = 0.4
    let flash = 0
    let nextFlash = 4 + Math.random() * 6
    let t = 0

    const mult = INTENSITY_MULT[live.current.atmos.intensity] ?? 1

    function resize() {
      W = window.innerWidth
      H = window.innerHeight
      dpr = Math.min(2, window.devicePixelRatio || 1)
      if (!canvas) return
      canvas.width = Math.round(W * dpr)
      canvas.height = Math.round(H * dpr)
      canvas.style.width = `${W}px`
      canvas.style.height = `${H}px`
      ctx!.setTransform(dpr, 0, 0, dpr, 0, 0)
    }
    resize()

    const eff = showing
    const wantRain = eff === 'rain' || eff === 'storm'
    const wantSnow = eff === 'snow'
    const wantClouds = eff === 'clouds' || eff === 'storm'
    const wantSun = eff === 'sunny'
    const wantWind = eff === 'wind' || eff === 'storm'
    const wantLightning = eff === 'storm'

    const rainCount = Math.round((eff === 'storm' ? 240 : 130) * mult)
    const snowCount = Math.round(110 * mult)
    const cloudCount = Math.round((eff === 'storm' ? 7 : eff === 'clouds' ? 6 : 4) * mult)
    const leafCount = Math.round(14 * mult)

    // khởi tạo hạt
    for (let i = 0; i < rainCount; i++) {
      rain.push({ x: Math.random() * (W + 300) - 150, y: Math.random() * -H, l: 12 + Math.random() * 16, v: 720 + Math.random() * 420, w: 0.9 + Math.random() * 0.8, o: 0.25 + Math.random() * 0.35 })
    }
    for (let i = 0; i < snowCount; i++) {
      snow.push({ x: Math.random() * W, y: Math.random() * -H, r: 1.4 + Math.random() * 2.6, v: 34 + Math.random() * 46, sway: 16 + Math.random() * 26, phase: Math.random() * Math.PI * 2, o: 0.5 + Math.random() * 0.45 })
    }
    for (let i = 0; i < cloudCount; i++) {
      clouds.push({ x: Math.random() * (W + 520) - 260, y: (H * 0.04) + Math.random() * (H * (eff === 'storm' ? 0.34 : 0.42)), s: 0.55 + Math.random() * 1.05, v: (5 + Math.random() * 9) * (eff === 'storm' ? 2.6 : 1), o: 0, seed: Math.random() * 10 })
    }
    for (let i = 0; i < leafCount; i++) {
      leaves.push({ x: Math.random() * W - W * 0.3, y: Math.random() * H, r: 4 + Math.random() * 5, vx: 120 + Math.random() * 240, vy: -20 + Math.random() * 70, rot: Math.random() * Math.PI, vr: 1.2 + Math.random() * 3.4, hue: 20 + Math.random() * 60 })
    }

    let last = performance.now()

    function drawCloud(c: Cloud, alpha: number) {
      const cx = c.x
      const cy = c.y
      const s = c.s * 120
      ctx!.beginPath()
      // cụm 5 ellipse mềm như mây đùn
      const lobes: [number, number, number, number][] = [
        [0, 0, 1.0, 0.62],
        [-0.62, 0.1, 0.72, 0.44],
        [0.62, 0.08, 0.78, 0.5],
        [-0.28, -0.28, 0.66, 0.5],
        [0.3, -0.24, 0.6, 0.46],
      ]
      for (const [dx, dy, rx, ry] of lobes) {
        ctx!.ellipse(cx + dx * s, cy + dy * s, rx * s, ry * s, 0, 0, Math.PI * 2)
      }
      ctx!.fillStyle = `rgba(255,255,255,${alpha})`
      ctx!.fill()
    }

    function step(now: number) {
      if (!running) return
      const dt = Math.min(0.05, (now - last) / 1000)
      last = now
      t += dt
      ctx!.clearRect(0, 0, W, H)
      windGust = 0.5 + Math.sin(t * 0.32) * 0.28 + Math.sin(t * 1.17) * 0.12

      const cfgNow = live.current
      const effNow = cfgNow.atmos.effect === 'auto' ? live.current.effect : cfgNow.atmos.effect
      if (cfgNow.atmos.effect === 'off' || !cfgNow.atmos.enabled) {
        raf = requestAnimationFrame(step)
        return
      }

      // ============ NẮNG ============
      if (effNow === 'sunny') {
        // ánh nắng vàng phủ góc trên
        const g = ctx!.createRadialGradient(W * 0.82, H * 0.06, 40, W * 0.82, H * 0.06, Math.max(W, H) * 0.95)
        g.addColorStop(0, 'rgba(255,214,120,0.30)')
        g.addColorStop(0.35, 'rgba(255,200,90,0.10)')
        g.addColorStop(1, 'rgba(255,190,80,0)')
        ctx!.fillStyle = g
        ctx!.fillRect(0, 0, W, H)
        // các tia sáng xoay chậm
        ctx!.save()
        ctx!.translate(W * 0.82, H * 0.06)
        ctx!.rotate(t * 0.05)
        for (let i = 0; i < 9; i++) {
          const a = (i / 9) * Math.PI * 2
          const len = Math.max(W, H) * (0.5 + 0.14 * Math.sin(t * 0.7 + i))
          const grd = ctx!.createLinearGradient(0, 0, Math.cos(a) * len, Math.sin(a) * len)
          grd.addColorStop(0, 'rgba(255,232,150,0.13)')
          grd.addColorStop(1, 'rgba(255,232,150,0)')
          ctx!.strokeStyle = grd
          ctx!.lineWidth = 26 + 14 * Math.sin(t + i)
          ctx!.beginPath()
          ctx!.moveTo(0, 0)
          ctx!.lineTo(Math.cos(a) * len, Math.sin(a) * len)
          ctx!.stroke()
        }
        ctx!.restore()
        // bụi sáng lơ lửng
        ctx!.fillStyle = 'rgba(255,240,190,0.5)'
        for (let i = 0; i < 26; i++) {
          const px = ((i * 137.5) % W + Math.sin(t * 0.22 + i) * 30 + W) % W
          const py = ((i * 91.7 + t * 12) % (H * 0.8)) + H * 0.05
          const o = 0.18 + 0.32 * (0.5 + 0.5 * Math.sin(t * 1.4 + i * 1.7))
          ctx!.beginPath()
          ctx!.arc(px, py, 1.1 + (i % 3) * 0.7, 0, Math.PI * 2)
          ctx!.fillStyle = `rgba(255,240,190,${o * mult})`
          ctx!.fill()
        }
      }

      // ============ MÂY ============
      if (effNow === 'clouds' || effNow === 'storm') {
        for (const c of clouds) {
          c.x += (c.v + windGust * 14) * dt
          if (c.x - 260 * c.s > W) c.x = -260 * c.s
          const target = effNow === 'storm' ? 0.5 : 0.66
          c.o += (target * mult - c.o) * dt * 0.6
          drawCloud(c, Math.max(0, Math.min(0.8, c.o)))
        }
        if (effNow === 'storm') {
          // trời u ám hơn
          const g = ctx!.createLinearGradient(0, 0, 0, H)
          g.addColorStop(0, 'rgba(30,38,58,0.34)')
          g.addColorStop(1, 'rgba(30,38,58,0.05)')
          ctx!.fillStyle = g
          ctx!.fillRect(0, 0, W, H)
        }
      }

      // ============ MƯA ============
      if (effNow === 'rain' || effNow === 'storm') {
        const slant = effNow === 'storm' ? 2.6 + windGust * 1.5 : 0.7 + windGust * 0.5
        ctx!.lineCap = 'round'
        for (const d of rain) {
          d.y += d.v * dt
          d.x += d.v * slant * dt
          if (d.y > H + 30) {
            // bắn tí nước khi chạm "đất"
            if (Math.random() < 0.16) splashes.push({ x: d.x - slant * 10, y: H - 2 - Math.random() * 8, r: 0, o: 0.4 })
            d.y = -30 - Math.random() * 90
            d.x = Math.random() * (W + 300) - 150
          }
          ctx!.strokeStyle = `rgba(190,214,240,${d.o * mult})`
          ctx!.lineWidth = d.w
          ctx!.beginPath()
          ctx!.moveTo(d.x, d.y)
          ctx!.lineTo(d.x - d.l * slant, d.y - d.l)
          ctx!.stroke()
        }
        for (let i = splashes.length - 1; i >= 0; i--) {
          const s = splashes[i]
          s.r += 60 * dt
          s.o -= 1.6 * dt
          if (s.o <= 0) {
            splashes.splice(i, 1)
            continue
          }
          ctx!.strokeStyle = `rgba(200,222,245,${s.o})`
          ctx!.lineWidth = 1
          ctx!.beginPath()
          ctx!.ellipse(s.x, s.y, s.r, s.r * 0.34, 0, 0, Math.PI * 2)
          ctx!.stroke()
        }
      }

      // ============ TUYẾT ============
      if (effNow === 'snow') {
        for (const f of snow) {
          f.y += f.v * dt
          f.phase += dt * 1.4
          f.x += Math.sin(f.phase) * f.sway * dt + windGust * 12 * dt
          if (f.y > H + 8) {
            f.y = -8
            f.x = Math.random() * W
          }
          if (f.x > W + 8) f.x = -8
          if (f.x < -8) f.x = W + 8
          ctx!.beginPath()
          ctx!.arc(f.x, f.y, f.r, 0, Math.PI * 2)
          ctx!.fillStyle = `rgba(255,255,255,${f.o * mult})`
          ctx!.fill()
        }
      }

      // ============ GIÓ ============
      if (effNow === 'wind' || effNow === 'storm') {
        // vệt gió cong lượn ngang màn hình
        ctx!.lineCap = 'round'
        const streaks = Math.round(9 * mult)
        for (let i = 0; i < streaks; i++) {
          const prog = (t * (0.14 + (i % 4) * 0.05) + i * 0.37) % 1.4
          const y = H * (0.12 + ((i * 0.13) % 0.74)) + Math.sin(prog * Math.PI * 3 + i) * 26
          const x0 = -80 + prog * (W + 260)
          const len = 90 + 70 * Math.sin(i * 2.1 + t)
          const grd = ctx!.createLinearGradient(x0, y, x0 + len, y)
          const a = Math.sin(Math.min(1, prog / 1.4) * Math.PI) * 0.34
          grd.addColorStop(0, 'rgba(255,255,255,0)')
          grd.addColorStop(0.5, `rgba(255,255,255,${a})`)
          grd.addColorStop(1, 'rgba(255,255,255,0)')
          ctx!.strokeStyle = grd
          ctx!.lineWidth = 1.6
          ctx!.beginPath()
          ctx!.moveTo(x0, y)
          ctx!.quadraticCurveTo(x0 + len * 0.5, y - 10, x0 + len, y + 4)
          ctx!.stroke()
        }
        // lá bay
        for (const l of leaves) {
          l.x += (l.vx * (0.7 + windGust * 0.6)) * dt
          l.y += (l.vy + Math.sin(t * 2 + l.rot) * 40) * dt
          l.rot += l.vr * dt
          if (l.x > W + 30) {
            l.x = -30
            l.y = Math.random() * H
          }
          if (l.y > H + 20) l.y = -20
          if (l.y < -30) l.y = H * 0.5
          ctx!.save()
          ctx!.translate(l.x, l.y)
          ctx!.rotate(l.rot)
          ctx!.fillStyle = `hsla(${l.hue},62%,44%,0.75)`
          ctx!.beginPath()
          ctx!.ellipse(0, 0, l.r, l.r * 0.52, 0, 0, Math.PI * 2)
          ctx!.fill()
          ctx!.restore()
        }
      }

      // ============ CHỚP SÉT (bão) ============
      if (effNow === 'storm') {
        nextFlash -= dt
        if (nextFlash <= 0) {
          nextFlash = 3.5 + Math.random() * 7
          flash = 1
          // tia sét zigzag
          const sx = W * (0.15 + Math.random() * 0.7)
          let lx = sx
          let ly = 0
          ctx!.save()
          ctx!.strokeStyle = 'rgba(255,255,235,0.95)'
          ctx!.lineWidth = 2.4
          ctx!.shadowColor = 'rgba(190,215,255,0.95)'
          ctx!.shadowBlur = 18
          ctx!.beginPath()
          ctx!.moveTo(lx, ly)
          while (ly < H * 0.62) {
            lx += (Math.random() - 0.5) * 66
            ly += 26 + Math.random() * 44
            ctx!.lineTo(lx, ly)
          }
          ctx!.stroke()
          ctx!.restore()
        }
        if (flash > 0) {
          flash -= dt * 2.6
          const a = Math.max(0, flash) * 0.42
          ctx!.fillStyle = `rgba(225,235,255,${a})`
          ctx!.fillRect(0, 0, W, H)
        }
      }

      raf = requestAnimationFrame(step)
    }

    raf = requestAnimationFrame(step)

    function onResize() {
      resize()
    }
    window.addEventListener('resize', onResize)

    function onHidden() {
      if (document.hidden && running) {
        running = false
        cancelAnimationFrame(raf)
        last = performance.now()
      } else if (!document.hidden && !running) {
        running = true
        last = performance.now()
        raf = requestAnimationFrame(step)
      }
    }
    document.addEventListener('visibilitychange', onHidden)

    return () => {
      running = false
      cancelAnimationFrame(raf)
      window.removeEventListener('resize', onResize)
      document.removeEventListener('visibilitychange', onHidden)
    }
  }, [showing])

  if (!showing) return null

  return (
    <div className="pointer-events-none fixed inset-0 z-[1]" aria-hidden>
      <canvas ref={canvasRef} className="h-full w-full" />
      {/* Nhãn nguồn dữ liệu khi chế độ auto — xác nhận hiệu ứng đang theo thời tiết thật */}
      {atmos.effect === 'auto' && autoInfo && (
        <div
          className="absolute right-3 top-[46px] rounded-full bg-black/25 px-3 py-1 text-[10.5px] font-medium text-white/90 backdrop-blur-sm"
          style={{ textShadow: '0 1px 2px rgba(0,0,0,0.4)' }}
        >
          ☁︎ {autoInfo.label}
          {autoInfo.temp !== null ? ` · ${Math.round(autoInfo.temp)}°C` : ''}
          {autoInfo.wind >= 20 ? ` · gió ${Math.round(autoInfo.wind)}km/h` : ''}
          <span className="ml-1 opacity-70">— {atmos.city || 'vị trí của bạn'}</span>
        </div>
      )}
    </div>
  )
}
