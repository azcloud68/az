'use client'

/**
 * Title Cache — cache tên động cho title cửa sổ (projects:<id>, viewer:<path>, note:<id>).
 * Tách riêng khỏi app-registry để plugin-runtime import không bị vòng (circular):
 * app-registry → plugin-runtime → title-cache (một chiều).
 */
import { create } from 'zustand'

/** Cache tên dự án (đặt từ ProjectsPage — cả bản module lẫn plugin) */
export const projectNameCache = new Map<string, string>()
export function setProjectName(id: string, name: string) {
  projectNameCache.set(id, name)
}

/** Cache tiêu đề động (TextViewerPage / NoteWindow / plugin Note) */
export const dynamicTitleCache = new Map<string, string>()
/** Store phiên bản tiêu đề — WindowFrame đăng ký để title cập nhật tức thì khi cache đổi */
const useTitleVersion = create<{ v: number; bump: () => void }>((set) => ({
  v: 0,
  bump: () => set((s) => ({ v: s.v + 1 })),
}))
export function setDynamicTitle(key: string, title: string) {
  dynamicTitleCache.set(key, title)
  useTitleVersion.getState().bump()
}
/** Hook nội bộ cho WindowFrame */
export function useTitleTick(): number {
  return useTitleVersion((s) => s.v)
}
