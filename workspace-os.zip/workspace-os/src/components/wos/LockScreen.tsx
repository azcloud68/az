'use client'

/**
 * LockScreen — phủ kín desktop khi khóa (Ctrl+Shift+Z hoặc menu người dùng).
 * Mở khóa bằng mật khẩu tài khoản (POST /api/core/auth/verify — không tạo session mới).
 */
import { useEffect, useRef, useState } from 'react'
import { useWos } from '@/core/client/wos-store'
import { wallpaperStyle } from './wallpaper'
import { Loader2, Lock, ArrowRight } from 'lucide-react'

export function LockScreen() {
  const { user, wallpaper, unlock, logout } = useWos()
  const [password, setPassword] = useState('')
  const [error, setError] = useState(false)
  const [busy, setBusy] = useState(false)
  const [now, setNow] = useState(() => new Date())
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    const iv = setInterval(() => setNow(new Date()), 1000)
    return () => clearInterval(iv)
  }, [])

  useEffect(() => {
    inputRef.current?.focus()
  }, [])

  async function submit(e?: React.FormEvent) {
    e?.preventDefault()
    if (!password || busy) return
    setBusy(true)
    const ok = await unlock(password)
    setBusy(false)
    if (ok) {
      setPassword('')
      setError(false)
    } else {
      setError(true)
      setPassword('')
      inputRef.current?.focus()
    }
  }

  return (
    <div className="wos-lock" role="dialog" aria-label="Màn hình khóa">
      <div className="wos-wallpaper" style={wallpaperStyle(wallpaper)} aria-hidden />
      <div className="wos-lock-blur" aria-hidden />
      <p className="wos-lock-clock">
        {now.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}
      </p>
      <p className="wos-lock-date">
        {now.toLocaleDateString('vi-VN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
      </p>

      <div className="relative flex flex-col items-center gap-3">
        <span
          className="flex h-16 w-16 items-center justify-center rounded-full text-2xl font-bold text-white shadow-xl"
          style={{ background: user?.avatarColor || '#f97316' }}
        >
          {(user?.displayName || 'W').slice(0, 1).toUpperCase()}
        </span>
        <p className="text-[15px] font-semibold text-white drop-shadow">{user?.displayName || 'Người dùng'}</p>

        <form
          onSubmit={submit}
          className={`flex items-center gap-2 rounded-full bg-white/25 px-4 py-2 backdrop-blur-xl transition-shadow ${
            error ? 'ring-2 ring-rose-400' : 'ring-1 ring-white/40'
          }`}
        >
          <Lock className="h-4 w-4 text-white/80" />
          <input
            ref={inputRef}
            type="password"
            value={password}
            onChange={(e) => { setPassword(e.target.value); setError(false) }}
            placeholder="Nhập mật khẩu để mở khóa…"
            className="h-8 w-56 bg-transparent text-[13.5px] text-white placeholder-white/60 outline-none"
            autoComplete="current-password"
            aria-label="Mật khẩu mở khóa"
          />
          <button
            type="submit"
            disabled={busy || !password}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-white/30 text-white transition hover:bg-white/45 disabled:opacity-40"
            aria-label="Mở khóa"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowRight className="h-4 w-4" />}
          </button>
        </form>
        {error && <p className="text-[12.5px] font-medium text-rose-200">Mật khẩu không đúng, thử lại</p>}
        <p className="text-[11.5px] text-white/60">Phím tắt khóa màn hình: Ctrl + Shift + Z</p>
        <button onClick={logout} className="text-[12px] text-white/70 underline underline-offset-2 hover:text-white">
          Đăng xuất khỏi Workspace
        </button>
      </div>
    </div>
  )
}
