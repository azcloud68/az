'use client'

/**
 * UserLayout (legacy) — đã chuyển vào Desktop Manager (`src/core/client/desktop`).
 * File này giữ lại làm cầu tương thích: các import cũ vẫn hoạt động.
 * Mọi code mới hãy import từ '@/core/client/desktop'.
 */
export { useDesktopStore as useUserLayout, clearLocalLayout, type LayoutBlob } from '@/core/client/desktop'
