'use client'

/**
 * WOS Plugin Runtime — chạy mã plugin phía client.
 * Plugin = chuỗi JS (không JSX) được đánh giá qua new Function với biến `WOS` tiêm sẵn:
 *   h, Fragment, useState, useEffect, useRef, useMemo, useCallback, api, bus, toast,
 *   openApp, notify, emitEvent, clearCache, storage {get,set,remove}, css, registerApp,
 *   registerPet, plugin {slug, config}
 * - registerApp({component, windowSize?}) → app mở được từ Launchpad/Desktop/Dock (cửa sổ riêng)
 * - registerPet({component})  → nhân vật chạy trên desktop (DesktopPetLayer render)
 * Ghi chú bảo mật: plugin do ADMIN cài (tự host) — tin cậy như mã hệ thống.
 */
import { createElement as h, Fragment, useState, useEffect, useRef, useMemo, useCallback } from 'react'
import type { ComponentType } from 'react'
import { api } from '@/core/client/api'
import { bus } from '@/core/client/event-bus'
import { useWindows } from '@/core/client/window-store'
import { toast } from 'sonner'

export interface PluginMeta {
  id: string
  slug: string
  name: string
  description: string
  version: string
  author: string
  icon: string
  color: string
  kind: 'app' | 'pet'
  config: Record<string, unknown>
  enabled: boolean
  builtin: boolean
  desktopIcon: boolean
  showDock: boolean
  windowSize: { w: number; h: number }
  order: number
  entry: string
  /** CSS tự chèn (plugin .zip khai manifest.styles) */
  styles?: string
}

export interface RegisteredApp {
  slug: string
  component: ComponentType
  windowSize?: { w: number; h: number }
}

export interface RegisteredPet {
  slug: string
  component: ComponentType
}

/** Registry runtime (không persist — chạy lại khi reload) */
const apps = new Map<string, RegisteredApp>()
const pets = new Map<string, RegisteredPet>()
const failed = new Set<string>()

export function getPluginApp(slug: string): RegisteredApp | undefined {
  return apps.get(slug)
}
export function getPluginPet(slug: string): RegisteredPet | undefined {
  return pets.get(slug)
}
export function isPluginFailed(slug: string): boolean {
  return failed.has(slug)
}
/** Reset registry (plugin gỡ cài / tắt / refresh) */
export function resetPlugin(slug: string) {
  apps.delete(slug)
  pets.delete(slug)
  failed.delete(slug)
  removePluginCss(slug)
}

/** Plugin CSS cache — inject <style data-plugin="slug"> */
const cssNodes = new Map<string, HTMLStyleElement>()
export function removePluginCss(slug: string) {
  cssNodes.get(slug)?.remove()
  cssNodes.delete(slug)
}

/** Chạy 1 plugin: đánh giá entry + đăng ký component vào registry */
export function runPlugin(meta: PluginMeta): { ok: boolean; error?: string } {
  if (!meta.enabled) return { ok: false, error: 'Plugin đang tắt' }
  const already = meta.kind === 'pet' ? pets.has(meta.slug) : apps.has(meta.slug)
  if (already || failed.has(meta.slug)) return { ok: true }

  const WOS = {
    // React primitives (không JSX — plugin dùng h())
    h,
    Fragment,
    createElement: h,
    useState,
    useEffect,
    useRef,
    useMemo,
    useCallback,
    // Hệ thống
    api,
    bus,
    toast,
    openApp: (moduleId: string, opts?: { route?: string; key?: string }) =>
      useWindows.getState().openApp(moduleId, opts),
    plugin: {
      slug: meta.slug,
      name: meta.name,
      config: meta.config || {},
      version: meta.version,
    },
    /** Gửi thông báo vào Notification Center (qua API server — persist) */
    notify: async (opts: { title: string; content?: string; type?: string; action?: string }) => {
      await api('/api/core/plugins/notify', { method: 'POST', body: { slug: meta.slug, ...opts } })
      // client cũng refresh sóng notification
      bus.emit('plugin.notified', meta.slug, { title: opts.title })
    },
    /** Phát event lên server Event Bus (Timeline + Activity đọc được) + client bus */
    emitEvent: async (type: string, payload?: Record<string, unknown>) => {
      await api('/api/core/plugins/event', { method: 'POST', body: { slug: meta.slug, type, payload } })
      bus.emit(`plugin.${meta.slug}.${type}`, meta.slug, payload || {})
    },
    /** Xoá bộ nhớ đệm của plugin (localStorage prefix riêng) */
    clearCache: () => {
      const prefix = `wos_plugin_${meta.slug}`
      Object.keys(localStorage)
        .filter((k) => k.startsWith(prefix))
        .forEach((k) => localStorage.removeItem(k))
    },
    /** localStorage có prefix theo slug */
    storage: {
      get: (key: string, fallback: unknown = null) => {
        try {
          const raw = localStorage.getItem(`wos_plugin_${meta.slug}_${key}`)
          return raw === null ? fallback : JSON.parse(raw)
        } catch {
          return fallback
        }
      },
      set: (key: string, value: unknown) => {
        try {
          localStorage.setItem(`wos_plugin_${meta.slug}_${key}`, JSON.stringify(value))
        } catch {
          /* quota */
        }
      },
      remove: (key: string) => localStorage.removeItem(`wos_plugin_${meta.slug}_${key}`),
    },
    /** Inject CSS scoped — nên prefix class bằng slug để tránh xung đột */
    css: (cssText: string) => {
      if (typeof document === 'undefined') return
      let node = cssNodes.get(meta.slug)
      if (!node) {
        node = document.createElement('style')
        node.setAttribute('data-plugin', meta.slug)
        document.head.appendChild(node)
        cssNodes.set(meta.slug, node)
      }
      node.textContent = cssText
    },
    /** URL tài nguyên plugin (ảnh/css… trong pack .zip: assets/x.png) */
    assetUrl: (file: string) =>
      `/api/core/plugins/asset?slug=${encodeURIComponent(meta.slug)}&file=${encodeURIComponent(file)}`,
    /** Đăng ký app (mở được từ Launchpad/Desktop/Dock) */
    registerApp: (def: { component: ComponentType; windowSize?: { w: number; h: number } }) => {
      apps.set(meta.slug, { slug: meta.slug, component: def.component, windowSize: def.windowSize })
    },
    /** Đăng ký pet (nhân vật desktop) */
    registerPet: (def: { component: ComponentType }) => {
      pets.set(meta.slug, { slug: meta.slug, component: def.component })
    },
  }

  try {
    // CSS khai trong manifest.styles → tự chèn TRƯỚC khi chạy entry
    if (meta.styles && meta.styles.trim()) {
      WOS.css(meta.styles)
    }
    const fn = new Function('WOS', `"use strict";\n${meta.entry}`)
    fn(WOS)
    return { ok: true }
  } catch (err) {
    failed.add(meta.slug)
    console.error(`[plugin:${meta.slug}]`, err)
    toast.error(`Lỗi chạy plugin "${meta.name}"`, {
      description: err instanceof Error ? err.message : String(err),
    })
    return { ok: false, error: err instanceof Error ? err.message : String(err) }
  }
}
