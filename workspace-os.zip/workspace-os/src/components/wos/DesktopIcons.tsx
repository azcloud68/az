'use client'

/**
 * DesktopIcons — lớp icon trên desktop, render theo Desktop Manager:
 * 1. Icon APP + FILE/FOLDER dùng CHUNG một Grid Engine (ô lưới) — kéo thả
 *    snap vào ô trống gần nhất trên BẢN ĐỒ CHUNG → không bao giờ chồng chéo (review #9).
 * 2. Click 1 lần = CHỌN, double-click = MỞ (review #3) — click ngay sau khi kéo bị bỏ qua.
 * 3. Cỡ icon Small/Medium/Large theo Settings → Appearance (review #7).
 * 4. Mở tệp/thư mục qua system.openPath() — không gọi openApp trực tiếp (review #1).
 * 5. Vị trí theo TÀI KHOẢN (blob layout: appCells + fileCells).
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { useWos } from '@/core/client/wos-store'
import { useWindows } from '@/core/client/window-store'
import { AppIconTile } from './ModuleIcon'
import { ContextMenu, openCtx, type CtxItem, type CtxMenuState } from './ContextMenu'
import { api, formatBytes, timeAgo } from '@/core/client/api'
import { bus } from '@/core/client/event-bus'
import { useClipboard } from '@/core/client/clipboard'
import {
  useDesktopStore,
  system,
  gridMetrics,
  cellPos,
  cellFromPoint,
  nearestFreeCell,
  iconSizePreset,
  assignAppCells,
  assignFileCells,
} from '@/core/client/desktop'
import type { DesktopSelection } from '@/core/client/desktop'
import { useToggleDockPin } from './dock-utils'
import {
  X, FolderOpen, Download, Pencil, Trash2, Share2, Info, FilePlus2, FolderPlus, Star, AppWindow,
  RotateCcw, Puzzle, ExternalLink, Loader2, EyeOff, Layers, Plus, Pin, PinOff, Copy, Scissors,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { MENUBAR_H, DOCK_H } from '@/core/client/window-store'
import { toast } from 'sonner'

export const DESKTOP_DIR = 'Desktop'
/** cũ (v2.1): vị trí px localStorage — dùng 1 lần để nâng cấp sang blob.filePos */
const LEGACY_POS_KEY = 'wos_desktop_files_v1'

export type { DesktopSelection }

interface Entry {
  name: string
  path: string
  isDir: boolean
  size: number
  mtime: string
  mime: string
}

const TEXT_EXTS = ['txt', 'md', 'markdown', 'json', 'csv', 'xml', 'yml', 'yaml', 'log', 'sh', 'js', 'ts', 'css', 'html', 'ini', 'conf', 'env']
const IMAGE_EXTS = ['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'bmp', 'avif']

function extOf(name: string): string {
  return name.split('.').pop()?.toLowerCase() || ''
}

function fileGlyph(e: Entry): string {
  if (e.isDir) return '📁'
  const ext = extOf(e.name)
  if (IMAGE_EXTS.includes(ext)) return '🖼️'
  if (['mp4', 'webm', 'mov', 'mkv'].includes(ext)) return '🎬'
  if (['mp3', 'wav', 'ogg', 'flac'].includes(ext)) return '🎵'
  if (ext === 'pdf') return '📕'
  if (['doc', 'docx'].includes(ext)) return '📘'
  if (['xls', 'xlsx', 'csv'].includes(ext)) return '📗'
  if (['zip', 'tar', 'gz'].includes(ext)) return '🗜️'
  if (TEXT_EXTS.includes(ext)) return '📝'
  return '📄'
}

interface AppEntry {
  id: string
  name: string
  icon: string
  color: string
  isPlugin: boolean
  /** Ứng dụng web shortcut — mở trong app Browser của WOS */
  isWeb?: boolean
  url?: string
}

/** Danh sách app hiển thị trên desktop (module + plugin + web shortcut) — dùng chung 2 lớp icon */
function useDesktopApps(): AppEntry[] {
  const modules = useWos((s) => s.modules)
  const plugins = useWos((s) => s.plugins)
  const iconHidden = useWos((s) => s.iconHidden)
  const webApps = useWos((s) => s.webApps)
  return useMemo(
    () =>
      [
        ...modules
          .filter((m) => m.enabled && m.section === 'main' && m.id !== 'dashboard')
          .sort((a, b) => a.order - b.order)
          .slice(0, 12)
          .map((m) => ({ id: m.id, name: m.name, icon: m.icon, color: m.color, isPlugin: false })),
        ...plugins
          .filter((p) => p.kind === 'app' && p.enabled && p.desktopIcon)
          .map((p) => ({ id: p.slug, name: p.name, icon: p.icon, color: p.color, isPlugin: true })),
        ...webApps.map((w) => ({
          id: w.id,
          name: w.name,
          icon: w.emoji || '🌐',
          color: '#0ea5e9',
          isPlugin: false,
          isWeb: true,
          url: w.url,
        })),
      ].filter((a) => !iconHidden[a.id]), // Ẩn theo TỪNG app (per-account, Settings → Appearance)
    [modules, plugins, webApps, iconHidden],
  )
}

// =====================================================================
// APP ICONS — lưới ô snap (bản đồ ô CHUNG với file — không chồng chéo)
// =====================================================================

function DesktopAppIcons({
  apps,
  appCells,
  fileCells,
}: {
  apps: AppEntry[]
  appCells: Record<string, number>
  fileCells: Record<string, number>
}) {
  const windows = useWindows((s) => s.windows)
  const openApp = useWindows((s) => s.openApp)
  const closeModule = useWindows((s) => s.closeModule)
  const focus = useWindows((s) => s.focusWindow)
  const isAdmin = useWos((s) => s.user?.role === 'admin')
  const patchPlugin = useWos((s) => s.patchPlugin)
  const setIconHidden = useWos((s) => s.setIconHidden)
  const iconSize = useWos((s) => s.desktopIconSize)
  const blob = useDesktopStore((s) => s.blob)
  const update = useDesktopStore((s) => s.update)
  const sel = useDesktopStore((s) => s.selection)
  const setSelection = useDesktopStore((s) => s.setSelection)
  const clearSelection = useDesktopStore((s) => s.clearSelection)
  const toggleDockPin = useToggleDockPin()
  const dockPinned = useWos((s) => s.dockPinned)
  const [selected, setSelected] = useState<string | null>(null)
  const [menu, setMenu] = useState<CtxMenuState | null>(null)
  const [drag, setDrag] = useState<{ id: string; x: number; y: number } | null>(null)
  const dragRef = useRef<{ id: string; sx: number; sy: number; moved: boolean } | null>(null)
  /** thời điểm kết thúc kéo gần nhất — click ngay sau đó bị bỏ qua (review #3) */
  const lastDragEnd = useRef(0)
  const [, force] = useState(0)
  const resizeTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const selRef = useRef(sel)
  useEffect(() => {
    selRef.current = sel
  }, [sel])
  const cellsRef = useRef({ appCells, fileCells })
  useEffect(() => {
    cellsRef.current = { appCells, fileCells }
  }, [appCells, fileCells])

  const preset = iconSizePreset(iconSize)
  const btnW = preset.cellW - 14

  /** Mở app: web shortcut → Browser; còn lại → mở app tương ứng */
  const launchApp = useCallback(
    (a: AppEntry) => {
      if (a.isWeb && a.url) openApp('browser', { route: `browser:${encodeURIComponent(a.url)}` })
      else openApp(a.id)
    },
    [openApp],
  )

  // re-render khi resize (vị trí ô tính theo viewport)
  useEffect(() => {
    const onResize = () => {
      if (resizeTimer.current) clearTimeout(resizeTimer.current)
      resizeTimer.current = setTimeout(() => force((n) => n + 1), 120)
    }
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  // kéo icon app — nếu icon đang nằm trong nhóm chọn (marquee) → kéo CẢ NHÓM
  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      const d = dragRef.current
      if (!d) return
      if (Math.abs(e.clientX - d.sx) > 3 || Math.abs(e.clientY - d.sy) > 3) {
        d.moved = true
        setDrag({ id: d.id, x: e.clientX - preset.tile / 2, y: e.clientY - preset.tile / 2 })
      }
    }
    const onUp = (e: PointerEvent) => {
      const d = dragRef.current
      dragRef.current = null
      setDrag(null)
      if (!d || !d.moved) return
      lastDragEnd.current = Date.now()
      const { appCells: ac, fileCells: fc } = cellsRef.current
      const g = gridMetrics(iconSize)
      const group = selRef.current?.apps?.length
        ? selRef.current.apps.filter((id) => id !== d.id && apps.some((a) => a.id === id))
        : []
      const moveIds = [d.id, ...group]
      if (moveIds.length <= 1) {
        // kéo 1 icon — snap ô trống gần nhất trên BẢN ĐỒ CHUNG (app + file + thùng rác)
        const want = cellFromPoint(e.clientX, e.clientY, iconSize)
        const taken = new Set<number>([
          ...Object.entries(ac).filter(([id]) => id !== d.id).map(([, c]) => c),
          ...Object.values(fc),
        ])
        const final = nearestFreeCell(want, taken, g.capacity, g.rows)
        update((prev) => ({ ...prev, appCells: { ...(prev.appCells || {}), [d.id]: final } }))
        return
      }
      // kéo NHÓM: sắp các icon đã chọn vào các ô trống quanh điểm thả
      const taken = new Set<number>([
        ...Object.entries(ac).filter(([id]) => !moveIds.includes(id)).map(([, c]) => c),
        ...Object.values(fc),
      ])
      let want = cellFromPoint(e.clientX, e.clientY, iconSize)
      update((prev) => {
        const nextCells = { ...(prev.appCells || {}) }
        for (const id of moveIds) {
          const cell = nearestFreeCell(want, taken, g.capacity, g.rows)
          nextCells[id] = cell
          taken.add(cell)
          want = cell + 1 < g.capacity ? cell + 1 : cell - 1
        }
        return { ...prev, appCells: nextCells }
      })
      clearSelection()
    }
    window.addEventListener('pointermove', onMove)
    window.addEventListener('pointerup', onUp)
    return () => {
      window.removeEventListener('pointermove', onMove)
      window.removeEventListener('pointerup', onUp)
    }
  }, [apps, update, clearSelection, iconSize, preset.tile])

  function menuFor(a: AppEntry): CtxItem[] {
    const win = windows.find((w) => w.moduleId === a.id)
    const group = sel?.apps?.length ? sel.apps.filter((id) => id !== a.id) : []
    const pinned = dockPinned === null ? true : dockPinned.includes(a.id)
    const base: CtxItem[] = [
      ...(group.length > 0
        ? [
            {
              label: `Mở tất cả (${group.length + 1} ứng dụng)`,
              icon: Layers,
              onClick: () => {
                for (const id of [a.id, ...group]) openApp(id)
                clearSelection()
              },
            },
            {
              label: `Ẩn ${group.length + 1} icon này`,
              icon: EyeOff,
              onClick: () => {
                for (const id of [a.id, ...group]) void setIconHidden(id, true)
                clearSelection()
                toast.success(`Đã ẩn ${group.length + 1} icon`, { description: 'Hiện lại trong Cài đặt → Hiển thị → Icon đã ẩn' })
              },
            },
            { separator: true, label: '' },
          ]
        : []),
      { label: `Mở ${a.name}`, onClick: () => launchApp(a) },
      ...(a.isWeb && a.url
        ? [
            {
              label: 'Mở tab trình duyệt ngoài',
              icon: ExternalLink,
              onClick: () => window.open(a.url, '_blank', 'noreferrer noopener'),
            },
          ]
        : []),
      ...(win
        ? [
            { label: 'Đưa lên trước', onClick: () => focus(win.id) },
            { separator: true, label: '' },
            { label: 'Đóng cửa sổ', danger: true, icon: X, onClick: () => closeModule(a.id) },
          ]
        : []),
      { label: 'Đưa về vị trí mặc định', icon: RotateCcw, onClick: () => resetCell(a.id) },
      {
        label: pinned ? 'Bỏ ghim khỏi Dock' : 'Ghim vào Dock',
        icon: pinned ? PinOff : Pin,
        onClick: () => toggleDockPin(a.id, !pinned),
      },
      ...(a.isWeb
        ? [
            {
              label: 'Xoá shortcut khỏi desktop',
              danger: true,
              icon: Trash2,
              onClick: () => {
                void useWos.getState().removeWebApp(a.id)
                toast.success(`Đã xoá shortcut ${a.name}`)
              },
            },
          ]
        : [
            {
              label: 'Ẩn icon này',
              icon: EyeOff,
              onClick: () => {
                void setIconHidden(a.id, true)
                toast.success(`Đã ẩn icon ${a.name}`, { description: 'Hiện lại trong Cài đặt → Hiển thị → Icon đã ẩn' })
              },
            },
          ]),
    ]
    if (a.isPlugin && isAdmin) {
      base.push({ separator: true, label: '' })
      base.push({
        label: 'Tắt / mở plugin',
        icon: Puzzle,
        onClick: () => {
          const p = useWos.getState().plugins.find((x) => x.slug === a.id)
          if (p) void patchPlugin(a.id, { enabled: !p.enabled })
        },
      })
    }
    return base
  }

  function resetCell(id: string) {
    update((prev) => {
      const next = { ...(prev.appCells || {}) }
      delete next[id]
      return { ...prev, appCells: next }
    })
  }

  // Ẩn/hiện icon app theo tuỳ chọn từng tài khoản (v5)
  const hideApps = blob?.hideAppIcons === true
  if (apps.length === 0 || hideApps) return null

  return (
    <div className="absolute inset-0 z-[6] hidden select-none pointer-events-none md:block" aria-label="Icon ứng dụng trên desktop">
      {apps.map((a) => {
        const running = a.isWeb ? false : windows.some((w) => w.moduleId === a.id)
        const cell = appCells[a.id] ?? 0
        const base = cellPos(cell, iconSize)
        const dragging = drag?.id === a.id
        const pos = dragging && drag ? { x: drag.x, y: drag.y } : base
        const inGroup = !!sel?.apps?.includes(a.id)
        return (
          <button
            key={a.id}
            /* review #3: click 1 lần = CHỌN; double-click = MỞ; click sau khi kéo = bỏ qua */
            onClick={() => {
              if (Date.now() - lastDragEnd.current < 350) return
              setSelected(a.id)
            }}
            onDoubleClick={() => launchApp(a)}
            onKeyDown={(ev) => {
              if (ev.key === 'Enter') {
                ev.preventDefault()
                launchApp(a)
              }
            }}
            onPointerDown={(ev) => {
              if (ev.button !== 0) return
              ev.stopPropagation()
              // click icon ngoài nhóm chọn → bỏ chọn nhóm (như PC)
              if (!sel?.apps?.includes(a.id)) clearSelection()
              setSelected(a.id)
              dragRef.current = { id: a.id, sx: ev.clientX, sy: ev.clientY, moved: false }
            }}
            onContextMenu={(e) => {
              setSelected(a.id)
              openCtx(e, setMenu, menuFor(a))
            }}
            className={`wos-desktop-icon group absolute pointer-events-auto flex flex-col items-center gap-1 rounded-xl px-1.5 py-1.5 transition-all ${
              selected === a.id || inGroup ? 'bg-white/25 dark:bg-white/15' : 'hover:bg-white/15 dark:hover:bg-white/10'
            } ${inGroup ? 'ring-2 ring-white/70' : ''} ${dragging ? 'scale-105 opacity-90 shadow-2xl' : ''}`}
            style={{
              left: pos.x,
              top: pos.y,
              width: btnW,
              cursor: dragging ? 'grabbing' : 'default',
              transition: dragging ? 'none' : 'left .18s ease, top .18s ease',
            }}
            aria-label={`Ứng dụng ${a.name} (double-click để mở)`}
            aria-pressed={running}
            data-app={a.id}
          >
            {/* Ảnh tuỳ biến / ảnh plugin → FULL size như icon macOS; còn lại ô gradient */}
            <AppIconTile moduleId={a.id} icon={a.icon} color={a.color} size={preset.tile} className="group-hover:scale-105" />
            <span className="max-w-full truncate text-[11px] font-medium text-white drop-shadow-[0_1px_3px_rgba(0,0,0,0.8)]">
              {a.name}
            </span>
            {running ? <span className="absolute -bottom-1 h-1.5 w-1.5 rounded-full bg-white/90" aria-hidden /> : null}
          </button>
        )
      })}
      {menu ? <ContextMenu state={menu} onClose={() => setMenu(null)} /> : null}
    </div>
  )
}

// =====================================================================
// FILE ICONS — cùng Grid Engine như app: snap ô, bản đồ ô chung (review #9)
// =====================================================================

function DesktopFiles({
  entries,
  appCells,
  fileCells,
}: {
  entries: Entry[] | null
  appCells: Record<string, number>
  fileCells: Record<string, number>
}) {
  const openApp = useWindows((s) => s.openApp)
  const iconSize = useWos((s) => s.desktopIconSize)
  const blob = useDesktopStore((s) => s.blob)
  const update = useDesktopStore((s) => s.update)
  const sel = useDesktopStore((s) => s.selection)
  const setSelection = useDesktopStore((s) => s.setSelection)
  const clearSelection = useDesktopStore((s) => s.clearSelection)
  const clipboard = useClipboard()
  const [selected, setSelected] = useState<string | null>(null)
  const [menu, setMenu] = useState<CtxMenuState | null>(null)
  const [info, setInfo] = useState<Entry | null>(null)
  const [renaming, setRenaming] = useState<Entry | null>(null)
  const [renameValue, setRenameValue] = useState('')
  const [drag, setDrag] = useState<{ path: string; x: number; y: number } | null>(null)
  const dragRef = useRef<{ path: string; sx: number; sy: number; moved: boolean } | null>(null)
  /** thời điểm kết thúc kéo gần nhất — click ngay sau đó bị bỏ qua (review #3) */
  const lastDragEnd = useRef(0)
  const [, force] = useState(0)
  const resizeTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const selRef = useRef(sel)
  useEffect(() => {
    selRef.current = sel
  }, [sel])
  const cellsRef = useRef({ appCells, fileCells })
  useEffect(() => {
    cellsRef.current = { appCells, fileCells }
  }, [appCells, fileCells])

  const preset = iconSizePreset(iconSize)

  // re-render khi resize (vị trí ô tính theo viewport)
  useEffect(() => {
    const onResize = () => {
      if (resizeTimer.current) clearTimeout(resizeTimer.current)
      resizeTimer.current = setTimeout(() => force((n) => n + 1), 120)
    }
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  // nâng cấp 1 lần từ vị trí px cũ (v2.1, localStorage) → blob.filePos
  useEffect(() => {
    if (!blob || blob.filePos) return
    try {
      const legacy = JSON.parse(localStorage.getItem(LEGACY_POS_KEY) || 'null') as Record<string, { x: number; y: number }> | null
      if (legacy && Object.keys(legacy).length) {
        const vh = window.innerHeight
        const usable = Math.max(1, vh - MENUBAR_H - DOCK_H)
        const pos: Record<string, { fx: number; fy: number }> = {}
        for (const [p, v] of Object.entries(legacy)) {
          pos[p] = { fx: v.x / window.innerWidth, fy: Math.min(1, Math.max(0, (v.y - MENUBAR_H) / usable)) }
        }
        update((prev) => ({ ...prev, filePos: { ...(prev.filePos || {}), ...pos } }))
      }
    } catch {
      /* bỏ qua */
    }
  }, [blob, update])

  /** Mở tệp/thư mục qua System service (review #1) — KHÔNG gọi openApp trực tiếp */
  const openEntry = useCallback(
    (e: Entry) => {
      system.openPath(e.path, { isDir: e.isDir, mime: e.mime })
    },
    [],
  )

  // kéo file — snap vào ô trống trên BẢN ĐỒ CHUNG; kéo file trong nhóm chọn → cả nhóm
  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      const d = dragRef.current
      if (!d) return
      if (Math.abs(e.clientX - d.sx) > 3 || Math.abs(e.clientY - d.sy) > 3) {
        d.moved = true
        setDrag({ path: d.path, x: e.clientX - preset.tile / 2, y: e.clientY - preset.tile / 2 })
      }
    }
    const onUp = (e: PointerEvent) => {
      const d = dragRef.current
      dragRef.current = null
      setDrag(null)
      if (!d || !d.moved) return
      lastDragEnd.current = Date.now()
      const { appCells: ac, fileCells: fc } = cellsRef.current
      const g = gridMetrics(iconSize)
      const group = selRef.current?.files?.length ? selRef.current.files.filter((p) => p !== d.path) : []
      const movePaths = [d.path, ...group]
      const taken = new Set<number>([
        ...Object.values(ac),
        ...Object.entries(fc).filter(([p]) => !movePaths.includes(p)).map(([, c]) => c),
      ])
      let want = cellFromPoint(e.clientX, e.clientY, iconSize)
      update((prev) => {
        const nextCells = { ...(prev.fileCells || {}) }
        for (const p of movePaths) {
          const cell = nearestFreeCell(want, taken, g.capacity, g.rows)
          nextCells[p] = cell
          taken.add(cell)
          want = cell + 1 < g.capacity ? cell + 1 : cell - 1
        }
        return { ...prev, fileCells: nextCells }
      })
      if (group.length) clearSelection()
    }
    window.addEventListener('pointermove', onMove)
    window.addEventListener('pointerup', onUp)
    return () => {
      window.removeEventListener('pointermove', onMove)
      window.removeEventListener('pointerup', onUp)
    }
  }, [update, clearSelection, iconSize, preset.tile])

  async function op(opName: string, body: Record<string, unknown>, msg?: string) {
    try {
      await api(`/api/modules/files/${opName}`, { method: 'POST', body })
      if (msg) bus.emit('file.updated', 'files', { name: body.name || '' })
    } catch (err) {
      console.error('[desktop-file]', err)
    }
  }

  /** Copy/Cut vào clipboard toàn hệ thống — menu Desktop "Dán" dùng được (review #2) */
  function clipCopy(mode: 'copy' | 'cut', path: string) {
    const group = sel?.files?.length ? sel.files.filter((p) => p !== path) : []
    const paths = [path, ...group]
    if (mode === 'copy') clipboard.copyFiles(paths, DESKTOP_DIR)
    else clipboard.cutFiles(paths, DESKTOP_DIR)
    toast.success(mode === 'copy' ? `Đã sao chép ${paths.length} mục` : `Đã cắt ${paths.length} mục`, {
      description: 'Dán bằng chuột phải Desktop → Dán, hoặc trong app Files',
    })
  }

  function menuFor(e: Entry): CtxItem[] {
    const ext = extOf(e.name)
    const viewable = !e.isDir && (TEXT_EXTS.includes(ext) || IMAGE_EXTS.includes(ext) || ext === 'pdf')
    const inGroup = !!sel?.files?.includes(e.path) && (sel?.files?.length || 0) > 1
    return [
      { label: 'Mở', icon: FolderOpen, onClick: () => openEntry(e) },
      ...(viewable
        ? [{
            label: 'Mở cửa sổ riêng',
            icon: AppWindow,
            onClick: () => {
              const enc = encodeURIComponent(e.path)
              openApp('viewer', { route: `viewer:${enc}`, key: `v:${enc}` })
            },
          }]
        : []),
      {
        label: 'Mở trong Files',
        icon: ExternalLink,
        onClick: () => system.openDir(e.isDir ? e.path : DESKTOP_DIR),
      },
      { separator: true, label: '' },
      { label: 'Sao chép', icon: Copy, onClick: () => clipCopy('copy', e.path) },
      { label: 'Cắt', icon: Scissors, onClick: () => clipCopy('cut', e.path) },
      { separator: true, label: '' },
      { label: 'Tải xuống', icon: Download, disabled: e.isDir, onClick: () => window.open(`/api/modules/files/download?path=${encodeURIComponent(e.path)}`) },
      {
        label: 'Đổi tên',
        icon: Pencil,
        onClick: () => {
          setRenaming(e)
          setRenameValue(e.name)
        },
      },
      { label: 'Chia sẻ', icon: Share2, disabled: e.isDir, onClick: () => op('share', { path: e.path }) },
      { label: 'Yêu thích', icon: Star, onClick: () => op('favorite', { path: e.path, favorite: true }) },
      { separator: true, label: '' },
      { label: 'Xem thông tin', icon: Info, onClick: () => setInfo(e) },
      { label: inGroup ? `Xoá ${sel?.files?.length} mục (vào thùng rác)` : 'Xoá (vào thùng rác)', icon: Trash2, danger: true, onClick: () => {
        const paths = inGroup ? sel?.files || [e.path] : [e.path]
        for (const p of paths) void op('trash', { path: p })
        clearSelection()
      } },
    ]
  }

  return (
    <>
      {(entries || []).map((e) => {
        const cell = fileCells[e.path] ?? 0
        const base = cellPos(cell, iconSize)
        const dragging = drag?.path === e.path
        const pos = dragging && drag ? { x: drag.x, y: drag.y } : base
        const inGroup = !!sel?.files?.includes(e.path)
        return (
          <div
            key={e.path}
            className={`wos-desktop-file ${selected === e.path || inGroup ? 'selected' : ''} ${dragging ? 'opacity-90' : ''}`}
            style={{
              left: pos.x,
              top: pos.y,
              width: preset.cellW - 8,
              transition: dragging ? 'none' : 'left .18s ease, top .18s ease',
            }}
            role="button"
            tabIndex={0}
            aria-label={`${e.isDir ? 'Thư mục' : 'Tệp'} ${e.name} (double-click để mở)`}
            data-path={e.path}
            onPointerDown={(ev) => {
              if (ev.button !== 0) return
              ev.stopPropagation()
              // click file ngoài nhóm chọn → bỏ chọn nhóm (như PC)
              if (!sel?.files?.includes(e.path)) clearSelection()
              setSelected(e.path)
              dragRef.current = { path: e.path, sx: ev.clientX, sy: ev.clientY, moved: false }
            }}
            onDoubleClick={() => openEntry(e)}
            onKeyDown={(ev) => {
              if (ev.key === 'Enter') {
                ev.preventDefault()
                openEntry(e)
              }
            }}
            onContextMenu={(ev) => {
              setSelected(e.path)
              openCtx(ev, setMenu, menuFor(e))
            }}
          >
            <span
              className="leading-none drop-shadow-[0_2px_6px_rgba(0,0,0,0.45)]"
              style={{ fontSize: preset.fileGlyph }}
              aria-hidden
            >
              {fileGlyph(e)}
            </span>
            <span className="wos-desktop-file-label">{e.name}</span>
          </div>
        )
      })}

      {menu ? <ContextMenu state={menu} onClose={() => setMenu(null)} /> : null}

      {/* Dialog thông tin */}
      {info && (
        <Dialog open onOpenChange={(o) => !o && setInfo(null)}>
          <DialogContent className="wos-glass-strong sm:max-w-[360px]">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-base">
                <span className="text-xl">{fileGlyph(info)}</span> Thông tin
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-1.5 text-[13px]">
              <p className="break-all"><b>Tên:</b> {info.name}</p>
              <p className="break-all font-mono text-[11.5px] text-muted-foreground">{info.path}</p>
              <p><b>Loại:</b> {info.isDir ? 'Thư mục' : info.mime || 'Tệp'}</p>
              {!info.isDir && <p><b>Dung lượng:</b> {formatBytes(info.size)}</p>}
              <p><b>Sửa đổi:</b> {timeAgo(info.mtime)}</p>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Dialog đổi tên */}
      {renaming && (
        <Dialog open onOpenChange={(o) => !o && setRenaming(null)}>
          <DialogContent className="wos-glass-strong sm:max-w-[340px]">
            <DialogHeader><DialogTitle>Đổi tên</DialogTitle></DialogHeader>
            <input
              value={renameValue}
              onChange={(e) => setRenameValue(e.target.value)}
              autoFocus
              className="h-9 w-full rounded-lg border border-input bg-transparent px-3 text-sm outline-none focus:ring-2 focus:ring-ring"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && renameValue.trim() && renameValue !== renaming.name) {
                  void op('rename', { path: renaming.path, name: renameValue.trim() })
                  setRenaming(null)
                }
              }}
            />
            <div className="flex justify-end gap-2">
              <Button variant="outline" size="sm" onClick={() => setRenaming(null)}>Huỷ</Button>
              <Button
                size="sm"
                disabled={!renameValue.trim() || renameValue === renaming.name}
                onClick={() => {
                  void op('rename', { path: renaming.path, name: renameValue.trim() })
                  setRenaming(null)
                }}
              >
                Lưu
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </>
  )
}

// =====================================================================
// THÙNG RÁC — icon góc phải-dưới (ô được giữ riêng trên bản đồ lưới)
// =====================================================================

function DesktopTrash() {
  const [count, setCount] = useState<number | null>(null)
  const [menu, setMenu] = useState<CtxMenuState | null>(null)
  const [confirmEmpty, setConfirmEmpty] = useState(false)
  const [emptying, setEmptying] = useState(false)

  const load = useCallback(async () => {
    try {
      const data = await api<{ trash: unknown[] }>('/api/modules/files/trash')
      setCount(data.trash?.length ?? 0)
    } catch {
      setCount(0)
    }
  }, [])

  useEffect(() => {
    load()
    const off = bus.onAny((ev) => {
      if (ev.module === 'files') load()
    })
    const t = setInterval(load, 60000)
    return () => {
      off()
      clearInterval(t)
    }
  }, [load])

  async function empty() {
    setEmptying(true)
    try {
      await api('/api/modules/files/empty-trash', { method: 'POST', body: {} })
      bus.emit('file.deleted', 'files', { name: 'empty-trash' })
      toast.success('Đã dọn sạch thùng rác')
    } catch (err) {
      toast.error('Không dọn được thùng rác', { description: err instanceof Error ? err.message : '' })
    } finally {
      setEmptying(false)
      setConfirmEmpty(false)
      await load()
    }
  }

  const items: CtxItem[] = [
    { label: 'Mở thùng rác', icon: FolderOpen, onClick: () => system.openTrash() },
    { label: 'Xoá ngay (không qua thùng)', danger: true, icon: Trash2, onClick: () => setConfirmEmpty(true) },
  ]

  return (
    <div
      className="absolute z-[6] hidden select-none md:block"
      style={{ right: 18, bottom: DOCK_H + 16 }}
      aria-label="Thùng rác"
      data-trash="1"
    >
      <button
        onClick={() => system.openTrash()}
        onDoubleClick={() => system.openTrash()}
        onPointerDown={(e) => e.stopPropagation()}
        onContextMenu={(e) => {
          e.preventDefault()
          e.stopPropagation()
          openCtx(e, setMenu, items)
        }}
        className="wos-desktop-file group pointer-events-auto flex w-[84px] flex-col items-center gap-1 rounded-xl px-1.5 py-1.5 transition-all hover:bg-white/15"
        title="Thùng rác — double-click để mở"
      >
        <span className="relative">
          <span
            className="flex h-12 w-12 items-center justify-center rounded-[26%] text-white shadow-lg transition-transform group-hover:scale-105"
            style={{
              background: count && count > 0
                ? 'linear-gradient(145deg, #c9a35c, #a67c3d)'
                : 'linear-gradient(145deg, #b6bcc7, #8b93a1)',
              boxShadow: '0 5px 14px rgba(0,0,0,0.35), inset 0 1px 1px rgba(255,255,255,0.45)',
            }}
          >
            <Trash2 className="h-6 w-6" strokeWidth={1.8} />
          </span>
          {count !== null && count > 0 ? (
            <span
              className="absolute -right-1.5 -top-1.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-rose-500 px-1 text-[10px] font-bold text-white shadow"
              aria-label={`${count} mục trong thùng rác`}
            >
              {count > 99 ? '99+' : count}
            </span>
          ) : null}
        </span>
        <span className="max-w-full truncate text-[11px] font-medium text-white drop-shadow-[0_1px_3px_rgba(0,0,0,0.8)]">
          Thùng rác
        </span>
      </button>

      {menu ? <ContextMenu state={menu} onClose={() => setMenu(null)} /> : null}

      {confirmEmpty && (
        <Dialog open onOpenChange={(o) => !o && setConfirmEmpty(false)}>
          <DialogContent className="wos-glass-strong sm:max-w-[340px]">
            <DialogHeader><DialogTitle>Dọn sạch thùng rác?</DialogTitle></DialogHeader>
            <p className="text-sm text-muted-foreground">
              {count !== null ? `${count} mục sẽ bị xoá vĩnh viễn.` : 'Mọi mục trong thùng rác sẽ bị xoá vĩnh viễn.'}
            </p>
            <div className="flex justify-end gap-2">
              <Button variant="outline" size="sm" onClick={() => setConfirmEmpty(false)}>Huỷ</Button>
              <Button variant="destructive" size="sm" disabled={emptying} onClick={() => void empty()}>
                {emptying ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : null} Dọn sạch
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}

/**
 * Export chính — đọc trạng thái từ Desktop Manager store (không còn prop drilling):
 * app icons + thùng rác + file desktop, tất cả dùng chung một bản đồ ô lưới.
 */
export function DesktopIcons() {
  const canFiles = useWos((s) => s.user?.role === 'admin' || (s.user?.permissions?.allowFiles !== false && (!Array.isArray(s.user?.permissions?.modules) || s.user.permissions.modules.includes('files'))))
  const blob = useDesktopStore((s) => s.blob)
  const iconSize = useWos((s) => s.desktopIconSize)
  const apps = useDesktopApps()
  const [entries, setEntries] = useState<Entry[] | null>(null)

  // Danh sách tệp trong thư mục Desktop (làm 1 lần ở cha — 2 lớp icon dùng chung)
  const load = useCallback(async () => {
    try {
      await api('/api/modules/files/mkdir', { method: 'POST', body: { path: '', name: DESKTOP_DIR } }).catch(() => {})
      const data = await api<{ entries: Entry[] }>(`/api/modules/files/list?dir=${DESKTOP_DIR}`)
      setEntries(data.entries || [])
    } catch {
      setEntries([])
    }
  }, [])

  useEffect(() => {
    load()
    return bus.onAny((ev) => {
      if (ev.module === 'files') load()
    })
  }, [load])

  // BẢN ĐỒ Ô CHUNG: app gán trước (cột phải→trái), file gán sau (né ô app + thùng rác)
  // File mặc định xếp THEO TÊN (thư mục trước) — hành vi "Sắp xếp icon" của macOS
  const { appCells, fileCells } = useMemo(
    () => {
      const ac = assignAppCells(apps.map((a) => a.id), blob, iconSize)
      const sorted = [...(entries || [])].sort((a, b) => {
        if (a.isDir !== b.isDir) return a.isDir ? -1 : 1
        return a.name.localeCompare(b.name, 'vi')
      })
      const fc = assignFileCells(sorted.map((e) => e.path), blob, ac, iconSize)
      return { appCells: ac, fileCells: fc }
    },
    [apps, entries, blob, iconSize],
  )

  // v6.1: "Ẩn toàn bộ icon" (Settings → Appearance → Icon trên Desktop = "Ẩn tất cả")
  // → KHÔNG render lớp icon nào (app + file + thùng rác) — như Hide icons của macOS.
  // Kéo-thả upload vào desktop vẫn hoạt động (tầng drop nằm ở Desktop.tsx, không phải đây).
  if (blob?.hideAllIcons === true) return null

  return (
    <>
      <DesktopAppIcons apps={apps} appCells={appCells} fileCells={fileCells} />
      {/* File manager bị khoá cho tài khoản này → ẩn cả file desktop + thùng rác */}
      {canFiles ? (
        <>
          <DesktopTrash />
          <DesktopFiles entries={entries} appCells={appCells} fileCells={fileCells} />
        </>
      ) : null}
    </>
  )
}

export { FolderPlus, FilePlus2 }

// =====================================================================
// WEB APP LAUNCHER V3 — dialog thêm ứng dụng web lên desktop
// (mở từ menu Desktop "Tạo mới → Ứng dụng web…" hoặc Settings → Appearance)
// =====================================================================

const WEB_EMOJIS = ['🌐', '📧', '📂', '▶', '🤖', '✦', '💬', '🗺', '📰', '🎵', '🎬', '⚙', '🔗', '📈', '✍', '🐙']
const WEB_SUGGESTIONS: { name: string; url: string; emoji: string }[] = [
  { name: 'Gmail', url: 'https://mail.google.com', emoji: '📧' },
  { name: 'Google Drive', url: 'https://drive.google.com', emoji: '📂' },
  { name: 'YouTube', url: 'https://www.youtube.com', emoji: '▶' },
  { name: 'ChatGPT', url: 'https://chat.openai.com', emoji: '🤖' },
  { name: 'Claude', url: 'https://claude.ai', emoji: '✦' },
  { name: 'GitHub', url: 'https://github.com', emoji: '🐙' },
  { name: 'Wikipedia', url: 'https://vi.wikipedia.org', emoji: '🌐' },
  { name: 'Google Maps', url: 'https://maps.google.com', emoji: '🗺' },
]

/** Dialog "Thêm ứng dụng web…" — chọn từ catalog gợi ý hoặc tự nhập tên/URL/emoji */
export function WebAppAddDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const addWebApp = useWos((s) => s.addWebApp)
  const webApps = useWos((s) => s.webApps)
  const [name, setName] = useState('')
  const [url, setUrl] = useState('')
  const [emoji, setEmoji] = useState('🌐')
  const [saving, setSaving] = useState(false)

  const submit = async () => {
    let u = url.trim()
    if (!u) return
    if (!/^https?:\/\//i.test(u)) u = `https://${u}`
    let valid = false
    try {
      new URL(u)
      valid = true
    } catch {
      valid = false
    }
    if (!valid) return
    setSaving(true)
    try {
      await addWebApp({ name: name.trim() || u.replace(/^https?:\/\//, '').split('/')[0], url: u, emoji })
      onClose()
      setName('')
      setUrl('')
      setEmoji('🌐')
    } finally {
      setSaving(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="wos-glass-strong max-w-md rounded-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <span className="text-lg">🌐</span> Thêm ứng dụng web lên Desktop
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          {/* Gợi ý nhanh */}
          <div>
            <p className="mb-2 text-[12px] font-medium text-muted-foreground">Gợi ý nhanh</p>
            <div className="flex flex-wrap gap-1.5">
              {WEB_SUGGESTIONS.map((s) => (
                <button
                  key={s.url}
                  className="flex items-center gap-1.5 rounded-full border bg-card px-2.5 py-1 text-[12px] transition hover:bg-accent disabled:opacity-40"
                  disabled={webApps.some((w) => w.url === s.url)}
                  onClick={() => {
                    setName(s.name)
                    setUrl(s.url)
                    setEmoji(s.emoji)
                  }}
                >
                  <span>{s.emoji}</span>
                  {s.name}
                </button>
              ))}
            </div>
          </div>

          {/* Nhập tay */}
          <div className="space-y-2.5">
            <div className="flex items-center gap-2">
              <button
                className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border bg-card text-xl transition hover:bg-accent"
                onClick={() => {
                  const i = WEB_EMOJIS.indexOf(emoji)
                  setEmoji(WEB_EMOJIS[(i + 1) % WEB_EMOJIS.length])
                }}
                title="Đổi icon"
              >
                {emoji}
              </button>
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Tên hiển thị (vd Gmail)"
                className="h-11 flex-1"
                maxLength={40}
              />
            </div>
            <div className="flex gap-1.5">
              {WEB_EMOJIS.slice(0, 10).map((e) => (
                <button
                  key={e}
                  className={`flex h-8 w-8 items-center justify-center rounded-lg text-[16px] transition hover:bg-accent ${emoji === e ? 'bg-accent ring-1 ring-primary' : ''}`}
                  onClick={() => setEmoji(e)}
                >
                  {e}
                </button>
              ))}
            </div>
            <Input
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://… (địa chỉ web)"
              className="h-11"
              inputMode="url"
            />
          </div>

          <div className="flex justify-end gap-2 pt-1">
            <Button variant="ghost" onClick={onClose}>
              Huỷ
            </Button>
            <Button onClick={() => void submit()} disabled={!url.trim() || saving} className="gap-1.5">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
              Thêm lên Desktop
            </Button>
          </div>
          <p className="text-[11px] leading-relaxed text-muted-foreground">
            Icon mở trong app <b>Trình duyệt</b> của WOS. Lưu theo tài khoản — chỉ bạn thấy.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  )
}


