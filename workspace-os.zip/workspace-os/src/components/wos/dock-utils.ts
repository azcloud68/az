'use client'

/**
 * Dock utilities — dữ liệu ứng viên Dock + thao tác ghim/bỏ ghim.
 * Dock Manager: `dockPinned` (per-account, lưu trong appearance settings)
 * giữ DANH SÁCH THỨ TỰ app ghim; null = mặc định tự động theo module.
 *
 * v6.3 (request user): ứng viên Dock = MỌI app đang bật — module lẫn plugin,
 * KHÔNG phụ thuộc cờ showDock (cờ đó chỉ quyết định danh sách MẶC ĐỊNH).
 * Người dùng được tuỳ ý thêm/bớt TẤT CẢ app vào Dock.
 */
import { useCallback, useMemo } from 'react'
import { useWos } from '@/core/client/wos-store'

export interface DockApp {
  id: string
  name: string
  icon: string
  color: string
  order: number
  /** có trong danh sách Dock MẶC ĐỰNG hay không (cờ showDock) */
  defaultDock: boolean
  /** app plugin cài thêm (hiện badge trong dialog tuỳ chỉnh) */
  isPlugin: boolean
}

/** Danh sách app CÓ THỂ ghim vào Dock (mọi module + plugin app đang bật) */
export function useDockCandidates(): DockApp[] {
  const modules = useWos((s) => s.modules)
  const plugins = useWos((s) => s.plugins)
  return useMemo(
    () => [
      ...modules
        .filter((m) => m.enabled)
        .sort((a, b) => a.order - b.order)
        .map((m) => ({
          id: m.id,
          name: m.name,
          icon: m.icon,
          color: m.color,
          order: m.order,
          defaultDock: m.showDock,
          isPlugin: false,
        })),
      ...plugins
        .filter((p) => p.enabled && p.kind === 'app')
        .map((p) => ({
          id: p.slug,
          name: p.name,
          icon: p.icon,
          color: p.color,
          order: 100 + p.order,
          defaultDock: p.showDock,
          isPlugin: true,
        })),
    ],
    [modules, plugins],
  )
}

/** Danh sách ghim MẶC ĐỊNH (dockPinned === null) — chỉ app có cờ showDock */
export function useDockDefaultIds(): string[] {
  const candidates = useDockCandidates()
  return useMemo(() => candidates.filter((c) => c.defaultDock).map((c) => c.id), [candidates])
}

/**
 * Ghim / bỏ ghim 1 app khỏi Dock (dùng ở Desktop icon menu + Dock menu + Launchpad).
 * Lần ghim ĐẦU TIÊN khi dockPinned === null: lấy danh sách mặc định làm nền
 * rồi thêm/bớt app — giữ nguyên trải nghiệm cũ cho người dùng chưa tuỳ biến.
 */
export function useToggleDockPin(): (id: string, pinned: boolean) => void {
  const candidates = useDockCandidates()
  const dockPinned = useWos((s) => s.dockPinned)
  const saveDockPinned = useWos((s) => s.saveDockPinned)
  return useCallback(
    (id: string, pinned: boolean) => {
      const base =
        dockPinned ??
        candidates.filter((c) => c.defaultDock).map((c) => c.id)
      if (!pinned && !base.includes(id)) return
      const next = pinned
        ? base.includes(id)
          ? base
          : [...base, id]
        : base.filter((x) => x !== id)
      void saveDockPinned(next)
    },
    [candidates, dockPinned, saveDockPinned],
  )
}
