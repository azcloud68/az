'use client'

/**
 * WindowFrame — cửa sổ kiểu macOS: traffic lights (đóng/thu nhỏ/phóng to),
 * kéo theo titlebar, resize góc phải-dưới, double-click maximize, focus z-order.
 * V2: SNAP — kéo sát biên trái/phải = 50%, lên đỉnh = maximize, 4 góc = 1/4 màn hình
 * (hiện overlay preview mờ trong lúc kéo); kéo cửa sổ maximized/snapped → thoát khỏi
 * vùng và về kích thước cũ như macOS. Nội dung trang được bọc RouteProvider.
 */
import { useCallback, useEffect, useRef, useState } from 'react'
import {
  useWindows,
  useSnapPreview,
  detectSnapZone,
  snapGeometry,
  type WosWindow,
  type SnapZone,
  MENUBAR_H,
} from '@/core/client/window-store'
import { useWos } from '@/core/client/wos-store'
import { RouteProvider } from '@/core/client/route-context'
import { PAGES, windowTitleSuffix, useTitleTick } from './app-registry'
import { AppIcon } from './ModuleIcon'
import { useIsMobile } from '@/hooks/use-mobile'

interface DragInfo {
  mode: 'move' | 'resize'
  sx: number
  sy: number
  x: number
  y: number
  w: number
  h: number
  /** vùng snap đang hover (chỉ mode move) */
  snap: SnapZone | null
}

/** App hệ thống V3 tự vẽ kín cửa sổ (không padding trang) */
const FULL_BLEED_APPS = new Set(['terminal', 'browser', 'doc', 'media', 'monitor', 'downloads'])

export function WindowFrame({ win }: { win: WosWindow }) {
  const close = useWindows((s) => s.closeWindow)
  const focus = useWindows((s) => s.focusWindow)
  const toggleMin = useWindows((s) => s.toggleMinimize)
  const toggleMax = useWindows((s) => s.toggleMaximize)
  const zTop = useWindows((s) => s.zTop)
  const module_ = useWos((s) => s.modules.find((m) => m.id === win.moduleId))
  const plugin_ = useWos((s) => s.plugins.find((p) => p.slug === win.moduleId))
  const iconColor = useWos((s) => s.iconColors[win.moduleId])
  const wosNavigate = useWos((s) => s.navigate)
  /** Review #4: vị trí nút cửa sổ (macOS trái / Windows phải) — Settings → Appearance */
  const windowControls = useWos((s) => s.windowControls)
  const isMobile = useIsMobile()
  const dragRef = useRef<DragInfo | null>(null)
  /** đang kéo cửa sổ (titlebar) — đổi con trỏ grab → grabbing như PC thật (v6.3) */
  const [dragging, setDragging] = useState(false)

  const Page = PAGES[win.moduleId]
  /** App plugin → trang full-bleed (không padding), marker __wos_plugin_slug */
  const isPluginPage = Boolean(
    (PAGES[win.moduleId] as { __wos_plugin_slug?: string } | undefined)?.__wos_plugin_slug,
  )
  const isFullBleed = isPluginPage || FULL_BLEED_APPS.has(win.moduleId)
  const focused = !win.minimized && win.z === zTop
  const appName = module_?.name || plugin_?.name || win.moduleId
  const appIcon = module_?.icon || plugin_?.icon || 'box'
  const appColor = iconColor || module_?.color || plugin_?.color || '#8b5cf6'
  useTitleTick() // title động (viewer/note) cập nhật khi setDynamicTitle bump
  const title = appName + windowTitleSuffix(win.moduleId, win.route, win.key)

  // Gắn listener toàn cục 1 lần — move/size đọc store trực tiếp (không stale)
  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      const d = dragRef.current
      if (!d) return
      const { moveWindow, sizeWindow } = useWindows.getState()
      if (d.mode === 'move') {
        const x = Math.max(-d.w + 140, Math.min(window.innerWidth - 80, e.clientX - (d.sx - d.x)))
        const y = Math.max(MENUBAR_H, Math.min(window.innerHeight - 60, e.clientY - (d.sy - d.y)))
        moveWindow(win.id, x, y)
        // V2: dò vùng snap theo con trỏ → hiện overlay preview
        if (!isMobile) {
          const zone = detectSnapZone(e.clientX, e.clientY)
          if (zone !== d.snap) {
            d.snap = zone
            useSnapPreview.getState().setZone(zone)
          }
        }
      } else {
        sizeWindow(win.id, Math.max(360, d.w + (e.clientX - d.sx)), Math.max(260, d.h + (e.clientY - d.sy)))
      }
    }
    const onUp = () => {
      const d = dragRef.current
      if (d?.mode === 'move' && d.snap) {
        // thả chuột trên vùng snap → áp dụng hình học vùng đó
        useWindows.getState().snapWindow(win.id, d.snap)
      }
      if (d) d.snap = null
      dragRef.current = null
      setDragging(false)
      useSnapPreview.getState().setZone(null)
    }
    window.addEventListener('pointermove', onMove)
    window.addEventListener('pointerup', onUp)
    return () => {
      window.removeEventListener('pointermove', onMove)
      window.removeEventListener('pointerup', onUp)
    }
  }, [win.id, isMobile])

  const startDrag = (mode: 'move' | 'resize') => (e: React.PointerEvent) => {
    if (isMobile) return
    focus(win.id)
    if (mode === 'move') setDragging(true)
    // Kéo titlebar của cửa sổ maximized/snapped → thoát vùng: phục hồi kích thước cũ,
    // đặt cửa sổ dưới con trỏ (như macOS) rồi kéo bình thường
    if (mode === 'move' && (win.maximized || win.snapped)) {
      const prev = win.prev || { x: win.x, y: win.y, w: Math.round(win.w * 0.6), h: Math.round(win.h * 0.6) }
      const nx = Math.max(8, Math.round(e.clientX - prev.w / 2))
      const ny = Math.max(MENUBAR_H + 4, Math.round(e.clientY - 24))
      const { moveWindow, sizeWindow, unsnapWindow } = useWindows.getState()
      unsnapWindow(win.id)
      moveWindow(win.id, nx, ny)
      sizeWindow(win.id, prev.w, prev.h)
      dragRef.current = { mode, sx: e.clientX, sy: e.clientY, x: nx, y: ny, w: prev.w, h: prev.h, snap: null }
      return
    }
    dragRef.current = { mode, sx: e.clientX, sy: e.clientY, x: win.x, y: win.y, w: win.w, h: win.h, snap: null }
  }

  /** Route cục bộ: cùng module → set cửa sổ; khác module → mở app khác */
  const navigateLocal = useCallback(
    (r: string) => {
      const targetModule = r.split(':')[0]
      if (targetModule === win.moduleId) {
        useWindows.getState().setRoute(win.id, r)
      } else {
        wosNavigate(r)
      }
    },
    [win.id, win.moduleId, wosNavigate],
  )

  if (win.minimized) return null

  return (
    <section
      className={`wos-window wos-pop ${focused ? 'wos-window-focused' : 'wos-window-blur'} ${
        isMobile ? 'wos-window-mobile' : ''
      } ${windowControls === 'right' ? 'wos-window-ctl-right' : ''}`}
      style={{ left: win.x, top: win.y, width: win.w, height: win.h, zIndex: win.z }}
      onPointerDown={() => focus(win.id)}
      role="dialog"
      aria-label={title}
      data-module={win.moduleId}
    >
      {/* Titlebar — nút điều khiển TRÁI (macOS) hoặc PHẢI (Windows) theo Settings */}
      <header
        className="flex h-10 shrink-0 select-none items-center gap-2 border-b border-black/[0.06] px-3.5 dark:border-white/[0.06]"
        onPointerDown={(e) => {
          e.stopPropagation() // kéo titlebar không lan xuống nền desktop (review #3)
          if (win.maximized) return
          startDrag('move')(e)
        }}
        onDoubleClick={() => toggleMax(win.id)}
        /* v6.3: con trỏ báo rõ cửa sổ kéo được — grab khi rê, grabbing khi đang kéo
           (trước đây luôn 'default' → người dùng không biết titlebar kéo được) */
        style={{ cursor: isMobile || win.maximized ? 'default' : dragging ? 'grabbing' : 'grab' }}
      >
        <div className="wos-tls flex items-center gap-2">
          <button onClick={() => close(win.id)} className="wos-tl wos-tl-red" aria-label="Đóng cửa sổ" title="Đóng">
            <span className="wos-tl-glyph">×</span>
          </button>
          <button
            onClick={() => toggleMin(win.id)}
            className="wos-tl wos-tl-yellow"
            aria-label="Thu nhỏ"
            title="Thu nhỏ"
          >
            <span className="wos-tl-glyph">–</span>
          </button>
          <button
            onClick={() => toggleMax(win.id)}
            className="wos-tl wos-tl-green"
            aria-label="Phóng to / thu nhỏ về"
            title="Phóng to"
          >
            <span className="wos-tl-glyph">⤢</span>
          </button>
        </div>
        <div className="pointer-events-none absolute left-1/2 flex -translate-x-1/2 items-center gap-1.5 text-[13px] font-semibold text-foreground/70">
          <span
            className="flex h-4.5 w-4.5 items-center justify-center rounded text-white"
            style={{ background: appColor, width: 18, height: 18 }}
          >
            <AppIcon moduleId={win.moduleId} icon={appIcon} px={13} className="h-3 w-3" />
          </span>
          <span className="max-w-[420px] truncate">{title}</span>
        </div>
      </header>

      {/* Nội dung — trang module, có route riêng của cửa sổ.
          flex + min-h-full cho phép trang "full-frame" (TextViewer, NoteWindow) fill hết cửa sổ.
          APP PLUGIN: không padding (full-bleed) — plugin tự vẽ kín cửa sổ (vd máy tính macOS). */}
      <div className="wos-scroll relative min-h-0 flex-1 overflow-y-auto">
        {Page ? (
          <RouteProvider route={win.route} navigate={navigateLocal} seq={win.routeSeq || 0}>
            {isFullBleed ? (
              <div className="wos-page h-full w-full">
                <Page />
              </div>
            ) : (
              <div className="wos-page mx-auto flex min-h-full w-full flex-col p-4 md:p-5">
                <Page />
              </div>
            )}
          </RouteProvider>
        ) : (
          <div className="flex h-64 flex-col items-center justify-center gap-3 text-muted-foreground">
            <p className="text-4xl">🧩</p>
            <p className="font-medium">Module không tồn tại hoặc đã bị tắt</p>
          </div>
        )}
      </div>

      {/* Resize handle */}
      {!win.maximized && !isMobile ? (
        <div
          onPointerDown={(e) => {
            e.stopPropagation()
            startDrag('resize')(e)
          }}
          className="absolute bottom-0 right-0 h-4.5 w-4.5 cursor-nwse-resize"
          aria-hidden
          style={{
            background:
              'linear-gradient(135deg, transparent 50%, oklch(0.5 0 0 / 18%) 50%)',
            width: 18,
            height: 18,
          }}
        />
      ) : null}
    </section>
  )
}

/** Overlay preview vùng snap — Desktop render 1 lần, hiện khi đang kéo cửa sổ */
export function SnapOverlay() {
  const zone = useSnapPreview((s) => s.zone)
  if (!zone || typeof window === 'undefined') return null
  const geo = snapGeometry(zone)
  return (
    <div
      aria-hidden
      className="pointer-events-none fixed z-[43] rounded-xl border-2 border-white/40 bg-white/25 backdrop-blur-[2px] transition-all duration-150 dark:border-white/30 dark:bg-white/10"
      style={{ left: geo.x, top: geo.y, width: geo.w, height: geo.h }}
    />
  )
}
