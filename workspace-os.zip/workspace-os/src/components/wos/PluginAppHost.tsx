'use client'

/**
 * PluginHost — render component plugin bên trong cửa sổ app (WindowFrame).
 * Bọc lỗi: plugin crash → hiển thị panel lỗi macOS thay vì phá cả cửa sổ.
 */
import { useEffect, useState } from 'react'
import { runPlugin, getPluginApp, isPluginFailed } from './plugin-runtime'
import type { PluginMeta } from './plugin-runtime'
import { Loader2, Puzzle, TriangleAlert } from 'lucide-react'

export function PluginAppHost({ meta }: { meta: PluginMeta }) {
  const [state, setState] = useState<'loading' | 'ready' | 'error' | 'empty'>('loading')
  const [error, setError] = useState('')

  useEffect(() => {
    setState('loading')
    const r = runPlugin(meta)
    if (isPluginFailed(meta.slug)) {
      setError(r.error || 'Không chạy được plugin')
      setState('error')
      return
    }
    if (getPluginApp(meta.slug)) {
      setState('ready')
    } else {
      setState('empty') // plugin không gọi registerApp
    }
  }, [meta])

  const app = getPluginApp(meta.slug)

  if (state === 'loading') {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    )
  }
  if (state === 'error') {
    return (
      <div className="flex h-64 flex-col items-center justify-center gap-3 text-muted-foreground">
        <TriangleAlert className="h-10 w-10 text-amber-500" />
        <p className="font-medium">Plugin lỗi</p>
        <p className="max-w-sm break-all text-center text-xs">{error}</p>
      </div>
    )
  }
  if (state === 'empty' || !app) {
    return (
      <div className="flex h-64 flex-col items-center justify-center gap-3 text-muted-foreground">
        <Puzzle className="h-10 w-10 opacity-40" />
        <p className="text-sm">Plugin không đăng ký giao diện</p>
        <p className="text-xs">(thiếu lệnh WOS.registerApp trong mã nguồn)</p>
      </div>
    )
  }
  const C = app.component
  return <C />
}
