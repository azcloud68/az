'use client'

import {
  LayoutDashboard, FolderKanban, CheckSquare, Calendar, StickyNote, BookOpen, Folder,
  GitCommitHorizontal, BarChart3, Activity, Bell, Users, Settings, LayoutGrid, Box,
  ClipboardList, FolderClock, FileText, Calculator, Cat, Globe, TerminalSquare, Gauge,
  Download, Play, type LucideIcon,
} from 'lucide-react'
import { useWos } from '@/core/client/wos-store'

const ICON_MAP: Record<string, LucideIcon> = {
  'layout-dashboard': LayoutDashboard,
  'folder-kanban': FolderKanban,
  'check-square': CheckSquare,
  calendar: Calendar,
  'sticky-note': StickyNote,
  'book-open': BookOpen,
  folder: Folder,
  'git-commit-horizontal': GitCommitHorizontal,
  'bar-chart-3': BarChart3,
  activity: Activity,
  bell: Bell,
  users: Users,
  settings: Settings,
  box: Box,
  'clipboard-list': ClipboardList,
  'folder-clock': FolderClock,
  'file-text': FileText,
  calculator: Calculator,
  cat: Cat,
  globe: Globe,
  'terminal-square': TerminalSquare,
  gauge: Gauge,
  download: Download,
  play: Play,
}

/** Icon là chuỗi "không phải tên lucide" (emoji/ký tự) → render dạng text */
function isGlyphIcon(icon: string): boolean {
  return Boolean(icon) && !isImageIcon(icon) && !ICON_MAP[icon] && !/^[a-z0-9-]+$/.test(icon)
}

/** Icon là ảnh (URL / đường dẫn / data:) → render thẻ <img> */
export function isImageIcon(icon: string): boolean {
  if (!icon) return false
  return (
    icon.startsWith('/') ||
    icon.startsWith('http://') ||
    icon.startsWith('https://') ||
    icon.startsWith('data:') ||
    /\.(png|jpe?g|gif|svg|webp|avif|ico|bmp)([?#].*)?$/i.test(icon)
  )
}

/** Nguồn ảnh plugin: "assets/x.png" → /api/core/plugins/asset?slug=...&file=... */
function resolveImageSrc(moduleId: string, icon: string): string {
  if (icon.startsWith('/') || icon.startsWith('http') || icon.startsWith('data:')) return icon
  return `/api/core/plugins/asset?slug=${encodeURIComponent(moduleId)}&file=${encodeURIComponent(icon)}`
}

function Glyph({ icon, className, px }: { icon: string; className?: string; px?: number }) {
  return (
    <span
      className={`${className ?? ''} flex items-center justify-center leading-none select-none`}
      style={{ fontSize: px ? `${px}px` : '1.1em' }}
      aria-hidden
    >
      {icon}
    </span>
  )
}

export function ModuleIcon({ icon, className, px }: { icon: string; className?: string; px?: number }) {
  if (isGlyphIcon(icon)) return <Glyph icon={icon} className={className} px={px} />
  const Icon = ICON_MAP[icon] || Box
  return <Icon className={className} />
}

/**
 * AppIcon — icon app có áp tuỳ biến từ Settings → Appearance
 * (emoji hoặc ảnh tải lên, override theo moduleId). Fallback: lucide icon gốc
 * hoặc emoji (plugin) HOẶC ảnh plugin (assets/…, URL). `px` = cỡ emoji/ảnh (px).
 */
export function AppIcon({
  moduleId,
  icon,
  className,
  px,
}: {
  moduleId: string
  icon: string
  className?: string
  px?: number
}) {
  const override = useWos((s) => s.iconOverrides[moduleId])
  if (override?.type === 'emoji' && override.value) {
    return <Glyph icon={override.value} className={className} px={px} />
  }
  const imgSrc = override?.type === 'image' && override.value ? override.value : isImageIcon(icon) ? resolveImageSrc(moduleId, icon) : null
  if (imgSrc) {
    return <img src={imgSrc} alt="" draggable={false} className={`${className ?? ''} object-contain`} />
  }
  if (isGlyphIcon(icon)) return <Glyph icon={icon} className={className} px={px} />
  const Icon = ICON_MAP[icon] || Box
  return <Icon className={className} />
}

/**
 * AppIconTile — Ô icon chuẩn macOS "đầy" (full-bleed):
 * - Ảnh tuỳ biến (Settings → Appearance → Ảnh) hoặc ảnh plugin → render ẢNH LỀN TOÀN Ô
 *   (bo góc + đổ bóng như icon app macOS thật), KHÔNG còn nằm nhỏ trong ô màu.
 * - Còn lại: ô gradient màu + lucide/emoji bên trong (như cũ).
 * Dùng cho Desktop icon / Dock / Launchpad / preview Settings.
 */
export function AppIconTile({
  moduleId,
  icon,
  color,
  size = 52,
  glyphPx,
  className = '',
}: {
  moduleId: string
  icon: string
  color?: string
  /** kích thước ô (px) — ảnh sẽ lấp đầy đúng size này */
  size?: number
  /** cỡ lucide/emoji bên trong ô gradient (mặc định ~size*0.5) */
  glyphPx?: number
  className?: string
}) {
  const override = useWos((s) => s.iconOverrides[moduleId])
  const colorOverride = useWos((s) => s.iconColors[moduleId])
  const c = colorOverride || color || '#8b5cf6'
  const px = glyphPx ?? Math.round(size * 0.48)

  const imgSrc =
    override?.type === 'image' && override.value
      ? override.value
      : isImageIcon(icon)
        ? resolveImageSrc(moduleId, icon)
        : null

  // Ảnh → full-bleed như icon app macOS
  if (imgSrc) {
    return (
      <img
        src={imgSrc}
        alt=""
        draggable={false}
        className={`rounded-[22%] object-cover shadow-lg ${className}`}
        style={{
          width: size,
          height: size,
          boxShadow: '0 5px 14px rgba(0,0,0,0.32), inset 0 0 0 1px rgba(255,255,255,0.14)',
        }}
      />
    )
  }

  const isEmoji = (override?.type === 'emoji' && override.value) || isGlyphIcon(icon)
  return (
    <span
      className={`flex shrink-0 items-center justify-center rounded-[26%] text-white shadow-lg transition-transform ${className}`}
      style={{
        width: size,
        height: size,
        background: isEmoji ? 'rgba(255,255,255,0.18)' : `linear-gradient(145deg, ${c}, ${c}bb)`,
        boxShadow: isEmoji ? 'none' : '0 5px 14px rgba(0,0,0,0.35), inset 0 1px 1px rgba(255,255,255,0.4)',
      }}
      aria-hidden
    >
      <AppIcon moduleId={moduleId} icon={icon} px={px} className="h-1/2 w-1/2" />
    </span>
  )
}

/** Màu app sau override (Settings → Appearance) */
export function useAppColor(moduleId: string, fallback: string): string {
  return useWos((s) => s.iconColors[moduleId] || fallback)
}

/** Đọc trực tiếp override (dùng ngoài render, vd dock gradient) — tách selector tránh object mới mỗi lần */
export function useAppOverrides(): {
  iconOverrides: Record<string, { type: 'emoji' | 'image'; value: string }>
  iconColors: Record<string, string>
} {
  const iconOverrides = useWos((s) => s.iconOverrides)
  const iconColors = useWos((s) => s.iconColors)
  return { iconOverrides, iconColors }
}
