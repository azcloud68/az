'use client'

import { useEffect, useState, useCallback, useRef } from 'react'
import { useWos } from '@/core/client/wos-store'
import { api } from '@/core/client/api'
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command'
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog'
import { Search, LayoutDashboard, Loader2 } from 'lucide-react'

interface SearchResult {
  id: string
  module: string
  type: string
  title: string
  detail: string
  action: string
  icon: string
  color: string
  at?: string
}

const ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  task: () => <span className="text-sm font-semibold text-amber-500">✓</span>,
  event: () => <span className="text-sm font-semibold text-emerald-500">📅</span>,
  note: () => <span className="text-sm font-semibold text-yellow-500">📝</span>,
  wiki: () => <span className="text-sm font-semibold text-lime-600">📖</span>,
  file: () => <span className="text-sm font-semibold text-green-600">📄</span>,
  project: () => <span className="text-sm font-semibold text-orange-600">🗂</span>,
  activity: () => <span className="text-sm font-semibold text-cyan-600">◎</span>,
  user: () => <span className="text-sm font-semibold text-pink-500">👤</span>,
}

/** Global Search — Ctrl+K, dữ liệu từ mọi module đang bật */
export function CommandPalette() {
  const { searchOpen, openSearch, navigate, modules } = useWos()
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<SearchResult[]>([])
  const [loading, setLoading] = useState(false)
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null)

  // Hotkey Ctrl+K / Cmd+K
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault()
        openSearch(!useWos.getState().searchOpen)
      }
      if (e.key === 'Escape') openSearch(false)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [openSearch])

  const doSearch = useCallback((q: string) => {
    if (timer.current) clearTimeout(timer.current)
    if (q.trim().length < 1) {
      setResults([])
      return
    }
    timer.current = setTimeout(async () => {
      setLoading(true)
      try {
        const data = await api<{ results: SearchResult[] }>(`/api/core/search?q=${encodeURIComponent(q)}`)
        setResults(data.results)
      } catch {
        setResults([])
      } finally {
        setLoading(false)
      }
    }, 220)
  }, [])

  useEffect(() => {
    doSearch(query)
  }, [query, doSearch])

  // Group theo module
  const groups = new Map<string, SearchResult[]>()
  for (const r of results) {
    const key = r.module
    if (!groups.has(key)) groups.set(key, [])
    groups.get(key)!.push(r)
  }
  const moduleName = (id: string) => modules.find((m) => m.id === id)?.name || id

  const quickNav = [
    { id: 'dashboard', label: 'Dashboard' },
    ...modules
      .filter((m) => m.enabled && m.showSidebar && m.id !== 'dashboard')
      .map((m) => ({ id: m.id, label: m.name })),
  ].slice(0, 14)

  return (
    <Dialog open={searchOpen} onOpenChange={openSearch}>
      <DialogContent
        className="wos-glass-strong top-[18%] max-w-[560px] translate-y-0 gap-0 overflow-hidden rounded-2xl p-0"
        style={{ position: 'fixed' }}
        aria-describedby={undefined}
      >
        <DialogTitle className="sr-only">Tìm kiếm toàn Workspace</DialogTitle>
        <Command shouldFilter={false} className="[&_[cmdk-input-wrapper]]:px-3 [&_[cmdk-input]]:h-12">
          <div className="flex items-center gap-2 border-b px-4">
            {loading ? <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" /> : <Search className="h-4 w-4 text-muted-foreground" />}
            <CommandInput
              value={query}
              onValueChange={setQuery}
              placeholder="Tìm kiếm toàn Workspace… (Task, Note, Wiki, File, Project)"
              className="flex-1"
            />
            <kbd className="rounded border bg-muted px-1.5 py-0.5 text-[10px] text-muted-foreground">ESC</kbd>
          </div>
          <CommandList className="wos-scroll max-h-[380px] overflow-y-auto p-2">
            <CommandEmpty>{query ? 'Không tìm thấy kết quả' : 'Gõ để tìm kiếm'}</CommandEmpty>

            {query.trim() === '' && (
              <CommandGroup heading="Đi nhanh">
                {quickNav.map((n) => (
                  <CommandItem key={n.id} onSelect={() => navigate(n.id)} className="gap-2 rounded-lg px-3 py-2">
                    <LayoutDashboard className="h-4 w-4 text-muted-foreground" />
                    {n.label}
                  </CommandItem>
                ))}
              </CommandGroup>
            )}

            {[...groups.entries()].map(([mod, items]) => (
              <CommandGroup key={mod} heading={moduleName(mod)}>
                {items.slice(0, 6).map((r) => (
                  <CommandItem
                    key={r.id}
                    onSelect={() => navigate(r.action)}
                    className="gap-3 rounded-lg px-3 py-2"
                  >
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md text-xs" style={{ background: `${r.color}22` }}>
                      {ICONS[r.type] ? (() => {
                        const Icon = ICONS[r.type]
                        return <Icon />
                      })() : <span>•</span>}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{r.title}</p>
                      <p className="truncate text-xs text-muted-foreground">{r.detail}</p>
                    </div>
                  </CommandItem>
                ))}
              </CommandGroup>
            ))}
          </CommandList>
        </Command>
      </DialogContent>
    </Dialog>
  )
}
