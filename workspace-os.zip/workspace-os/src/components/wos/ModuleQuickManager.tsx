'use client'

import { useWos } from '@/core/client/wos-store'
import { Button } from '@/components/ui/button'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Switch } from '@/components/ui/switch'
import { LayoutGrid, Lock } from 'lucide-react'

/** Nút "Module" trên Toolbar — bật/tắt nhanh, quản lý chi tiết vào Settings → Modules */
export function ModuleQuickManager() {
  const { modules, user, toggleModule } = useWos()
  if (user?.role !== 'admin') return null

  const list = [...modules].sort((a, b) => a.order - b.order)

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg" aria-label="Quản lý module">
          <LayoutGrid className="h-4.5 w-4.5" />
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="wos-glass-strong w-72 rounded-2xl p-3">
        <div className="mb-2 flex items-center justify-between px-1">
          <p className="text-sm font-semibold">Module Manager</p>
          <span className="text-[11px] text-muted-foreground">
            {modules.filter((m) => m.enabled).length}/{modules.length} đang bật
          </span>
        </div>
        <div className="wos-scroll max-h-[320px] space-y-1 overflow-y-auto pr-1">
          {list.map((m) => (
            <div
              key={m.id}
              className="flex items-center gap-3 rounded-xl px-2 py-2 transition-colors hover:bg-muted"
            >
              <div
                className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-white"
                style={{ background: m.color }}
              >
                <LayoutGrid className="h-4 w-4" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium">
                  {m.name} {m.core && <Lock className="ml-1 inline h-3 w-3 text-muted-foreground" />}
                </p>
                <p className="truncate text-[11px] text-muted-foreground">{m.description}</p>
              </div>
              <Switch
                checked={m.enabled}
                disabled={m.core}
                onCheckedChange={(v) => toggleModule(m.id, v)}
                aria-label={`${m.enabled ? 'Tắt' : 'Bật'} module ${m.name}`}
              />
            </div>
          ))}
        </div>
      </PopoverContent>
    </Popover>
  )
}
