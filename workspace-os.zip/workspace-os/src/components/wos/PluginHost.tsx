'use client'

/**
 * PluginHost — bootstrap hệ thống plugin phía client:
 * 1. Gắn window.WOS (API cho plugin gọi)
 * 2. Tải danh sách plugin + inject script các plugin đang bật
 * 3. Nghe event plugin.installed/uninstalled → gợi ý reload (tải lại script mới)
 * Render rỗng — chỉ hiệu ứng phụ.
 */
import { useEffect } from 'react'
import { useWos } from '@/core/client/wos-store'
import { usePlugins, resetInjectedScripts } from '@/core/client/plugin-store'
import { setupWosGlobal } from '@/core/client/wos-global'
import { bus } from '@/core/client/event-bus'
import { useWindows } from '@/core/client/window-store'
import { toast } from 'sonner'

export function PluginHost() {
  const user = useWos((s) => s.user)
  const load = usePlugins((s) => s.load)
  const status = usePlugins((s) => s.status)

  useEffect(() => {
    if (!user) return
    setupWosGlobal()
    void load()
  }, [user, load])

  // Đăng xuất → đóng cửa sổ plugin + reset
  useEffect(() => {
    if (user) return
    useWindows.getState().windows
      .filter((w) => w.moduleId.startsWith('plugin:'))
      .forEach((w) => useWindows.getState().closeWindow(w.id))
    resetInjectedScripts()
  }, [user])

  // Cài/gỡ plugin → gợi ý tải lại trang (script đã inject cũ không tự thay thế)
  useEffect(() => {
    if (!user) return
    return bus.onAny((ev) => {
      if (ev.type === 'plugin.installed' || ev.type === 'plugin.uninstalled' || ev.type === 'plugin.enabled' || ev.type === 'plugin.disabled') {
        const name = String(ev.payload?.title || '')
        toast('Ứng dụng bổ sung đã thay đổi', {
          description: `${name ? name + ' — ' : ''}tải lại trang để áp dụng`,
          action: { label: 'Tải lại', onClick: () => window.location.reload() },
          duration: 12000,
        })
      }
    })
  }, [user])

  void status
  return null
}
