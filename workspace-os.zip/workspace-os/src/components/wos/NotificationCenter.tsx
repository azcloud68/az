'use client'

import { useWos } from '@/core/client/wos-store'
import { eventLabel } from '@/core/client/event-bus'
import { Button } from '@/components/ui/button'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Bell, Check, Archive, Trash2, Settings2 } from 'lucide-react'
import { timeAgo } from '@/core/client/api'
import { toast } from 'sonner'
import { useState } from 'react'

/** Notification Center — gọi từ Toolbar */
export function NotificationCenterPanel() {
  const { notifications, unreadCount, notifAction, refreshNotifications, navigate, openNotif } = useWos()
  const [tab, setTab] = useState<'all' | 'unread' | 'archived'>('all')

  async function switchTab(t: 'all' | 'unread' | 'archived') {
    setTab(t)
    await refreshNotifications(t === 'all' ? 'all' : t)
  }

  const items = notifications.filter((n) =>
    tab === 'unread' ? !n.read : tab === 'archived' ? n.archived : !n.archived
  )

  return (
    <div className="flex h-[min(70vh,480px)] w-[min(94vw,380px)] max-w-full flex-col">
      <div className="flex items-center justify-between border-b px-4 py-3">
        <div className="flex min-w-0 items-center gap-2 font-semibold">
          <Bell className="h-4 w-4 shrink-0" />
          <span className="truncate">Thông báo</span>
          {unreadCount > 0 && (
            <span className="rounded-full bg-primary px-2 py-0.5 text-xs font-medium text-primary-foreground">
              {unreadCount}
            </span>
          )}
        </div>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="sm" className="h-7 px-2 text-xs" onClick={() => notifAction([], 'read-all')}>
            <Check className="mr-1 h-3.5 w-3.5" /> Đọc tất cả
          </Button>
        </div>
      </div>

      <div className="flex gap-1 border-b px-3 py-2">
        {(
          [
            ['all', 'Tất cả'],
            ['unread', 'Chưa đọc'],
            ['archived', 'Lưu trữ'],
          ] as const
        ).map(([k, label]) => (
          <button
            key={k}
            onClick={() => switchTab(k)}
            className={`rounded-full px-3 py-1 text-xs font-medium transition-colors ${
              tab === k ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-muted'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      <div className="wos-scroll flex-1 overflow-y-auto p-2">
        {items.length === 0 && (
          <div className="flex h-full flex-col items-center justify-center gap-2 text-muted-foreground">
            <Bell className="h-10 w-10 opacity-30" />
            <p className="text-sm">Không có thông báo</p>
          </div>
        )}
        {items.map((n) => (
          <button
            key={n.id}
            onClick={() => {
              if (!n.read) notifAction([n.id], 'read')
              if (n.action) {
                navigate(n.action.replace(/^wos:/, ''))
                openNotif(false)
              }
            }}
            className={`group flex w-full items-start gap-3 rounded-xl p-3 text-left transition-colors hover:bg-muted ${
              n.archived ? 'opacity-50' : ''
            }`}
          >
            <div
              className="mt-1 h-2 w-2 shrink-0 rounded-full"
              style={{ background: n.read ? 'transparent' : 'var(--primary)' }}
            />
            <div className="min-w-0 flex-1">
              <div className="flex items-baseline justify-between gap-2">
                <p className={`truncate text-sm ${n.read ? 'font-normal' : 'font-semibold'}`}>{n.title}</p>
                <span className="shrink-0 text-[11px] text-muted-foreground">{timeAgo(n.createdAt)}</span>
              </div>
              {n.content && <p className="mt-0.5 line-clamp-2 text-xs text-muted-foreground">{n.content}</p>}
              <div className="mt-1 flex items-center gap-2 text-[11px] text-muted-foreground">
                <span className="rounded bg-muted px-1.5 py-0.5">{eventLabel(n.type) || n.module}</span>
              </div>
            </div>
          </button>
        ))}
      </div>

      <div className="flex items-center justify-between border-t px-4 py-2">
        <Button
          variant="ghost"
          size="sm"
          className="h-7 px-2 text-xs"
          disabled={items.length === 0}
          onClick={() => notifAction(items.filter((n) => !n.archived).map((n) => n.id), 'archive')}
        >
          <Archive className="mr-1 h-3.5 w-3.5" /> Lưu trữ
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="h-7 px-2 text-xs"
          disabled={notifications.filter((n) => n.archived).length === 0}
          onClick={async () => {
            await refreshNotifications('archived')
            toast.info('Xem tab Lưu trữ để quản lý')
          }}
        >
          <Trash2 className="mr-1 h-3.5 w-3.5" /> Đã lưu trữ
        </Button>
        <Button variant="ghost" size="sm" className="h-7 px-2 text-xs" onClick={() => { navigate('settings'); openNotif(false) }}>
          <Settings2 className="mr-1 h-3.5 w-3.5" /> Cài đặt
        </Button>
      </div>
    </div>
  )
}
