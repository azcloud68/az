'use client'

import { useTheme } from 'next-themes'
import { useWos } from '@/core/client/wos-store'
import { Button } from '@/components/ui/button'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'
import { NotificationCenterPanel } from './NotificationCenter'
import { Sun, Moon, Search, Bell, LayoutGrid, LogOut, KeyRound, User, HardDrive } from 'lucide-react'
import { ModuleQuickManager } from './ModuleQuickManager'

/** Thanh trên (Toolbar) — luôn cố định: Logo, Workspace, Search, Notification, Theme, Module, User */
export function Toolbar() {
  const { user, settings, unreadCount, notifOpen, openNotif, openSearch, logout, navigate } = useWos()
  const { theme, setTheme } = useTheme()

  return (
    <header className="wos-glass sticky top-0 z-40 flex h-12 w-full shrink-0 items-center gap-2 border-x-0 border-t-0 px-3 md:px-4">
      {/* Traffic lights — trang trí chuẩn macOS */}
      <div className="hidden items-center gap-2 pl-1 pr-2 md:flex" aria-hidden>
        <span className="wos-dot wos-dot-red" />
        <span className="wos-dot wos-dot-yellow" />
        <span className="wos-dot wos-dot-green" />
      </div>

      {/* Logo + tên workspace */}
      <button className="flex items-center gap-2.5" onClick={() => navigate('dashboard')} aria-label="Về Dashboard">
        <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-br from-orange-500 to-rose-500 text-sm font-bold text-white shadow-sm">
          W
        </div>
        <span className="hidden text-[15px] font-semibold tracking-tight sm:block">
          {settings.workspace_name || 'Workspace OS'}
        </span>
      </button>

      <div className="flex-1" />

      {/* Search */}
      <button
        onClick={() => openSearch(true)}
        className="flex h-8 items-center gap-2 rounded-lg bg-black/[0.06] px-3 text-sm text-muted-foreground transition-colors hover:bg-black/[0.09] dark:bg-white/[0.08] dark:hover:bg-white/[0.13]"
      >
        <Search className="h-4 w-4" />
        <span className="hidden md:inline">Tìm kiếm</span>
        <kbd className="hidden rounded border bg-background/60 px-1.5 py-0.5 text-[10px] md:inline">Ctrl K</kbd>
      </button>

      {/* Notification */}
      <Popover open={notifOpen} onOpenChange={openNotif}>
        <PopoverTrigger asChild>
          <Button variant="ghost" size="icon" className="relative h-8 w-8 rounded-lg" aria-label="Thông báo">
            <Bell className="h-4.5 w-4.5" />
            {unreadCount > 0 && (
              <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-rose-500 px-1 text-[10px] font-semibold text-white">
                {unreadCount > 99 ? '99+' : unreadCount}
              </span>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent align="end" className="wos-glass-strong w-[380px] rounded-2xl p-0" style={{ position: 'fixed' }}>
          <NotificationCenterPanel />
        </PopoverContent>
      </Popover>

      {/* Theme */}
      <Button
        variant="ghost"
        size="icon"
        className="h-8 w-8 rounded-lg"
        onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
        aria-label="Đổi giao diện sáng/tối"
      >
        {theme === 'dark' ? <Sun className="h-4.5 w-4.5" /> : <Moon className="h-4.5 w-4.5" />}
      </Button>

      {/* Module Manager nhanh */}
      <ModuleQuickManager />

      {/* User */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button className="ml-1 flex items-center gap-2 rounded-full pl-1 pr-2 transition-colors hover:bg-black/[0.06] dark:hover:bg-white/[0.08]">
            <div
              className="flex h-7 w-7 items-center justify-center rounded-full text-xs font-semibold text-white shadow-sm"
              style={{ background: user?.avatarColor || '#f97316' }}
            >
              {(user?.displayName || 'W').slice(0, 1).toUpperCase()}
            </div>
            <span className="hidden text-sm font-medium lg:block">{user?.displayName}</span>
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-52">
          <DropdownMenuItem onClick={() => navigate('settings')} className="gap-2">
            <User className="h-4 w-4" /> Hồ sơ & Cài đặt
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => navigate('settings:security')} className="gap-2">
            <KeyRound className="h-4 w-4" /> Đổi mật khẩu
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => navigate('settings:storage')} className="gap-2">
            <HardDrive className="h-4 w-4" /> Lưu trữ
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={logout} className="gap-2 text-rose-600 focus:text-rose-600">
            <LogOut className="h-4 w-4" /> Đăng xuất
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </header>
  )
}
