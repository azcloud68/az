'use client'

/**
 * Wallpaper Engine — hình nền desktop tuỳ chỉnh:
 * mặc định Sonoma / gradient / màu / ảnh / ĐỘNG (animated CSS) / VIDEO (mp4/webm).
 * Cấu hình lưu trong Setting module 'appearance' (wallpaper, wallpaper_collection,
 * wallpaper_rotation) — đồng bộ theo tài khoản.
 */
import type { CSSProperties } from 'react'
import type { WallpaperConfig } from '@/core/client/wos-store'

export const WALLPAPER_PRESETS: { id: string; label: string; kind: 'gradient' | 'color'; value: string }[] = [
  { id: 'sonoma', label: 'Sonoma (mặc định)', kind: 'gradient', value: '' },
  { id: 'sunset', label: 'Sunset', kind: 'gradient', value: 'linear-gradient(160deg, #0f2027, #203a43, #2c5364)' },
  { id: 'peach', label: 'Peach', kind: 'gradient', value: 'linear-gradient(135deg, #ff9a9e 0%, #fecfef 50%, #fecfef 100%)' },
  { id: 'mint', label: 'Mint Ocean', kind: 'gradient', value: 'linear-gradient(160deg, #134e5e 0%, #71b280 100%)' },
  { id: 'purple', label: 'Twilight', kind: 'gradient', value: 'linear-gradient(160deg, #41295a 0%, #2f0743 100%)' },
  { id: 'forest', label: 'Forest', kind: 'gradient', value: 'linear-gradient(160deg, #0b3d2e 0%, #14532d 60%, #166534 100%)' },
  { id: 'ocean', label: 'Deep Ocean', kind: 'gradient', value: 'linear-gradient(160deg, #0f172a 0%, #1e3a8a 100%)' },
  { id: 'fire', label: 'Ember', kind: 'gradient', value: 'linear-gradient(160deg, #7f1d1d 0%, #b91c1c 55%, #f97316 100%)' },
  { id: 'rose', label: 'Rose Quartz', kind: 'gradient', value: 'linear-gradient(135deg, #e0c3fc 0%, #8ec5fc 100%)' },
  { id: 'mono', label: 'Graphite', kind: 'gradient', value: 'linear-gradient(160deg, #1f2937 0%, #374151 100%)' },
  { id: 'white', label: 'Trắng sạch', kind: 'color', value: '#e8eaed' },
  { id: 'dark', label: 'Đen tuyền', kind: 'color', value: '#111214' },
  { id: 'orange', label: 'Cam Workspace', kind: 'color', value: '#f97316' },
]

/** Hình nền ĐỘNG (animated) — CSS thuần, mượt trên Orange Pi (GPU composite) */
export interface AnimatedPreset {
  id: string
  label: string
  value: string
  backgroundSize: string
  animation: string
  preview?: string
}

export const ANIMATED_PRESETS: AnimatedPreset[] = [
  {
    id: 'aurora',
    label: 'Aurora — sóng cực quang',
    value:
      'linear-gradient(115deg, #00c6fb 0%, #005bea 25%, #7f7fd5 50%, #34e0a1 75%, #00c6fb 100%)',
    backgroundSize: '400% 400%',
    animation: 'wos-wp-pan 18s ease-in-out infinite, wos-wp-hue 24s linear infinite',
  },
  {
    id: 'sunset-drift',
    label: 'Sunset Drift — hoàng hôn trôi',
    value:
      'radial-gradient(120% 90% at 80% 10%, rgba(255,153,102,.9), transparent 55%),' +
      'radial-gradient(120% 100% at 20% 90%, rgba(233,84,32,.85), transparent 60%),' +
      'linear-gradient(150deg, #1a1a2e, #16213e, #e94560)',
    backgroundSize: '180% 180%, 200% 200%, 100% 100%',
    animation: 'wos-wp-pan 26s ease-in-out infinite alternate, wos-wp-glow 12s ease-in-out infinite alternate',
  },
  {
    id: 'ocean-waves',
    label: 'Ocean Waves — sóng biển',
    value:
      'radial-gradient(140% 120% at 50% 120%, #0b486b 0%, transparent 60%),' +
      'linear-gradient(180deg, #0f2027 0%, #203a43 50%, #2c5364 100%)',
    backgroundSize: '200% 200%, 220% 220%',
    animation: 'wos-wp-waves 14s ease-in-out infinite alternate',
  },
  {
    id: 'nebula',
    label: 'Nebula — tinh vân',
    value:
      'radial-gradient(35% 28% at 22% 30%, rgba(139,92,246,.75), transparent 70%),' +
      'radial-gradient(28% 22% at 68% 20%, rgba(236,72,153,.65), transparent 70%),' +
      'radial-gradient(25% 20% at 55% 68%, rgba(56,189,248,.6), transparent 70%),' +
      'radial-gradient(2px 2px at 12% 42%, #fff, transparent 100%),' +
      'radial-gradient(2px 2px at 44% 12%, #fff9, transparent 100%),' +
      'radial-gradient(2px 2px at 78% 55%, #fff, transparent 100%),' +
      'radial-gradient(1.5px 1.5px at 88% 18%, #fffc, transparent 100%),' +
      'linear-gradient(160deg, #0b0f2a, #131a3a)',
    backgroundSize: '220% 220%, 260% 260%, 240% 240%, 100% 100%, 100% 100%, 100% 100%, 100% 100%, 100% 100%',
    animation: 'wos-wp-pan 34s ease-in-out infinite, wos-wp-twinkle 6s ease-in-out infinite',
  },
  {
    id: 'lava',
    label: 'Magma — dung nham',
    value:
      'radial-gradient(80% 60% at 50% 110%, #f97316 0%, #b91c1c 40%, transparent 70%),' +
      'linear-gradient(180deg, #0a0a0a 0%, #1c1917 60%, #450a0a 100%)',
    backgroundSize: '250% 250%, 100% 100%',
    animation: 'wos-wp-magma 20s ease-in-out infinite alternate',
  },
]

export function animatedPresetById(id: string): AnimatedPreset | undefined {
  return ANIMATED_PRESETS.find((p) => p.id === id)
}

/** Style áp lên div .wos-wallpaper theo config */
export function wallpaperStyle(wp: WallpaperConfig | null | undefined): CSSProperties {
  if (!wp || wp.kind === 'default' || !wp.value) return {}
  if (wp.kind === 'image') {
    return {
      backgroundImage: `url(${wp.value})`,
      backgroundSize: 'cover',
      backgroundPosition: 'center',
    }
  }
  if (wp.kind === 'animated') {
    // value = id của preset trong ANIMATED_PRESETS (vd 'aurora')
    const preset = animatedPresetById(wp.value) || ANIMATED_PRESETS.find((p) => p.value === wp.value)
    if (preset) {
      return {
        background: preset.value,
        backgroundSize: preset.backgroundSize,
        animation: preset.animation,
      }
    }
    // value là CSS background tuỳ chỉnh
    return { background: wp.value, backgroundSize: '300% 300%', animation: 'wos-wp-pan 20s ease-in-out infinite' }
  }
  if (wp.kind === 'video') {
    // video render thẻ <video> riêng — div nền dùng màu tối dự phòng
    return { background: 'linear-gradient(160deg, #0f172a, #1e293b)' }
  }
  return { background: wp.value }
}

/** Nhận diện URL/video từ phần mở rộng */
export function isVideoUrl(url: string): boolean {
  return /\.(mp4|webm|mov|ogv)(\?|$)/i.test(url)
}

export function isCustom(wp: WallpaperConfig | null | undefined): boolean {
  return Boolean(wp && wp.kind !== 'default' && wp.value)
}
