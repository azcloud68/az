'use client'

/**
 * ContextMenu — menu chuột phải kiểu macOS (glass, mục có icon, danger, submenu).
 * Dùng chung cho desktop / icon desktop / dock / titlebar / file trong Files.
 */
import { useEffect, useLayoutEffect, useRef, useState, type ReactNode } from 'react'
import { ChevronRight } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'

export interface CtxItem {
  label: string
  icon?: LucideIcon
  danger?: boolean
  disabled?: boolean
  separator?: boolean
  shortcut?: string
  onClick?: () => void
  /** Menu con hiện ra khi hover (vd danh sách widget, kiểu sắp xếp) */
  children?: CtxItem[]
}

export interface CtxMenuState {
  x: number
  y: number
  items: CtxItem[]
}

export function ContextMenu({ state, onClose }: { state: CtxMenuState; onClose: () => void }) {
  const ref = useRef<HTMLDivElement>(null)
  const [pos, setPos] = useState({ x: state.x, y: state.y })
  const [visible, setVisible] = useState(false)
  /** submenu đang mở (index item) */
  const [openSub, setOpenSub] = useState<number | null>(null)

  // Kẹp menu trong màn hình + hiện dần
  useLayoutEffect(() => {
    const el = ref.current
    if (!el) return
    const r = el.getBoundingClientRect()
    const x = Math.min(state.x, window.innerWidth - r.width - 8)
    const y = Math.min(state.y, window.innerHeight - r.height - 8)
    setPos({ x: Math.max(4, x), y: Math.max(38, y) })
    setVisible(true)
  }, [state])

  // Đóng khi click ngoài / Escape / scroll
  useEffect(() => {
    const close = () => onClose()
    // Click vào chính menu → bỏ qua (để nút kịp nhận click)
    const onDown = (e: PointerEvent) => {
      if (ref.current && e.target instanceof Node && ref.current.contains(e.target)) return
      onClose()
    }
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    const t = setTimeout(() => {
      document.addEventListener('pointerdown', onDown)
      document.addEventListener('keydown', onKey)
      window.addEventListener('blur', close)
    }, 10)
    return () => {
      clearTimeout(t)
      document.removeEventListener('pointerdown', onDown)
      document.removeEventListener('keydown', onKey)
      window.removeEventListener('blur', close)
    }
  }, [onClose])

  return (
    <div
      ref={ref}
      className={`wos-ctx-menu wos-glass-strong fixed z-[60] rounded-xl p-1.5 transition-opacity ${
        visible ? 'opacity-100' : 'opacity-0'
      }`}
      style={{ left: pos.x, top: pos.y, visibility: visible ? 'visible' : 'hidden' }}
      role="menu"
      aria-label="Menu ngữ cảnh"
      onPointerLeave={() => setOpenSub(null)}
    >
      {state.items.map((item, i) =>
        item.separator ? (
          <div key={i} className="mx-2 my-1 h-px bg-foreground/10" role="separator" />
        ) : item.children?.length ? (
          <div
            key={i}
            className="relative"
            onMouseEnter={() => setOpenSub(i)}
          >
            <button
              role="menuitem"
              disabled={item.disabled}
              className={`flex w-full items-center gap-2.5 rounded-lg px-2.5 py-1.5 text-[13px] font-medium transition-colors disabled:opacity-40 ${
                item.danger
                  ? 'text-rose-600 hover:bg-rose-500/10 dark:text-rose-400'
                  : 'text-foreground/85 hover:bg-black/[0.06] dark:hover:bg-white/[0.09]'
              }`}
            >
              {item.icon ? <item.icon className="h-4 w-4 shrink-0" /> : <span className="w-4" />}
              <span className="flex-1 truncate text-left">{item.label}</span>
              <ChevronRight className="h-3.5 w-3.5 text-muted-foreground" />
            </button>
            {openSub === i && (
              <div
                className="wos-ctx-menu wos-glass-strong absolute left-[calc(100%-4px)] top-0 z-[61] min-w-44 rounded-xl p-1.5"
                style={{ maxHeight: 340, overflowY: 'auto' }}
                role="menu"
              >
                {item.children.map((sub, j) =>
                  sub.separator ? (
                    <div key={j} className="mx-2 my-1 h-px bg-foreground/10" role="separator" />
                  ) : (
                    <button
                      key={j}
                      role="menuitem"
                      disabled={sub.disabled}
                      onClick={() => {
                        sub.onClick?.()
                        onClose()
                      }}
                      className={`flex w-full items-center gap-2.5 rounded-lg px-2.5 py-1.5 text-[13px] font-medium transition-colors disabled:opacity-40 ${
                        sub.danger
                          ? 'text-rose-600 hover:bg-rose-500/10 dark:text-rose-400'
                          : 'text-foreground/85 hover:bg-black/[0.06] dark:hover:bg-white/[0.09]'
                      }`}
                    >
                      {sub.icon ? <sub.icon className="h-4 w-4 shrink-0" /> : <span className="w-4" />}
                      <span className="flex-1 truncate text-left">{sub.label}</span>
                    </button>
                  ),
                )}
              </div>
            )}
          </div>
        ) : (
          <button
            key={i}
            role="menuitem"
            disabled={item.disabled}
            onClick={() => {
              item.onClick?.()
              onClose()
            }}
            className={`flex w-full items-center gap-2.5 rounded-lg px-2.5 py-1.5 text-[13px] font-medium transition-colors disabled:opacity-40 ${
              item.danger
                ? 'text-rose-600 hover:bg-rose-500/10 dark:text-rose-400'
                : 'text-foreground/85 hover:bg-black/[0.06] dark:hover:bg-white/[0.09]'
            }`}
          >
            {item.icon ? <item.icon className="h-4 w-4 shrink-0" /> : <span className="w-4" />}
            <span className="flex-1 truncate text-left">{item.label}</span>
            {item.shortcut ? (
              <span className="text-[10px] text-muted-foreground">{item.shortcut}</span>
            ) : null}
          </button>
        ),
      )}
    </div>
  )
}

/** Helper mở menu từ sự kiện chuột phải */
export function openCtx(
  e: React.MouseEvent,
  setState: (s: CtxMenuState) => void,
  items: CtxItem[],
) {
  e.preventDefault()
  e.stopPropagation()
  setState({ x: e.clientX, y: e.clientY, items })
}

/** Wrapper gọn cho zone có menu riêng */
export function CtxZone({
  items,
  children,
  className,
}: {
  items: CtxItem[]
  children: ReactNode
  className?: string
}) {
  const [state, setState] = useState<CtxMenuState | null>(null)
  return (
    <div className={className} onContextMenu={(e) => openCtx(e, setState, items)}>
      {children}
      {state ? <ContextMenu state={state} onClose={() => setState(null)} /> : null}
    </div>
  )
}
