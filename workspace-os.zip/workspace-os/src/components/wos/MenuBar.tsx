'use client'

/**
 * MenuBar — thanh menu 34px kiểu macOS (thay Toolbar cũ):
 * trái: logo + tên workspace + tên app đang focus; phải: CPU/RAM, search, thông báo,
 * theme, module manager, user, đồng hồ.
 */
import { useEffect, useState } from 'react'
import { useTheme } from 'next-themes'
import { useWos } from '@/core/client/wos-store'
import { useWindows, MENUBAR_H } from '@/core/client/window-store'
import { Button } from '@/components/ui/button'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { NotificationCenterPanel } from './NotificationCenter'
import { ModuleQuickManager } from './ModuleQuickManager'
import { Sun, Moon, Search, LogOut, KeyRound, User, HardDrive, Bell, Activity, Lock, Download } from 'lucide-react'
import { api } from '@/core/client/api'
import { useDownloads, downloadsSummary } from '@/core/client/downloads'

interface Stats {
  cpu: number
  mem: { percent: number }
  disk: { percent: number }
}

function Clock() {
  const [now, setNow] = useState(() => new Date())
  useEffect(() => {
    const iv = setInterval(() => setNow(new Date()), 5000)
    return () => clearInterval(iv)
  }, [])
  return (
    <span className="flex select-none items-center gap-2 text-[12px] font-medium tabular-nums">
      {/* mobile: chỉ giờ; sm trở lên: ngày + giờ (giữa thanh menu như macOS) */}
      <span className="sm:hidden">{now.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}</span>
      <span className="hidden sm:inline">
        {now.toLocaleDateString('vi-VN', { weekday: 'short', day: 'numeric', month: 'short' })}
      </span>
      <span className="hidden sm:inline">{now.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}</span>
    </span>
  )
}

function SysChip() {
  const [stats, setStats] = useState<Stats | null>(null)
  const user = useWos((s) => s.user)
  useEffect(() => {
    if (!user) return
    let alive = true
    const load = () =>
      api<Stats>('/api/core/stats')
        .then((d) => alive && setStats(d))
        .catch(() => {})
    load()
    const iv = setInterval(load, 10000)
    return () => {
      alive = false
      clearInterval(iv)
    }
  }, [user])
  if (!stats) return null
  const heavy = stats.mem.percent > 85 || stats.cpu > 90
  return (
    <span
      className="hidden select-none items-center gap-1.5 rounded-md px-2 py-0.5 text-[11px] tabular-nums lg:flex"
      style={{ background: heavy ? 'oklch(0.62 0.19 25 / 14%)' : 'oklch(0.5 0 0 / 6%)' }}
      title={`CPU ${Math.round(stats.cpu)}% · RAM ${stats.mem.percent}% · Đĩa ${stats.disk.percent}%`}
    >
      <Activity className="h-3 w-3" />
      CPU {Math.round(stats.cpu)}% · RAM {stats.mem.percent}%
    </span>
  )
}

/** Chip Downloads — hiện tiến trình tải đang chạy; click mở app Downloads */
function DownloadChip() {
  const items = useDownloads((s) => s.items)
  const openApp = useWindows((s) => s.openApp)
  const { active, pct } = downloadsSummary(items)
  if (active === 0) return null
  return (
    <button
      onClick={() => openApp('downloads')}
      className="flex h-7 items-center gap-1.5 rounded-lg px-2 text-[11px] font-medium tabular-nums transition-colors hover:bg-black/[0.07] dark:hover:bg-white/[0.1]"
      title={`${active} tệp đang tải — ${pct}% — bấm để mở Downloads`}
      aria-label="Mở trình quản lý tải xuống"
    >
      <Download className="h-3.5 w-3.5 animate-pulse" />
      <span className="hidden sm:inline">{pct > 0 ? `${pct}%` : 'đang tải'}</span>
    </button>
  )
}

export function MenuBar() {
  const { user, settings, unreadCount, notifOpen, openNotif, openSearch, logout, navigate, lock } = useWos()
  const { theme, setTheme } = useTheme()
  const windows = useWindows((s) => s.windows)
  const zTop = useWindows((s) => s.zTop)
  const focused = windows.filter((w) => !w.minimized).sort((a, b) => b.z - a.z)[0]
  const focusedModule = useWos((s) => s.modules.find((m) => m.id === focused?.moduleId))
  void zTop

  return (
    <header
      className="wos-menubar wos-glass fixed inset-x-0 top-0 z-[41] flex select-none items-center justify-between px-2.5"
      style={{ height: MENUBAR_H }}
      aria-label="Thanh menu"
    >
      {/* Trái: logo + workspace + app đang focus */}
      <div className="flex min-w-0 items-center gap-1.5">
        <button
          className="flex h-7 items-center gap-2 rounded-lg px-1.5 transition-colors hover:bg-black/[0.07] dark:hover:bg-white/[0.1]"
          onClick={() => navigate('dashboard')}
          aria-label="Mở Dashboard"
        >
          <span
            className="flex h-5.5 w-5.5 items-center justify-center rounded-md text-[11px] font-bold text-white shadow-sm"
            style={{ background: 'linear-gradient(135deg, #f97316, #e11d48)', width: 22, height: 22 }}
          >
            W
          </span>
          <span className="hidden text-[13px] font-semibold tracking-tight sm:block">
            {settings.workspace_name || 'Workspace OS'}
          </span>
        </button>
        {focusedModule ? (
          <span className="hidden select-none items-center gap-1.5 px-1.5 text-[12.5px] font-semibold text-foreground/80 md:flex">
            <span className="h-3.5 w-px bg-foreground/20" aria-hidden />
            {focusedModule.name}
          </span>
        ) : null}
      </div>

      {/* GIỮA thanh menu: đồng hồ + ngày (request user v6.3 — absolute cho ra
          CHÍNH GIỮA thật sự, không lệch theo 2 cụm trái/phải) */}
      <div className="pointer-events-none absolute inset-y-0 left-1/2 z-10 flex -translate-x-1/2 items-center">
        <div className="pointer-events-auto rounded-lg px-3 py-1 transition-colors hover:bg-black/[0.07] dark:hover:bg-white/[0.1]">
          <Clock />
        </div>
      </div>

      {/* Phải: hệ thống + tiện ích */}
      <div className="flex items-center gap-0.5">
        <SysChip />
        <DownloadChip />

        <button
          onClick={() => openSearch(true)}
          className="flex h-7 items-center gap-1.5 rounded-lg px-2 text-[12px] text-muted-foreground transition-colors hover:bg-black/[0.07] dark:hover:bg-white/[0.1]"
          aria-label="Tìm kiếm toàn workspace (Ctrl K)"
        >
          <Search className="h-3.5 w-3.5" />
          <kbd className="hidden rounded border bg-background/60 px-1 py-0.5 text-[9px] md:inline">⌘K</kbd>
        </button>

        <Popover open={notifOpen} onOpenChange={openNotif}>
          <PopoverTrigger asChild>
            <Button variant="ghost" size="icon" className="relative h-7 w-7 rounded-lg" aria-label="Thông báo">
              <Bell className="h-3.5 w-3.5" />
              {unreadCount > 0 && (
                <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-rose-500 px-1 text-[10px] font-semibold text-white">
                  {unreadCount > 99 ? '99+' : unreadCount}
                </span>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent
            align="end"
            sideOffset={8}
            collisionPadding={10}
            className="wos-glass-strong w-[min(94vw,380px)] rounded-2xl p-0"
          >
            <NotificationCenterPanel />
          </PopoverContent>
        </Popover>

        <Button
          variant="ghost"
          size="icon"
          className="h-7 w-7 rounded-lg"
          onClick={lock}
          aria-label="Khóa màn hình (Ctrl Shift Z)"
          title="Khóa màn hình (Ctrl+Shift+Z)"
        >
          <Lock className="h-3.5 w-3.5" />
        </Button>

        <Button
          variant="ghost"
          size="icon"
          className="h-7 w-7 rounded-lg"
          onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
          aria-label="Đổi giao diện sáng/tối"
        >
          {theme === 'dark' ? <Sun className="h-3.5 w-3.5" /> : <Moon className="h-3.5 w-3.5" />}
        </Button>

        <ModuleQuickManager />

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              className="ml-0.5 flex h-7 items-center gap-1.5 rounded-full pl-1 pr-1.5 transition-colors hover:bg-black/[0.07] dark:hover:bg-white/[0.1]"
              aria-label="Menu người dùng"
            >
              <span
                className="flex h-6 w-6 items-center justify-center rounded-full text-[10px] font-semibold text-white shadow-sm"
                style={{ background: user?.avatarColor || '#f97316' }}
              >
                {(user?.displayName || 'W').slice(0, 1).toUpperCase()}
              </span>
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-52">
            <DropdownMenuItem onClick={() => navigate('settings')} className="gap-2">
              <User className="h-4 w-4" /> Hồ sơ & Cài đặt
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate('settings:security')} className="gap-2">
              <KeyRound className="h-4 w-4" /> Đổi mật khẩu
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate('settings:storage')} className="gap-2">
              <HardDrive className="h-4 w-4" /> Lưu trữ
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={lock} className="gap-2">
              <Lock className="h-4 w-4" /> Khóa màn hình
              <span className="ml-auto text-[10px] text-muted-foreground">⌃⇧Z</span>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={logout} className="gap-2 text-rose-600 focus:text-rose-600">
              <LogOut className="h-4 w-4" /> Đăng xuất
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  )
}
