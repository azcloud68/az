'use client'

/**
 * useWallpaperRotation — tự đổi hình nền theo lịch (bộ sưu tập + interval).
 * Chạy trong Desktop: tick mỗi 20s, đổi khi đủ interval; đổi qua saveAppearance
 * (persist server theo tài khoản) → crossfade tự nhiên qua CSS class.
 */
import { useEffect, useRef } from 'react'
import { useWos, type WallpaperConfig, type WallpaperItem } from '@/core/client/wos-store'

export function useWallpaperRotation() {
  const rotation = useWos((s) => s.wallpaperRotation)
  const collection = useWos((s) => s.wallpaperCollection)
  const saveAppearance = useWos((s) => s.saveAppearance)
  const lastApplied = useRef<string>('')

  useEffect(() => {
    if (!rotation.enabled || collection.length < 2) return
    const intervalMs = Math.max(1, rotation.intervalMin) * 60000

    const tick = () => {
      const now = Date.now()
      const since = now - (rotation.lastAt || 0)
      if (rotation.lastAt && since < intervalMs) return
      // chọn hình kế tiếp
      let idx: number
      if (rotation.order === 'random') {
        do {
          idx = Math.floor(Math.random() * collection.length)
        } while (idx === rotation.lastIdx && collection.length > 1)
      } else {
        idx = (rotation.lastIdx + 1) % collection.length
      }
      const item: WallpaperItem = collection[idx]
      if (!item) return
      const next: WallpaperConfig = { kind: item.kind, value: item.value }
      const stamp = JSON.stringify(next)
      if (stamp === lastApplied.current) return
      lastApplied.current = stamp
      void saveAppearance({
        wallpaper: JSON.stringify(next),
        wallpaper_rotation: JSON.stringify({ ...rotation, lastIdx: idx, lastAt: now }),
      })
    }

    // lần đầu boot: nếu chưa từng đổi (lastAt=0) → đặt mốc giờ, KHÔNG đổi ngay
    if (!rotation.lastAt) {
      void saveAppearance({ wallpaper_rotation: JSON.stringify({ ...rotation, lastAt: Date.now() }) })
    }
    const t = setInterval(tick, 20000)
    return () => clearInterval(t)
  }, [rotation, collection, saveAppearance])
}
