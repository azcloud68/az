'use client'

/**
 * Desktop — "Desktop Environment" thuần (wallpaper, MenuBar, marquee, menu chuột phải).
 * Từ v6 mọi logic icon/widget/dock đã tách xuống Desktop Manager (src/core/client/desktop),
 * Dock Manager (dock-utils) và các component riêng — Desktop không còn kiêm
 * File Manager / App Launcher / Widget Manager (kiến trúc review).
 *
 * Menu chuột phải chuẩn PC (review #2):
 *   Tạo mới ▸ | Dán | Sắp xếp ▸ | Cài đặt Desktop… | Đổi hình nền… | Làm mới
 * (Widget / Atmosphere / Pet / Upload / Module / Plugin → chuyển vào Settings)
 */
import { useEffect, useRef, useState } from 'react'
import { useWos } from '@/core/client/wos-store'
import { useWindows } from '@/core/client/window-store'
import { useIsMobile } from '@/hooks/use-mobile'
import { MenuBar } from './MenuBar'
import { Dock } from './Dock'
import { DesktopIcons, WebAppAddDialog } from './DesktopIcons'
import { Launchpad } from './Launchpad'
import { WindowFrame, SnapOverlay } from './WindowFrame'
import { CommandPalette } from './CommandPalette'
import { AppIcon } from './ModuleIcon'
import { ContextMenu, openCtx, type CtxMenuState } from './ContextMenu'
import { WidgetLayer } from './widgets/WidgetLayer'
import { AltTabSwitcher } from './AltTabSwitcher'
import { LockScreen } from './LockScreen'
import { WallpaperPicker } from './WallpaperPicker'
import { wallpaperStyle } from './wallpaper'
import { syncPluginApps } from './app-registry'
import { DesktopPetLayer } from './DesktopPetLayer'
import { WeatherEngine } from './WeatherEngine'
import { useWallpaperRotation } from './use-wallpaper-rotation'
import { useDesktopStore, system } from '@/core/client/desktop'
import { useClipboard } from '@/core/client/clipboard'
import {
  LayoutGrid, Grid3x3, Minus, X, CloudUpload, Loader2, FolderPlus, FileText,
  Wallpaper as WallpaperIcon, Globe, Settings2, RefreshCw, ClipboardPaste, ArrowDownAZ,
} from 'lucide-react'
import { toast } from 'sonner'
import { bus } from '@/core/client/event-bus'

/** Kéo-thả file từ máy thật → upload vào thư mục Desktop (XHR để có tiến độ) */
function useDesktopUpload() {
  const { modules } = useWos()
  const [dropActive, setDropActive] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [pct, setPct] = useState(0)
  const [names, setNames] = useState('')
  /** Trạng thái kéo-thả: đếm sâu drag enter/leave để chống nhấp nháy UI */
  const depth = useRef(0)

  async function uploadFiles(files: FileList | File[]) {
    const arr = Array.from(files)
    if (arr.length === 0) return
    if (!modules.find((m) => m.id === 'files' && m.enabled)) {
      toast.error('Module Files đang tắt', { description: 'Bật lại trong Module Manager để tải tệp lên.' })
      return
    }
    setUploading(true)
    setPct(0)
    setNames(arr.length === 1 ? arr[0].name : `${arr.length} tệp`)
    try {
      const form = new FormData()
      for (const f of arr) form.append('files', f)
      await new Promise<void>((resolve, reject) => {
        const xhr = new XMLHttpRequest()
        xhr.open('POST', '/api/modules/files/upload?dir=Desktop')
        xhr.upload.onprogress = (e) => {
          if (e.lengthComputable) setPct(Math.round((e.loaded / e.total) * 100))
        }
        xhr.onload = () =>
          xhr.status < 300
            ? resolve()
            : reject(new Error(JSON.parse(xhr.responseText || '{}').error || `HTTP ${xhr.status}`))
        xhr.onerror = () => reject(new Error('Lỗi mạng khi tải lên'))
        xhr.send(form)
      })
      bus.emit('file.uploaded', 'files', { name: arr.length === 1 ? arr[0].name : `${arr.length} tệp` })
      toast.success('Đã tải lên Desktop', { description: `${arr.length} tệp → thư mục Desktop` })
    } catch (err) {
      toast.error('Tải lên thất bại', { description: err instanceof Error ? err.message : '' })
    } finally {
      setUploading(false)
      setPct(0)
    }
  }

  const onDragEnter = (e: React.DragEvent) => {
    if (Array.from(e.dataTransfer.types).includes('Files')) {
      depth.current++
      setDropActive(true)
    }
  }
  const onDragLeave = () => {
    if (depth.current > 0 && --depth.current === 0) setDropActive(false)
  }
  const onDrop = (e: React.DragEvent) => {
    if (e.dataTransfer.files.length) {
      e.preventDefault()
      depth.current = 0
      setDropActive(false)
      void uploadFiles(e.dataTransfer.files)
    }
  }

  return { dropActive, uploading, pct, names, uploadFiles, onDragEnter, onDragLeave, onDrop }
}

/** Mobile: tab bar dưới cùng thay Dock */
function MobileTabBar() {
  const modules = useWos((s) => s.modules)
  const windows = useWindows((s) => s.windows)
  const openApp = useWindows((s) => s.openApp)
  const setLaunchpad = useWindows((s) => s.setLaunchpad)
  const focused = windows.filter((w) => !w.minimized).sort((a, b) => b.z - a.z)[0]
  const tabs = modules.filter((m) => m.enabled && m.showDock).sort((a, b) => a.order - b.order).slice(0, 5)
  return (
    <nav
      className="wos-dock fixed bottom-0 left-0 right-0 z-[40] flex items-center justify-around rounded-none border-x-0 border-b-0 px-2 py-1.5"
      aria-label="Tab điều hướng"
    >
      {tabs.map((m) => {
        const active = focused?.moduleId === m.id
        return (
          <button
            key={m.id}
            onClick={() => openApp(m.id)}
            className="flex flex-col items-center gap-0.5 rounded-lg px-3 py-1.5"
            style={{ color: active ? m.color : 'var(--muted-foreground)' }}
            aria-label={`Mở ${m.name}`}
          >
            <AppIcon moduleId={m.id} icon={m.icon} px={18} className="h-5 w-5" />
            <span className="text-[10px] font-medium">{m.name}</span>
          </button>
        )
      })}
      <button
        onClick={() => setLaunchpad(true)}
        className="flex flex-col items-center gap-0.5 rounded-lg px-3 py-1.5"
        style={{ color: 'var(--muted-foreground)' }}
        aria-label="Mở Launchpad"
      >
        <LayoutGrid className="h-5 w-5" />
        <span className="text-[10px] font-medium">Thêm</span>
      </button>
    </nav>
  )
}

export function Desktop() {
  const { navigate, wallpaper, lock, locked, plugins } = useWos()
  const windows = useWindows((s) => s.windows)
  const launchpadOpen = useWindows((s) => s.launchpadOpen)
  const tileWindows = useWindows((s) => s.tileWindows)
  const minimizeAll = useWindows((s) => s.minimizeAll)
  const closeAll = useWindows((s) => s.closeAll)
  const switcherOpen = useWindows((s) => s.switcherOpen)
  const isMobile = useIsMobile()
  const [menu, setMenu] = useState<CtxMenuState | null>(null)
  const [wallpaperOpen, setWallpaperOpen] = useState(false)
  const [webAppOpen, setWebAppOpen] = useState(false)
  useWallpaperRotation()

  // Selection Engine + Persistence — từ Desktop Manager store
  const sel = useDesktopStore((s) => s.selection)
  const setSel = useDesktopStore((s) => s.setSelection)
  const clearSel = useDesktopStore((s) => s.clearSelection)
  const updateLayout = useDesktopStore((s) => s.update)
  const clipboard = useClipboard()
  const clipFiles = clipboard.payload?.kind === 'files' ? clipboard.payload.paths.length : 0
  const clipText = clipboard.payload?.kind === 'text'

  const {
    dropActive, uploading, pct, names, uploadFiles, onDragEnter, onDragLeave, onDrop,
  } = useDesktopUpload()

  // File manager có bị khoá cho tài khoản này không (ẩn mục menu liên quan file)
  const canFiles = useWos((s) =>
    s.user?.role === 'admin' ||
    (s.user?.permissions?.allowFiles !== false &&
      (!Array.isArray(s.user?.permissions?.modules) || s.user.permissions.modules.includes('files'))),
  )

  // ===== CHỌN KHUNG (marquee) kiểu PC: kéo chuột trái trên nền → chọn nhiều icon =====
  const [marquee, setMarquee] = useState<{ x0: number; y0: number; x1: number; y1: number } | null>(null)
  const marqueeRef = useRef(marquee)
  useEffect(() => {
    marqueeRef.current = marquee
  }, [marquee])

  useEffect(() => {
    if (!marquee) return
    const onMove = (e: PointerEvent) => {
      setMarquee((m) => (m ? { ...m, x1: e.clientX, y1: e.clientY } : m))
    }
    const onUp = () => {
      const m = marqueeRef.current
      if (m) {
        const left = Math.min(m.x0, m.x1)
        const right = Math.max(m.x0, m.x1)
        const top = Math.min(m.y0, m.y1)
        const bottom = Math.max(m.y0, m.y1)
        if (right - left > 6 && bottom - top > 6) {
          const apps: string[] = []
          const files: string[] = []
          document.querySelectorAll<HTMLElement>('.wos-desktop-icon[data-app], .wos-desktop-file[data-path]').forEach((n) => {
            if (n.closest('[data-trash]')) return
            const r = n.getBoundingClientRect()
            if (r.left < right && r.right > left && r.top < bottom && r.bottom > top) {
              const appId = n.getAttribute('data-app')
              const filePath = n.getAttribute('data-path')
              if (appId) apps.push(appId)
              else if (filePath) files.push(filePath)
            }
          })
          if (apps.length || files.length) setSel({ apps, files })
        }
      }
      setMarquee(null)
    }
    window.addEventListener('pointermove', onMove)
    window.addEventListener('pointerup', onUp)
    return () => {
      window.removeEventListener('pointermove', onMove)
      window.removeEventListener('pointerup', onUp)
    }
  }, [marquee !== null])

  // Escape → bỏ chọn nhóm
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && sel) clearSel()
    }
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  }, [sel])

  // Đăng ký app plugin vào PAGES (cửa sổ/dock/launchpad dùng chung registry)
  useEffect(() => {
    syncPluginApps(plugins)
  }, [plugins])

  // Chặn menu chuột phải mặc định của trình duyệt trong môi trường WOS
  // (giữ menu gốc cho input/textarea/chọn văn bản để copy-paste vẫn tiện)
  useEffect(() => {
    const h = (e: MouseEvent) => {
      const t = e.target as HTMLElement | null
      if (!t) return
      if (t.closest('input, textarea, select, [contenteditable="true"], [data-native-menu]')) return
      if (window.getSelection()?.toString()) return
      e.preventDefault()
    }
    document.addEventListener('contextmenu', h)
    return () => document.removeEventListener('contextmenu', h)
  }, [])

  // ===== Phím tắt toàn cục =====
  // Alt+Tab (hoặc Meta+Tab): switcher cửa sổ — Tab vòng lặp, thả Alt chọn
  // Ctrl+Shift+Z: khóa màn hình
  useEffect(() => {
    const switcherActive = () => useWindows.getState().switcherOpen
    const onKeyDown = (e: KeyboardEvent) => {
      // Ctrl+Shift+Z → khóa màn hình
      if (e.ctrlKey && e.shiftKey && (e.key === 'z' || e.key === 'Z')) {
        e.preventDefault()
        lock()
        return
      }
      const isAltTab = (e.altKey && e.key === 'Tab') || (e.metaKey && e.key === 'Tab')
      if (isAltTab) {
        e.preventDefault()
        if (switcherActive()) {
          useWindows.getState().stepSwitcher(e.shiftKey)
        } else {
          useWindows.getState().startSwitcher(e.shiftKey)
        }
        return
      }
      // F4 → Launchpad (kiểu Windows/PC)
      if (e.key === 'F4') {
        e.preventDefault()
        useWindows.getState().setLaunchpad(!useWindows.getState().launchpadOpen)
        return
      }
      if (e.key === 'Escape' && switcherActive()) {
        useWindows.getState().cancelSwitcher()
      }
    }
    const onKeyUp = (e: KeyboardEvent) => {
      if ((e.key === 'Alt' || e.key === 'Meta') && useWindows.getState().switcherOpen) {
        e.preventDefault()
        useWindows.getState().commitSwitcher()
      }
    }
    window.addEventListener('keydown', onKeyDown, true)
    window.addEventListener('keyup', onKeyUp, true)
    return () => {
      window.removeEventListener('keydown', onKeyDown, true)
      window.removeEventListener('keyup', onKeyUp, true)
    }
  }, [lock])

  async function createOnDesktop(kind: 'folder' | 'file') {
    const label = kind === 'folder' ? 'thư mục' : 'tệp văn bản'
    const name = prompt(`Tên ${label} mới:`)
    if (!name?.trim()) return
    try {
      await system.createIn('Desktop', kind, name.trim())
      toast.success(`Đã tạo ${label}`, { description: name.trim() })
    } catch (err) {
      toast.error(`Không tạo được ${label}`, { description: err instanceof Error ? err.message : '' })
    }
  }

  /** Sắp xếp icon: reset về lưới mặc định — file xếp THEO TÊN (cột trái), app theo thứ tự mặc định (cột phải) */
  function sortIcons() {
    updateLayout((prev) => ({ ...prev, appCells: {}, fileCells: {} }))
    system.refreshDesktop()
    toast.success('Đã sắp xếp lại icon', { description: 'File theo tên bên trái · app theo thứ tự mặc định bên phải' })
  }
  const desktopMenu: CtxMenuState['items'] = [
    {
      label: 'Tạo mới',
      icon: FolderPlus,
      disabled: !canFiles,
      children: [
        { label: 'Thư mục mới', icon: FolderPlus, disabled: !canFiles, onClick: () => void createOnDesktop('folder') },
        { label: 'Tệp văn bản mới', icon: FileText, disabled: !canFiles, onClick: () => void createOnDesktop('file') },
        { label: 'Ứng dụng web…', icon: Globe, onClick: () => setWebAppOpen(true) },
      ],
    },
    { separator: true, label: '' },
    {
      label: clipFiles ? `Dán (${clipFiles} mục)` : clipText ? 'Dán văn bản (tạo ghi chú)' : 'Dán',
      icon: ClipboardPaste,
      disabled: (!clipFiles && !clipText) || !canFiles,
      onClick: () => void system.pasteInto('Desktop'),
    },
    { separator: true, label: '' },
    {
      label: 'Sắp xếp',
      icon: ArrowDownAZ,
      children: [
        { label: 'Sắp xếp icon theo tên', icon: ArrowDownAZ, onClick: sortIcons },
        { separator: true, label: '' },
        {
          label: 'Sắp xếp cửa sổ',
          icon: Grid3x3,
          disabled: windows.filter((w) => !w.minimized).length < 2,
          onClick: tileWindows,
        },
        { label: 'Thu nhỏ tất cả cửa sổ', icon: Minus, disabled: windows.length === 0, onClick: minimizeAll },
        { label: 'Đóng tất cả cửa sổ', icon: X, danger: true, disabled: windows.length === 0, onClick: closeAll },
      ],
    },
    { separator: true, label: '' },
    { label: 'Cài đặt Desktop…', icon: Settings2, onClick: () => navigate('settings:appearance') },
    { label: 'Đổi hình nền…', icon: WallpaperIcon, onClick: () => setWallpaperOpen(true) },
    { separator: true, label: '' },
    { label: 'Làm mới', icon: RefreshCw, onClick: () => system.refreshDesktop() },
  ]

  // "Sắp xếp theo tên" cho FILE cần dữ liệu entries — DesktopIcons tự sắp qua sortIcons đơn giản hoá
  // (reset toàn bộ về lưới mặc định, file xếp theo tên bên trái nhờ assignFileCells).

  return (
    <div
      className="fixed inset-0 select-none overflow-hidden"
      onContextMenu={(e) => {
        // Chỉ menu desktop khi right-click vào nền (không vào cửa sổ/dock/icon/widget/pet/
        // menu ngữ cảnh đang mở/Launchpad — các zone đó có menu riêng của chúng)
        const t = e.target as HTMLElement
        if (t.closest('.wos-window, .wos-dock, .wos-desktop-icon, .wos-desktop-file, .wos-widget, .wos-pet, .wos-launchpad, .wos-ctx-menu, [data-native-menu]')) return
        openCtx(e, setMenu, desktopMenu)
      }}
      onPointerDown={(e) => {
        // KÉO KHUNG CHỌN (marquee) kiểu PC: bắt đầu từ nền desktop (chuột trái).
        // Bỏ qua cả menu ngữ cảnh đang mở (click chọn mục menu KHÔNG được kéo marquee
        // dưới menu — v6.3 fix) và Launchpad.
        if (e.button !== 0) return
        const t = e.target as HTMLElement
        if (t.closest('.wos-window, .wos-dock, .wos-menubar, .wos-desktop-icon, .wos-desktop-file, .wos-widget, .wos-cat-root, .wos-launchpad, .wos-ctx-menu, [data-native-menu]')) return
        clearSel() // click nền → bỏ chọn (như PC)
        setMarquee({ x0: e.clientX, y0: e.clientY, x1: e.clientX, y1: e.clientY })
      }}
      onDragEnter={onDragEnter}
      onDragOver={(e) => {
        if (Array.from(e.dataTransfer.types).includes('Files')) {
          e.preventDefault()
          e.dataTransfer.dropEffect = 'copy'
        }
      }}
      onDragLeave={onDragLeave}
      onDrop={(e) => {
        if (!canFiles) return
        onDrop(e)
      }}
    >
      <div className="wos-wallpaper" style={wallpaperStyle(wallpaper)} aria-hidden />
      {wallpaper.kind === 'video' && wallpaper.value ? (
        <video
          key={wallpaper.value}
          className="wos-wallpaper-video"
          src={wallpaper.value}
          autoPlay
          muted
          loop
          playsInline
          aria-hidden
        />
      ) : null}
      {/* Hiệu ứng thời tiết (trên wallpaper, dưới icon) */}
      <WeatherEngine />
      <MenuBar />
      {!isMobile && <DesktopIcons />}
      {!isMobile && <WidgetLayer />}
      {!isMobile && <DesktopPetLayer />}

      {/* Tầng cửa sổ */}
      <div className="contents">
        {windows.map((w) => (
          <WindowFrame key={w.id} win={w} />
        ))}
      </div>

      {/* Overlay preview vùng snap (kéo cửa sổ sát biên) */}
      <SnapOverlay />

      {/* Khung chọn marquee (kéo chuột trái trên nền desktop) */}
      {marquee ? (
        <div
          className="pointer-events-none fixed z-[38] rounded-[3px] border border-sky-300/90 bg-sky-400/15"
          style={{
            left: Math.min(marquee.x0, marquee.x1),
            top: Math.min(marquee.y0, marquee.y1),
            width: Math.abs(marquee.x1 - marquee.x0),
            height: Math.abs(marquee.y1 - marquee.y0),
            boxShadow: '0 0 0 1px rgba(255,255,255,0.35) inset',
          }}
          aria-hidden
        />
      ) : null}

      {/* Số đối tượng đang chọn nhóm */}
      {sel && (sel.apps.length > 0 || sel.files.length > 0) && !marquee ? (
        <div className="pointer-events-none fixed bottom-24 left-1/2 z-[38] -translate-x-1/2 rounded-full bg-sky-500/85 px-3.5 py-1 text-[11.5px] font-medium text-white shadow-lg backdrop-blur-sm">
          Đã chọn {sel.apps.length + sel.files.length} đối tượng — kéo để di chuyển cả nhóm · chuột phải để mở tất cả · Esc để bỏ chọn
        </div>
      ) : null}

      {launchpadOpen ? <Launchpad /> : null}
      {isMobile ? <MobileTabBar /> : <Dock />}
      <CommandPalette />
      {switcherOpen ? <AltTabSwitcher /> : null}

      {/* Vùng thả tệp — kéo file từ máy thật vào */}
      {dropActive ? (
        <div
          className="wos-drop-overlay pointer-events-none fixed inset-3 z-[44] flex flex-col items-center justify-center gap-4 rounded-3xl border-2 border-dashed border-white/70"
          aria-live="polite"
        >
          <CloudUpload className="h-16 w-16 text-white drop-shadow-lg" />
          <p className="rounded-full bg-black/45 px-5 py-2 text-[15px] font-semibold text-white backdrop-blur-sm">
            Thả tệp vào Desktop để tải lên
          </p>
        </div>
      ) : null}

      {/* Tiến độ tải lên */}
      {uploading ? (
        <div className="wos-glass-strong fixed bottom-24 right-4 z-[46] flex w-72 flex-col gap-2 rounded-2xl p-4">
          <div className="flex items-center gap-2.5">
            <Loader2 className="h-4 w-4 animate-spin text-primary" />
            <p className="flex-1 truncate text-[13px] font-medium">Đang tải lên — {names}</p>
            <span className="text-[12px] tabular-nums text-muted-foreground">{pct}%</span>
          </div>
          <div className="h-1.5 overflow-hidden rounded-full bg-muted">
            <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${pct}%` }} />
          </div>
        </div>
      ) : null}

      {menu ? <ContextMenu state={menu} onClose={() => setMenu(null)} /> : null}
      <WallpaperPicker open={wallpaperOpen} onClose={() => setWallpaperOpen(false)} />
      <WebAppAddDialog open={webAppOpen} onClose={() => setWebAppOpen(false)} />
      {locked ? <LockScreen /> : null}
    </div>
  )
}
