'use client'

/**
 * DesktopPetLayer — render các plugin kind='pet' (nhân vật chạy trên desktop).
 * Layer nằm NGAY SAU wallpaper trong DOM (trước icon) → pet không che icon file/app:
 * nó tương tác vật lý (né, nhảy lên ngồi) thay vì đè lên. Pet tự quản vị trí qua rAF.
 * v5.1: nút "ẩn gợi ý" hoạt động thật (thêm pointer-events-auto — bug cũ: cha có
 * pointer-events:none nên nút không bao giờ nhận click); tuỳ chọn bật/tắt nhân vật
 * theo tài khoản (Settings → Appearance → Nhân vật desktop).
 */
import { useEffect, useState } from 'react'
import { useWos } from '@/core/client/wos-store'
import { runPlugin, getPluginPet, isPluginFailed } from './plugin-runtime'
import type { PluginMeta } from './plugin-runtime'
import { Puzzle, TriangleAlert } from 'lucide-react'

function PetHost({ meta }: { meta: PluginMeta }) {
  const [state, setState] = useState<'loading' | 'ready' | 'error'>('loading')
  const [error, setError] = useState('')

  useEffect(() => {
    setState('loading')
    const r = runPlugin(meta)
    if (isPluginFailed(meta.slug)) {
      setError(r.error || 'Không chạy được plugin')
      setState('error')
      return
    }
    setState(getPluginPet(meta.slug) ? 'ready' : 'error')
  }, [meta])

  const pet = getPluginPet(meta.slug)
  if (state === 'error' || !pet) {
    if (state === 'loading') return null
    return (
      <div className="pointer-events-auto fixed bottom-28 left-4 z-[7] max-w-[260px] rounded-xl border border-amber-500/40 bg-amber-500/15 p-3 text-[11.5px] text-amber-700 backdrop-blur-md dark:text-amber-300">
        <p className="flex items-center gap-1.5 font-semibold">
          <TriangleAlert className="h-3.5 w-3.5" /> Plugin pet &quot;{meta.name}&quot; lỗi
        </p>
        <p className="mt-0.5 opacity-80">{error || 'Không đăng ký được nhân vật (WOS.registerPet)'}</p>
      </div>
    )
  }
  const C = pet.component
  return <C />
}

export function DesktopPetLayer() {
  const plugins = useWos((s) => s.plugins)
  const petCfg = useWos((s) => s.pet)
  const pets = plugins.filter((p) => p.kind === 'pet' && p.enabled)
  if (!petCfg.enabled || pets.length === 0) return null
  return (
    <div className="pointer-events-none fixed inset-0 z-[2]" aria-label="Nhân vật desktop">
      {pets.map((p) => (
        <div key={p.slug} className="pointer-events-none contents">
          <PetHost meta={p} />
        </div>
      ))}
      <PetHint count={pets.length} />
    </div>
  )
}

function PetHint({ count }: { count: number }) {
  const [seen, setSeen] = useState(true)
  useEffect(() => {
    try {
      setSeen(localStorage.getItem('wos_pet_hint') === '1')
    } catch {
      setSeen(true)
    }
  }, [])
  if (seen || count === 0) return null
  return (
    <button
      // FIX: cha có pointer-events:none → nút PHẢI tự khai pointer-events:auto
      // (trước đây thiếu dòng này nên "Bấm để ẩn gợi ý này" không bao giờ phản hồi)
      className="pointer-events-auto fixed bottom-28 left-4 z-[7] flex max-w-[300px] items-start gap-2 rounded-xl border border-border bg-card/90 p-3 text-left text-[11.5px] text-muted-foreground shadow-lg backdrop-blur-md transition-transform hover:scale-[1.01]"
      onClick={() => {
        try {
          localStorage.setItem('wos_pet_hint', '1')
        } catch {
          /* quota */
        }
        setSeen(true)
      }}
    >
      <Puzzle className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
      <span>
        Nhân vật desktop đang chạy — kéo thả để bê đi, nó tự né/nhảy lên icon tệp, thỉnh thoảng
        còn &quot;nghĩ&quot; ra thông báo mới trong bong bóng truyện tranh. Bấm để ẩn gợi ý này.
      </span>
    </button>
  )
}
