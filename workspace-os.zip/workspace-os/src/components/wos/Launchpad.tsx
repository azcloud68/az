'use client'

/**
 * Launchpad — màn hình app toàn màn (blur nền), tìm kiếm nhanh, mở app.
 * v6.3: right-click từng app → menu (Mở / Ghim-Bỏ ghim Dock / admin: tắt plugin)
 * — ghim được MỌI app (module + plugin) như yêu cầu tuỳ biến Dock.
 */
import { useEffect, useMemo, useState } from 'react'
import { useWos } from '@/core/client/wos-store'
import { useWindows } from '@/core/client/window-store'
import { AppIcon, useAppOverrides } from './ModuleIcon'
import { ContextMenu, openCtx, type CtxMenuState } from './ContextMenu'
import { useToggleDockPin, useDockDefaultIds } from './dock-utils'
import { Search, X, Pin, PinOff, Puzzle, ChevronUp } from 'lucide-react'

export function Launchpad() {
  const modules = useWos((s) => s.modules)
  const plugins = useWos((s) => s.plugins)
  const user = useWos((s) => s.user)
  const dockPinned = useWos((s) => s.dockPinned)
  const defaultDockIds = useDockDefaultIds()
  const isAdmin = user?.role === 'admin'
  const openApp = useWindows((s) => s.openApp)
  const setLaunchpad = useWindows((s) => s.setLaunchpad)
  const { iconOverrides, iconColors } = useAppOverrides()
  const toggleDockPin = useToggleDockPin()
  const patchPlugin = useWos((s) => s.patchPlugin)
  const [q, setQ] = useState('')
  const [menu, setMenu] = useState<CtxMenuState | null>(null)

  const apps = useMemo(() => {
    const list = [
      ...modules
        .filter(
          (m) =>
            m.enabled &&
            (m.section !== 'admin' || user?.role === 'admin') &&
            m.name.toLowerCase().includes(q.toLowerCase()),
        )
        .sort((a, b) => a.order - b.order),
      // plugin app cài thêm (kind=app, đang bật) — xuất hiện như app gốc
      ...plugins
        .filter((p) => p.enabled && p.kind === 'app' && p.name.toLowerCase().includes(q.toLowerCase()))
        .map((p) => ({
          id: p.slug,
          name: p.name,
          icon: p.icon,
          color: p.color,
          order: p.order,
          description: p.description,
          isPlugin: true,
        })),
    ]
    return list
  }, [modules, plugins, q, user])

  // Escape đóng
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setLaunchpad(false)
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [setLaunchpad])

  /** app có đang được ghim trên Dock không (null = mặc định theo showDock) */
  const isPinned = (id: string) => {
    if (dockPinned) return dockPinned.includes(id)
    return defaultDockIds.includes(id)
  }

  const menuFor = (id: string, name: string, isPlugin: boolean) => {
    const pinned = isPinned(id)
    const items = [
      { label: `Mở ${name}`, icon: ChevronUp, onClick: () => openApp(id) },
      {
        label: pinned ? 'Bỏ ghim khỏi Dock' : 'Ghim vào Dock',
        icon: pinned ? PinOff : Pin,
        onClick: () => toggleDockPin(id, !pinned),
      },
    ]
    if (isPlugin && isAdmin) {
      items.push({
        label: 'Tắt / mở plugin',
        icon: Puzzle,
        onClick: () => {
          const p = useWos.getState().plugins.find((x) => x.slug === id)
          if (p) void patchPlugin(id, { enabled: !p.enabled })
        },
      })
    }
    return items
  }

  return (
    <div
      className="wos-launchpad fixed inset-0 z-[45] flex flex-col items-center overflow-hidden pt-16 pb-28"
      role="dialog"
      aria-label="Launchpad — tất cả ứng dụng"
      onClick={(e) => e.target === e.currentTarget && setLaunchpad(false)}
    >
      <button
        onClick={() => setLaunchpad(false)}
        className="absolute right-4 top-11 flex h-9 w-9 items-center justify-center rounded-full bg-white/15 text-white transition hover:bg-white/25"
        aria-label="Đóng Launchpad"
      >
        <X className="h-4 w-4" />
      </button>

      <div className="relative mb-8">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/60" />
        <input
          autoFocus
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Tìm ứng dụng…"
          className="h-9 w-72 rounded-full border border-white/20 bg-white/15 pl-9 pr-3 text-[13px] text-white placeholder-white/50 outline-none transition focus:bg-white/25"
          aria-label="Tìm ứng dụng"
        />
      </div>

      <div className="wos-scroll w-full max-w-4xl flex-1 overflow-y-auto px-8">
        <div className="grid grid-cols-3 gap-x-3 gap-y-6 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-7">
          {apps.map((m) => {
            const color = iconColors[m.id] || m.color
            const hasEmojiOverride = iconOverrides[m.id]?.type === 'emoji'
            return (
              <button
                key={m.id}
                onClick={() => {
                  openApp(m.id)
                  setLaunchpad(false)
                }}
                onContextMenu={(e) => openCtx(e, setMenu, menuFor(m.id, m.name, Boolean((m as { isPlugin?: boolean }).isPlugin)))}
                className="group flex flex-col items-center gap-2"
                aria-label={`Mở ${m.name}`}
              >
                <span
                  className="flex h-[64px] w-[64px] items-center justify-center rounded-[24%] text-white shadow-xl transition-transform duration-150 group-hover:scale-110 group-active:scale-95"
                  style={{
                    background: hasEmojiOverride ? 'rgba(255,255,255,0.18)' : `linear-gradient(145deg, ${color}, ${color}bb)`,
                    boxShadow: hasEmojiOverride ? 'none' : '0 10px 24px rgba(0,0,0,0.4), inset 0 1px 1px rgba(255,255,255,0.45)',
                  }}
                >
                  <AppIcon moduleId={m.id} icon={m.icon} px={34} className="h-8 w-8" />
                </span>
                <span className="flex items-center gap-1">
                  {isPinned(m.id) ? (
                    <Pin className="h-3 w-3 text-white/70" aria-label="Đã ghim trên Dock" />
                  ) : null}
                  <span className="max-w-full truncate text-[12.5px] font-medium text-white drop-shadow-[0_1px_3px_rgba(0,0,0,0.9)]">
                    {m.name}
                  </span>
                </span>
              </button>
            )
          })}
          {apps.length === 0 ? (
            <p className="col-span-7 py-8 text-center text-[13px] text-white/60">Không có ứng dụng nào khớp.</p>
          ) : null}
        </div>
      </div>

      {menu ? <ContextMenu state={menu} onClose={() => setMenu(null)} /> : null}
    </div>
  )
}
