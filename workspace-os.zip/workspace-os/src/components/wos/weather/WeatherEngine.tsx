'use client'

/**
 * WeatherEngine — hiệu ứng thời tiết THỰC trên nền desktop (canvas 2D):
 * mưa (rơi + bung toé), gió (lá + vệt gió), nắng (tia sáng + bụi li ti),
 * bão (mưa xiên nặng + chớp sáng + tối màn), tuyết (bông lượn), mây (trôi mềm).
 *
 * - Chế độ auto: lấy thời tiết thật theo lat/lon (/api/core/weather, poll 10 phút)
 *   → map mã WMO + tốc độ gió → cảnh + độ xiên mưa.
 * - Chế độ manual: ép cảnh theo cấu hình Settings → Appearance → Thời tiết.
 * - Tầng canvas z-[2]: trên wallpaper (z-1), dưới icon (z-6)/widget (z-5)/cửa sổ (10+).
 * - Hiệu năng Orange Pi: DPR ≤ 1.5, số hạt theo diện tích màn, dừng khi tab ẩn,
 *   dt clamp 50ms, không chạy trên mobile.
 */
import { useEffect, useRef } from 'react'
import { useWos, type AtmosphereConfig, type AtmosEffect } from '@/core/client/wos-store'
import { useIsMobile } from '@/hooks/use-mobile'
import { api } from '@/core/client/api'
import { useSyncExternalStore } from 'react'

export type SceneKind = 'sunny' | 'clouds' | 'rain' | 'storm' | 'snow' | 'wind'

export interface Scene {
  kind: SceneKind
  /** hệ số cường độ hạt */
  intensity: number
  /** gió ngang 0..1 (độ xiên mưa / trôi tuyết / lá) */
  wind: number
}

interface AutoWeather {
  weathercode: number
  windspeed: number
  temperature: number | null
}

/** WMO weather code + tốc độ gió → cảnh hiển thị */
export function wmoToScene(code: number, windKmh: number): Scene {
  let kind: SceneKind
  if (code >= 95) kind = 'storm'
  else if ([65, 67, 82].includes(code)) kind = 'storm' // mưa to / mưa rào dữ dội
  else if ([51, 53, 55, 56, 57, 61, 63, 66, 80, 81].includes(code)) kind = 'rain'
  else if ([71, 73, 75, 77, 85, 86].includes(code)) kind = 'snow'
  else if ([2, 3, 45, 48].includes(code)) kind = 'clouds'
  else kind = 'sunny' // 0, 1 — quang / ít mây

  const wind = Math.min(1, Math.max(0, (windKmh - 8) / 40))
  if (kind === 'sunny' && windKmh >= 30) kind = 'wind'
  if (kind === 'clouds' && windKmh >= 42) kind = 'wind'

  let intensity = 1
  if (kind === 'rain') intensity = [51, 61, 80].includes(code) ? 0.7 : 1
  if (kind === 'storm') intensity = 1.35
  if (kind === 'snow') intensity = [71, 85].includes(code) ? 0.7 : 1.1
  return { kind, intensity, wind }
}

const INTENSITY_FACTOR: Record<AtmosphereConfig['intensity'], number> = {
  light: 0.55,
  normal: 1,
  strong: 1.7,
}

// ---------------------------------------------------------------------------
// Nguồn thời tiết auto — dùng useSyncExternalStore để KHÔNG re-render WeatherEngine
// mỗi lần poll (canvas tự vẽ), chỉ re-render khi cảnh đổi kind.
// ---------------------------------------------------------------------------
let autoWeather: AutoWeather | null = null
const weatherListeners = new Set<() => void>()

function setAutoWeather(w: AutoWeather | null) {
  autoWeather = w
  weatherListeners.forEach((l) => l())
}

let pollTimer: ReturnType<typeof setInterval> | null = null
let pollKey = ''

function subscribeAutoWeather(key: string, cb: () => void): () => void {
  // (re) khởi động poll khi có subscriber đầu tiên hoặc đổi toạ độ
  if (pollKey !== key || !pollTimer) {
    if (pollTimer) clearInterval(pollTimer)
    pollKey = key
    const [lat, lon] = key.split('|')
    const load = async () => {
      try {
        const d = await api<AutoWeather>(`/api/core/weather?lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lon)}`)
        if (typeof d.weathercode === 'number') setAutoWeather(d)
      } catch { /* giữ dữ liệu cũ */ }
    }
    void load()
    pollTimer = setInterval(load, 10 * 60_000)
  }
  // QUAN TRỌNG: đăng ký đúng callback React (cb) — không thì khi dữ liệu tới
  // React không re-render để đọc snapshot mới
  weatherListeners.add(cb)
  return () => {
    weatherListeners.delete(cb)
    if (weatherListeners.size === 0 && pollTimer) {
      clearInterval(pollTimer)
      pollTimer = null
      pollKey = ''
    }
  }
}

function snapshotAutoWeather(): string {
  // snapshot dạng chuỗi để so sánh shallow — chỉ đổi khi giá trị đổi
  if (!autoWeather) return ''
  return `${autoWeather.weathercode}|${autoWeather.windspeed}`
}

function getAutoWeather(): AutoWeather | null {
  return autoWeather
}

interface Drop { x: number; y: number; v: number; len: number; depth: number }
interface Flake { x: number; y: number; r: number; v: number; phase: number; tw: number }
interface Splash { x: number; y: number; t: number }
interface Mote { x: number; y: number; vx: number; vy: number; r: number; tw: number }
interface Leaf { x: number; y: number; vx: number; vy: number; rot: number; vr: number; size: number; hue: number; phase: number }
interface CloudPuff { x: number; y: number; w: number; h: number; v: number; alpha: number }

interface Lightning {
  bolt: { x: number; y: number }[] | null
  flash: number
  nextAt: number
}

/** Vẽ 1 tia sét zigzag từ đỉnh màn xuống khoảng giữa màn */
function makeBolt(w: number, h: number): { x: number; y: number }[] {
  const pts: { x: number; y: number }[] = []
  let x = w * (0.2 + Math.random() * 0.6)
  let y = -10
  const target = h * (0.45 + Math.random() * 0.2)
  const segs = 8 + Math.floor(Math.random() * 5)
  for (let i = 0; i < segs && y < target; i++) {
    x += (Math.random() - 0.5) * 70
    y += (target / segs) * (0.7 + Math.random() * 0.6)
    pts.push({ x, y })
  }
  return pts
}

/** Renderer chạy trên 1 canvas — khởi tạo 1 lần, scene thay đổi qua setScene */
class WeatherRenderer {
  private ctx: CanvasRenderingContext2D
  private raf = 0
  private last = 0
  private running = false
  private w = 0
  private h = 0
  private drops: Drop[] = []
  private splashes: Splash[] = []
  private flakes: Flake[] = []
  private motes: Mote[] = []
  private leaves: Leaf[] = []
  private clouds: CloudPuff[] = []
  private lightning: Lightning = { bolt: null, flash: 0, nextAt: 0 }
  private time = 0
  private fade = 0
  scene: Scene = { kind: 'rain', intensity: 1, wind: 0.3 }

  constructor(private canvas: HTMLCanvasElement) {
    this.ctx = canvas.getContext('2d', { alpha: true })!
    this.resize()
  }

  resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 1.5)
    this.w = window.innerWidth
    this.h = window.innerHeight
    this.canvas.width = Math.round(this.w * dpr)
    this.canvas.height = Math.round(this.h * dpr)
    this.canvas.style.width = `${this.w}px`
    this.canvas.style.height = `${this.h}px`
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
  }

  private newDrop(spread: boolean): Drop {
    const depth = 0.35 + Math.random() * 0.65
    return {
      x: Math.random() * this.w * (spread ? 1.25 : 1.15) - this.w * 0.1,
      y: spread ? Math.random() * this.h : -30 - Math.random() * 80,
      v: (420 + Math.random() * 380) * (0.55 + depth * 0.6),
      len: (9 + Math.random() * 16) * depth,
      depth,
    }
  }

  private newLeaf(spread: boolean): Leaf {
    return {
      x: spread ? Math.random() * this.w : -30 - Math.random() * 60,
      y: Math.random() * this.h * 0.85,
      vx: 120 + Math.random() * 190, vy: -30 + Math.random() * 70,
      rot: Math.random() * Math.PI, vr: (Math.random() - 0.5) * 7,
      size: 5 + Math.random() * 7, hue: 18 + Math.random() * 32,
      phase: Math.random() * Math.PI * 2,
    }
  }

  /** (tái) sinh hạt theo cảnh hiện tại */
  private seed() {
    const area = (this.w * this.h) / (1440 * 800)
    const n = Math.max(0.5, area)
    const k = this.scene.kind
    const inten = this.scene.intensity

    if (k === 'rain' || k === 'storm') {
      const count = Math.round((k === 'storm' ? 150 : 85) * n * inten)
      this.drops = Array.from({ length: count }, () => this.newDrop(true))
      this.splashes = []
    } else this.drops = []

    if (k === 'snow') {
      const count = Math.round(70 * n * inten)
      this.flakes = Array.from({ length: count }, () => ({
        x: Math.random() * this.w, y: Math.random() * this.h,
        r: 1.2 + Math.random() * 2.6, v: 14 + Math.random() * 26,
        phase: Math.random() * Math.PI * 2, tw: 0,
      }))
    } else this.flakes = []

    if (k === 'sunny') {
      const count = Math.round(46 * n)
      this.motes = Array.from({ length: count }, () => ({
        x: Math.random() * this.w, y: Math.random() * this.h,
        vx: (Math.random() - 0.5) * 7, vy: (Math.random() - 0.5) * 5,
        r: 0.7 + Math.random() * 1.9, tw: Math.random() * Math.PI * 2,
      }))
    } else this.motes = []

    if (k === 'wind') {
      const count = Math.round(16 * n * inten)
      this.leaves = Array.from({ length: count }, () => this.newLeaf(true))
    } else this.leaves = []

    if (k === 'clouds' || k === 'storm') {
      const count = Math.round((k === 'storm' ? 7 : 5) * Math.max(1, n * 1.2))
      this.clouds = Array.from({ length: count }, () => ({
        x: Math.random() * this.w, y: 40 + Math.random() * this.h * 0.32,
        w: 240 + Math.random() * 340, h: 70 + Math.random() * 90,
        v: 12 + Math.random() * 20, alpha: (k === 'storm' ? 0.34 : 0.16) + Math.random() * 0.1,
      }))
    } else this.clouds = []

    this.fade = 0
    if (k === 'storm') this.lightning = { bolt: null, flash: 0, nextAt: performance.now() + 1500 + Math.random() * 2500 }
    else this.lightning = { bolt: null, flash: 0, nextAt: 0 }
  }

  start() {
    if (this.running) return
    this.running = true
    this.seed()
    this.last = performance.now()
    const step = (now: number) => {
      if (!this.running) return
      const dt = Math.min(0.05, (now - this.last) / 1000)
      this.last = now
      this.time += dt
      this.fade = Math.min(1, this.fade + dt * 1.8)
      this.update(dt)
      this.draw()
      this.raf = requestAnimationFrame(step)
    }
    this.raf = requestAnimationFrame(step)
  }

  stop() {
    this.running = false
    cancelAnimationFrame(this.raf)
  }

  setScene(scene: Scene) {
    if (scene.kind === this.scene.kind) {
      this.scene = scene
      return
    }
    this.scene = scene
    if (this.running) this.seed()
  }

  private update(dt: number) {
    const { kind, wind } = this.scene
    const wx = wind * 260

    if (kind === 'rain' || kind === 'storm') {
      const ground = this.h - 2
      for (const d of this.drops) {
        d.y += d.v * dt
        d.x += wx * dt * (0.5 + d.depth * 0.6)
        if (d.y > ground) {
          if (Math.random() < 0.5 && this.splashes.length < 90) this.splashes.push({ x: d.x, y: ground, t: 0 })
          Object.assign(d, this.newDrop(false))
        }
      }
      for (let i = this.splashes.length - 1; i >= 0; i--) {
        this.splashes[i].t += dt
        if (this.splashes[i].t > 0.42) this.splashes.splice(i, 1)
      }
      if (kind === 'storm') {
        const now = performance.now()
        if (this.lightning.flash > 0) this.lightning.flash = Math.max(0, this.lightning.flash - dt * 3.2)
        if (this.lightning.bolt && this.lightning.flash < 0.35) this.lightning.bolt = null
        if (now > this.lightning.nextAt) {
          this.lightning.bolt = makeBolt(this.w, this.h)
          this.lightning.flash = 0.9 + Math.random() * 0.35
          this.lightning.nextAt = now + 3200 + Math.random() * 6500
        }
      }
    }

    if (kind === 'snow') {
      for (const f of this.flakes) {
        f.phase += dt * (0.8 + f.r * 0.25)
        f.tw += dt * 1.5
        f.y += (f.v + wind * 40) * dt
        f.x += Math.sin(f.phase) * 18 * dt + wx * 0.35 * dt
        if (f.y > this.h + 6) { f.y = -8; f.x = Math.random() * this.w }
        if (f.x > this.w + 8) f.x = -8
        if (f.x < -8) f.x = this.w + 8
      }
    }

    if (kind === 'sunny') {
      for (const m of this.motes) {
        m.x += (m.vx + wind * 30) * dt
        m.y += m.vy * dt
        m.tw += dt * 1.6
        if (m.x < -5) m.x = this.w + 5
        if (m.x > this.w + 5) m.x = -5
        if (m.y < -5) m.y = this.h + 5
        if (m.y > this.h + 5) m.y = -5
      }
    }

    if (kind === 'wind') {
      for (const l of this.leaves) {
        l.phase += dt * 2.2
        l.x += (l.vx + wx * 1.6) * dt
        l.y += (l.vy + Math.sin(l.phase) * 46) * dt
        l.rot += l.vr * dt
        if (l.x > this.w + 40 || l.y > this.h + 40 || l.y < -60) Object.assign(l, this.newLeaf(false))
      }
    }

    if (this.clouds.length) {
      for (const c of this.clouds) {
        c.x += (c.v + wx * 0.5) * dt
        if (c.x - c.w > this.w) { c.x = -c.w; c.y = 40 + Math.random() * this.h * 0.3 }
      }
    }
  }

  private draw() {
    const ctx = this.ctx
    const { w, h } = this
    ctx.clearRect(0, 0, w, h)
    const { kind, intensity } = this.scene
    const globalAlpha = this.fade

    // ===== mây trôi mềm (mây / bão) =====
    if (this.clouds.length) {
      for (const c of this.clouds) {
        const bright = kind === 'storm' ? 0.6 : 0.96
        ctx.save()
        ctx.translate(c.x, c.y)
        ctx.scale(1, Math.max(0.3, c.h / (c.w / 2)))
        const g = ctx.createRadialGradient(0, 0, 0, 0, 0, c.w / 2)
        g.addColorStop(0, `rgba(${Math.round(255 * bright)},${Math.round(255 * bright)},${Math.round(255 * bright)},${c.alpha * globalAlpha})`)
        g.addColorStop(1, 'rgba(255,255,255,0)')
        ctx.fillStyle = g
        ctx.beginPath()
        ctx.arc(0, 0, c.w / 2, 0, Math.PI * 2)
        ctx.fill()
        ctx.restore()
      }
    }

    // ===== mưa / bão =====
    if (kind === 'rain' || kind === 'storm') {
      ctx.lineCap = 'round'
      const slant = this.scene.wind * 0.42
      for (const d of this.drops) {
        const a = (kind === 'storm' ? 0.34 : 0.27) * (0.5 + d.depth * 0.5) * globalAlpha
        ctx.strokeStyle = `rgba(178,208,255,${a})`
        ctx.lineWidth = 1 + d.depth * 0.9
        const dx = -(d.v * slant) * (d.len / (d.v || 1))
        ctx.beginPath()
        ctx.moveTo(d.x, d.y)
        ctx.lineTo(d.x + dx, d.y + d.len)
        ctx.stroke()
      }
      for (const s of this.splashes) {
        const p = s.t / 0.42
        const r = 2 + p * 9
        ctx.strokeStyle = `rgba(190,220,255,${(0.36 - p * 0.34) * globalAlpha})`
        ctx.lineWidth = 1
        ctx.beginPath()
        ctx.ellipse(s.x, s.y - 1, r, Math.max(0.5, r * 0.34), 0, Math.PI, Math.PI * 2)
        ctx.stroke()
      }
      if (kind === 'storm') {
        ctx.fillStyle = `rgba(10,16,34,${0.24 * globalAlpha})`
        ctx.fillRect(0, 0, w, h)
        const L = this.lightning
        if (L.flash > 0) {
          ctx.fillStyle = `rgba(226,238,255,${Math.min(0.5, L.flash * 0.42) * globalAlpha})`
          ctx.fillRect(0, 0, w, h)
          if (L.bolt) {
            ctx.save()
            ctx.strokeStyle = `rgba(255,255,255,${Math.min(1, L.flash) * globalAlpha})`
            ctx.lineWidth = 2.6
            ctx.shadowColor = 'rgba(190,215,255,0.95)'
            ctx.shadowBlur = 22
            ctx.beginPath()
            ctx.moveTo(L.bolt[0].x, L.bolt[0].y)
            for (const p of L.bolt.slice(1)) ctx.lineTo(p.x, p.y)
            ctx.stroke()
            ctx.lineWidth = 1.4
            ctx.strokeStyle = `rgba(225,238,255,${Math.min(0.9, L.flash) * globalAlpha})`
            const mid = L.bolt[Math.floor(L.bolt.length / 2)]
            if (mid) {
              ctx.beginPath()
              ctx.moveTo(mid.x, mid.y)
              ctx.lineTo(mid.x + (Math.random() - 0.5) * 90, mid.y + 60 + Math.random() * 60)
              ctx.stroke()
            }
            ctx.restore()
          }
        }
      }
    }

    // ===== tuyết =====
    if (kind === 'snow') {
      for (const f of this.flakes) {
        const tw = 0.55 + Math.sin(f.tw) * 0.25
        ctx.fillStyle = `rgba(255,255,255,${(0.5 + f.r * 0.14) * tw * globalAlpha})`
        ctx.beginPath()
        ctx.arc(f.x, f.y, f.r, 0, Math.PI * 2)
        ctx.fill()
      }
      ctx.fillStyle = `rgba(200,225,255,${0.045 * intensity * globalAlpha})`
      ctx.fillRect(0, 0, w, h)
    }

    // ===== nắng =====
    if (kind === 'sunny') {
      const cx = w * 0.84
      const cy = h * 0.12
      ctx.save()
      ctx.globalCompositeOperation = 'lighter'
      ctx.translate(cx, cy)
      ctx.rotate(this.time * 0.03)
      const len = Math.max(w, h) * 1.25
      for (let i = 0; i < 11; i++) {
        const ang = (i / 11) * Math.PI * 2
        const spread = 0.1 + 0.05 * Math.sin(this.time * 0.35 + i)
        const g = ctx.createLinearGradient(0, 0, Math.cos(ang) * len, Math.sin(ang) * len)
        g.addColorStop(0, `rgba(255,214,140,${0.085 * globalAlpha})`)
        g.addColorStop(0.6, `rgba(255,214,140,${0.028 * globalAlpha})`)
        g.addColorStop(1, 'rgba(255,214,140,0)')
        ctx.fillStyle = g
        ctx.beginPath()
        ctx.moveTo(0, 0)
        ctx.arc(0, 0, len, ang - spread, ang + spread)
        ctx.closePath()
        ctx.fill()
      }
      ctx.restore()
      const halo = ctx.createRadialGradient(cx, cy, 0, cx, cy, 250)
      halo.addColorStop(0, `rgba(255,225,170,${0.3 * globalAlpha})`)
      halo.addColorStop(0.35, `rgba(255,214,140,${0.1 * globalAlpha})`)
      halo.addColorStop(1, 'rgba(255,214,140,0)')
      ctx.fillStyle = halo
      ctx.fillRect(cx - 260, cy - 260, 520, 520)
      ctx.save()
      ctx.globalCompositeOperation = 'lighter'
      for (const m of this.motes) {
        const a = (0.25 + Math.sin(m.tw) * 0.18) * globalAlpha
        ctx.fillStyle = `rgba(255,244,214,${Math.max(0, a)})`
        ctx.beginPath()
        ctx.arc(m.x, m.y, m.r, 0, Math.PI * 2)
        ctx.fill()
      }
      ctx.restore()
      ctx.fillStyle = `rgba(255,196,110,${0.05 * globalAlpha})`
      ctx.fillRect(0, 0, w, h)
    }

    // ===== gió =====
    if (kind === 'wind') {
      ctx.lineCap = 'round'
      const nStreak = 7
      for (let i = 0; i < nStreak; i++) {
        const base = ((this.time * (0.16 + i * 0.022) + i / nStreak) % 1) * 1.4 - 0.2
        const x0 = base * (w + 400) - 200
        const y = (h * (i + 0.5) / nStreak) + Math.sin(this.time * 1.7 + i * 2.1) * 34
        const g = ctx.createLinearGradient(x0, y, x0 + 260, y - 26)
        g.addColorStop(0, 'rgba(255,255,255,0)')
        g.addColorStop(0.5, `rgba(255,255,255,${0.1 * globalAlpha})`)
        g.addColorStop(1, 'rgba(255,255,255,0)')
        ctx.strokeStyle = g
        ctx.lineWidth = 1.6
        ctx.beginPath()
        ctx.moveTo(x0, y)
        ctx.bezierCurveTo(x0 + 90, y - 16, x0 + 170, y - 8, x0 + 260, y - 26)
        ctx.stroke()
      }
      for (const l of this.leaves) {
        ctx.save()
        ctx.translate(l.x, l.y)
        ctx.rotate(l.rot)
        ctx.fillStyle = `hsla(${l.hue}, 68%, 52%, ${0.75 * globalAlpha})`
        ctx.beginPath()
        ctx.ellipse(0, 0, l.size, l.size * 0.45, 0, 0, Math.PI * 2)
        ctx.fill()
        ctx.fillStyle = `hsla(${l.hue - 12}, 60%, 38%, ${0.5 * globalAlpha})`
        ctx.beginPath()
        ctx.ellipse(-l.size * 0.3, 0, l.size * 0.4, l.size * 0.2, 0.5, 0, Math.PI * 2)
        ctx.fill()
        ctx.restore()
      }
    }

    // ===== mây mù dịu =====
    if (kind === 'clouds') {
      ctx.fillStyle = `rgba(226,232,240,${0.05 * globalAlpha})`
      ctx.fillRect(0, 0, w, h)
    }
  }
}

/** Map hiệu ứng thủ công → Scene */
function manualScene(effect: Exclude<AtmosEffect, 'auto'>): Scene | null {
  switch (effect) {
    case 'sunny': return { kind: 'sunny', intensity: 1, wind: 0.12 }
    case 'clouds': return { kind: 'clouds', intensity: 1, wind: 0.2 }
    case 'rain': return { kind: 'rain', intensity: 1, wind: 0.35 }
    case 'storm': return { kind: 'storm', intensity: 1.3, wind: 0.85 }
    case 'snow': return { kind: 'snow', intensity: 1, wind: 0.25 }
    case 'wind': return { kind: 'wind', intensity: 1, wind: 1 }
    case 'off': return null
  }
}

/** Bảng mô tả nhanh cảnh đang chạy (hiện thị ở UI/Debug) */
export const SCENE_LABEL: Record<SceneKind, string> = {
  sunny: 'Nắng',
  clouds: 'Nhiều mây',
  rain: 'Mưa',
  storm: 'Dông bão',
  snow: 'Tuyết',
  wind: 'Gió',
}

/**
 * WeatherEngine — render <canvas> hiệu ứng. Lưu ý hiệu năng:
 * - Poll thời tiết dùng store ngoài React (useSyncExternalStore, snapshot string)
 * - Canvas render hoàn toàn trong class, KHÔNG setState mỗi frame
 */
export function WeatherEngine() {
  const atmosphere = useWos((s) => s.atmosphere)
  const isMobile = useIsMobile()
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const rendererRef = useRef<WeatherRenderer | null>(null)

  const autoMode = atmosphere.enabled && atmosphere.effect === 'auto'
  // Subscription: re-render khi dữ liệu thời tiết mới tới (giá trị trả về không cần dùng)
  useSyncExternalStore(
    (cb) => subscribeAutoWeather(autoMode ? `${atmosphere.lat}|${atmosphere.lon}` : 'off', cb),
    snapshotAutoWeather,
    () => '',
  )
  const weather = getAutoWeather()

  // Tính scene mục tiêu
  let scene: Scene | null = null
  if (atmosphere.enabled) {
    const factor = INTENSITY_FACTOR[atmosphere.intensity] ?? 1
    if (atmosphere.effect === 'auto') {
      if (weather) scene = wmoToScene(weather.weathercode, weather.windspeed)
    } else {
      scene = manualScene(atmosphere.effect)
    }
    if (scene) scene = { ...scene, intensity: scene.intensity * factor }
  }

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas || !scene || isMobile) return
    let renderer = rendererRef.current
    if (!renderer) {
      renderer = new WeatherRenderer(canvas)
      rendererRef.current = renderer
    }
    renderer.setScene(scene)
    renderer.start()
    const onResize = () => renderer?.resize()
    window.addEventListener('resize', onResize)
    const onVis = () => {
      if (document.hidden) renderer?.stop()
      else renderer.start()
    }
    document.addEventListener('visibilitychange', onVis)
    return () => {
      window.removeEventListener('resize', onResize)
      document.removeEventListener('visibilitychange', onVis)
      renderer?.stop()
    }
    // deps: chỉ restart khi kind/intensity/wind đổi — tránh loop do scene là object mới mỗi render
  }, [scene?.kind, scene?.intensity, scene?.wind, isMobile])

  if (!scene || isMobile) return null

  return (
    <canvas
      ref={canvasRef}
      className="pointer-events-none fixed inset-0 z-[2]"
      aria-hidden
    />
  )
}
