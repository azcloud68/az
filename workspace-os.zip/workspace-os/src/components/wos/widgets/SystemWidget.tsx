'use client'

/** SystemWidget — CPU / RAM / Đĩa của máy chạy WOS (poll /api/core/stats). */
import { useEffect, useState } from 'react'
import { api } from '@/core/client/api'
import { Cpu, HardDrive, MemoryStick } from 'lucide-react'

interface Stats {
  cpu: number
  mem: { percent: number; used: number; total: number }
  disk: { percent: number; used: number; total: number }
}

function Bar({ pct, label, value, icon: Icon }: { pct: number; label: string; value: string; icon: typeof Cpu }) {
  const color = pct > 85 ? 'bg-rose-500' : pct > 60 ? 'bg-amber-400' : 'bg-emerald-500'
  return (
    <div className="flex items-center gap-2.5">
      <Icon className="h-4 w-4 shrink-0 text-muted-foreground" />
      <div className="min-w-0 flex-1">
        <div className="mb-1 flex justify-between text-[10.5px]">
          <span className="font-medium">{label}</span>
          <span className="tabular-nums text-muted-foreground">{value}</span>
        </div>
        <div className="h-1.5 overflow-hidden rounded-full bg-muted">
          <div className={`h-full rounded-full ${color} transition-all`} style={{ width: `${Math.min(100, pct)}%` }} />
        </div>
      </div>
    </div>
  )
}

function gb(bytes: number): string {
  return `${(bytes / 1024 / 1024 / 1024).toFixed(1)}GB`
}

export default function SystemWidget() {
  const [stats, setStats] = useState<Stats | null>(null)
  useEffect(() => {
    let alive = true
    const load = () => api<Stats>('/api/core/stats').then((d) => alive && setStats(d)).catch(() => {})
    load()
    const iv = setInterval(load, 10000)
    return () => {
      alive = false
      clearInterval(iv)
    }
  }, [])

  if (!stats) {
    return (
      <div className="wos-widget-body flex items-center justify-center">
        <MemoryStick className="h-5 w-5 animate-pulse text-muted-foreground" />
      </div>
    )
  }

  return (
    <div className="wos-widget-body flex flex-col justify-center gap-2.5 p-3.5">
      <Bar pct={stats.cpu} label="CPU" value={`${Math.round(stats.cpu)}%`} icon={Cpu} />
      <Bar pct={stats.mem.percent} label="RAM" value={`${gb(stats.mem.used)} / ${gb(stats.mem.total)}`} icon={MemoryStick} />
      <Bar pct={stats.disk.percent} label="Đĩa" value={`${gb(stats.disk.used)} / ${gb(stats.disk.total)}`} icon={HardDrive} />
    </div>
  )
}
