'use client'

/**
 * Widget Registry — định nghĩa các widget desktop có thể thêm vào màn hình.
 * WidgetLayer + Desktop menu "Thêm Widget" đọc từ đây.
 */
import type { LucideIcon } from 'lucide-react'
import { StickyNote, CloudSun, Clock, Activity, ClipboardList, CalendarRange } from 'lucide-react'

export interface WidgetDef {
  type: string
  title: string
  icon: LucideIcon
  defaultW: number
  defaultH: number
  minW?: number
  minH?: number
}

export const WIDGET_DEFS: WidgetDef[] = [
  { type: 'note', title: 'Ghi chú nhanh', icon: StickyNote, defaultW: 220, defaultH: 200, minW: 160, minH: 140 },
  { type: 'weather', title: 'Thời tiết', icon: CloudSun, defaultW: 230, defaultH: 180, minW: 180, minH: 150 },
  { type: 'clock', title: 'Đồng hồ & Lịch', icon: Clock, defaultW: 230, defaultH: 250, minW: 190, minH: 210 },
  { type: 'system', title: 'CPU / RAM / Đĩa', icon: Activity, defaultW: 250, defaultH: 160, minW: 200, minH: 130 },
  { type: 'tasks', title: 'Việc hôm nay', icon: ClipboardList, defaultW: 250, defaultH: 240, minW: 200, minH: 170 },
  { type: 'week', title: 'Timeline công việc tuần', icon: CalendarRange, defaultW: 360, defaultH: 420, minW: 280, minH: 300 },
]

export function widgetDef(type: string): WidgetDef | undefined {
  return WIDGET_DEFS.find((w) => w.type === type)
}
