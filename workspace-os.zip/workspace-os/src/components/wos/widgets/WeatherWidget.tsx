'use client'

/**
 * WeatherWidget — thời tiết open-meteo (server proxy /api/core/weather, không API key).
 * Thành phố geocode trực tiếp từ trình duyệt; lưu vào config widget.
 */
import { useCallback, useEffect, useState } from 'react'
import { api } from '@/core/client/api'
import { Pencil, Search, Loader2, Wind } from 'lucide-react'

const WMO: Record<number, { label: string; icon: string }> = {
  0: { label: 'Trời quang', icon: '☀️' }, 1: { label: 'Ít mây', icon: '🌤️' }, 2: { label: 'Có mây', icon: '⛅' },
  3: { label: 'Nhiều mây', icon: '☁️' }, 45: { label: 'Sương mù', icon: '🌫️' }, 48: { label: 'Sương giá', icon: '🌫️' },
  51: { label: 'Mưa phùn nhẹ', icon: '🌦️' }, 53: { label: 'Mưa phùn', icon: '🌦️' }, 55: { label: 'Mưa phùn nhiều', icon: '🌧️' },
  61: { label: 'Mưa nhẹ', icon: '🌦️' }, 63: { label: 'Mưa', icon: '🌧️' }, 65: { label: 'Mưa to', icon: '⛈️' },
  71: { label: 'Tuyết nhẹ', icon: '🌨️' }, 73: { label: 'Tuyết', icon: '❄️' }, 75: { label: 'Tuyết dày', icon: '❄️' },
  80: { label: 'Mưa rào nhẹ', icon: '🌦️' }, 81: { label: 'Mưa rào', icon: '🌧️' }, 82: { label: 'Mưa rào to', icon: '⛈️' },
  95: { label: 'Dông', icon: '⛈️' }, 96: { label: 'Dông kèm mưa đá', icon: '⛈️' }, 99: { label: 'Dông dữ dội', icon: '⛈️' },
}

interface GeoResult { name: string; latitude: number; longitude: string | number; country?: string }

export default function WeatherWidget({
  config,
  setConfig,
}: {
  config: Record<string, unknown>
  setConfig?: (c: Record<string, unknown>) => void
}) {
  const city = String(config.city || '')
  const [weather, setWeather] = useState<{ temperature: number; windspeed: number; weathercode: number } | null>(null)
  const [editing, setEditing] = useState(false)
  const [query, setQuery] = useState(city)
  const [results, setResults] = useState<GeoResult[]>([])
  const [searching, setSearching] = useState(false)
  const [error, setError] = useState('')

  const load = useCallback(async () => {
    const lat = String(config.lat || '10.762622')
    const lon = String(config.lon || '106.660172')
    try {
      const d = await api<{ temperature: number; windspeed: number; weathercode: number }>(
        `/api/core/weather?lat=${lat}&lon=${lon}`,
      )
      setWeather(d)
      setError('')
    } catch {
      setError('Không lấy được thời tiết')
    }
  }, [config.lat, config.lon])

  useEffect(() => {
    load()
    const iv = setInterval(load, 15 * 60000)
    return () => clearInterval(iv)
  }, [load])

  async function searchCity() {
    if (!query.trim()) return
    setSearching(true)
    try {
      const res = await fetch(
        `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(query.trim())}&count=5&language=vi`,
      )
      const data = (await res.json()) as { results?: GeoResult[] }
      setResults(data.results || [])
    } catch {
      setResults([])
    } finally {
      setSearching(false)
    }
  }

  const wmo = weather ? WMO[weather.weathercode] || { label: '—', icon: '🌡️' } : null

  return (
    <div className="wos-widget-body flex flex-col p-3">
      <div className="mb-1.5 flex items-center justify-between">
        <p className="truncate text-[12.5px] font-semibold">{city || 'Thành phố của bạn'}</p>
        <button
          onClick={() => { setEditing(!editing); setQuery(city); setResults([]) }}
          className="rounded-md p-1 text-muted-foreground hover:bg-muted hover:text-foreground"
          aria-label="Đổi thành phố"
        >
          {editing ? <Search className="h-3.5 w-3.5" /> : <Pencil className="h-3.5 w-3.5" />}
        </button>
      </div>

      {editing ? (
        <div className="space-y-1.5">
          <div className="flex gap-1">
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && searchCity()}
              placeholder="Tên thành phố…"
              className="h-8 min-w-0 flex-1 rounded-lg bg-muted px-2.5 text-[12.5px] outline-none"
              autoFocus
            />
            <button
              onClick={searchCity}
              disabled={searching}
              className="flex h-8 w-8 items-center justify-center rounded-lg bg-muted text-muted-foreground hover:text-foreground"
              aria-label="Tìm"
            >
              {searching ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Search className="h-3.5 w-3.5" />}
            </button>
          </div>
          {results.map((r) => (
            <button
              key={`${r.name}-${r.latitude}`}
              onClick={() => {
                setConfig?.({ ...config, city: r.name, lat: String(r.latitude), lon: String(r.longitude) })
                setEditing(false)
              }}
              className="w-full truncate rounded-lg bg-muted/70 px-2.5 py-1.5 text-left text-[12px] hover:bg-muted"
            >
              {r.name}
              {r.country ? `, ${r.country}` : ''}
            </button>
          ))}
          <p className="px-1 text-[10px] text-muted-foreground">Tìm & chọn thành phố để lưu</p>
        </div>
      ) : weather ? (
        <div className="flex flex-1 flex-col items-center justify-center gap-1 py-1">
          <div className="flex items-center gap-3">
            <span className="text-4xl leading-none">{wmo?.icon}</span>
            <span className="text-3xl font-bold tabular-nums">{weather.temperature}°C</span>
          </div>
          <p className="text-[11.5px] text-muted-foreground">{wmo?.label}</p>
          <p className="flex items-center gap-1 text-[10.5px] text-muted-foreground">
            <Wind className="h-3 w-3" /> Gió {weather.windspeed} km/h
          </p>
          {error && <p className="text-[10px] text-rose-500">{error}</p>}
        </div>
      ) : (
        <div className="flex flex-1 items-center justify-center">
          {error ? <p className="text-[11px] text-rose-500">{error}</p> : <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />}
        </div>
      )}
    </div>
  )
}
