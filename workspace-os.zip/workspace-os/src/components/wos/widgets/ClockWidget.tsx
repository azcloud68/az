'use client'

/** ClockWidget — đồng hồ + lịch mini kiểu macOS (đánh dấu hôm nay). */
import { useEffect, useState } from 'react'

export default function ClockWidget() {
  const [now, setNow] = useState(() => new Date())
  useEffect(() => {
    const iv = setInterval(() => setNow(new Date()), 1000)
    return () => clearInterval(iv)
  }, [])

  const days = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN']
  // tuần bắt đầu Thứ 2
  const monday = new Date(now)
  const dow = (now.getDay() + 6) % 7
  monday.setDate(now.getDate() - dow)
  const week = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(monday)
    d.setDate(monday.getDate() + i)
    return d
  })

  return (
    <div className="wos-widget-body flex flex-col items-center justify-center gap-1 p-3">
      <p className="text-4xl font-bold tabular-nums tracking-tight">
        {now.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}
        <span className="ml-1 text-lg font-medium text-muted-foreground">
          {now.toLocaleTimeString('vi-VN', { second: '2-digit' })}
        </span>
      </p>
      <p className="text-[11.5px] font-medium capitalize text-muted-foreground">
        {now.toLocaleDateString('vi-VN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
      </p>
      <div className="mt-1 grid grid-cols-7 gap-0.5 rounded-lg bg-muted/60 p-1.5">
        {days.map((d) => (
          <span key={d} className="w-6 text-center text-[9px] font-semibold text-muted-foreground">{d}</span>
        ))}
        {week.map((d) => {
          const today = d.toDateString() === now.toDateString()
          return (
            <span
              key={d.toISOString()}
              className={`flex h-6 w-6 items-center justify-center rounded-md text-[10.5px] font-medium tabular-nums ${
                today ? 'bg-primary text-primary-foreground' : 'text-foreground/75'
              }`}
            >
              {d.getDate()}
            </span>
          )
        })}
      </div>
    </div>
  )
}
