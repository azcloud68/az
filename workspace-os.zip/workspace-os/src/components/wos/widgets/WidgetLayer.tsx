'use client'

/**
 * WidgetLayer — tầng widget trên desktop kiểu macOS:
 * kéo di chuyển (titlebar), resize (góc dưới-phải), xoá.
 * v6: đọc layout trực tiếp từ Desktop Manager store (không còn prop blob/update;
 * thêm/xoá widget từ Settings → Appearance hoặc từ desktop).
 */
import { useCallback, useEffect, useRef, useState } from 'react'
import { WIDGET_DEFS, widgetDef, type WidgetDef } from './registry'
import NoteWidget from './NoteWidget'
import WeatherWidget from './WeatherWidget'
import ClockWidget from './ClockWidget'
import SystemWidget from './SystemWidget'
import TasksWidget from './TasksWidget'
import WeekWidget from './WeekWidget'
import { MENUBAR_H, DOCK_H } from '@/core/client/window-store'
import { useDesktopStore } from '@/core/client/desktop'
import { X } from 'lucide-react'

export interface WidgetInstance {
  id: string // uid
  type: string
  /** vị trí dạng PHÂN SỐ so với vùng desktop (0..1) — co giãn mọi màn hình */
  fx: number
  fy: number
  w: number
  h: number
  config: Record<string, unknown>
}

let seq = Date.now() % 100000

/** Thêm 1 widget mới lên desktop — dùng chung Settings → Appearance và menu desktop */
export function addWidgetToDesktop(type: string): void {
  const def = widgetDef(type)
  if (!def) return
  const u = usable()
  const w = Math.min(def.defaultW, u.w - 80)
  const h = Math.min(def.defaultH, u.h - 40)
  const blob = useDesktopStore.getState().blob || {}
  const n = ((blob.widgets || []) as unknown[]).length
  const offset = (n % 5) * 26
  const x = Math.max(16, Math.min(u.w - w - 20, 36 + offset))
  const y = Math.max(u.top + 12, u.top + Math.min(u.h - h - 20, 90 + offset))
  const f = toFraction(x, y)
  const inst: WidgetInstance = { id: `w-${seq++}`, type: def.type, fx: f.fx, fy: f.fy, w, h, config: {} }
  useDesktopStore.getState().update((prev) => ({ ...prev, widgets: [...((prev.widgets || []) as unknown[]), inst as unknown] }))
}

/** vùng dùng được của desktop (trừ menubar + dock) */
function usable(): { w: number; h: number; top: number } {
  const vw = window.innerWidth
  const vh = window.innerHeight
  return { w: vw, h: Math.max(200, vh - MENUBAR_H - DOCK_H), top: MENUBAR_H }
}

/** Chuyển fraction → px + CLAMP trong viewport (không bao giờ trôi ra ngoài) */
function toPx(inst: WidgetInstance): { x: number; y: number } {
  const u = usable()
  const x = Math.round(Math.max(4, Math.min(u.w - inst.w - 12, inst.fx * u.w)))
  const y = Math.round(Math.max(u.top + 4, Math.min(u.top + u.h - 60, u.top + inst.fy * u.h)))
  return { x, y }
}

/** Chuyển px → fraction (đã clamp 0..1) */
function toFraction(x: number, y: number): { fx: number; fy: number } {
  const u = usable()
  return {
    fx: Math.min(1, Math.max(0, x / u.w)),
    fy: Math.min(1, Math.max(0, (y - u.top) / u.h)),
  }
}

function clampSize(type: string, w: number, h: number): { w: number; h: number } {
  const def = widgetDef(type)
  const u = usable()
  return {
    w: Math.round(Math.max(def?.minW ?? 160, Math.min(u.w - 24, w))),
    h: Math.round(Math.max(def?.minH ?? 120, Math.min(u.h - 16, h))),
  }
}

/** Nâng cấp instance cũ (px) → fraction — chạy 1 lần */
function migrate(inst: Record<string, unknown>): WidgetInstance | null {
  if (typeof inst.fx === 'number' && typeof inst.fy === 'number') {
    return {
      id: String(inst.id || `w-${seq++}`),
      type: String(inst.type || ''),
      fx: Number(inst.fx),
      fy: Number(inst.fy),
      w: Number(inst.w) || 240,
      h: Number(inst.h) || 200,
      config: (inst.config && typeof inst.config === 'object' ? inst.config : {}) as Record<string, unknown>,
    }
  }
  if (typeof inst.x === 'number' && typeof inst.y === 'number') {
    const f = toFraction(Number(inst.x), Number(inst.y))
    return {
      id: String(inst.id || `w-${seq++}`),
      type: String(inst.type || ''),
      fx: f.fx,
      fy: f.fy,
      w: Number(inst.w) || 240,
      h: Number(inst.h) || 200,
      config: (inst.config && typeof inst.config === 'object' ? inst.config : {}) as Record<string, unknown>,
    }
  }
  return null
}

function renderWidget(inst: WidgetInstance, setConfig: (id: string, c: Record<string, unknown>) => void) {
  switch (inst.type) {
    case 'note':
      return <NoteWidget config={inst.config} />
    case 'weather':
      return <WeatherWidget config={inst.config} setConfig={(c) => setConfig(inst.id, c)} />
    case 'clock':
      return <ClockWidget />
    case 'system':
      return <SystemWidget />
    case 'tasks':
      return <TasksWidget />
    case 'week':
      return <WeekWidget config={inst.config} setConfig={(c) => setConfig(inst.id, c)} />
    default:
      return <p className="p-4 text-xs text-muted-foreground">Widget không hỗ trợ</p>
  }
}

export function WidgetLayer() {
  const blob = useDesktopStore((s) => s.blob)
  const update = useDesktopStore((s) => s.update)
  const [live, setLive] = useState<{ id: string; x: number; y: number; w: number; h: number } | null>(null)
  const dragRef = useRef<{ id: string; mode: 'move' | 'resize'; sx: number; sy: number; x: number; y: number; w: number; h: number; moved: boolean } | null>(null)
  const [tick, setTick] = useState(0)
  const resizeTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  const instances: WidgetInstance[] = ((blob?.widgets || []) as unknown[])
    .map((w) => (w && typeof w === 'object' ? migrate(w as Record<string, unknown>) : null))
    .filter((w): w is WidgetInstance => Boolean(w && widgetDef(w.type)))

  // vị trí px tính lại khi viewport đổi (fraction → px tự thích nghi)
  useEffect(() => {
    const onResize = () => {
      if (resizeTimer.current) clearTimeout(resizeTimer.current)
      resizeTimer.current = setTimeout(() => setTick((n) => n + 1), 120)
    }
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  // Listener move/resize toàn cục — px tạm thời (liveRef), thả ra mới lưu fraction
  // liveRef giữ vị trí MỚI NHẤT để onUp không bị stale closure (kéo nhanh vẫn lưu đúng)
  const liveRef = useRef<{ id: string; x: number; y: number; w: number; h: number } | null>(null)
  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      const d = dragRef.current
      if (!d) return
      if (Math.abs(e.clientX - d.sx) > 2 || Math.abs(e.clientY - d.sy) > 2) d.moved = true
      const inst = instances.find((i) => i.id === d.id)
      if (!inst) return
      if (d.mode === 'move') {
        const u = usable()
        const x = Math.max(4, Math.min(u.w - 80, d.x + (e.clientX - d.sx)))
        const y = Math.max(u.top + 2, Math.min(u.top + u.h - 60, d.y + (e.clientY - d.sy)))
        liveRef.current = { id: d.id, x, y, w: d.w, h: d.h }
        setLive(liveRef.current)
      } else {
        const def = widgetDef(inst.type)
        const w = Math.max(def?.minW ?? 160, d.w + (e.clientX - d.sx))
        const h = Math.max(def?.minH ?? 120, d.h + (e.clientY - d.sy))
        liveRef.current = { id: d.id, x: d.x, y: d.y, w, h }
        setLive(liveRef.current)
      }
    }
    const onUp = () => {
      const d = dragRef.current
      dragRef.current = null
      const cur = liveRef.current
      liveRef.current = null
      setLive(null)
      if (!d || !d.moved || !cur) return
      const f = toFraction(cur.x, cur.y)
      update((prev) => ({
        ...prev,
        widgets: ((prev.widgets || []) as unknown[]).map((raw) => {
          const inst = migrate(raw as Record<string, unknown>)
          if (!inst || inst.id !== d.id) return raw
          const size = clampSize(inst.type, cur.w, cur.h)
          return { ...inst, fx: f.fx, fy: f.fy, w: size.w, h: size.h }
        }),
      }))
    }
    window.addEventListener('pointermove', onMove)
    window.addEventListener('pointerup', onUp)
    return () => {
      window.removeEventListener('pointermove', onMove)
      window.removeEventListener('pointerup', onUp)
    }
  }, [instances, update])

  const startDrag = (inst: WidgetInstance, mode: 'move' | 'resize') => (e: React.PointerEvent) => {
    e.stopPropagation()
    const pos = toPx(inst)
    dragRef.current = { id: inst.id, mode, sx: e.clientX, sy: e.clientY, x: pos.x, y: pos.y, w: inst.w, h: inst.h, moved: false }
  }

  const remove = (id: string) => {
    update((prev) => ({ ...prev, widgets: ((prev.widgets || []) as unknown[]).filter((raw) => (raw as { id?: string }).id !== id) }))
  }

  const setConfig = useCallback(
    (id: string, config: Record<string, unknown>) => {
      update((prev) => ({
        ...prev,
        widgets: ((prev.widgets || []) as unknown[]).map((raw) => {
          const inst = raw as { id?: string; config?: Record<string, unknown> }
          return inst.id === id ? { ...(raw as object), config } : raw
        }),
      }))
    },
    [update],
  )

  if (instances.length === 0) return null

  return (
    <>
      {instances.map((inst) => {
        const def = widgetDef(inst.type) as WidgetDef | undefined
        const Icon = def?.icon
        const base = toPx(inst)
        const pos = live?.id === inst.id ? live : { x: base.x, y: base.y, w: inst.w, h: inst.h }
        void tick // re-render khi resize viewport
        return (
          <section
            key={inst.id}
            className="wos-widget"
            style={{ left: pos.x, top: pos.y, width: pos.w, height: pos.h, transition: live?.id === inst.id ? 'none' : undefined }}
            onPointerDown={(e) => e.stopPropagation()}
            aria-label={`Widget ${def?.title || inst.type}`}
          >
            <div className="wos-widget-bar group" onPointerDown={startDrag(inst, 'move')}>
              {Icon ? <Icon className="h-3 w-3 shrink-0" /> : null}
              <span className="flex-1 truncate">{def?.title || inst.type}</span>
              <button
                onClick={() => remove(inst.id)}
                className="rounded-full p-0.5 opacity-0 transition-opacity hover:bg-black/10 group-hover:opacity-100 dark:hover:bg-white/15"
                aria-label="Xoá widget"
              >
                <X className="h-3 w-3" />
              </button>
            </div>
            <div className="wos-widget-body">{renderWidget(inst, setConfig)}</div>
            <div className="wos-widget-resize" onPointerDown={startDrag(inst, 'resize')} aria-hidden />
          </section>
        )
      })}
    </>
  )
}

export { WIDGET_DEFS }
