'use client'

/**
 * TasksWidget — việc cần làm hôm nay (đọc Task module), tick hoàn thành ngay trên desktop.
 */
import { useCallback, useEffect, useState } from 'react'
import { api } from '@/core/client/api'
import { bus } from '@/core/client/event-bus'
import { useWindows } from '@/core/client/window-store'
import { CheckCircle2, Circle, ClipboardList, Loader2 } from 'lucide-react'

interface TaskLite {
  id: string
  title: string
  status: string
  priority: string
  dueAt: string | null
}

export default function TasksWidget() {
  const [tasks, setTasks] = useState<TaskLite[] | null>(null)
  const [busy, setBusy] = useState<string | null>(null)
  const openApp = useWindows((s) => s.openApp)

  const load = useCallback(async () => {
    try {
      const today = new Date()
      const from = new Date(today.getFullYear(), today.getMonth(), today.getDate()).toISOString()
      const to = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1).toISOString()
      const data = await api<{ tasks: TaskLite[] }>(`/api/modules/tasks?status=all`)
      setTasks(
        (data.tasks || [])
          .filter((t) => t.status !== 'done' && t.status !== 'archived' && t.dueAt && t.dueAt >= from && t.dueAt < to)
          .slice(0, 8),
      )
    } catch {
      setTasks([])
    }
  }, [])

  useEffect(() => {
    load()
    const off = bus.onAny((ev) => {
      if (ev.module === 'tasks') load()
    })
    return off
  }, [load])

  async function toggleDone(t: TaskLite) {
    setBusy(t.id)
    try {
      await api(`/api/modules/tasks/${t.id}`, { method: 'PATCH', body: { status: 'done' } })
      bus.emit('task.completed', 'tasks', { title: t.title })
      await load()
    } finally {
      setBusy(null)
    }
  }

  return (
    <div className="wos-widget-body flex flex-col p-2.5">
      <div className="mb-1 flex items-center justify-between px-1">
        <p className="text-[11.5px] font-semibold">Việc hôm nay</p>
        <button
          onClick={() => openApp('tasks')}
          className="rounded-md p-1 text-muted-foreground hover:bg-muted hover:text-foreground"
          aria-label="Mở Tasks"
        >
          <ClipboardList className="h-3.5 w-3.5" />
        </button>
      </div>
      {tasks === null ? (
        <div className="flex flex-1 items-center justify-center">
          <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
        </div>
      ) : tasks.length === 0 ? (
        <p className="flex-1 py-6 text-center text-[11.5px] text-muted-foreground">Hôm nay không có việc đến hạn 🎉</p>
      ) : (
        <div className="wos-scroll flex-1 space-y-1 overflow-y-auto">
          {tasks.map((t) => (
            <button
              key={t.id}
              onClick={() => busy !== t.id && void toggleDone(t)}
              className="flex w-full items-center gap-2 rounded-lg px-1.5 py-1.5 text-left transition-colors hover:bg-muted"
              disabled={busy === t.id}
            >
              {busy === t.id ? (
                <Loader2 className="h-4 w-4 shrink-0 animate-spin text-muted-foreground" />
              ) : t.status === 'done' ? (
                <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-500" />
              ) : (
                <Circle className="h-4 w-4 shrink-0 text-muted-foreground" />
              )}
              <span className="min-w-0 flex-1 truncate text-[12px]">
                {t.priority === 'urgent' && <span className="mr-1 text-rose-500">●</span>}
                {t.priority === 'high' && <span className="mr-1 text-amber-500">●</span>}
                {t.title}
              </span>
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
