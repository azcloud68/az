'use client'

/**
 * NoteWidget — sticky note nhanh trên desktop.
 * Nội dung lưu localStorage (nháp cá nhân, không chiếm DB).
 */
import { useEffect, useRef } from 'react'

export default function NoteWidget({ config }: { config: Record<string, unknown> }) {
  const keyRef = useRef(`wos_widget_note_${String(config.key || 'default')}`)
  const taRef = useRef<HTMLTextAreaElement>(null)

  useEffect(() => {
    const el = taRef.current
    if (!el) return
    el.value = localStorage.getItem(keyRef.current) || ''
  }, [])

  return (
    <textarea
      ref={taRef}
      className="wos-widget-note-text"
      placeholder="Ghi chú nhanh…"
      onInput={(e) => {
        localStorage.setItem(keyRef.current, (e.target as HTMLTextAreaElement).value)
      }}
      aria-label="Ghi chú desktop"
    />
  )
}
