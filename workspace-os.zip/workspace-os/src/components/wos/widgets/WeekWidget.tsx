'use client'

/**
 * WeekWidget — widget desktop của module Weekly (Công Việc Tuần).
 * Hiển thị danh sách việc của 1 ngày (mặc định hôm nay) THEO CÂY PHÂN CẤP:
 *  - Việc NHÓM (có việc con): in đậm + icon FolderOpen + badge "x/y" con + thanh tiến độ
 *    mini 1.5px — nhóm TỰ TỔNG HỢP từ việc con nên KHÔNG tick trực tiếp
 *    (hover title giải thích; click tên → mở app Weekly)
 *  - Việc LÁ: giữ hàng tick Circle / CheckCircle2 / CircleSlash như cũ;
 *    việc con thụt lề pl-3 mỗi cấp + icon CornerDownRight
 *  - ◀ ▶ đổi ngày (lưu config.date), cutoff giờ cảnh báo (mặc định 16h, lưu config.cutoff)
 *  - Thanh tiến độ + đếm done / pass / pending CHỈ TÍNH VIỆC LÁ (khối lượng thật sự)
 *    + hiển thị "N nhóm" nhỏ bên cạnh khi có nhóm
 *  - Cảnh báo đỏ khi còn việc pending sau giờ cutoff; ≥ 20h → "Sắp hết ngày"
 *  - Tick lỗi (vd 400 việc nhóm) → toast báo rõ, KHÔNG im lặng
 *  - Mở app Weekly đúng ngày (weekly:YYYY-MM-DD)
 *  - Tự refresh qua bus (module weekly) + interval 60s; dọn sạch effect khi unmount
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { api } from '@/core/client/api'
import { bus } from '@/core/client/event-bus'
import { useWindows } from '@/core/client/window-store'
import { useToast } from '@/hooks/use-toast'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  ChevronLeft, ChevronRight, Circle, CheckCircle2, CircleSlash, ClipboardList,
  Loader2, Settings2, Minus, Plus, AlertTriangle, ExternalLink, FlaskConical,
  FolderOpen, CornerDownRight,
} from 'lucide-react'
import {
  addDaysISO, fmtDM, fmtISODate, isISODate, WEEKDAY_SHORT, weekdayOfISO, AUTO_PASS_NOTE,
  buildTree, type TreeNode,
} from '@/modules/weekly/lib'

interface WTask {
  id: string
  parentId?: string | null
  name: string
  status: string
  note: string
  isPrep: boolean
  prepRound: number
  quantity: number | null
}
interface DayData {
  day: { offline: boolean; offlineNote: string } | null
  tasks: WTask[]
}

const MODULE_COLOR = '#3b82f6'

export default function WeekWidget({
  config,
  setConfig,
}: {
  config: Record<string, unknown>
  setConfig: (c: Record<string, unknown>) => void
}) {
  const { toast } = useToast()
  const [date, setDate] = useState<string>(() =>
    isISODate(config.date) ? (config.date as string) : fmtISODate(new Date()),
  )
  const [cutoff, setCutoff] = useState<number>(() =>
    typeof config.cutoff === 'number' && config.cutoff >= 8 && config.cutoff <= 23 ? Math.floor(config.cutoff) : 16,
  )
  const [data, setData] = useState<DayData | null>(null)
  const [now, setNow] = useState(() => new Date())
  const [menuOpen, setMenuOpen] = useState(false)

  const aliveRef = useRef(true)
  const seqRef = useRef(0)

  const saveConfig = useCallback(
    (next: Record<string, unknown>) => {
      if (typeof setConfig === 'function') setConfig(next)
    },
    [setConfig],
  )

  const load = useCallback(async () => {
    const seq = ++seqRef.current
    try {
      const res = await api<DayData>(`/api/modules/weekly/days/${date}`)
      if (aliveRef.current && seq === seqRef.current) setData(res)
    } catch {
      if (aliveRef.current && seq === seqRef.current) setData({ day: null, tasks: [] })
    }
  }, [date])

  // Load khi đổi ngày — cờ alive + seq chống setState sau khi unmount / response cũ
  useEffect(() => {
    aliveRef.current = true
    load()
    return () => {
      aliveRef.current = false
    }
  }, [load])

  // Bus refresh (module weekly) + interval 60s — dọn sạch khi unmount
  useEffect(() => {
    const off = bus.onAny((ev) => {
      if (ev.module === 'weekly') load()
    })
    const timer = setInterval(() => {
      setNow(new Date())
      load()
    }, 60000)
    return () => {
      off()
      clearInterval(timer)
    }
  }, [load])

  async function tick(t: WTask) {
    const next = t.status === 'done' ? 'pending' : 'done'
    try {
      await api(`/api/modules/weekly/tasks/${t.id}`, { method: 'PATCH', body: { status: next } })
      bus.emit(next === 'done' ? 'weekly.task.completed' : 'weekly.day.updated', 'weekly', { title: t.name })
    } catch (err) {
      // Không còn im lặng: API từ chối (vd tick vào việc nhóm → 400) → báo rõ cho user
      const status = (err as Error & { status?: number }).status
      if (status === 400) {
        toast({
          title: 'Không tick được việc nhóm',
          description: 'Việc nhóm tự tổng hợp tiến độ từ việc con — hãy tick từng việc con.',
          variant: 'destructive',
        })
      } else {
        toast({
          title: 'Không cập nhật được việc',
          description: err instanceof Error ? err.message : 'Lỗi kết nối',
          variant: 'destructive',
        })
      }
    }
  }

  function changeDate(delta: number) {
    const next = addDaysISO(date, delta)
    setDate(next)
    saveConfig({ ...config, date: next, cutoff })
  }

  function changeCutoff(delta: number) {
    const next = Math.min(23, Math.max(8, cutoff + delta))
    setCutoff(next)
    saveConfig({ ...config, date, cutoff: next })
  }

  function openWeekly() {
    useWindows.getState().openApp('weekly', { route: `weekly:${date}` })
  }

  // ------------------------------------------------------------------
  // Trạng thái hiển thị — cây phân cấp + thống kê CHỈ TÍNH VIỆC LÁ
  // ------------------------------------------------------------------
  const tasks = data?.tasks || []

  /** cây việc (việc con nằm trong việc mẹ; mồ côi parentId → làm gốc) */
  const tree = useMemo(() => buildTree(tasks), [tasks])
  /** id của mọi việc NHÓM = được ít nhất 1 việc khác trỏ tới làm cha */
  const groupIds = useMemo(() => {
    const ids = new Set(tasks.map((t) => t.id))
    return new Set(
      tasks
        .map((t) => (t.parentId && t.parentId !== t.id ? t.parentId : null))
        .filter((p): p is string => !!p && ids.has(p)),
    )
  }, [tasks])
  /** việc LÁ = không được ai làm cha → khối lượng thật sự để tick */
  const leaves = useMemo(() => tasks.filter((t) => !groupIds.has(t.id)), [tasks, groupIds])

  const done = leaves.filter((t) => t.status === 'done').length
  const passed = leaves.filter((t) => t.status === 'passed').length
  const pending = leaves.filter((t) => t.status === 'pending').length
  const total = leaves.length
  const groupCount = groupIds.size
  const hasGroups = groupCount > 0
  const pct = total ? Math.round(((done + passed) / total) * 100) : 0

  const isToday = date === fmtISODate(now)
  const hour = now.getHours()
  const danger = isToday && pending > 0 && hour >= 20
  const warn = !danger && isToday && pending > 0 && hour >= cutoff

  const borderCls = danger
    ? 'border-2 border-rose-600 shadow-[0_0_18px_rgba(225,29,72,0.35)]'
    : warn
      ? 'border-2 border-rose-400'
      : ''

  return (
    <Card className={`wos-glass border-0 ${borderCls}`}>
      <CardHeader className="flex-row items-center justify-between gap-2 pb-2">
        <CardTitle className="flex items-center gap-2 text-sm font-semibold">
          <span className="flex h-6 w-6 items-center justify-center rounded-lg text-white" style={{ background: MODULE_COLOR }}>
            <ClipboardList className="h-3.5 w-3.5" />
          </span>
          Công việc {WEEKDAY_SHORT[weekdayOfISO(date)]} {fmtDM(date)}
        </CardTitle>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => changeDate(-1)} aria-label="Ngày trước" title="Ngày trước">
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" className="h-7 px-2 text-xs" onClick={() => {
            const today = fmtISODate(new Date())
            setDate(today)
            saveConfig({ ...config, date: today, cutoff })
          }} aria-label="Hôm nay" title="Hôm nay">
            Hôm nay
          </Button>
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => changeDate(1)} aria-label="Ngày sau" title="Ngày sau">
            <ChevronRight className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 text-muted-foreground"
            onClick={() => setMenuOpen((v) => !v)}
            aria-label="Cấu hình widget"
            title="Chỉnh giờ cảnh báo"
          >
            <Settings2 className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>

      {/* Menu nhỏ: chỉnh giờ cutoff */}
      {menuOpen && (
        <div className="mx-6 mb-2 flex items-center gap-2 rounded-xl bg-muted/60 px-3 py-1.5 text-xs">
          <span className="text-muted-foreground">Cảnh báo sau</span>
          <div className="flex items-center gap-1">
            <Button variant="outline" size="icon" className="h-6 w-6" onClick={() => changeCutoff(-1)} aria-label="Giảm giờ cảnh báo">
              <Minus className="h-3 w-3" />
            </Button>
            <span className="w-10 text-center font-semibold tabular-nums">{cutoff}:00</span>
            <Button variant="outline" size="icon" className="h-6 w-6" onClick={() => changeCutoff(1)} aria-label="Tăng giờ cảnh báo">
              <Plus className="h-3 w-3" />
            </Button>
          </div>
          <span className="text-muted-foreground">mỗi ngày</span>
        </div>
      )}

      <CardContent>
        {data === null ? (
          <div className="flex h-20 items-center justify-center">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <>
            {/* Ngày nghỉ */}
            {data.day?.offline && (
              <p className="mb-2 rounded-lg bg-amber-500/10 px-2.5 py-1.5 text-xs font-medium text-amber-600 dark:text-amber-400">
                Ngày nghỉ{data.day.offlineNote ? ` — ${data.day.offlineNote}` : ''}
              </p>
            )}

            {/* Danh sách việc — render ĐỆ QUY theo cây (nhóm → việc con thụt lề) */}
            {tasks.length === 0 ? (
              <div className="flex flex-col items-center gap-1.5 py-5 text-center">
                <ClipboardList className="h-6 w-6 text-muted-foreground/30" />
                <p className="text-xs text-muted-foreground">Không có việc trong ngày này</p>
                <Button variant="outline" size="sm" className="h-7 gap-1.5 text-xs" onClick={openWeekly}>
                  <ExternalLink className="h-3 w-3" /> Mở app để thêm việc
                </Button>
              </div>
            ) : (
              <div className={`${hasGroups ? 'max-h-[22rem]' : 'max-h-72'} space-y-0.5 overflow-y-auto pr-1`}>
                {tree.map((node) => (
                  <WidgetTaskNode key={node.data.id} node={node} depth={0} onTick={tick} onOpen={openWeekly} />
                ))}
              </div>
            )}

            {/* Tiến độ (chỉ việc lá) + cảnh báo */}
            {total > 0 && (
              <div className="mt-2.5 space-y-1.5">
                {(warn || danger) && (
                  <p className={`flex items-center gap-1.5 text-xs font-semibold ${danger ? 'text-rose-600 dark:text-rose-400' : 'text-rose-500'}`}>
                    <AlertTriangle className="h-3.5 w-3.5" />
                    {danger ? `Sắp hết ngày — còn ${pending} việc chưa làm` : `Còn ${pending} việc sau ${cutoff}h`}
                  </p>
                )}
                <div className="h-2 overflow-hidden rounded-full bg-muted" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}>
                  <div
                    className={`h-full rounded-full transition-all ${pct === 100 ? 'bg-emerald-500' : 'bg-primary'}`}
                    style={{ width: `${pct}%` }}
                  />
                </div>
                <div className="flex items-center justify-between text-[11px] text-muted-foreground">
                  <span>
                    <b className="text-emerald-600 dark:text-emerald-400">{done}</b> xong ·{' '}
                    <b className="text-amber-600 dark:text-amber-400">{passed}</b> pass · <b>{pending}</b> chờ
                    {groupCount > 0 && <span className="ml-1 opacity-80">· {groupCount} nhóm</span>}
                  </span>
                  <button onClick={openWeekly} className="flex items-center gap-1 hover:text-primary" title={`Mở app Công Việc Tuần — ${date}`}>
                    Chi tiết <ExternalLink className="h-3 w-3" />
                  </button>
                </div>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  )
}

// =====================================================================
// 1 node việc trong widget — đệ quy (nhóm in đậm không tick / lá tick được)
// =====================================================================
function WidgetTaskNode({
  node, depth, onTick, onOpen,
}: {
  node: TreeNode<WTask>
  depth: number
  onTick: (t: WTask) => void
  onOpen: () => void
}) {
  const { data: t, children } = node

  // ---- Việc NHÓM (có việc con): tự tổng hợp tiến độ — KHÔNG có nút tick ----
  if (children.length > 0) {
    const settled = children.filter((c) => c.data.status === 'done' || c.data.status === 'passed').length
    const pct = Math.round((settled / children.length) * 100)
    const allDone = settled === children.length
    return (
      <div>
        <div
          className="group flex items-center gap-2 rounded-lg px-2 py-1.5 transition-colors hover:bg-muted"
          style={{ paddingLeft: 8 + depth * 12 }}
          title="Nhóm tự tổng hợp tiến độ từ việc con — tick từng việc con (mở app để thêm việc con)"
        >
          <FolderOpen
            className={`h-4 w-4 shrink-0 ${allDone ? 'text-emerald-500' : 'text-amber-500/90'}`}
            aria-hidden="true"
          />
          <button
            type="button"
            onClick={onOpen}
            className="min-w-0 flex-1 truncate text-left text-sm font-semibold hover:underline focus:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            title={`Mở app Công Việc Tuần — ${t.name}`}
          >
            {t.name}
          </button>
          <span className="shrink-0 rounded-full bg-muted px-1.5 py-0.5 text-[10px] font-semibold tabular-nums" title={`${settled}/${children.length} việc con đã xong/pass`}>
            {settled}/{children.length}
          </span>
          <div
            className="h-[1.5px] w-14 shrink-0 overflow-hidden rounded-full bg-muted"
            role="progressbar"
            aria-valuenow={pct}
            aria-valuemin={0}
            aria-valuemax={100}
            aria-label={`Tiến độ nhóm ${t.name}`}
          >
            <div className={`h-full rounded-full transition-all ${allDone ? 'bg-emerald-500' : 'bg-primary'}`} style={{ width: `${pct}%` }} />
          </div>
        </div>
        {children.map((child) => (
          <WidgetTaskNode key={child.data.id} node={child} depth={depth + 1} onTick={onTick} onOpen={onOpen} />
        ))}
      </div>
    )
  }

  // ---- Việc LÁ: hàng tick như cũ, thụt lề theo cấp (pl-3 mỗi cấp) ----
  const isDone = t.status === 'done'
  const isPassed = t.status === 'passed'
  const auto = t.note === AUTO_PASS_NOTE
  return (
    <div className="group flex items-center gap-2.5 rounded-lg px-2 py-1.5 transition-colors hover:bg-muted" style={{ paddingLeft: 8 + depth * 12 }}>
      <button
        onClick={() => onTick(t)}
        className="shrink-0 rounded-full focus:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        aria-label={isDone ? 'Bỏ hoàn thành' : 'Hoàn thành'}
        title={isDone ? 'Bỏ hoàn thành' : isPassed ? 'Việc đã pass' : 'Hoàn thành'}
      >
        {isDone ? (
          <CheckCircle2 className="h-4.5 w-4.5 text-emerald-500" />
        ) : isPassed ? (
          <CircleSlash className="h-4.5 w-4.5 text-amber-500" />
        ) : (
          <Circle className="h-4.5 w-4.5 text-muted-foreground transition-colors group-hover:text-primary" />
        )}
      </button>
      {depth > 0 && <CornerDownRight className="h-3 w-3 shrink-0 text-muted-foreground/60" aria-hidden="true" />}
      <span className={`flex min-w-0 flex-1 items-center gap-1.5 text-sm ${isDone || isPassed ? 'text-muted-foreground line-through' : ''}`}>
        {t.isPrep && <FlaskConical className="h-3 w-3 shrink-0 text-amber-500" />}
        <span className="truncate">{t.name}</span>
        {t.isPrep && t.prepRound > 1 && (
          <span className="shrink-0 rounded-full bg-amber-500/15 px-1.5 py-0.5 text-[10px] font-semibold text-amber-600 dark:text-amber-400">
            Lần {t.prepRound}
          </span>
        )}
      </span>
      {t.quantity != null && t.quantity > 0 && (
        <span className="shrink-0 text-[10px] tabular-nums text-muted-foreground">{t.quantity}h</span>
      )}
      {isPassed && !auto && t.note && (
        <span className="hidden max-w-[110px] shrink-0 truncate text-[10px] italic text-amber-600/80 dark:text-amber-400/80 sm:inline" title={t.note}>
          {t.note}
        </span>
      )}
    </div>
  )
}
