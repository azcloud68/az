'use client'

import { useEffect, useState } from 'react'
import { useWos } from '@/core/client/wos-store'
import { api } from '@/core/client/api'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Checkbox } from '@/components/ui/checkbox'
import { Label } from '@/components/ui/label'
import { Loader2, Lock, ArrowLeft, KeyRound, UserPlus, Hammer, Clock } from 'lucide-react'
import { toast } from 'sonner'

/** Lock screen chuẩn macOS: đồng hồ lớn, avatar, ô mật khẩu viên thuốc */
export function LoginScreen() {
  const login = useWos((s) => s.login)
  const [now, setNow] = useState(() => new Date())
  const [password, setPassword] = useState('')
  const [username, setUsername] = useState('')
  const [remember, setRemember] = useState(true)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [shake, setShake] = useState(false)
  const [mode, setMode] = useState<'login' | 'forgot' | 'reset' | 'register'>('login')
  const [resetCode, setResetCode] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [info, setInfo] = useState('')

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000)
    return () => clearInterval(t)
  }, [])

  useEffect(() => {
    const saved = localStorage.getItem('wos_username')
    if (saved) setUsername(saved)
  }, [])

  async function submitLogin(e: React.FormEvent) {
    e.preventDefault()
    if (loading) return
    setLoading(true)
    setError('')
    try {
      await login(username.trim(), password, remember)
      if (remember) localStorage.setItem('wos_username', username.trim())
      else localStorage.removeItem('wos_username')
      toast.success('Chào mừng trở lại!')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Đăng nhập thất bại')
      setShake(true)
      setTimeout(() => setShake(false), 500)
    } finally {
      setLoading(false)
    }
  }

  async function submitForgot(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setInfo('')
    try {
      // Server KHÔNG trả mã qua API (chống chiếm tài khoản) — mã chỉ đến từ admin hoặc log server
      await api<{ message?: string }>('/api/core/auth/forgot', {
        method: 'POST',
        body: { username: username.trim() },
      })
      setResetCode('')
      setMode('reset')
      setInfo(
        'Mã đặt lại (15 phút) đã được sinh nếu tài khoản tồn tại. Chỉ còn 1 mã hợp lệ ' +
          '(mã mới vô hiệu hoá mã cũ). Lấy mã từ: (1) quản trị viên — Administration → Users, ' +
          'hoặc (2) log server: journalctl -u wos | grep WOS:reset (có thể bị admin tắt).'
      )
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Không tạo được mã')
    } finally {
      setLoading(false)
    }
  }

  async function submitReset(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setInfo('')
    try {
      await api('/api/core/auth/reset', {
        method: 'POST',
        body: { username: username.trim(), code: resetCode, password: newPassword },
      })
      toast.success('Đã đặt lại mật khẩu — hãy đăng nhập')
      setPassword('')
      setMode('login')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Đặt lại thất bại')
    } finally {
      setLoading(false)
    }
  }

  const clock = now.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })
  const date = now.toLocaleDateString('vi-VN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })

  return (
    <div className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden select-none">
      <div className="wos-wallpaper" />

      {/* Đồng hồ + ngày — đầu màn hình */}
      <div className="absolute top-[10vh] flex flex-col items-center gap-1 text-white drop-shadow-lg">
        <div className="text-[13vw] md:text-[96px] font-bold leading-none tracking-tight tabular-nums [text-shadow:0_2px_30px_rgba(0,0,0,0.25)]">
          {clock}
        </div>
        <div className="text-lg md:text-xl font-medium text-white/90">{date}</div>
      </div>

      {/* Khối avatar + form */}
      <div className={`mt-[22vh] flex w-full max-w-[340px] flex-col items-center gap-4 ${shake ? 'wos-shake' : ''}`}>
        <div className="flex h-[84px] w-[84px] items-center justify-center rounded-full bg-gradient-to-br from-orange-400 to-rose-500 text-3xl font-semibold text-white shadow-xl ring-4 ring-white/30">
          {(username || 'W').slice(0, 1).toUpperCase()}
        </div>

        {mode === 'login' && (
          <form onSubmit={submitLogin} className="flex w-full flex-col items-center gap-4">
            <div className="flex w-full flex-col gap-2">
              <Input
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Tên đăng nhập"
                autoCapitalize="none"
                className="h-11 rounded-full border-white/40 bg-white/80 text-center text-[15px] backdrop-blur-md focus-visible:ring-white/60 dark:bg-black/40 dark:text-white"
              />
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Nhập mật khẩu"
                autoFocus
                className="h-11 rounded-full border-white/40 bg-white/80 text-center text-[15px] backdrop-blur-md focus-visible:ring-white/60 dark:bg-black/40 dark:text-white"
              />
            </div>
            {error && <p className="text-sm text-rose-100 drop-shadow">{error}</p>}
            <div className="flex items-center gap-2 text-white/90">
              <Checkbox
                id="remember"
                checked={remember}
                onCheckedChange={(v) => setRemember(v === true)}
                className="border-white/60 bg-white/30"
              />
              <Label htmlFor="remember" className="text-sm font-normal">
                Ghi nhớ đăng nhập
              </Label>
            </div>
            <Button
              type="submit"
              disabled={loading || !password}
              className="h-11 w-[210px] rounded-full bg-white/85 text-[15px] font-medium text-neutral-800 shadow-lg backdrop-blur hover:bg-white dark:bg-black/50 dark:text-white dark:hover:bg-black/70"
            >
              {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Lock className="h-4 w-4" />}
              Đăng nhập
            </Button>
            <button
              type="button"
              onClick={() => {
                setMode('forgot')
                setError('')
              }}
              className="text-sm text-white/80 underline-offset-2 hover:text-white hover:underline"
            >
              Quên mật khẩu?
            </button>
            <span className="text-white/40">·</span>
            <button
              type="button"
              onClick={() => {
                setMode('register')
                setError('')
              }}
              className="flex items-center gap-1 text-sm font-medium text-white/90 underline-offset-2 hover:text-white hover:underline"
            >
              <UserPlus className="h-3.5 w-3.5" /> Đăng ký tài khoản
            </button>
          </form>
        )}

        {mode === 'register' && (
          <div className="flex w-full flex-col items-center gap-4">
            <div className="wos-glass w-full rounded-2xl p-5 text-center">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-500/20 text-amber-500">
                <Hammer className="h-6 w-6" />
              </div>
              <p className="mt-3 text-[15px] font-semibold text-white">Đăng ký tạm thời bị khoá</p>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-white/80">
                Workspace OS đang trong thời gian phát triển nên tính năng đăng ký chỉ mở khoá rất hạn chế.
                Hẹn bạn quay lại sau nhé!
              </p>
              <div className="mt-3 flex items-center justify-center gap-1.5 text-[11px] text-white/60">
                <Clock className="h-3.5 w-3.5" /> Phiên bản đang chạy: bản thử nghiệm nội bộ
              </div>
            </div>
            <div className="wos-glass w-full rounded-2xl p-4 text-[12px] leading-relaxed text-white/85">
              <p className="mb-1 font-semibold">Cần tài khoản ngay?</p>
              <p>
                Hãy liên hệ quản trị viên của hệ thống — quản trị viên có thể tạo tài khoản cho bạn trong
                <b> Administration → Users</b> (kèm phân quyền từng module riêng cho tài khoản của bạn).
              </p>
            </div>
            <button type="button" onClick={() => setMode('login')} className="flex items-center gap-1 text-sm text-white/80 hover:text-white">
              <ArrowLeft className="h-4 w-4" /> Quay lại đăng nhập
            </button>
          </div>
        )}

        {mode === 'forgot' && (
          <form onSubmit={submitForgot} className="flex w-full flex-col items-center gap-4">
            <div className="wos-glass flex items-center gap-3 rounded-2xl p-4 text-sm">
              <KeyRound className="h-5 w-5 shrink-0 text-primary" />
              <p>Nhập tên đăng nhập — quản trị viên (hoặc log server) sẽ cấp mã đặt lại, hiệu lực 15 phút.</p>
            </div>
            <Input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Tên đăng nhập"
              className="h-11 rounded-full border-white/40 bg-white/80 text-center backdrop-blur-md dark:bg-black/40 dark:text-white"
            />
            {error && <p className="text-sm text-rose-100">{error}</p>}
            <Button type="submit" disabled={loading} className="h-11 rounded-full px-8">
              {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : 'Lấy mã đặt lại'}
            </Button>
            <button type="button" onClick={() => setMode('login')} className="flex items-center gap-1 text-sm text-white/80 hover:text-white">
              <ArrowLeft className="h-4 w-4" /> Quay lại đăng nhập
            </button>
          </form>
        )}

        {mode === 'reset' && (
          <form onSubmit={submitReset} className="flex w-full flex-col items-center gap-3">
            {info && (
              <div className="wos-glass w-full rounded-2xl p-4 text-center text-sm">
                <p className="font-medium">Nhập mã đặt lại từ quản trị viên</p>
                <p className="mt-1 text-muted-foreground">{info}</p>
              </div>
            )}
            <Input
              value={resetCode}
              onChange={(e) => setResetCode(e.target.value.toUpperCase())}
              placeholder="Mã đặt lại (8 ký tự)"
              className="h-11 rounded-full border-white/40 bg-white/80 text-center font-mono tracking-widest backdrop-blur-md dark:bg-black/40 dark:text-white"
            />
            <Input
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="Mật khẩu mới (tối thiểu 6 ký tự)"
              className="h-11 rounded-full border-white/40 bg-white/80 text-center backdrop-blur-md dark:bg-black/40 dark:text-white"
            />
            {error && <p className="text-sm text-rose-100">{error}</p>}
            <Button type="submit" disabled={loading || !resetCode || newPassword.length < 6} className="h-11 rounded-full px-8">
              {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : 'Đặt lại mật khẩu'}
            </Button>
            <button type="button" onClick={() => setMode('login')} className="flex items-center gap-1 text-sm text-white/80 hover:text-white">
              <ArrowLeft className="h-4 w-4" /> Quay lại đăng nhập
            </button>
          </form>
        )}
      </div>

      {/* Footer branding */}
      <div className="absolute bottom-6 flex items-center gap-2 text-white/70">
        <div className="flex h-6 w-6 items-center justify-center rounded-md bg-white/20 text-xs font-bold">W</div>
        <span className="text-sm font-medium tracking-wide">Workspace OS</span>
      </div>
    </div>
  )
}
