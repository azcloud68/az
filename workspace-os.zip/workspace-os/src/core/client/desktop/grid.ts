'use client'

/**
 * Grid Engine — lưới icon desktop DÙNG CHUNG cho app + file + folder (review #9).
 * - App mặc định xếp từ cột PHẢI sang trái (kiểu macOS), file từ cột TRÁI sang phải
 * - Mọi đối tượng chia sẻ một "bản đồ ô chiếm chỗ" → nearestFreeCell() đảm bảo
 *   KHÔNG BAO GIỜ chồng chéo (folder/file/widget-icon đè nhau như trước đây)
 * - Ô lưới phụ thuộc cỡ icon (Small/Medium/Large — review #7): đổi cỡ = tự co giãn
 */
import { MENUBAR_H, DOCK_H } from '../window-store'
import type { DesktopIconSize } from './types'

export interface IconSizePreset {
  /** kích thước ô icon (px) */
  tile: number
  cellW: number
  cellH: number
  /** cỡ emoji glyph của file icon (px) */
  fileGlyph: number
  label: string
}

export const ICON_SIZES: Record<DesktopIconSize, IconSizePreset> = {
  small: { tile: 40, cellW: 76, cellH: 86, fileGlyph: 34, label: 'Nhỏ' },
  medium: { tile: 52, cellW: 96, cellH: 106, fileGlyph: 44, label: 'Vừa' },
  large: { tile: 66, cellW: 116, cellH: 128, fileGlyph: 56, label: 'Lớn' },
}

export function iconSizePreset(size: DesktopIconSize | string | undefined): IconSizePreset {
  return ICON_SIZES[(size as DesktopIconSize) || 'medium'] || ICON_SIZES.medium
}

const GRID_PAD = 10
const GRID_TOP = MENUBAR_H + 12
const GRID_BOTTOM = DOCK_H + 12

export interface GridMetrics {
  vw: number
  vh: number
  areaX: number
  areaY: number
  areaW: number
  areaH: number
  cols: number
  rows: number
  capacity: number
  cellW: number
  cellH: number
  tile: number
}

/** Số đo lưới theo viewport HIỆN TẠI + cỡ icon */
export function gridMetrics(size: DesktopIconSize | string | undefined = 'medium'): GridMetrics {
  const p = iconSizePreset(size)
  const vw = window.innerWidth
  const vh = window.innerHeight
  const areaX = GRID_PAD
  const areaW = vw - GRID_PAD * 2
  const areaY = GRID_TOP
  const areaH = Math.max(p.cellH, vh - GRID_TOP - GRID_BOTTOM)
  const cols = Math.max(1, Math.floor(areaW / p.cellW))
  const rows = Math.max(1, Math.floor(areaH / p.cellH))
  return {
    vw, vh, areaX, areaY, areaW, areaH, cols, rows,
    capacity: cols * rows,
    cellW: p.cellW, cellH: p.cellH, tile: p.tile,
  }
}

/** Vị trí px (góc trên-trái icon) của ô cell — col tính TỪ TRÁI */
export function cellPos(cell: number, size: DesktopIconSize | string | undefined = 'medium'): { x: number; y: number } {
  const g = gridMetrics(size)
  if (cell < 0) cell = 0
  const col = Math.floor(cell / g.rows)
  const row = cell % g.rows
  const x = g.areaX + col * g.cellW + (g.cellW - g.tile) / 2
  const y = g.areaY + row * g.cellH + 4
  return { x: Math.round(x), y: Math.round(y) }
}

/** Ô lưới dưới con trỏ */
export function cellFromPoint(px: number, py: number, size: DesktopIconSize | string | undefined = 'medium'): number {
  const g = gridMetrics(size)
  const col = Math.max(0, Math.min(g.cols - 1, Math.floor((px - g.areaX) / g.cellW)))
  const row = Math.max(0, Math.min(g.rows - 1, Math.floor((py - g.areaY) / g.cellH)))
  return col * g.rows + row
}

/** Ô trống gần nhất (tìm bán kính tăng dần) — dùng chung cho MỌI loại đối tượng */
export function nearestFreeCell(want: number, taken: Set<number>, capacity: number, rows: number): number {
  if (want >= 0 && want < capacity && !taken.has(want)) return want
  for (let d = 1; d <= capacity; d++) {
    for (const c of [want - d, want + d, want - d * rows, want + d * rows]) {
      if (c >= 0 && c < capacity && !taken.has(c)) return c
    }
  }
  for (let i = 0; i < capacity; i++) if (!taken.has(i)) return i
  return Math.max(0, want)
}

/** Thứ tự ô mặc định cho APP: cột PHẢI → trái, trên → dưới (macOS) */
export function defaultAppOrder(g: GridMetrics): number[] {
  const out: number[] = []
  for (let col = g.cols - 1; col >= 0; col--) for (let row = 0; row < g.rows; row++) out.push(col * g.rows + row)
  return out
}

/** Thứ tự ô mặc định cho FILE/FOLDER: cột TRÁI → phải, trên → dưới */
export function defaultFileOrder(g: GridMetrics): number[] {
  const out: number[] = []
  for (let col = 0; col < g.cols; col++) for (let row = 0; row < g.rows; row++) out.push(col * g.rows + row)
  return out
}

/** Ô của icon Thùng rác (góc phải-dưới) — loại khỏi bản đồ ô để không app nào đè lên */
export function trashCell(size: DesktopIconSize | string | undefined = 'medium'): number {
  const g = gridMetrics(size)
  const col = g.cols - 1
  const row = Math.max(0, g.rows - 1)
  return col * g.rows + row
}
