'use client'

/**
 * Cell Assignment — thuật toán GÁN Ô determinist cho mọi DesktopObject.
 * Cả DesktopAppIcons lẫn DesktopFiles gọi đúng các hàm thuần này (cùng input → cùng output)
 * nên hai lớp luôn thấy CÙNG một bản đồ ô → không bao giờ giành ô của nhau.
 */
import type { LayoutBlob } from './desktop-store'
import {
  gridMetrics,
  nearestFreeCell,
  defaultAppOrder,
  defaultFileOrder,
  trashCell,
} from './grid'

/**
 * Gán ô cho danh sách app (theo thứ tự truyền vào — ổn định với thứ tự module).
 * Ưu tiên ô đã lưu trong blob.appCells; ô conflict/tràn → ô trống gần nhất
 * theo thứ tự mặc định PHẢI → trái. Ô Thùng rác luôn được giữ riêng.
 */
export function assignAppCells(
  appIds: string[],
  blob: LayoutBlob | null,
  size: string | undefined,
): Record<string, number> {
  const g = gridMetrics(size)
  const saved = (blob?.appCells || {}) as Record<string, number>
  const result: Record<string, number> = {}
  const taken = new Set<number>([trashCell(size)]) // giữ ô thùng rác
  const order = defaultAppOrder(g)
  let oi = 0
  const nextDefault = (): number => {
    while (oi < order.length && taken.has(order[oi])) oi++
    const cell = oi < order.length ? order[oi] : nearestFreeCell(order[0] ?? 0, taken, g.capacity, g.rows)
    taken.add(cell)
    return cell
  }
  // vòng 1: ô đã lưu hợp lệ
  for (const id of appIds) {
    const c = saved[id]
    if (c === undefined || c < 0 || c >= g.capacity || taken.has(c)) continue
    result[id] = c
    taken.add(c)
  }
  // vòng 2: app chưa có ô → ô mặc định trống kế tiếp
  for (const id of appIds) {
    if (result[id] !== undefined) continue
    result[id] = nextDefault()
  }
  return result
}

/**
 * Gán ô cho danh sách file/folder desktop (theo path).
 * Ưu tiên blob.fileCells (v6+); nếu chưa có (nâng cấp từ filePos fraction ≤v5)
 * thì quy đổi vị trí fraction cũ → ô gần nhất — một lần duy nhất rồi mọi thao tác
 * kéo thả đều snap vào lưới chung với app (review #9).
 */
export function assignFileCells(
  filePaths: string[],
  blob: LayoutBlob | null,
  appCells: Record<string, number>,
  size: string | undefined,
): Record<string, number> {
  const g = gridMetrics(size)
  const savedCells = (blob?.fileCells || {}) as Record<string, number>
  const legacyPos = (blob?.filePos || {}) as Record<string, { fx?: number; fy?: number }>
  const result: Record<string, number> = {}
  const taken = new Set<number>([trashCell(size)])
  for (const c of Object.values(appCells)) taken.add(c)

  // vòng 1: ô đã lưu / vị trí cũ quy đổi
  for (const p of filePaths) {
    let cell = savedCells[p]
    if (cell === undefined || cell < 0 || cell >= g.capacity || taken.has(cell)) {
      const f = legacyPos[p]
      if (f && typeof f.fx === 'number' && typeof f.fy === 'number') {
        const px = g.areaX + f.fx * g.areaW
        const py = g.areaY + f.fy * g.areaH
        const want = Math.max(0, Math.min(g.capacity - 1, Math.floor((px - g.areaX) / g.cellW) * g.rows + Math.floor((py - g.areaY) / g.cellH)))
        cell = nearestFreeCell(want, taken, g.capacity, g.rows)
      } else {
        continue
      }
    }
    result[p] = cell
    taken.add(cell)
  }
  // vòng 2: file chưa có ô → ô mặc định TRÁI → phải
  const order = defaultFileOrder(g)
  let oi = 0
  for (const p of filePaths) {
    if (result[p] !== undefined) continue
    while (oi < order.length && taken.has(order[oi])) oi++
    const cell = oi < order.length ? order[oi] : nearestFreeCell(0, taken, g.capacity, g.rows)
    result[p] = cell
    taken.add(cell)
  }
  return result
}

/** Sắp xếp lại file theo tên (thư mục trước) vào các ô mặc định bên trái — menu "Sắp xếp icon" */
export function sortFileCells(
  files: { path: string; name: string; isDir: boolean }[],
  appCells: Record<string, number>,
  size: string | undefined,
): Record<string, number> {
  const sorted = [...files].sort((a, b) => {
    if (a.isDir !== b.isDir) return a.isDir ? -1 : 1
    return a.name.localeCompare(b.name, 'vi')
  })
  return assignFileCells(
    sorted.map((f) => f.path),
    { fileCells: {} },
    appCells,
    size,
  )
}
