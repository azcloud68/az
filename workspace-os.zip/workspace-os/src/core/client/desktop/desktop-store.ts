'use client'

/**
 * Desktop Manager (zustand) — Selection Engine + Persistence.
 * - Selection: chọn 1 / chọn nhóm (marquee) dùng chung mọi lớp icon — Desktop.tsx
 *   ghi, DesktopIcons/Files đọc (hết prop-drilling sel/clearSel).
 * - Layout: blob desktop THEO TÀI KHOẢN (localStorage instant + server).
 *   v7 sửa 2 lỗi persistence cũ:
 *   1) LS ghi kèm uid của chủ sở hữu — hết rò rỉ layout giữa các tài khoản
 *      cùng trình duyệt (cache của user A không đè lên user B khi GET về).
 *   2) Toggle "ẩn icon" lưu NGAY (không debounce) — hết mất cài đặt khi
 *      thoát nhanh trước khi debounce 600ms kịp PUT lên server.
 */
import { create } from 'zustand'
import { api } from '../api'
import type { DesktopSelection } from './types'

export interface LayoutBlob {
  widgets?: unknown[]
  appCells?: Record<string, number>
  /** v6: file/folder desktop dùng ô lưới chung với app — không còn chồng chéo */
  fileCells?: Record<string, number>
  /** cũ (≤v5): vị trí px dạng fraction — quy đổi 1 lần sang fileCells rồi bỏ dùng */
  filePos?: Record<string, { fx: number; fy: number }>
  /** ẩn toàn bộ icon ứng dụng (thùng rác + file vẫn hiện) */
  hideAppIcons?: boolean
  /** v6.1: Ẩn TOÀN BỘ icon trên desktop (app + file + thùng rác) — như "Hide icons" của macOS */
  hideAllIcons?: boolean
}

const LS_KEY = 'wos_user_layout_v2'

/** LS lưu { uid, blob } — uid của tài khoản ghi cache (chống rò rỉ giữa tài khoản) */
interface LSEnvelope {
  uid?: string
  blob?: LayoutBlob
}

function readLS(): LSEnvelope {
  try {
    return JSON.parse(localStorage.getItem(LS_KEY) || '{}') as LSEnvelope
  } catch {
    return {}
  }
}

function writeLS(uid: string | null | undefined, blob: LayoutBlob) {
  try {
    localStorage.setItem(LS_KEY, JSON.stringify({ uid: uid || '', blob }))
  } catch {
    /* quota */
  }
}

interface DesktopState {
  /** layout theo tài khoản (null = chưa load xong) */
  blob: LayoutBlob | null
  /** uid chủ sở hữu blob hiện tại (khớp cache LS + server) */
  uid: string | null
  /** lựa chọn nhóm hiện tại (marquee / multi-select) */
  selection: DesktopSelection | null
  /** tín hiệu "mở hộp thoại thêm web app" từ bất kỳ đâu (menu desktop / Settings) */
  webAppSignal: number
  update: (fn: (prev: LayoutBlob) => LayoutBlob, immediate?: boolean) => void
  reload: () => Promise<void>
  setSelection: (sel: DesktopSelection | null) => void
  clearSelection: () => void
  /** toggle "ẩn icon ứng dụng" từ nhiều nơi (menu/Settings) — lưu NGAY lên server */
  setHideAppIcons: (hidden: boolean) => void
  /** toggle "ẩn toàn bộ icon desktop" (app + file + thùng rác) — lưu NGAY lên server */
  setHideAllIcons: (hidden: boolean) => void
  openWebAppDialog: () => void
}

let saveTimer: ReturnType<typeof setTimeout> | null = null

/** Đưa blob về đúng dạng (bọc non-object về {}) */
function asBlob(v: unknown): LayoutBlob {
  return v && typeof v === 'object' ? (v as LayoutBlob) : {}
}

export const useDesktopStore = create<DesktopState>((set, get) => {
  // Load 1 lần khi store khởi tạo: localStorage trước (instant, không nhấp nháy)
  // → server (nguồn sự thật theo tài khoản) sau. Cache LS chỉ được merge khi
  // uid trong cache TRÙNG uid của session hiện tại (v7 — hết leak giữa tài khoản).
  const cached = readLS()
  void api<{ value: LayoutBlob; userId?: string }>('/api/core/layout?scope=desktop')
    .then((data) => {
      const serverUid = data.userId || ''
      const server = asBlob(data.value)
      const cacheOk = cached.uid && cached.uid === serverUid ? asBlob(cached.blob) : {}
      const merged: LayoutBlob = {
        ...cacheOk,
        ...server,
        widgets: server.widgets ?? cacheOk.widgets,
        appCells: server.appCells ?? cacheOk.appCells,
        fileCells: server.fileCells ?? cacheOk.fileCells,
        filePos: server.filePos ?? cacheOk.filePos,
        hideAppIcons: server.hideAppIcons ?? cacheOk.hideAppIcons,
        hideAllIcons: server.hideAllIcons ?? cacheOk.hideAllIcons,
      }
      writeLS(serverUid, merged)
      set({ blob: merged, uid: serverUid })
    })
    .catch(() => {
      /* offline / chưa đăng nhập → dùng localStorage */
    })

  return {
    blob: asBlob(cached.blob),
    uid: cached.uid || null,
    selection: null,
    webAppSignal: 0,

    /** immediate=true → PUT lên server NGAY (toggle ẩn icon…); mặc định debounce
     *  600ms cho thao tác dồn dập (kéo icon, thả widget) */
    update: (fn, immediate = false) => {
      const next = fn(get().blob || {})
      writeLS(get().uid, next)
      set({ blob: next })
      const send = () => {
        api('/api/core/layout', { method: 'PUT', body: { scope: 'desktop', value: next } }).catch(() => {})
      }
      if (immediate) {
        if (saveTimer) clearTimeout(saveTimer)
        saveTimer = null
        send()
      } else {
        if (saveTimer) clearTimeout(saveTimer)
        saveTimer = setTimeout(() => {
          saveTimer = null
          send()
        }, 600)
      }
    },

    reload: async () => {
      try {
        const data = await api<{ value: LayoutBlob; userId?: string }>('/api/core/layout?scope=desktop')
        const serverUid = data.userId || ''
        const server = asBlob(data.value)
        // đang giữ blob của CHÍNH tài khoản này → cho phép cache lấp chỗ server thiếu;
        // khác tài khoản (vừa đổi tài khoản) → bỏ cache cũ hoàn toàn
        const sameUser = get().uid && get().uid === serverUid ? get().blob || {} : {}
        const merged: LayoutBlob = {
          ...sameUser,
          ...server,
          widgets: server.widgets ?? sameUser.widgets,
          appCells: server.appCells ?? sameUser.appCells,
          fileCells: server.fileCells ?? sameUser.fileCells,
          filePos: server.filePos ?? sameUser.filePos,
          hideAppIcons: server.hideAppIcons ?? sameUser.hideAppIcons,
          hideAllIcons: server.hideAllIcons ?? sameUser.hideAllIcons,
        }
        writeLS(serverUid, merged)
        set({ blob: merged, uid: serverUid })
      } catch {
        /* giữ blob hiện tại */
      }
    },

    setSelection: (selection) => set({ selection }),
    clearSelection: () => set({ selection: null }),

    setHideAppIcons: (hidden) => {
      get().update((prev) => ({ ...prev, hideAppIcons: hidden }), true)
    },

    setHideAllIcons: (hidden) => {
      get().update((prev) => ({ ...prev, hideAllIcons: hidden }), true)
    },

    openWebAppDialog: () => set((s) => ({ webAppSignal: s.webAppSignal + 1 })),
  }
})

/** Xoá cache local (đăng xuất) — giữ tương thích import cũ từ user-layout.
 *  Reset luôn state để tài khoản kế không thấy layout của tài khoản cũ. */
export function clearLocalLayout() {
  localStorage.removeItem(LS_KEY)
  useDesktopStore.setState({ blob: {}, uid: null, selection: null })
}
