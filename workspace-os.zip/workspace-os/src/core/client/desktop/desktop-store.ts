'use client'

/**
 * Desktop Manager (zustand) — Selection Engine + Persistence.
 * - Selection: chọn 1 / chọn nhóm (marquee) dùng chung mọi lớp icon — Desktop.tsx
 *   ghi, DesktopIcons/Files đọc (hết prop-drilling sel/clearSel).
 * - Layout: blob desktop THEO TÀI KHOẢN (localStorage instant + server debounce 600ms)
 *   — chuyển từ hook useUserLayout thành store để Settings (Widget/Dock manager)
 *   cũng đọc/sửa được cùng một nguồn dữ liệu.
 */
import { create } from 'zustand'
import { api } from '../api'
import type { DesktopSelection } from './types'

export interface LayoutBlob {
  widgets?: unknown[]
  appCells?: Record<string, number>
  /** v6: file/folder desktop dùng ô lưới chung với app — không còn chồng chéo */
  fileCells?: Record<string, number>
  /** cũ (≤v5): vị trí px dạng fraction — quy đổi 1 lần sang fileCells rồi bỏ dùng */
  filePos?: Record<string, { fx: number; fy: number }>
  /** ẩn toàn bộ icon ứng dụng (thùng rác + file vẫn hiện) */
  hideAppIcons?: boolean
  /** v6.1: Ẩn TOÀN BỘ icon trên desktop (app + file + thùng rác) — như "Hide icons" của macOS */
  hideAllIcons?: boolean
}

const LS_KEY = 'wos_user_layout_v2'

function readLS(): LayoutBlob {
  try {
    return JSON.parse(localStorage.getItem(LS_KEY) || '{}') as LayoutBlob
  } catch {
    return {}
  }
}

function writeLS(blob: LayoutBlob) {
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(blob))
  } catch {
    /* quota */
  }
}

interface DesktopState {
  /** layout theo tài khoản (null = chưa load xong) */
  blob: LayoutBlob | null
  /** lựa chọn nhóm hiện tại (marquee / multi-select) */
  selection: DesktopSelection | null
  /** tín hiệu "mở hộp thoại thêm web app" từ bất kỳ đâu (menu desktop / Settings) */
  webAppSignal: number
  update: (fn: (prev: LayoutBlob) => LayoutBlob) => void
  reload: () => Promise<void>
  setSelection: (sel: DesktopSelection | null) => void
  clearSelection: () => void
  /** toggle "ẩn icon ứng dụng" từ nhiều nơi (menu/Settings) */
  setHideAppIcons: (hidden: boolean) => void
  /** toggle "ẩn toàn bộ icon desktop" (app + file + thùng rác) */
  setHideAllIcons: (hidden: boolean) => void
  openWebAppDialog: () => void
}

let saveTimer: ReturnType<typeof setTimeout> | null = null

export const useDesktopStore = create<DesktopState>((set, get) => {
  // Load 1 lần khi store khởi tạo: localStorage trước (instant, không nhấp nháy)
  // → server (nguồn sự thật theo tài khoản) sau.
  const cached = readLS()
  void api<{ value: LayoutBlob }>('/api/core/layout?scope=desktop')
    .then((data) => {
      const server = data.value && typeof data.value === 'object' ? data.value : {}
      const merged: LayoutBlob = {
        ...cached,
        ...server,
        widgets: server.widgets ?? cached.widgets,
        appCells: server.appCells ?? cached.appCells,
        fileCells: server.fileCells ?? cached.fileCells,
        filePos: server.filePos ?? cached.filePos,
        hideAppIcons: server.hideAppIcons ?? cached.hideAppIcons,
        hideAllIcons: server.hideAllIcons ?? cached.hideAllIcons,
      }
      writeLS(merged)
      set({ blob: merged })
    })
    .catch(() => {
      /* offline / chưa đăng nhập → dùng localStorage */
    })

  return {
    blob: cached,
    selection: null,
    webAppSignal: 0,

    update: (fn) => {
      const next = fn(get().blob || {})
      writeLS(next)
      set({ blob: next })
      if (saveTimer) clearTimeout(saveTimer)
      saveTimer = setTimeout(() => {
        api('/api/core/layout', { method: 'PUT', body: { scope: 'desktop', value: next } }).catch(() => {})
      }, 600)
    },

    reload: async () => {
      try {
        const data = await api<{ value: LayoutBlob }>('/api/core/layout?scope=desktop')
        const server = data.value && typeof data.value === 'object' ? data.value : {}
        writeLS(server)
        set({ blob: server })
      } catch {
        /* giữ blob hiện tại */
      }
    },

    setSelection: (selection) => set({ selection }),
    clearSelection: () => set({ selection: null }),

    setHideAppIcons: (hidden) => {
      get().update((prev) => ({ ...prev, hideAppIcons: hidden }))
    },

    setHideAllIcons: (hidden) => {
      get().update((prev) => ({ ...prev, hideAllIcons: hidden }))
    },

    openWebAppDialog: () => set((s) => ({ webAppSignal: s.webAppSignal + 1 })),
  }
})

/** Xoá cache local (đăng xuất) — giữ tương thích import cũ từ user-layout */
export function clearLocalLayout() {
  localStorage.removeItem(LS_KEY)
}
