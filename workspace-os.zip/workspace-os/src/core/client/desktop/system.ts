'use client'

/**
 * System service — lớp trung gian DUY NHẤT giữa Desktop và Apps/API (review #1).
 * Desktop KHÔNG gọi trực tiếp `openApp('files', { route })` nữa:
 *
 *   Desktop → system.openPath("/Desktop/Documents") → File Service → Files App
 *
 * system tự dò: thư mục → app Files (deep-link chuẩn hoá), tệp → app đúng loại
 * theo phần mở rộng (PDF → Documents, mp4 → Media…), .url → Browser.
 * Tập trung cả thao tác hệ thống: Paste, tạo mới, làm mới, upload.
 */
import { useWindows } from '../window-store'
import { openFile } from '../applications'
import { api } from '../api'
import { bus } from '../event-bus'
import { useClipboard } from '../clipboard'
import { toast } from 'sonner'

export interface OpenPathMeta {
  isDir?: boolean
  mime?: string
}

/** Đọc shortcut .url → trả về URL bên trong */
async function readUrlShortcut(path: string): Promise<string | null> {
  try {
    const d = await api<{ content?: string }>(`/api/modules/files/read?path=${encodeURIComponent(path)}`)
    const url = (d.content || '').replace(/^\s*\[InternetShortcut\]\s*URL=/i, '').split(/\r?\n/)[0]?.trim()
    return url && /^https?:\/\//i.test(url) ? url : null
  } catch {
    return null
  }
}

export const system = {
  /**
   * Mở 1 đường dẫn (thư mục / tệp / shortcut .url) bằng app phù hợp.
   * Điểm vào duy nhất cho double-click trên Desktop & Files.
   */
  openPath(path: string, meta?: OpenPathMeta): void {
    const openApp = useWindows.getState().openApp
    const name = path.split('/').pop() || path
    const ext = name.includes('.') ? name.split('.').pop()?.toLowerCase() || '' : ''

    // Thư mục → app Files với deep-link chuẩn hoá (một định dạng, một nơi xử lý)
    if (meta?.isDir) {
      openApp('files', { route: `files:${encodeURIComponent(path)}` })
      return
    }

    if (ext === 'url') {
      void readUrlShortcut(path).then((url) => {
        if (url) openApp('browser', { route: `browser:${encodeURIComponent(url)}` })
        else openApp('viewer', { route: `viewer:${encodeURIComponent(path)}`, key: `v:${encodeURIComponent(path)}` })
      })
      return
    }

    // Tệp → Application System dò app theo ext (pdf→doc, mp4→media, txt/ảnh→viewer)
    openFile(path)
    if (ext && ['txt', 'md', 'json', 'csv', 'log', 'ini', 'conf', 'env'].includes(ext)) {
      void api('/api/modules/files/view', { method: 'POST', body: { path } }).catch(() => {})
    }
  },

  /** Mở thư mục trong app Files (dùng cho "Mở trong Files", breadcrumb…) */
  openDir(path: string): void {
    useWindows.getState().openApp('files', { route: `files:${encodeURIComponent(path)}` })
  },

  /** Mở thùng rác */
  openTrash(): void {
    useWindows.getState().openApp('files', { route: 'files:trash' })
  },

  /** Dán clipboard (tệp Copy/Cut hoặc text) vào thư mục — dùng chung Desktop + Files */
  async pasteInto(dir: string): Promise<void> {
    const r = await useClipboard.getState().pasteInto(dir)
    if (r.ok > 0) toast.success(`Đã dán ${r.ok} mục${r.failed.length ? `, ${r.failed.length} lỗi` : ''}`)
    else if (r.failed.length) toast.error('Không dán được', { description: r.failed[0] })
  },

  /** Tạo thư mục / tệp văn bản mới trong thư mục (menu "Tạo mới") */
  async createIn(dir: string, kind: 'folder' | 'file', name: string): Promise<void> {
    if (kind === 'folder') {
      await api('/api/modules/files/mkdir', { method: 'POST', body: { path: dir, name } })
    } else {
      await api('/api/modules/files/newfile', { method: 'POST', body: { path: dir, name, content: '' } })
    }
    bus.emit('file.uploaded', 'files', { name })
  },

  /** Làm mới desktop (icon file + thùng rác) — menu "Làm mới" */
  refreshDesktop(): void {
    bus.emit('file.updated', 'files', { name: 'refresh' })
  },

  /** Tải tệp lên thư mục Desktop (dùng chung: kéo-thả desktop + nút trong Settings) */
  async uploadToDesktop(files: FileList | File[]): Promise<void> {
    const arr = Array.from(files)
    if (arr.length === 0) return
    const form = new FormData()
    for (const f of arr) form.append('files', f)
    await new Promise<void>((resolve, reject) => {
      const xhr = new XMLHttpRequest()
      xhr.open('POST', '/api/modules/files/upload?dir=Desktop')
      xhr.onload = () =>
        xhr.status < 300
          ? resolve()
          : reject(new Error(JSON.parse(xhr.responseText || '{}').error || `HTTP ${xhr.status}`))
      xhr.onerror = () => reject(new Error('Lỗi mạng khi tải lên'))
      xhr.send(form)
    })
    bus.emit('file.uploaded', 'files', { name: arr.length === 1 ? arr[0].name : `${arr.length} tệp` })
  },
}
