'use client'

/**
 * Desktop Manager — tầng quản lý desktop duy nhất (kiến trúc review):
 *
 *   Desktop Manager
 *   ├── Object Registry  (types.ts — mọi thứ trên desktop là DesktopObject)
 *   ├── Grid Engine      (grid.ts + cells.ts — lưới chung, không chồng chéo)
 *   ├── Selection Engine (desktop-store.ts — chọn 1 / chọn nhóm marquee)
 *   ├── Drag Engine      (trong DesktopIcons — snap qua Grid Engine)
 *   ├── Persistence      (desktop-store.ts — blob theo tài khoản, LS + server)
 *   └── System service   (system.ts — system.openPath() và thao tác hệ thống)
 *
 * Desktop.tsx chỉ còn là "Desktop Environment" (wallpaper, menu, marquee)
 * — không tự làm File Manager / App Launcher / Widget Manager nữa.
 */
export type {
  DesktopObjectType,
  DesktopObject,
  DesktopSelection,
  DesktopIconSize,
  WindowControlSide,
} from './types'
export {
  ICON_SIZES,
  iconSizePreset,
  gridMetrics,
  cellPos,
  cellFromPoint,
  nearestFreeCell,
  defaultAppOrder,
  defaultFileOrder,
  trashCell,
} from './grid'
export { assignAppCells, assignFileCells, sortFileCells } from './cells'
export { useDesktopStore, clearLocalLayout, type LayoutBlob } from './desktop-store'
export { system, type OpenPathMeta } from './system'
