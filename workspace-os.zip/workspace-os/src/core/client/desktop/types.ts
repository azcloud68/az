'use client'

/**
 * Desktop Manager — kiểu dữ liệu chung cho MỌI đối tượng trên desktop.
 * Theo kiến trúc review: Icon / App / File / Folder / Widget đều là "DesktopObject",
 * được một tầng quản lý duy nhất (Grid Engine + Selection + Persistence + System service)
 * điều phối — Desktop.tsx không tự làm hết mọi việc nữa.
 */

export type DesktopObjectType = 'app' | 'folder' | 'file' | 'widget' | 'trash'

/** 1 đối tượng trên desktop — app/file/folder dùng chung không gian ô lưới (cell) */
export interface DesktopObject {
  id: string
  type: DesktopObjectType
  /** ô lưới chung (index = col * rows + row, col tính từ trái) */
  cell?: number
  /** widget: vị trí tự do dạng fraction (không thuộc lưới icon) */
  fx?: number
  fy?: number
}

/** Kết quả chọn nhóm (marquee) — dùng chung giữa Desktop và các lớp icon */
export interface DesktopSelection {
  apps: string[]
  files: string[]
}

/** Cỡ icon desktop — tuỳ chọn trong Settings → Appearance (review #7) */
export type DesktopIconSize = 'small' | 'medium' | 'large'

/** Vị trí nút điều khiển cửa sổ (review #4) */
export type WindowControlSide = 'left' | 'right'
