'use client'

/**
 * WOS Context Registry (Giai đoạn 2 — Lớp B) — AI biết app nào đang mở, route nào đang xem.
 *
 * Nguồn dữ liệu:
 *  - window-store  : danh sách cửa sổ (moduleId, key, route, z, minimized) — active =
 *                    cửa sổ z cao nhất chưa thu nhỏ
 *  - client bus    : event 'wos:selection' — module phát khi người dùng chọn dữ liệu
 *                    (vd TasksPage bấm 1 công việc) → registry giữ selection gần nhất theo module
 *
 * Plugin đọc qua WOS.getContext() — snapshot gửi kèm POST /api/ai/chat (activeContext).
 * KHÔNG lưu nội dung nhạy cảm — chỉ metadata (app, route, selection do module tự công bố).
 */
import { useWindows } from './window-store'
import { bus } from './event-bus'

export interface WorkspaceSelection {
  module: string
  type: string
  title?: string
  data?: Record<string, unknown>
  at: string
}

export interface WorkspaceContextSnapshot {
  activeApp: string
  activeRoute: string
  openApps: Array<{ id: string; key: string; title: string; route: string }>
  selection?: WorkspaceSelection
  at: string
}

/** Tên hiển thị của module (đồng bộ app-registry/widgets) */
const MODULE_TITLES: Record<string, string> = {
  dashboard: 'Bảng điều khiển',
  tasks: 'Công việc',
  calendar: 'Lịch',
  weekly: 'Công việc tuần',
  notes: 'Ghi chú',
  wiki: 'Wiki',
  files: 'Tệp tin',
  projects: 'Dự án',
  timeline: 'Dòng thời gian',
  activity: 'Hoạt động',
  reports: 'Báo cáo',
  notifications: 'Thông báo',
  settings: 'Cài đặt',
  browser: 'Trình duyệt',
  terminal: 'Terminal',
  monitor: 'Giám sát',
  downloads: 'Tải xuống',
  doc: 'Tài liệu',
  media: 'Media',
  viewer: 'Trình xem tệp',
}

const g = globalThis as unknown as {
  __wosSelections?: Map<string, WorkspaceSelection>
  __wosCtxStarted?: boolean
}

function selections(): Map<string, WorkspaceSelection> {
  if (!g.__wosSelections) g.__wosSelections = new Map()
  return g.__wosSelections
}

/** Bắt đầu lắng nghe selection (module gọi 1 lần — hoặc khởi động từ WosApp) */
export function startContextRegistry(): void {
  if (g.__wosCtxStarted || typeof window === 'undefined') return
  g.__wosCtxStarted = true
  bus.on('wos:selection', (ev) => {
    const p = ev.payload || {}
    if (!p.module || !p.type) return
    selections().set(String(p.module), {
      module: String(p.module),
      type: String(p.type),
      title: p.title ? String(p.title).slice(0, 120) : undefined,
      data: (p.data && typeof p.data === 'object' ? p.data : undefined) as Record<string, unknown> | undefined,
      at: new Date().toISOString(),
    })
  })
}

/** Module phát selection — ví dụ TasksPage: emitSelection('tasks', 'task', task.title, {id}) */
export function emitSelection(module: string, type: string, title?: string, data?: Record<string, unknown>): void {
  bus.emit('wos:selection', module, { module, type, title, data })
}

/** Snapshot ngữ cảnh hiện tại (gọi khi cần — không tốn render) */
export function getContextSnapshot(): WorkspaceContextSnapshot {
  const st = useWindows.getState()
  const sorted = [...st.windows].sort((a, b) => b.z - a.z)
  const visible = sorted.filter((w) => !w.minimized)
  const active = visible[0]
  const sel = active ? selections().get(active.moduleId) : undefined
  return {
    activeApp: active?.moduleId || '',
    activeRoute: active?.route || '',
    openApps: sorted.slice(0, 12).map((w) => ({
      id: w.moduleId,
      key: w.key || '',
      title: MODULE_TITLES[w.moduleId] || w.moduleId,
      route: w.route,
    })),
    selection: sel,
    at: new Date().toISOString(),
  }
}
