'use client'

/**
 * WOS Application System (V3) — Registry + File Router kiểu macOS Launch Services.
 * Window Manager KHÔNG cần biết nội dung cửa sổ là gì — chỉ cần appId + window spec.
 * App chia theo 'type':
 *   native    → trang React có sẵn trong PAGES (Files, Tasks, Settings…)
 *   document  → Document Engine (PDF/DOCX/XLSX/PPTX) — route 'doc:<encodedPath>'
 *   media     → Media Player (video/audio) — route 'media:<encodedPath>'
 *   browser   → Web Browser — route 'browser:<encodedUrl>'
 *   system    → app hệ thống (Terminal, Monitor, Downloads…)
 * Mở tệp: openFile(path) → dò ext → đúng app → openApp(appId, key, route).
 */
import { useWindows } from './window-store'

export type AppType = 'native' | 'document' | 'media' | 'browser' | 'system'

export interface AppDefinition {
  id: string
  name: string
  icon: string
  color: string
  type: AppType
  /** Kích thước cửa sổ mặc định */
  window: { w: number; h: number }
  /** Phần mở rộng tệp app này xử lý (chữ thường, không dấu chấm) */
  exts: string[]
  /** App chỉ mở 1 cửa sổ chính (browser/terminal) — app khác mở nhiều cửa sổ theo key */
  singleton?: boolean
  /** Ẩn khỏi Launchpad (app chỉ mở gián tiếp qua tệp) */
  hidden?: boolean
}

/** Registry app hệ thống — module nghiệp vụ (tasks/projects/…) tự động là app native */
export const SYSTEM_APPS: AppDefinition[] = [
  {
    id: 'browser',
    name: 'Trình duyệt',
    icon: 'globe',
    color: '#0ea5e9',
    type: 'browser',
    window: { w: 1120, h: 720 },
    exts: ['url', 'htm', 'html'],
    singleton: true,
  },
  {
    id: 'terminal',
    name: 'Terminal',
    icon: 'terminal-square',
    color: '#1f2937',
    type: 'system',
    window: { w: 840, h: 540 },
    exts: ['sh'],
  },
  {
    id: 'monitor',
    name: 'System Monitor',
    icon: 'gauge',
    color: '#ef4444',
    type: 'system',
    window: { w: 960, h: 640 },
    exts: [],
  },
  {
    id: 'downloads',
    name: 'Downloads',
    icon: 'download',
    color: '#6366f1',
    type: 'system',
    window: { w: 620, h: 520 },
    exts: [],
  },
  {
    id: 'doc',
    name: 'Documents',
    icon: 'file-text',
    color: '#f97316',
    type: 'document',
    window: { w: 940, h: 700 },
    exts: ['pdf', 'docx', 'xlsx', 'xls', 'pptx', 'csv', 'tsv'],
  },
  {
    id: 'media',
    name: 'Media Player',
    icon: 'play',
    color: '#ec4899',
    type: 'media',
    window: { w: 860, h: 580 },
    exts: ['mp4', 'webm', 'mov', 'mkv', 'm4v', 'avi', 'mp3', 'wav', 'ogg', 'flac', 'm4a', 'aac', 'opus'],
  },
  {
    id: 'viewer',
    name: 'Trình xem tệp',
    icon: 'file-text',
    color: '#22c55e',
    type: 'native',
    window: { w: 760, h: 600 },
    exts: [
      'txt', 'md', 'markdown', 'json', 'xml', 'yml', 'yaml', 'log', 'ini', 'conf', 'env',
      'js', 'ts', 'tsx', 'jsx', 'css', 'py', 'sql', 'sh',
      'png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'bmp', 'avif', 'ico',
    ],
  },
]

const APP_BY_ID = new Map(SYSTEM_APPS.map((a) => [a.id, a]))

/** Map ext → appId (app đầu tiên khớp trong registry thắng) */
const EXT_MAP: Record<string, string> = {}
for (const app of SYSTEM_APPS) {
  for (const ext of app.exts) {
    if (!EXT_MAP[ext]) EXT_MAP[ext] = app.id
  }
}

export function getApp(id: string): AppDefinition | undefined {
  return APP_BY_ID.get(id)
}

export function extOf(name: string): string {
  const n = name.split('/').pop() || ''
  const i = n.lastIndexOf('.')
  return i > 0 ? n.slice(i + 1).toLowerCase() : ''
}

/** Dò app xử lý tệp theo tên (giống Launch Services) — null = không app nào xử lý */
export function findAppForFile(name: string): AppDefinition | null {
  const ext = extOf(name)
  const appId = EXT_MAP[ext]
  return appId ? APP_BY_ID.get(appId) || null : null
}

/**
 * Mở tệp bằng app phù hợp — điểm vào duy nhất cho double-click Files/Desktop.
 * Trả về appId đã mở (hoặc 'viewer' mặc định cho tệp lạ).
 */
export function openFile(path: string): string {
  const name = path.split('/').pop() || path
  const app = findAppForFile(name)
  const appId = app?.id || 'viewer'
  const enc = encodeURIComponent(path)
  const key = app ? `f:${enc}` : `v:${enc}`
  const route = appId === 'viewer' ? `viewer:${enc}` : `${appId}:${enc}`
  useWindows.getState().openApp(appId, { key, route })
  return appId
}

/** Mở URL trong app Browser của WOS (tab mới, focus cửa sổ) */
export function openUrl(url: string): void {
  const enc = encodeURIComponent(url)
  useWindows.getState().openApp('browser', { route: `browser:${enc}` })
}

/** URL hiển thị trên thanh địa chỉ / logs — đảm bảo có scheme */
export function normalizeUrl(input: string): string {
  const s = input.trim()
  if (!s) return ''
  if (/^https?:\/\//i.test(s)) return s
  if (/^[\w-]+(\.[\w-]+)+([/?#].*)?$/i.test(s)) return `https://${s}` // ví dụ google.com → https://
  return s // để nguyên (có thể là từ khoá tìm kiếm)
}

/** Chuỗi nhập vào thanh địa chỉ → URL hoặc truy vấn tìm kiếm */
export function urlOrSearch(input: string, engine = 'https://duckduckgo.com/?q='): string {
  const s = input.trim()
  if (!s) return ''
  const looksUrl = /^https?:\/\//i.test(s) || /^[\w-]+(\.[\w-]{2,})+([/?#].*)?$/i.test(s) || s.startsWith('localhost')
  return looksUrl ? normalizeUrl(s) : engine + encodeURIComponent(s)
}

/** Tên miền gọn của URL (hiển thị title/tab) — 'google.com' từ 'https://google.com/x?y=1' */
export function prettyHost(url: string): string {
  try {
    const u = new URL(normalizeUrl(url))
    return u.hostname.replace(/^www\./, '')
  } catch {
    return url.slice(0, 40)
  }
}
