'use client'

/**
 * Drag & Drop thư mục từ máy thật (PC) vào Workspace OS.
 *
 * Trước đây các drop-handler chỉ đọc `e.dataTransfer.files` — khi kéo THƯ MỤC,
 * Chrome chỉ trả về 1 File 0 byte (hoặc rỗng) → thư mục bị bỏ qua hoàn toàn.
 *
 * Cách duyệt đúng: `dataTransfer.items[i].webkitGetAsEntry()` trả về
 * FileSystemEntry (file/dir); thư mục duyệt đệ quy qua `createReader().readEntries()`
 * (mỗi lần gọi trả tối đa 100 entry → phải đọc vòng lặp đến khi rỗng).
 *
 * Kết quả: danh sách PHẲNG `{ file, relPath }` — relPath giữ cấu trúc thư mục
 * ("MyFolder/sub/a.txt") để gửi kèm upload (server tự mkdir từng cấp).
 */

export interface DroppedItem {
  file: File
  /** Đường dẫn tương đối so với điểm thả, vd "du-an/src/main.ts" */
  relPath: string
}

interface FileSystemEntryLike {
  isFile: boolean
  isDirectory: boolean
  name: string
  fullPath: string
  file?: (cb: (f: File) => void, err?: (e: unknown) => void) => void
  createReader?: () => { readEntries: (cb: (entries: FileSystemEntryLike[]) => void, err?: (e: unknown) => void) => void }
}

/** Đọc hết entry con của 1 thư mục (readEntries trả từng lô ≤100 — phải lặp) */
function readAllEntries(dir: FileSystemEntryLike): Promise<FileSystemEntryLike[]> {
  return new Promise((resolve, reject) => {
    const reader = dir.createReader?.()
    if (!reader) return resolve([])
    const out: FileSystemEntryLike[] = []
    const readBatch = () => {
      reader.readEntries(
        (batch) => {
          if (batch.length === 0) return resolve(out)
          out.push(...batch)
          readBatch()
        },
        (err) => reject(err),
      )
    }
    readBatch()
  })
}

/** Đọc File từ entry file */
function entryToFile(entry: FileSystemEntryLike): Promise<File | null> {
  return new Promise((resolve) => {
    if (!entry.file) return resolve(null)
    entry.file(
      (f) => resolve(f),
      () => resolve(null),
    )
  })
}

/** Đệ quy 1 entry (file hoặc thư mục) → danh sách phẳng */
async function walkEntry(entry: FileSystemEntryLike, prefix: string, out: DroppedItem[], budget: { count: number }): Promise<void> {
  // An toàn: giới hạn tổng số tệp 1 lần thả (tránh treo UI với thư mục cực lớn)
  if (budget.count <= 0) return
  if (entry.isFile) {
    const file = await entryToFile(entry)
    if (file) {
      out.push({ file, relPath: prefix ? `${prefix}/${file.name}` : file.name })
      budget.count--
    }
    return
  }
  if (entry.isDirectory) {
    const children = await readAllEntries(entry)
    for (const child of children) {
      await walkEntry(child, prefix ? `${prefix}/${entry.name}` : entry.name, out, budget)
    }
  }
}

/**
 * Trích toàn bộ file + thư mục từ sự kiện drop — hỗ trợ cả file lẻ lẫn cây thư mục.
 * Trả về null nếu DataTransferItem API không khả dụng (fallback cho caller).
 */
export async function extractDroppedItems(dt: DataTransfer): Promise<DroppedItem[] | null> {
  const items = dt.items
  if (!items || typeof items[0]?.webkitGetAsEntry !== 'function') return null
  // PHẢI gọi webkitGetAsEntry ĐỒNG THỜI ĐIỂM (async sau đó entry bị detach)
  const entries: (FileSystemEntryLike | null)[] = []
  for (let i = 0; i < items.length; i++) {
    const it = items[i]
    if (it.kind !== 'file') continue
    try {
      entries.push((it as DataTransferItem & { webkitGetAsEntry?: () => FileSystemEntryLike | null }).webkitGetAsEntry?.() || null)
    } catch {
      entries.push(null)
    }
  }
  if (!entries.some(Boolean)) return null

  const out: DroppedItem[] = []
  const budget = { count: 5000 } // 5000 tệp / lần thả
  for (const e of entries) {
    if (e) await walkEntry(e, '', out, budget)
  }
  return out
}

/** true khi sự kiện kéo có chứa cả thư mục (hiện overlay "thả để tải lên") */
export function dropHasAnyFile(dt: DataTransfer): boolean {
  if (!dt.items?.length) return dt.files?.length > 0
  for (let i = 0; i < dt.items.length; i++) {
    if (dt.items[i].kind === 'file') return true
  }
  return dt.files?.length > 0
}
