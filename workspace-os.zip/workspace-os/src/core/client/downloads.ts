'use client'

/**
 * WOS Download Manager — như PC: theo dõi tiến trình tải xuống qua HTTP stream.
 * - startDownload(): fetch + ReadableStream → đo % theo Content-Length → blob → lưu
 * - Cancel được giữa chừng (AbortController)
 * - Files/Viewer/Browser gọi helper; MenuBar hiện chỉ báo; app Downloads liệt kê
 * - Tệp tải xong mở lại được qua Application System (openFile)
 */
import { create } from 'zustand'

export interface DownloadItem {
  id: string
  name: string
  url: string
  /** Đường dẫn WOS của tệp (nếu tải từ File Manager) — mở lại bằng openFile */
  path?: string
  size: number
  received: number
  status: 'active' | 'done' | 'error' | 'cancelled'
  error?: string
  startedAt: number
  finishedAt?: number
}

interface DownloadState {
  items: DownloadItem[]
  /** Bắt đầu tải (stream + đo tiến trình) — id trả về để cancel */
  startDownload: (opts: { url: string; name?: string; path?: string }) => string
  cancel: (id: string) => void
  retry: (id: string) => void
  remove: (id: string) => void
  clearFinished: () => void
}

let dlSeq = 1
const controllers = new Map<string, AbortController>()

/** Đọc tên tệp từ header Content-Disposition (chuẩn RFC + fallback filename=) */
function fileNameFromDisposition(cd: string | null): string {
  if (!cd) return ''
  const utf8 = cd.match(/filename\*=(?:UTF-8'')?([^;]+)/i)?.[1]
  if (utf8) {
    try {
      return decodeURIComponent(utf8.trim().replace(/^"|"$/g, ''))
    } catch {
      /* rơi về filename thường */
    }
  }
  const plain = cd.match(/filename="?([^";]+)"?/i)?.[1]
  return plain ? plain.trim() : ''
}

export const useDownloads = create<DownloadState>((set, get) => ({
  items: [],

  startDownload: ({ url, name, path }) => {
    const id = `dl-${dlSeq++}`
    const fallbackName = path ? path.split('/').pop() || 'tai-xuong' : 'tai-xuong'
    const item: DownloadItem = {
      id,
      name: name || fallbackName,
      url,
      path,
      size: 0,
      received: 0,
      status: 'active',
      startedAt: Date.now(),
    }
    set((s) => ({ items: [item, ...s.items].slice(0, 50) }))

    const ac = new AbortController()
    controllers.set(id, ac)

    ;(async () => {
      try {
        const res = await fetch(url, { signal: ac.signal, credentials: 'same-origin' })
        if (!res.ok) throw new Error(`HTTP ${res.status}`)
        const cd = res.headers.get('content-disposition')
        const finalName = name || fileNameFromDisposition(cd) || fallbackName
        const size = Number(res.headers.get('content-length')) || 0
        if (finalName !== fallbackName || size) {
          set((s) => ({
            items: s.items.map((i) => (i.id === id ? { ...i, name: finalName, size } : i)),
          }))
        }

        if (!res.body) {
          // trình duyệt cũ — tải kiểu blob một cục
          const blob = await res.blob()
          set((s) => ({
            items: s.items.map((i) =>
              i.id === id ? { ...i, received: blob.size, size: blob.size, status: 'done', finishedAt: Date.now() } : i,
            ),
          }))
          saveBlob(blob, finalName)
          return
        }

        const reader = res.body.getReader()
        const chunks: BlobPart[] = []
        for (;;) {
          const { done, value } = await reader.read()
          if (done) break
          if (value) {
            chunks.push(value as unknown as BlobPart)
            const received = get().items.find((i) => i.id === id)?.received || 0
            set((s) => ({
              items: s.items.map((i) =>
                i.id === id ? { ...i, received: received + value.byteLength } : i,
              ),
            }))
          }
        }
        set((s) => ({
          items: s.items.map((i) =>
            i.id === id ? { ...i, status: 'done', finishedAt: Date.now() } : i,
          ),
        }))
        saveBlob(new Blob(chunks), finalName)
      } catch (err) {
        const aborted = err instanceof DOMException && err.name === 'AbortError'
        set((s) => ({
          items: s.items.map((i) =>
            i.id === id
              ? {
                  ...i,
                  status: aborted ? 'cancelled' : 'error',
                  error: aborted ? undefined : err instanceof Error ? err.message : 'Lỗi tải',
                }
              : i,
          ),
        }))
      } finally {
        controllers.delete(id)
      }
    })()

    return id
  },

  cancel: (id) => {
    controllers.get(id)?.abort()
  },

  retry: (id) => {
    const item = get().items.find((i) => i.id === id)
    if (!item) return
    set((s) => ({ items: s.items.filter((i) => i.id !== id) }))
    get().startDownload({ url: item.url, name: item.name, path: item.path })
  },

  remove: (id) => {
    controllers.get(id)?.abort()
    set((s) => ({ items: s.items.filter((i) => i.id !== id) }))
  },

  clearFinished: () => set((s) => ({ items: s.items.filter((i) => i.status === 'active') })),
}))

function saveBlob(blob: Blob, name: string) {
  const a = document.createElement('a')
  const objUrl = URL.createObjectURL(blob)
  a.href = objUrl
  a.download = name
  document.body.appendChild(a)
  a.click()
  a.remove()
  setTimeout(() => URL.revokeObjectURL(objUrl), 30000)
}

/** Helper: tải tệp WOS từ File Manager về máy thật (kèm tiến trình) */
export function startFileDownload(path: string, name?: string): string {
  return useDownloads
    .getState()
    .startDownload({ url: `/api/modules/files/download?path=${encodeURIComponent(path)}`, name, path })
}

/** Tổng quan cho MenuBar: số đang tải + % trung bình */
export function downloadsSummary(items: DownloadItem[]): { active: number; pct: number } {
  const activeItems = items.filter((i) => i.status === 'active')
  if (activeItems.length === 0) return { active: 0, pct: 0 }
  const known = activeItems.filter((i) => i.size > 0)
  const pct =
    known.length > 0
      ? Math.round((known.reduce((a, i) => a + i.received / i.size, 0) / known.length) * 100)
      : 0
  return { active: activeItems.length, pct }
}

export function formatBytes(n: number): string {
  if (!Number.isFinite(n) || n <= 0) return '—'
  const units = ['B', 'KB', 'MB', 'GB']
  let v = n
  let u = 0
  while (v >= 1024 && u < units.length - 1) {
    v /= 1024
    u++
  }
  return `${v >= 100 ? Math.round(v) : v.toFixed(1).replace(/\.0$/, '')} ${units[u]}`
}
