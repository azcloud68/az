'use client'

/**
 * WOS Event Bus (client) — pub/sub trong trình duyệt
 * Task hoàn thành → bus.emit('task.completed') → Timeline, Activity, Notification,
 * Dashboard widget tự cập nhật. Module không import module — chỉ biết event name.
 */

export interface WosEvent {
  type: string
  module: string
  payload?: Record<string, unknown>
  at?: string
}

type Handler = (ev: WosEvent) => void

class EventBus {
  private handlers = new Map<string, Set<Handler>>()
  private anyHandlers = new Set<Handler>()
  private history: WosEvent[] = []

  on(type: string, handler: Handler): () => void {
    if (!this.handlers.has(type)) this.handlers.set(type, new Set())
    this.handlers.get(type)!.add(handler)
    return () => this.handlers.get(type)?.delete(handler)
  }

  /** Lắng nghe mọi event (dùng cho Notification toast) */
  onAny(handler: Handler): () => void {
    this.anyHandlers.add(handler)
    return () => this.anyHandlers.delete(handler)
  }

  emit(type: string, module: string, payload?: Record<string, unknown>): void {
    const ev: WosEvent = { type, module, payload, at: new Date().toISOString() }
    this.history.unshift(ev)
    if (this.history.length > 50) this.history.pop()
    this.handlers.get(type)?.forEach((h) => {
      try { h(ev) } catch (e) { console.error('[bus]', e) }
    })
    this.anyHandlers.forEach((h) => {
      try { h(ev) } catch (e) { console.error('[bus]', e) }
    })
  }

  recent(): WosEvent[] {
    return this.history
  }
}

export const bus = new EventBus()

/** Danh sách event chuẩn hệ thống (khớp server event-bus) */
export const EVENT_LABELS: Record<string, string> = {
  'auth.login': 'đăng nhập',
  'auth.logout': 'đăng xuất',
  'auth.password': 'đổi mật khẩu',
  'task.created': 'tạo công việc',
  'task.updated': 'cập nhật công việc',
  'task.completed': 'hoàn thành',
  'task.deleted': 'xoá công việc',
  'event.created': 'tạo sự kiện',
  'event.updated': 'sửa sự kiện',
  'event.deleted': 'xoá sự kiện',
  'note.created': 'tạo ghi chú',
  'note.updated': 'sửa ghi chú',
  'note.deleted': 'xoá ghi chú',
  'wiki.created': 'tạo wiki',
  'wiki.updated': 'sửa wiki',
  'wiki.deleted': 'xoá wiki',
  'file.uploaded': 'tải lên',
  'file.updated': 'cập nhật tệp',
  'file.downloaded': 'tải xuống',
  'file.deleted': 'xoá tệp',
  'file.restored': 'khôi phục tệp',
  'file.shared': 'chia sẻ tệp',
  'project.created': 'tạo dự án',
  'project.updated': 'cập nhật dự án',
  'project.archived': 'lưu trữ dự án',
  'milestone.completed': 'hoàn thành mốc',
  'module.enabled': 'bật module',
  'module.disabled': 'tắt module',
  'settings.updated': 'thay đổi cấu hình',
  'user.created': 'tạo người dùng',
  'user.updated': 'sửa người dùng',
  'user.deleted': 'xoá người dùng',
  'group.created': 'tạo nhóm',
  'backup.exported': 'xuất sao lưu',
  'backup.imported': 'nhập sao lưu',
  'weekly.process.created': 'tạo quy trình',
  'weekly.process.updated': 'sửa quy trình',
  'weekly.process.deleted': 'xoá quy trình',
  'weekly.task.completed': 'hoàn thành việc tuần',
  'weekly.task.passed': 'pass việc tuần',
  'weekly.day.offline': 'đánh dấu ngày nghỉ',
  'sync.backup.ok': 'backup lên Drive thành công',
  'sync.backup.error': 'backup Drive lỗi',
}

export function eventLabel(type: string): string {
  return EVENT_LABELS[type] || type
}
