'use client'

/**
 * Route Context — mỗi cửa sổ có route riêng (deep-link trong app, vd 'wiki:pageId').
 * Trang trong cửa sổ dùng useRoute() thay vì route toàn cục.
 * `seq` tăng mỗi lần route được GÁN (kể cả cùng giá trị) → app deep-link (Files…)
 * bắt được cả trường hợp "click lại đúng thư mục đang mở" (review #1).
 */
import { createContext, useContext, type ReactNode } from 'react'

interface RouteCtx {
  route: string
  navigate: (r: string) => void
  /** bộ đếm lần gán route — dùng làm dependency useEffect deep-link */
  seq: number
}

const RouteContext = createContext<RouteCtx>({ route: '', navigate: () => {}, seq: 0 })

export function RouteProvider({ route, navigate, seq = 0, children }: RouteCtx & { children: ReactNode }) {
  return <RouteContext.Provider value={{ route, navigate, seq }}>{children}</RouteContext.Provider>
}

export function useRoute(): RouteCtx {
  return useContext(RouteContext)
}
