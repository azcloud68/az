'use client'

/**
 * WOS Plugin Store (client) — tải & đăng ký app từ plugin cài ngoài.
 *
 * Quy trình:
 * 1. PluginHost gọi load() sau khi đăng nhập → GET /api/plugins
 * 2. Với mỗi plugin đang bật: inject <script src="/api/plugins/<id>/files/<entry>?v=<updatedAt>">
 * 3. Bundle plugin gọi WOS.registerApp({ id, component }) → thêm vào store
 *    → icon xuất hiện trên Desktop / Launchpad / Dock, mở như app cửa sổ bình thường
 *
 * WOS global (window.WOS) cung cấp cho plugin:
 *   - registerApp(app)        : đăng ký app (component dùng React CỦA WOS — không bundle lại)
 *   - React / ReactDOM        : tham chiếu React của hệ thống
 *   - storage.get/set/del/list: dữ liệu plugin (namespace server-side theo pluginId)
 *   - events.on/emit          : Event Bus toàn hệ thống
 *   - notify(title, body)     : tạo thông báo
 *   - navigate(route)         : mở/focus app (vd 'tasks', 'files:Documents')
 */
import { create } from 'zustand'
import type { ComponentType } from 'react'
import { bus } from './event-bus'
import { wosNavigate } from './window-store'

export interface PluginApp {
  id: string // appId: "plugin:<pluginId>"
  pluginId: string
  name: string
  icon: string // URL asset hoặc emoji
  color?: string
  window?: { w?: number; h?: number; minW?: number; minH?: number }
  component?: ComponentType
  mount?: (el: HTMLElement) => void | (() => void)
}

interface PluginState {
  apps: PluginApp[]
  status: 'idle' | 'loading' | 'ready' | 'error'
  error: string
  /** manifest từ server (để hiện icon trước khi script load xong) */
  manifests: {
    appId: string
    pluginId: string
    name: string
    icon: string
    window?: { w?: number; h?: number }
    enabled: boolean
    version?: string
  }[]
  load: () => Promise<void>
  registerApp: (app: Omit<PluginApp, 'id' | 'pluginId'> & { id?: string }) => void
  reset: () => void
}

export const usePlugins = create<PluginState>((set, get) => ({
  apps: [],
  status: 'idle',
  error: '',
  manifests: [],

  load: async () => {
    if (get().status === 'loading') return
    set({ status: 'loading' })
    try {
      const res = await fetch('/api/plugins', { credentials: 'same-origin' })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const data = (await res.json()) as {
        plugins: {
          id: string
          appId: string
          name: string
          icon: string
          window?: { w?: number; h?: number }
          enabled: boolean
          version?: string
          entry: string
          updatedAt: string
        }[]
      }
      const enabled = data.plugins.filter((p) => p.enabled)
      set({
        manifests: data.plugins.map((p) => ({
          appId: p.appId,
          pluginId: p.id,
          name: p.name,
          icon: p.icon,
          window: p.window,
          enabled: p.enabled,
          version: p.version,
        })),
        status: 'ready',
      })
      // inject script từng plugin — script gọi WOS.registerApp khi chạy
      for (const p of enabled) {
        await injectPluginScript(p.id, p.entry, p.updatedAt)
      }
    } catch (err) {
      set({ status: 'error', error: err instanceof Error ? err.message : 'Lỗi tải plugin' })
    }
  },

  registerApp: (app) => {
    const id = app.id || ''
    if (!id.startsWith('plugin:')) return
    set((st) => ({
      apps: [...st.apps.filter((a) => a.id !== id), { ...app, id, pluginId: id.slice('plugin:'.length) }],
    }))
  },

  reset: () => set({ apps: [], status: 'idle', error: '', manifests: [] }),
}))

/** Inject 1 lần / plugin (theo appId+version) */
const injected = new Set<string>()
function injectPluginScript(pluginId: string, entry: string, version: string): Promise<void> {
  const key = `${pluginId}@${version}`
  if (injected.has(key)) return Promise.resolve()
  injected.add(key)
  return new Promise((resolve) => {
    const s = document.createElement('script')
    s.src = `/api/plugins/${pluginId}/files/${entry}?v=${encodeURIComponent(version)}`
    s.async = true
    s.onload = () => resolve()
    s.onerror = () => resolve() // plugin hỏng → vẫn cho app khác chạy
    document.head.appendChild(s)
  })
}

/** Xoá script đã inject để tải lại (sau khi cài/gỡ plugin — caller reload trang) */
export function resetInjectedScripts(): void {
  injected.clear()
}

/** App plugin theo appId (WindowFrame tra component) */
export function usePluginApp(appId: string): PluginApp | undefined {
  return usePlugins((s) => s.apps.find((a) => a.id === appId))
}

export function getPluginApps(): PluginApp[] {
  return usePlugins.getState().apps
}
