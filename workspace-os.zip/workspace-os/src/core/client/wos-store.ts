'use client'

/**
 * WOS Store (zustand) — trạng thái toàn hệ thống:
 * session, modules runtime, settings, notifications, điều hướng SPA
 * Đây là "Kernel" phía client — mọi module đọc từ đây, không import nhau.
 */
import { create } from 'zustand'
import { api } from './api'
import { bus, type WosEvent } from './event-bus'
import { wosNavigate, useWindows } from './window-store'
import type { PluginMeta } from '@/components/wos/plugin-runtime'

export interface WosUser {
  id: string
  username: string
  displayName: string
  role: string
  avatarColor: string
  email: string | null
  /** Quyền hạn riêng tài khoản (JSON từ server, đã parse; {} = không hạn chế) */
  permissions?: UserPermissions | null
}

/** Quyền hạn riêng của từng tài khoản — admin đặt trong Administration → Users */
export interface UserPermissions {
  /** null / undefined = được dùng TẤT CẢ module; ngược lại = danh sách module id được phép */
  modules?: string[] | null
  /** false = khoá hoàn toàn File Manager (icon file desktop, upload, thùng rác, viewer) */
  allowFiles?: boolean
}

/** Parse chuỗi JSON quyền hạn an toàn */
export function parseUserPermissions(raw: unknown): UserPermissions | null {
  if (!raw) return null
  try {
    const obj = typeof raw === 'string' ? JSON.parse(raw) : raw
    if (!obj || typeof obj !== 'object') return null
    const out: UserPermissions = {}
    if (Array.isArray(obj.modules)) out.modules = obj.modules.filter((m: unknown) => typeof m === 'string')
    if (typeof obj.allowFiles === 'boolean') out.allowFiles = obj.allowFiles
    return out
  } catch {
    return null
  }
}

export interface WosModule {
  id: string
  name: string
  description: string
  icon: string
  color: string
  version: string
  order: number
  core: boolean
  showSidebar: boolean
  showDock: boolean
  section: 'main' | 'admin' | 'system'
  enabled: boolean
  config: Record<string, unknown>
  /** Manifest module có thể khai báo thêm (tuỳ chọn — dùng cho dashboard/settings) */
  widgets?: { id: string; title: string; zone: string; span: number }[]
  events?: string[]
  permissions?: Record<string, string[]>
}

/** Hình nền desktop: gradient / màu / ảnh / động (animated/video) / mặc định Sonoma */
export interface WallpaperConfig {
  kind: 'default' | 'gradient' | 'color' | 'image' | 'animated' | 'video'
  value: string
}

/** 1 item trong bộ sưu tập hình nền đã lưu */
export interface WallpaperItem {
  id: string
  label: string
  kind: 'gradient' | 'color' | 'image' | 'animated' | 'video'
  value: string
}

/** Cấu hình tự đổi hình nền theo thời gian */
export interface WallpaperRotation {
  enabled: boolean
  intervalMin: number // 1 | 5 | 15 | 30 | 60 | 180 | 720 | 1440
  order: 'sequential' | 'random'
  lastIdx: number
  lastAt: number // epoch ms
}

/** Icon override từng app: emoji hoặc ảnh tải lên */
export interface IconOverride {
  type: 'emoji' | 'image'
  value: string
}

// ============ Hiệu ứng thời tiết desktop (Atmosphere) ============
export type AtmosEffect = 'auto' | 'sunny' | 'clouds' | 'rain' | 'storm' | 'snow' | 'wind' | 'off'
export type AtmosIntensity = 'light' | 'normal' | 'strong'

export interface AtmosphereConfig {
  enabled: boolean
  effect: AtmosEffect
  intensity: AtmosIntensity
  lat: number
  lon: number
  city: string
  source: 'geolocation' | 'manual'
}

export const DEFAULT_ATMOSPHERE: AtmosphereConfig = {
  enabled: true,
  effect: 'auto',
  intensity: 'normal',
  lat: 10.762622,
  lon: 106.660172,
  city: 'TP. Hồ Chí Minh',
  source: 'manual',
}

/** Cấu hình nhân vật desktop (mèo) */
export interface PetConfig {
  enabled: boolean
}

/** Ứng dụng web shortcut trên desktop (Web App Launcher V3) — per-account */
export interface WebAppShortcut {
  id: string
  name: string
  url: string
  emoji: string
}

/** Vị trí nút điều khiển cửa sổ (review #4): 'left' = macOS, 'right' = Windows */
export type WindowControlSide = 'left' | 'right'

/** Cỡ icon desktop (review #7) */
export type DesktopIconSize = 'small' | 'medium' | 'large'

export interface WosNotification {
  id: string
  title: string
  content: string
  module: string
  type: string
  read: boolean
  archived: boolean
  action: string
  createdAt: string
}

interface WosState {
  booted: boolean
  user: WosUser | null
  modules: WosModule[]
  notifications: WosNotification[]
  unreadCount: number
  settings: Record<string, string>
  /** Settings module 'appearance': wallpaper, icons, dock... */
  wallpaper: WallpaperConfig
  wallpaperCollection: WallpaperItem[]
  wallpaperRotation: WallpaperRotation
  iconOverrides: Record<string, IconOverride>
  iconColors: Record<string, string>
  /** Ẩn icon TỪNG app riêng lẻ (per-account; key = moduleId/slug plugin) */
  iconHidden: Record<string, boolean>
  /** Hiệu ứng thời tiết desktop */
  atmosphere: AtmosphereConfig
  /** Nhân vật desktop (mèo) */
  pet: PetConfig
  /** Ứng dụng web trên desktop (per-account) */
  webApps: WebAppShortcut[]
  /** Thêm / xoá ứng dụng web (lưu appearance per-account) */
  addWebApp: (app: Omit<WebAppShortcut, 'id'>) => Promise<void>
  removeWebApp: (id: string) => Promise<void>
  /** Vị trí nút cửa sổ: trái (macOS) / phải (Windows) — per-account */
  windowControls: WindowControlSide
  /** Cỡ icon desktop: small / medium / large — per-account */
  desktopIconSize: DesktopIconSize
  /** Dock Manager (review #5): danh sách app ghim theo thứ tự — null = mặc định tự động */
  dockPinned: string[] | null
  /** Lưu tuỳ chọn desktop (nút cửa sổ, cỡ icon) — per-account */
  saveDesktopPrefs: (patch: { windowControls?: WindowControlSide; desktopIconSize?: DesktopIconSize }) => Promise<void>
  /** Dock Manager: lưu thứ tự app ghim (null = về mặc định tự động) */
  saveDockPinned: (ids: string[] | null) => Promise<void>
  /** Plugin cài thêm (app + pet) */
  plugins: PluginMeta[]
  /** Thư mục plugin riêng (upload code trực tiếp) */
  pluginsDir: string
  searchOpen: boolean
  notifOpen: boolean
  locked: boolean

  lock: () => void
  unlock: (password: string) => Promise<boolean>
  loadAppearance: () => Promise<void>
  saveAppearance: (values: Record<string, string>) => Promise<void>
  /** Ẩn/hiện icon 1 app riêng lẻ (per-account) */
  setIconHidden: (moduleId: string, hidden: boolean) => Promise<void>
  saveAtmosphere: (cfg: Partial<AtmosphereConfig>) => Promise<void>
  savePet: (cfg: Partial<PetConfig>) => Promise<void>
  boot: () => Promise<void>
  login: (username: string, password: string, remember: boolean) => Promise<void>
  logout: () => Promise<void>
  refreshModules: () => Promise<void>
  refreshPlugins: (rescan?: boolean) => Promise<void>
  patchPlugin: (slug: string, patch: Record<string, unknown>) => Promise<void>
  toggleModule: (moduleId: string, enabled: boolean) => Promise<void>
  saveModuleConfig: (moduleId: string, config: Record<string, unknown>) => Promise<void>
  loadSettings: (module?: string) => Promise<Record<string, string>>
  saveSettings: (module: string, settings: Record<string, string>) => Promise<void>
  refreshNotifications: (filter?: string) => Promise<void>
  notifAction: (ids: string[], action: string) => Promise<void>
  navigate: (route: string) => void
  openSearch: (open: boolean) => void
  openNotif: (open: boolean) => void
  emit: (type: string, module: string, payload?: Record<string, unknown>) => void
  onUnauthorized: () => void
}

let pollTimer: ReturnType<typeof setInterval> | null = null

export const useWos = create<WosState>((set, get) => ({
  booted: false,
  user: null,
  modules: [],
  notifications: [],
  unreadCount: 0,
  settings: {},
  wallpaper: { kind: 'default', value: '' },
  wallpaperCollection: [],
  wallpaperRotation: { enabled: false, intervalMin: 60, order: 'sequential', lastIdx: 0, lastAt: 0 },
  iconOverrides: {},
  iconColors: {},
  iconHidden: {},
  atmosphere: { ...DEFAULT_ATMOSPHERE },
  pet: { enabled: true },
  webApps: [],
  windowControls: 'left',
  desktopIconSize: 'medium',
  dockPinned: null,
  plugins: [],
  pluginsDir: '',
  searchOpen: false,
  notifOpen: false,
  locked: false,

  lock: () => set({ locked: true, notifOpen: false, searchOpen: false }),

  unlock: async (password) => {
    try {
      await api('/api/core/auth/verify', { method: 'POST', body: { password } })
      set({ locked: false })
      return true
    } catch {
      return false
    }
  },

  loadAppearance: async () => {
    try {
      const data = await api<{ settings: Record<string, string> }>('/api/core/settings?module=appearance')
      const s = data.settings
      let wallpaper: WallpaperConfig = { kind: 'default', value: '' }
      try {
        wallpaper = { kind: 'default', value: '', ...JSON.parse(s.wallpaper || '{}') }
      } catch { /* giữ mặc định */ }
      let iconOverrides: Record<string, IconOverride> = {}
      try {
        iconOverrides = JSON.parse(s.app_icons || '{}')
      } catch { /* giữ mặc định */ }
      let iconColors: Record<string, string> = {}
      try {
        iconColors = JSON.parse(s.app_colors || '{}')
      } catch { /* giữ mặc định */ }
      let iconHidden: Record<string, boolean> = {}
      try {
        const parsed = JSON.parse(s.app_hidden || '{}')
        if (parsed && typeof parsed === 'object') iconHidden = parsed
      } catch { /* giữ mặc định */ }
      let atmosphere: AtmosphereConfig = { ...DEFAULT_ATMOSPHERE }
      try {
        const parsed = JSON.parse(s.atmosphere || '{}')
        if (parsed && typeof parsed === 'object') atmosphere = { ...DEFAULT_ATMOSPHERE, ...parsed }
      } catch { /* mặc định */ }
      let pet: PetConfig = { enabled: true }
      try {
        const parsed = JSON.parse(s.pet || '{}')
        if (parsed && typeof parsed === 'object') pet = { enabled: parsed.enabled !== false }
      } catch { /* mặc định */ }
      let webApps: WebAppShortcut[] = []
      try {
        const parsed = JSON.parse(s.web_apps || '[]')
        if (Array.isArray(parsed)) {
          webApps = parsed
            .filter((w: unknown) => {
              const x = w as { name?: unknown; url?: unknown }
              return typeof x?.name === 'string' && typeof x?.url === 'string' && /^https?:\/\//i.test(x.url)
            })
            .slice(0, 24)
            .map((w: { name: string; url: string; emoji?: string; id?: string }) => ({
              id: typeof w.id === 'string' ? w.id : `web-${Math.random().toString(36).slice(2, 9)}`,
              name: w.name.slice(0, 40),
              url: w.url.slice(0, 500),
              emoji: typeof w.emoji === 'string' && w.emoji ? w.emoji.slice(0, 4) : '🌐',
            }))
        }
      } catch { /* rỗng */ }
      let wallpaperCollection: WallpaperItem[] = []
      try {
        const parsed = JSON.parse(s.wallpaper_collection || '[]')
        if (Array.isArray(parsed)) wallpaperCollection = parsed
      } catch { /* rỗng */ }
      let wallpaperRotation: WallpaperRotation = { enabled: false, intervalMin: 60, order: 'sequential', lastIdx: 0, lastAt: 0 }
      try {
        const parsed = JSON.parse(s.wallpaper_rotation || '{}')
        if (parsed && typeof parsed === 'object') {
          wallpaperRotation = { ...wallpaperRotation, ...parsed }
        }
      } catch { /* mặc định */ }
      // Desktop prefs (review #4/#7): vị trí nút cửa sổ + cỡ icon desktop
      const windowControls: WindowControlSide = s.window_controls === 'right' ? 'right' : 'left'
      const desktopIconSize: DesktopIconSize =
        s.desktop_icon_size === 'small' || s.desktop_icon_size === 'large' ? s.desktop_icon_size : 'medium'
      // Dock Manager (review #5): thứ tự app ghim — '' / thiếu = null (tự động theo module)
      let dockPinned: string[] | null = null
      try {
        const parsed = JSON.parse(s.dock_apps || 'null')
        if (Array.isArray(parsed)) dockPinned = parsed.filter((x: unknown): x is string => typeof x === 'string').slice(0, 32)
      } catch { /* null */ }
      set({ wallpaper, iconOverrides, iconColors, iconHidden, atmosphere, pet, webApps, wallpaperCollection, wallpaperRotation, windowControls, desktopIconSize, dockPinned })
    } catch {
      /* module appearance chưa có cấu hình */
    }
  },

  saveAppearance: async (values) => {
    await api('/api/core/settings', { method: 'PUT', body: { module: 'appearance', settings: values } })
    await get().loadAppearance()
    get().emit('settings.updated', 'appearance', { keys: Object.keys(values).join(', ') })
  },

  /** Ẩn icon 1 app riêng lẻ — hiện lại thì xoá key (app hiện ở ô mặc định) */
  setIconHidden: async (moduleId, hidden) => {
    const next = { ...get().iconHidden }
    if (hidden) next[moduleId] = true
    else delete next[moduleId]
    set({ iconHidden: next })
    await api('/api/core/settings', {
      method: 'PUT',
      body: { module: 'appearance', settings: { app_hidden: JSON.stringify(next) } },
    }).catch(() => {})
    get().emit('settings.updated', 'appearance', { keys: 'app_hidden' })
  },

  saveAtmosphere: async (cfg) => {
    const next = { ...get().atmosphere, ...cfg }
    set({ atmosphere: next })
    await api('/api/core/settings', {
      method: 'PUT',
      body: { module: 'appearance', settings: { atmosphere: JSON.stringify(next) } },
    }).catch(() => {})
    get().emit('settings.updated', 'appearance', { keys: 'atmosphere' })
  },

  savePet: async (cfg) => {
    const next = { ...get().pet, ...cfg }
    set({ pet: next })
    await api('/api/core/settings', {
      method: 'PUT',
      body: { module: 'appearance', settings: { pet: JSON.stringify(next) } },
    }).catch(() => {})
    get().emit('settings.updated', 'appearance', { keys: 'pet' })
  },

  /** Thêm ứng dụng web lên desktop (Web App Launcher) — per-account */
  addWebApp: async (app) => {
    const id = `web-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`
    const next = [...get().webApps, { ...app, id }].slice(0, 24)
    set({ webApps: next })
    await api('/api/core/settings', {
      method: 'PUT',
      body: { module: 'appearance', settings: { web_apps: JSON.stringify(next) } },
    }).catch(() => {})
    get().emit('settings.updated', 'appearance', { keys: 'web_apps' })
  },

  removeWebApp: async (id) => {
    const next = get().webApps.filter((w) => w.id !== id)
    set({ webApps: next })
    await api('/api/core/settings', {
      method: 'PUT',
      body: { module: 'appearance', settings: { web_apps: JSON.stringify(next) } },
    }).catch(() => {})
    get().emit('settings.updated', 'appearance', { keys: 'web_apps' })
  },

  /** Tuỳ chọn desktop (nút cửa sổ trái/phải, cỡ icon) — per-account */
  saveDesktopPrefs: async (patch) => {
    const next = {
      windowControls: patch.windowControls ?? get().windowControls,
      desktopIconSize: patch.desktopIconSize ?? get().desktopIconSize,
    }
    set(next)
    await api('/api/core/settings', {
      method: 'PUT',
      body: {
        module: 'appearance',
        settings: { window_controls: next.windowControls, desktop_icon_size: next.desktopIconSize },
      },
    }).catch(() => {})
    get().emit('settings.updated', 'appearance', { keys: 'desktop_prefs' })
  },

  /** Dock Manager: lưu thứ tự app ghim theo tài khoản (null = mặc định tự động) */
  saveDockPinned: async (ids) => {
    set({ dockPinned: ids })
    await api('/api/core/settings', {
      method: 'PUT',
      body: { module: 'appearance', settings: { dock_apps: ids === null ? '' : JSON.stringify(ids) } },
    }).catch(() => {})
    get().emit('settings.updated', 'appearance', { keys: 'dock_apps' })
  },

  boot: async () => {
    try {
      const data = await api<{ user: WosUser | null }>('/api/core/auth/me')
      if (data.user) {
        set({ user: data.user })
        await Promise.all([get().refreshModules(), get().loadSettings(), get().loadAppearance(), get().refreshNotifications(), get().refreshPlugins()])
        // polling thông báo nhẹ mỗi 45s (không cần ws riêng trên Orange Pi)
        if (!pollTimer) {
          pollTimer = setInterval(() => {
            if (get().user) get().refreshNotifications().catch(() => {})
          }, 45000)
        }
      }
    } catch {
      /* chưa đăng nhập */
    } finally {
      set({ booted: true })
    }
  },

  login: async (username, password, remember) => {
    const data = await api<{ user: WosUser }>('/api/core/auth/login', {
      method: 'POST',
      body: { username, password, remember },
    })
    set({ user: data.user })
    await Promise.all([get().refreshModules(), get().loadSettings(), get().loadAppearance(), get().refreshNotifications(), get().refreshPlugins()])
    if (!pollTimer) {
      pollTimer = setInterval(() => {
        if (get().user) get().refreshNotifications().catch(() => {})
      }, 45000)
    }
    get().emit('auth.login', 'core', { username })
  },

  logout: async () => {
    await api('/api/core/auth/logout', { method: 'POST' }).catch(() => {})
    if (pollTimer) {
      clearInterval(pollTimer)
      pollTimer = null
    }
    useWindows.getState().closeAll() // đóng mọi cửa sổ app
    set({ user: null, modules: [], notifications: [], unreadCount: 0, plugins: [] })
  },

  refreshModules: async () => {
    const data = await api<{ modules: WosModule[] }>('/api/core/modules')
    set({ modules: data.modules })
  },

  /** Plugin: danh sách từ API — lần đầu tự cài 2 plugin builtin */
  refreshPlugins: async (rescan = false) => {
    try {
      const data = await api<{ plugins: PluginMeta[]; pluginsDir?: string }>(
        `/api/core/plugins${rescan ? '?rescan=1' : ''}`,
      )
      set({ plugins: data.plugins, pluginsDir: data.pluginsDir || '' })
    } catch {
      set({ plugins: [] })
    }
  },

  /** Plugin: bật/tắt, desktopIcon, showDock, config (admin) */
  patchPlugin: async (slug, patch) => {
    await api('/api/core/plugins', { method: 'PATCH', body: { slug, ...patch } })
    await get().refreshPlugins()
    get().emit('plugin.updated', 'core', { slug })
  },

  toggleModule: async (moduleId, enabled) => {
    await api('/api/core/modules', { method: 'PATCH', body: { moduleId, enabled } })
    await get().refreshModules()
    get().emit(enabled ? 'module.enabled' : 'module.disabled', 'core', { moduleId })
    // Tắt module → đóng cửa sổ app tương ứng (Dock/Desktop tự cập nhật)
    if (!enabled) useWindows.getState().closeModule(moduleId)
  },

  saveModuleConfig: async (moduleId, config) => {
    await api('/api/core/modules', { method: 'PATCH', body: { moduleId, config } })
    await get().refreshModules()
  },

  loadSettings: async (module = 'core') => {
    const data = await api<{ settings: Record<string, string> }>(`/api/core/settings?module=${module}`)
    if (module === 'core') set({ settings: data.settings })
    return data.settings
  },

  saveSettings: async (module, settings) => {
    await api('/api/core/settings', { method: 'PUT', body: { module, settings } })
    if (module === 'core') set({ settings: { ...get().settings, ...settings } })
    get().emit('settings.updated', module, { keys: Object.keys(settings).join(', ') })
  },

  refreshNotifications: async (filter = 'all') => {
    const data = await api<{ notifications: WosNotification[]; unreadCount: number }>(
      `/api/core/notifications?filter=${filter}`
    )
    set({ notifications: data.notifications, unreadCount: data.unreadCount })
  },

  notifAction: async (ids, action) => {
    await api('/api/core/notifications', { method: 'PATCH', body: { ids, action } })
    await get().refreshNotifications()
  },

  /** Navigate toàn cục → mở/focus cửa sổ app (window manager) */
  navigate: (route) => {
    set({ searchOpen: false, notifOpen: false })
    wosNavigate(route)
  },

  openSearch: (open) => set({ searchOpen: open }),
  openNotif: (open) => set({ notifOpen: open }),

  emit: (type, module, payload) => {
    bus.emit(type, module, payload)
  },

  onUnauthorized: () => {
    set({ user: null, booted: true })
  },
}))

/** Tiện ích: lấy module đang bật + role hiện tại */
export function useEnabledModules(): WosModule[] {
  return useWos((s) => s.modules.filter((m) => m.enabled))
}

/** Tài khoản này có được dùng module không (admin = luôn có) */
export function useCanUseModule(moduleId: string): boolean {
  const user = useWos((s) => s.user)
  if (!user) return false
  if (user.role === 'admin') return true
  const perms = user.permissions
  if (!perms || !Array.isArray(perms.modules)) return true
  return perms.modules.includes(moduleId)
}

/** Tài khoản này có được dùng File Manager không (icon file, upload, thùng rác, viewer) */
export function useCanFiles(): boolean {
  const user = useWos((s) => s.user)
  if (!user) return false
  if (user.role === 'admin') return true
  if (user.permissions?.allowFiles === false) return false
  const mods = user.permissions?.modules
  if (Array.isArray(mods)) return mods.includes('files')
  return true
}

export function useModule(id: string): WosModule | undefined {
  return useWos((s) => s.modules.find((m) => m.id === id))
}

export function useCan(moduleId: string): { read: boolean; write: boolean } {
  const user = useWos((s) => s.user)
  const mod = useWos((s) => s.modules.find((m) => m.id === moduleId))
  if (!user || !mod) return { read: false, write: false }
  if (user.role === 'admin') return { read: true, write: true }
  if (!mod.enabled) return { read: false, write: false }
  return { read: true, write: user.role === 'member' }
}

export type { WosEvent }
