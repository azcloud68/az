'use client'

/**
 * WOS Window Manager (zustand, tách khỏi wos-store để kéo cửa sổ không re-render trang)
 * Mỗi module = 1 app = 1 cửa sổ (như macOS). Module có thể mở cửa sổ CON có key riêng
 * (vd projects:<id> mở thành cửa sổ riêng, tồn tại độc lập như app chính).
 * Alt+Tab: switcher đóng băng danh sách, Tab vòng lặp, thả Alt → focus.
 */
import { create } from 'zustand'

export interface WosWindow {
  id: string
  moduleId: string
  /** key cửa sổ con (vd 'p:<projectId>') — cửa sổ chính không có key */
  key?: string
  route: string // route cục bộ của app, vd 'files:%2FDocuments', 'settings:modules'
  /** tăng mỗi lần route được GÁN (kể cả giá trị giống nhau) — deep-link không bao giờ mất */
  routeSeq?: number
  x: number
  y: number
  w: number
  h: number
  z: number
  minimized: boolean
  maximized: boolean
  /** Vùng snap đang áp dụng (kéo thả biên) — kéo đi sẽ về kích thước cũ */
  snapped?: SnapZone
  prev?: { x: number; y: number; w: number; h: number }
}

/** Vùng snap cửa sổ (Windows/macOS style) */
export type SnapZone =
  | 'left'
  | 'right'
  | 'top'
  | 'top-left'
  | 'top-right'
  | 'bottom-left'
  | 'bottom-right'

/** Chiều cao menubar + vùng đế dock — cửa sổ không đè lên */
export const MENUBAR_H = 34
export const DOCK_H = 92

/** Kích thước cửa sổ mặc định theo module */
export const WINDOW_SIZE: Record<string, { w: number; h: number }> = {
  dashboard: { w: 1120, h: 700 },
  projects: { w: 1020, h: 650 },
  'projects-detail': { w: 880, h: 640 },
  tasks: { w: 1020, h: 650 },
  calendar: { w: 1040, h: 660 },
  weekly: { w: 1060, h: 680 },
  notes: { w: 900, h: 620 },
  'note-detail': { w: 720, h: 620 },
  wiki: { w: 1020, h: 650 },
  files: { w: 960, h: 620 },
  viewer: { w: 760, h: 600 },
  timeline: { w: 960, h: 610 },
  activity: { w: 880, h: 590 },
  reports: { w: 960, h: 650 },
  notifications: { w: 540, h: 640 },
  users: { w: 980, h: 630 },
  settings: { w: 920, h: 650 },
  browser: { w: 1120, h: 720 },
  terminal: { w: 840, h: 540 },
  monitor: { w: 960, h: 640 },
  downloads: { w: 620, h: 520 },
  doc: { w: 940, h: 700 },
  media: { w: 860, h: 580 },
}

/** Đăng ký kích thước cửa sổ cho plugin (khi plugin registerApp) */
export function registerWindowSize(moduleId: string, size: { w: number; h: number }) {
  WINDOW_SIZE[moduleId] = size
}

/** Hình học vùng snap theo kích thước viewport hiện tại */
export function snapGeometry(zone: SnapZone): { x: number; y: number; w: number; h: number } {
  const vw = window.innerWidth
  const vh = window.innerHeight
  const PAD = 6
  const top = MENUBAR_H + 4
  const bottom = vh - DOCK_H - 4
  const fullH = bottom - top
  const halfW = Math.floor((vw - PAD * 3) / 2)
  const halfH = Math.floor((fullH - PAD) / 2)
  switch (zone) {
    case 'left':
      return { x: PAD, y: top, w: halfW, h: fullH }
    case 'right':
      return { x: PAD * 2 + halfW, y: top, w: halfW, h: fullH }
    case 'top-left':
      return { x: PAD, y: top, w: halfW, h: halfH }
    case 'top-right':
      return { x: PAD * 2 + halfW, y: top, w: halfW, h: halfH }
    case 'bottom-left':
      return { x: PAD, y: top + halfH + PAD, w: halfW, h: halfH }
    case 'bottom-right':
      return { x: PAD * 2 + halfW, y: top + halfH + PAD, w: halfW, h: halfH }
    default:
      return { x: PAD, y: top, w: vw - PAD * 2, h: fullH } // 'top' = toàn màn hình
  }
}

/** z-index: cửa sổ 10..37 | dock 40 | menubar 41 | drop overlay 44 | launchpad 45 | radix dialog 50+ */
const Z_BASE = 10
const Z_MAX = 37

interface WinState {
  windows: WosWindow[]
  zTop: number
  launchpadOpen: boolean
  /** Alt+Tab switcher */
  switcherOpen: boolean
  switcherIndex: number
  switcherIds: string[]

  openApp: (moduleId: string, opts?: { route?: string; key?: string }) => void
  closeWindow: (id: string) => void
  closeModule: (moduleId: string) => void
  closeAll: () => void
  focusWindow: (id: string) => void
  toggleMinimize: (id: string) => void
  toggleMaximize: (id: string) => void
  minimizeAll: () => void
  tileWindows: () => void
  moveWindow: (id: string, x: number, y: number) => void
  sizeWindow: (id: string, w: number, h: number) => void
  /** Snap cửa sổ vào vùng (lưu kích thước cũ vào prev để kéo ra phục hồi) */
  snapWindow: (id: string, zone: SnapZone) => void
  /** Bỏ snap/maximize khi bắt đầu kéo titlebar (kéo ra = về kích thước cũ) */
  unsnapWindow: (id: string) => void
  /** Phục hồi phiên cửa sổ (session persistence) — mở lại hàng loạt giữ hình học */
  restoreWindows: (list: Array<Omit<WosWindow, 'id' | 'z'>>) => void
  setRoute: (id: string, route: string) => void
  setLaunchpad: (v: boolean) => void
  /** Alt+Tab */
  startSwitcher: (backwards?: boolean) => void
  stepSwitcher: (backwards?: boolean) => void
  commitSwitcher: () => void
  cancelSwitcher: () => void
}

let winSeq = 1

/** Chuẩn hoá lại z-index để luôn nằm trong 10..37 (tránh tràn phạm vi radix) */
function renormalize(windows: WosWindow[]): { windows: WosWindow[]; zTop: number } {
  const sorted = [...windows].sort((a, b) => a.z - b.z)
  const map = new Map(sorted.map((w, i) => [w.id, Z_BASE + i]))
  return {
    windows: windows.map((w) => ({ ...w, z: map.get(w.id) ?? w.z })),
    zTop: Z_BASE + windows.length,
  }
}

export const useWindows = create<WinState>((set, get) => ({
  windows: [],
  zTop: Z_BASE,
  launchpadOpen: false,
  switcherOpen: false,
  switcherIndex: 0,
  switcherIds: [],

  openApp: (moduleId, opts) => {
    const key = opts?.key
    // Tìm cửa sổ theo (moduleId, key): có key → đúng key; không key → cửa sổ chính
    const existing = get().windows.find(
      (w) => w.moduleId === moduleId && (key ? w.key === key : !w.key),
    )
    if (existing) {
      // đã mở → focus + bỏ thu nhỏ + cập nhật route nếu có
      // routeSeq LUÔN tăng khi có route mới: click lại CÙNG thư mục vẫn kích hoạt
      // deep-link bên trong app (không còn race "route bị reset trước khi đọc")
      set((st) => {
        let windows = st.windows.map((w) =>
          w.id === existing.id
            ? {
                ...w,
                z: st.zTop + 1,
                minimized: false,
                route: opts?.route ?? w.route,
                routeSeq: opts?.route ? (w.routeSeq || 0) + 1 : w.routeSeq,
              }
            : w,
        )
        let zTop = st.zTop + 1
        if (zTop >= Z_MAX) {
          const r = renormalize(windows)
          windows = r.windows
          zTop = r.zTop
        }
        return { windows, zTop }
      })
      return
    }
    const vw = window.innerWidth
    const vh = window.innerHeight
    const isMobile = vw < 768
    const sizeKey = key && WINDOW_SIZE[`${moduleId}-detail`] ? `${moduleId}-detail` : moduleId
    const size = WINDOW_SIZE[sizeKey] || { w: 900, h: 600 }
    const w = Math.min(size.w, vw - 40)
    const h = Math.min(size.h, vh - MENUBAR_H - DOCK_H - 16)
    const offset = ((get().windows.length + 1) % 6) * 28
    const z = get().zTop + 1
    const id = `win-${winSeq++}`
    set((st) => ({
      zTop: st.zTop + 1,
      windows: [
        ...st.windows,
        {
          id,
          moduleId,
          key,
          route: opts?.route ?? moduleId,
          routeSeq: opts?.route ? 1 : 0,
          x: isMobile ? 0 : Math.max(8, Math.round((vw - w) / 2) - 90 + offset),
          y: isMobile ? MENUBAR_H : Math.max(MENUBAR_H + 6, Math.round((vh - DOCK_H - h) / 2) - 30 + offset),
          w: isMobile ? vw : w,
          h: isMobile ? vh - MENUBAR_H : h,
          z,
          minimized: false,
          maximized: isMobile,
        },
      ],
    }))
  },

  closeWindow: (id) => set((st) => ({ windows: st.windows.filter((w) => w.id !== id) })),

  closeModule: (moduleId) => set((st) => ({ windows: st.windows.filter((w) => w.moduleId !== moduleId) })),

  closeAll: () => set({ windows: [], zTop: Z_BASE, launchpadOpen: false }),

  focusWindow: (id) =>
    set((st) => {
      const target = st.windows.find((w) => w.id === id)
      if (!target || (target.z === st.zTop && !target.minimized)) return st
      let windows = st.windows.map((w) => (w.id === id ? { ...w, z: st.zTop + 1 } : w))
      let zTop = st.zTop + 1
      if (zTop >= Z_MAX) {
        const r = renormalize(windows)
        windows = r.windows
        zTop = r.zTop
      }
      return { windows, zTop }
    }),

  toggleMinimize: (id) =>
    set((st) => ({ windows: st.windows.map((w) => (w.id === id ? { ...w, minimized: !w.minimized } : w)) })),

  toggleMaximize: (id) =>
    set((st) => ({
      windows: st.windows.map((w) => {
        if (w.id !== id) return w
        if (w.maximized && w.prev) {
          return { ...w, ...w.prev, maximized: false }
        }
        return {
          ...w,
          prev: { x: w.x, y: w.y, w: w.w, h: w.h },
          x: 6,
          y: MENUBAR_H + 4,
          w: window.innerWidth - 12,
          h: window.innerHeight - MENUBAR_H - 8 - DOCK_H,
          maximized: true,
        }
      }),
    })),

  minimizeAll: () => set((st) => ({ windows: st.windows.map((w) => ({ ...w, minimized: true })) })),

  /** Sắp xếp các cửa sổ đang mở thành lưới phủ màn hình (macOS "Tile") */
  tileWindows: () => {
    const st = get()
    const open = st.windows.filter((w) => !w.minimized)
    if (open.length === 0) return
    const vw = window.innerWidth
    const vh = window.innerHeight - MENUBAR_H - DOCK_H
    const cols = Math.ceil(Math.sqrt(open.length))
    const rows = Math.ceil(open.length / cols)
    const cw = Math.floor(vw / cols)
    const ch = Math.floor(vh / rows)
    const pos = new Map<string, { x: number; y: number; w: number; h: number }>()
    open.forEach((w, i) => {
      const c = i % cols
      const r = Math.floor(i / cols)
      pos.set(w.id, { x: c * cw + 4, y: MENUBAR_H + r * ch + 4, w: cw - 8, h: ch - 8 })
    })
    set({
      windows: st.windows.map((w) => {
        const p = pos.get(w.id)
        return p ? { ...w, ...p, maximized: false } : w
      }),
    })
  },

  moveWindow: (id, x, y) => set((st) => ({ windows: st.windows.map((w) => (w.id === id ? { ...w, x, y } : w)) })),

  sizeWindow: (id, w, h) => set((st) => ({ windows: st.windows.map((win) => (win.id === id ? { ...win, w, h } : win)) })),

  snapWindow: (id, zone) =>
    set((st) => ({
      windows: st.windows.map((w) => {
        if (w.id !== id) return w
        const geo = snapGeometry(zone)
        if (zone === 'top') {
          // kéo lên đỉnh = maximize (giữ semantic maximized cho double-click title)
          return {
            ...w,
            prev: w.maximized || w.snapped ? w.prev : { x: w.x, y: w.y, w: w.w, h: w.h },
            ...geo,
            maximized: true,
            snapped: undefined,
          }
        }
        return {
          ...w,
          prev: w.maximized || w.snapped ? w.prev : { x: w.x, y: w.y, w: w.w, h: w.h },
          ...geo,
          maximized: false,
          snapped: zone,
        }
      }),
    })),

  unsnapWindow: (id) =>
    set((st) => ({
      windows: st.windows.map((w) =>
        w.id === id ? { ...w, maximized: false, snapped: undefined, prev: undefined } : w,
      ),
    })),

  restoreWindows: (list) => {
    const st = get()
    // chỉ phục hồi app chưa mở (không đè cửa sổ đang có)
    const existing = new Set(st.windows.map((w) => `${w.moduleId}|${w.key || ''}`))
    const fresh = list
      .filter((w) => !existing.has(`${w.moduleId}|${w.key || ''}`))
      .slice(0, 14)
      .map((w, i) => ({
        ...w,
        id: `win-${winSeq++}`,
        z: Z_BASE + st.windows.length + i,
      }))
    if (fresh.length === 0) return
    set({ windows: [...st.windows, ...fresh], zTop: Z_BASE + st.windows.length + fresh.length })
  },

  setRoute: (id, route) => {
    // cùng module → cập nhật route cửa sổ (bump routeSeq để deep-link luôn kích hoạt);
    // route luôn đi kèm focus
    set((st) => ({
      windows: st.windows.map((w) =>
        w.id === id ? { ...w, route, routeSeq: (w.routeSeq || 0) + 1, minimized: false } : w,
      ),
    }))
    get().focusWindow(id)
  },

  setLaunchpad: (v) => set({ launchpadOpen: v }),

  /** Mở Alt+Tab switcher: danh sách cửa sổ theo z giảm dần (mới focus nhất trước) */
  startSwitcher: (backwards = false) => {
    const st = get()
    const list = [...st.windows].sort((a, b) => b.z - a.z)
    if (list.length === 0) return
    // bắt đầu từ cửa sổ kế tiếp (index 1) như Alt+Tab thật
    const ids = list.map((w) => w.id)
    const idx = list.length > 1 ? (backwards ? list.length - 1 : 1) : 0
    set({ switcherOpen: true, switcherIds: ids, switcherIndex: idx })
  },

  stepSwitcher: (backwards = false) => {
    const st = get()
    if (!st.switcherOpen || st.switcherIds.length === 0) return
    const n = st.switcherIds.length
    const next = backwards ? (st.switcherIndex - 1 + n) % n : (st.switcherIndex + 1) % n
    set({ switcherIndex: next })
  },

  /** Thả Alt → focus cửa sổ đang chọn + đóng switcher */
  commitSwitcher: () => {
    const st = get()
    if (!st.switcherOpen) return
    const id = st.switcherIds[st.switcherIndex]
    set({ switcherOpen: false, switcherIds: [], switcherIndex: 0 })
    if (id) get().focusWindow(id)
  },

  cancelSwitcher: () => set({ switcherOpen: false, switcherIds: [], switcherIndex: 0 }),
}))

/** Navigate toàn cục — widget/palette/notification gọi: mở hoặc focus cửa sổ app + đặt route */
export function wosNavigate(route: string) {
  const moduleId = route.split(':')[0] || 'dashboard'
  // projects:<id> → cửa sổ riêng cho từng dự án (tồn tại độc lập trên desktop)
  if (moduleId === 'projects' && route.includes(':', 8)) {
    const id = route.slice(route.indexOf(':') + 1)
    if (id) {
      useWindows.getState().openApp('projects', { key: `p:${id}`, route })
      return
    }
  }
  // viewer:<path> → cửa sổ trình xem tệp riêng theo từng tệp
  if (moduleId === 'viewer' && route.startsWith('viewer:')) {
    const p = route.slice('viewer:'.length)
    if (p) {
      useWindows.getState().openApp('viewer', { key: `v:${p}`, route })
      return
    }
  }
  // note:<id> → ghi chú mở cửa sổ riêng (tồn tại độc lập, nhiều cửa sổ so sánh được)
  if (moduleId === 'note' && route.startsWith('note:')) {
    const id = route.slice('note:'.length)
    if (id) {
      useWindows.getState().openApp('notes', { key: `n:${id}`, route })
      return
    }
  }

  // Application System V3 — browser:<url> → focus cửa sổ Browser + mở tab mới (app singleton)
  if (moduleId === 'browser') {
    useWindows.getState().openApp('browser', { route })
    return
  }
  useWindows.getState().openApp(moduleId, { route })
}

/** Preview vùng snap khi kéo cửa sổ sát biên (WindowFrame ghi, SnapOverlay đọc) */
export const useSnapPreview = create<{ zone: SnapZone | null; setZone: (z: SnapZone | null) => void }>((set) => ({
  zone: null,
  setZone: (zone) => set({ zone }),
}))

/** Dò vùng snap theo vị trí con trỏ trong lúc kéo titlebar */
export function detectSnapZone(px: number, py: number): SnapZone | null {
  const EDGE = 12
  const CORNER = 150
  const vw = window.innerWidth
  const vh = window.innerHeight
  const nearTop = py <= MENUBAR_H + EDGE
  const nearLeft = px <= EDGE
  const nearRight = px >= vw - EDGE
  const nearBottom = py >= vh - 160 // góc dưới: đủ gần đáy (tránh nhầm khi kéo xuống dock)
  if (nearTop && nearLeft) return 'top-left'
  if (nearTop && nearRight) return 'top-right'
  if (nearTop) return 'top'
  if (nearLeft && nearBottom) return 'bottom-left'
  if (nearRight && nearBottom) return 'bottom-right'
  if (nearLeft) return 'left'
  if (nearRight) return 'right'
  return null
}
