'use client'

/**
 * WOS Clipboard Service (P0 của Web PC) — bảng tạm THỐNG NHẤT cho text + TỆP/THƯ MỤC.
 * - Files/Desktop: Ctrl+C / Ctrl+X / Ctrl+V trên tệp đang chọn (copy/cut/paste qua
 *   API copy/move của File Manager — server tự lo atomically + rollback FS)
 * - Text: sao chép text (vd từ viewer) vào clipboard hệ thống browser (navigator.clipboard)
 *   + lưu nội bộ để dán vào Files (tạo tệp mới từ clipboard)
 * - Cut = di chuyển (move), Copy = sao chép (copy) — đúng ngữ nghĩa PC
 */
import { create } from 'zustand'
import { api } from './api'
import { bus } from './event-bus'

export interface ClipboardFiles {
  kind: 'files'
  paths: string[]
  cut: boolean
  /** nguồn dán (thư mục đang mở) — dán vào chính nó sẽ bị chặn phía server */
  from: string
  at: number
}

export interface ClipboardText {
  kind: 'text'
  text: string
  at: number
}

export type ClipboardPayload = ClipboardFiles | ClipboardText | null

interface ClipboardState {
  payload: ClipboardPayload
  /** Copy tệp/thư mục vào bảng tạm (Ctrl+C) */
  copyFiles: (paths: string[], from: string) => void
  /** Cắt tệp/thư mục (Ctrl+X) — dán sẽ DI CHUYỂN */
  cutFiles: (paths: string[], from: string) => void
  /** Copy text — vừa clipboard hệ thống vừa clipboard WOS */
  copyText: (text: string) => Promise<void>
  /** Dán vào thư mục đích — trả về số tệp đã dán (0 = lỗi/toàn lỗi) */
  pasteInto: (destDir: string) => Promise<{ ok: number; failed: string[] }>
  clear: () => void
}

/** Đổi tên nếu đích đã tồn tại — server chặn overwrite, tự thêm " (bản sao)" */
async function safeDestName(dir: string, srcPath: string): Promise<string> {
  const original = srcPath.split('/').pop() || 'tệp'
  return new Promise((resolve) => {
    api<{ entries?: unknown[] }>(`/api/modules/files/list?dir=${encodeURIComponent(dir)}`).then((d) => {
      const names = new Set(
        (d.entries as { name?: string }[] | undefined)?.map((e) => e.name?.toLowerCase()) || [],
      )
      const dot = original.lastIndexOf('.')
      const stem = dot > 0 ? original.slice(0, dot) : original
      const ext = dot > 0 ? original.slice(dot) : ''
      let candidate = original
      let i = 2
      while (names.has(candidate.toLowerCase())) {
        candidate = `${stem} (bản sao${i > 2 ? ` ${i}` : ''})${ext}`
        i++
      }
      resolve(`${dir === '/' ? '' : dir}/${candidate}`)
    }).catch(() => resolve(`${dir === '/' ? '' : dir}/${original}`))
  })
}

export const useClipboard = create<ClipboardState>((set, get) => ({
  payload: null,

  copyFiles: (paths, from) => {
    if (paths.length === 0) return
    set({ payload: { kind: 'files', paths, cut: false, from, at: Date.now() } })
  },

  cutFiles: (paths, from) => {
    if (paths.length === 0) return
    set({ payload: { kind: 'files', paths, cut: true, from, at: Date.now() } })
  },

  copyText: async (text) => {
    set({ payload: { kind: 'text', text, at: Date.now() } })
    try {
      await navigator.clipboard.writeText(text)
    } catch {
      /* http / không quyền — clipboard nội bộ vẫn dùng được */
    }
  },

  pasteInto: async (destDir) => {
    const p = get().payload
    if (!p) return { ok: 0, failed: ['Bảng tạm trống'] }

    if (p.kind === 'text') {
      // Dán text → tạo tệp văn bản mới trong thư mục đích
      const name = `ghi-chu-${new Date().toISOString().slice(11, 19).replace(/:/g, '-')}.txt`
      try {
        await api('/api/modules/files/newfile', {
          method: 'POST',
          body: { path: destDir, name, content: p.text },
        })
        bus.emit('file.uploaded', 'files', { name, dir: destDir })
        return { ok: 1, failed: [] }
      } catch (err) {
        return { ok: 0, failed: [err instanceof Error ? err.message : 'Không tạo được tệp'] }
      }
    }

    // Dán tệp/thư mục
    let ok = 0
    const failed: string[] = []
    for (const src of p.paths) {
      const name = src.split('/').pop() || 'tệp'
      try {
        const to = await safeDestName(destDir, src)
        await api('/api/modules/files/copy', {
          method: 'POST',
          body: p.cut ? { action: 'move', path: src, to } : { action: 'copy', path: src, to },
        })
        ok++
      } catch (err) {
        failed.push(`${name}: ${err instanceof Error ? err.message : 'lỗi'}`)
      }
    }
    if (ok > 0) {
      bus.emit('file.updated', 'files', { name: `dán ${ok} tệp vào ${destDir}` })
      // cut dán xong → bảng tạm rỗng (như PC)
      if (p.cut) set({ payload: null })
    }
    return { ok, failed }
  },

  clear: () => set({ payload: null }),
}))

/** Tắt cut-mode nếu tệp trong clipboard bị xoá/đi nơi khác — kiểm nhẹ khi paste */
export function clipboardHasPaths(): string[] | null {
  const p = useClipboard.getState().payload
  return p?.kind === 'files' ? p.paths : null
}
