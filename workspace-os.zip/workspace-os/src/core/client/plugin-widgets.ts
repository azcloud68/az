'use client'

/**
 * WOS Plugin Widget Registry (Giai đoạn 2) — cho plugin đăng ký widget desktop.
 *
 * Trước đây plugin chỉ có registerApp (cửa sổ) + registerPet (nhân vật) — không có
 * cách tạo widget nổi. Giờ plugin gọi:
 *   WOS.registerWidget({ type, title, icon, defaultW, defaultH, minW, minH, component })
 * Widget plugin được WidgetLayer quản lý Y HỆT widget hệ thống: kéo di chuyển,
 * resize, vị trí lưu theo fraction (sống sót qua F5), thêm từ Settings → Desktop.
 *
 * Type nội bộ thêm prefix "<slug>:" để không đụng widget hệ thống.
 */
import type { ComponentType } from 'react'

export interface PluginWidgetDef {
  /** type nội bộ: "<slug>:<type do plugin đặt>" */
  type: string
  title: string
  /** emoji hiển thị trên titlebar (LucideIcon của hệ thống không truyền được qua JSON runtime) */
  icon: string
  defaultW: number
  defaultH: number
  minW: number
  minH: number
  component: ComponentType
  slug: string
}

const g = globalThis as unknown as {
  __wosPluginWidgets?: Map<string, PluginWidgetDef>
  __wosPluginWidgetListeners?: Set<() => void>
}

function store(): Map<string, PluginWidgetDef> {
  if (!g.__wosPluginWidgets) g.__wosPluginWidgets = new Map()
  return g.__wosPluginWidgets
}

function listeners(): Set<() => void> {
  if (!g.__wosPluginWidgetListeners) g.__wosPluginWidgetListeners = new Set()
  return g.__wosPluginWidgetListeners
}

/** Plugin đăng ký widget — gọi lúc chạy entry (idempotent theo type) */
export function registerPluginWidget(slug: string, def: {
  type: string
  title: string
  icon?: string
  defaultW?: number
  defaultH?: number
  minW?: number
  minH?: number
  component: ComponentType
}): { type: string } {
  const type = `${slug}:${String(def.type || '').replace(/[^a-z0-9-]/gi, '')}`
  store().set(type, {
    type,
    title: String(def.title || 'Widget').slice(0, 40),
    icon: String(def.icon || '🧩').slice(0, 8),
    defaultW: Math.max(160, Math.min(800, Number(def.defaultW) || 300)),
    defaultH: Math.max(120, Math.min(900, Number(def.defaultH) || 320)),
    minW: Math.max(140, Math.min(400, Number(def.minW) || 200)),
    minH: Math.max(100, Math.min(500, Number(def.minH) || 160)),
    component: def.component,
    slug,
  })
  listeners().forEach((fn) => fn())
  return { type }
}

/** Widget plugin theo type nội bộ */
export function getPluginWidget(type: string): PluginWidgetDef | undefined {
  return store().get(type)
}

/** Toàn bộ widget plugin đang đăng ký */
export function getPluginWidgetDefs(): PluginWidgetDef[] {
  return Array.from(store().values())
}

/** Gỡ widget của 1 plugin (plugin tắt/gỡ) */
export function unregisterPluginWidgets(slug: string): void {
  for (const [type, def] of store()) {
    if (def.slug === slug) store().delete(type)
  }
  listeners().forEach((fn) => fn())
}

/** Lắng nghe thay đổi danh sách widget plugin (Settings/DesktopSection refresh) */
export function onPluginWidgetsChange(fn: () => void): () => void {
  listeners().add(fn)
  return () => listeners().delete(fn)
}
