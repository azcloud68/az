'use client'

/**
 * window.WOS — API toàn cục dành cho plugin (bundle main.js gọi vào khi load).
 * Khởi tạo 1 lần trong PluginHost (sau khi đăng nhập).
 *
 * API (xem DEVELOPING-MODULES.md):
 *   const ctx = WOS.registerApp({ id, name, icon, window, component })
 *     → ctx.storage.get(key) / set(key, value) / del(key) / list()  — namespace THEO plugin
 *     → ctx.notify(title, content) / ctx.navigate(route) / ctx.events.on/emit
 *
 *   WOS.React / WOS.ReactDOMClient — React của hệ thống (plugin KHÔNG bundle React lại)
 *   WOS.version
 */
import * as React from 'react'
import * as ReactDOMClient from 'react-dom/client'
import type { ComponentType } from 'react'
import { usePlugins } from './plugin-store'
import { bus } from './event-bus'
import { wosNavigate } from './window-store'

/** Context riêng của từng plugin (nhận được từ WOS.registerApp) */
export interface WosPluginContext {
  pluginId: string
  storage: {
    get: (key: string) => Promise<unknown>
    set: (key: string, value: unknown) => Promise<void>
    del: (key: string) => Promise<void>
    list: () => Promise<{ key: string; value: unknown }[]>
  }
  events: {
    on: (type: string, cb: (payload?: Record<string, unknown>) => void) => () => void
    emit: (type: string, payload?: Record<string, unknown>) => void
  }
  notify: (title: string, content?: string) => Promise<void>
  navigate: (route: string) => void
}

interface RegisterAppInput {
  /** id plugin — phải khớp wos-module.json trong gói .wos */
  id: string
  name?: string
  icon?: string
  window?: { w?: number; h?: number; minW?: number; minH?: number }
  component?: ComponentType
  mount?: (el: HTMLElement) => void | (() => void)
}

interface WosGlobalApi {
  version: string
  React: typeof React
  ReactDOMClient: typeof ReactDOMClient
  registerApp: (app: RegisterAppInput) => WosPluginContext
}

function makeContext(pluginId: string): WosPluginContext {
  return {
    pluginId,
    storage: {
      get: async (key) => {
        const res = await fetch(`/api/plugins/data?plugin=${encodeURIComponent(pluginId)}&key=${encodeURIComponent(key)}`, {
          credentials: 'same-origin',
        })
        if (!res.ok) return null
        const data = (await res.json()) as { value?: string | null }
        if (!data.value) return null
        try {
          return JSON.parse(data.value)
        } catch {
          return data.value
        }
      },
      set: async (key, value) => {
        const res = await fetch('/api/plugins/data', {
          method: 'PUT',
          headers: { 'content-type': 'application/json' },
          credentials: 'same-origin',
          body: JSON.stringify({ plugin: pluginId, key, value: JSON.stringify(value ?? null) }),
        })
        if (!res.ok) {
          const data = (await res.json().catch(() => ({}))) as { error?: string }
          throw new Error(data.error || `Lỗi lưu dữ liệu (${res.status})`)
        }
      },
      del: async (key) => {
        await fetch(`/api/plugins/data?plugin=${encodeURIComponent(pluginId)}&key=${encodeURIComponent(key)}`, {
          method: 'DELETE',
          credentials: 'same-origin',
        })
      },
      list: async () => {
        const res = await fetch(`/api/plugins/data?plugin=${encodeURIComponent(pluginId)}`, { credentials: 'same-origin' })
        if (!res.ok) return []
        const data = (await res.json()) as { entries?: { key: string; value: string }[] }
        return (data.entries || []).map((e) => {
          let value: unknown = e.value
          try {
            value = JSON.parse(e.value)
          } catch { /* giữ chuỗi */ }
          return { key: e.key, value }
        })
      },
    },
    events: {
      on: (type, cb) => bus.on(type, (ev) => cb(ev.payload)),
      emit: (type, payload) => bus.emit(type, 'plugin', payload),
    },
    notify: async (title, content) => {
      await fetch('/api/core/notifications', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ title, content: content || '', action: '' }),
      }).catch(() => {})
    },
    navigate: (route) => wosNavigate(route),
  }
}

export function setupWosGlobal(): void {
  if (typeof window === 'undefined') return
  const w = window as { WOS?: WosGlobalApi }
  if (w.WOS) return

  w.WOS = {
    version: '1.0.0',
    React,
    ReactDOMClient,

    registerApp: (app) => {
      const pluginId = String(app.id || '').replace(/^plugin:/, '')
      usePlugins.getState().registerApp({
        id: `plugin:${pluginId}`,
        name: app.name || pluginId,
        icon: app.icon || '🧩',
        window: app.window,
        component: app.component,
        mount: app.mount,
      })
      return makeContext(pluginId)
    },
  }
}
