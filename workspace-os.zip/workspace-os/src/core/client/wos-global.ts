'use client'

/**
 * window.WOS — API toàn cục dành cho plugin (bundle main.js gọi vào khi load).
 * Khởi tạo 1 lần trong PluginHost (sau khi đăng nhập).
 *
 * API (xem docs/widget-guide.md):
 *   const ctx = WOS.registerApp({ id, name, icon, window, component })
 *     → ctx.storage.get(key) / set(key, value) / del(key) / list()  — namespace THEO plugin
 *     → ctx.notify(title, content) / ctx.navigate(route) / ctx.events.on/emit
 *
 *   WOS.registerWidget({ type, title, icon, defaultW, defaultH, minW, minH, component })
 *     → đăng ký WIDGET DESKTOP (fix lỗi 5): widget xuất hiện trong Settings →
 *       Appearance → Desktop & Dock → Widget Manager và menu chuột phải Desktop.
 *       Trước đây API này CHỈ tồn tại trong sandbox plugin.json (plugin-runtime.ts)
 *       — plugin load qua <script> dùng window.WOS sẽ KHÔNG có → widget không đăng ký được.
 *       Giờ cả hai hệ đều dùng chung registry plugin-widgets.ts.
 *       Tùy chọn truyền slug: WOS.registerWidget(def, 'my-plugin').
 *
 *   WOS.unregisterWidgets() — gỡ toàn bộ widget của plugin đang gọi
 *   WOS.React / WOS.ReactDOMClient — React của hệ thống (plugin KHÔNG bundle React lại)
 *   WOS.version
 */
import * as React from 'react'
import * as ReactDOMClient from 'react-dom/client'
import type { ComponentType } from 'react'
import { usePlugins } from './plugin-store'
import { bus } from './event-bus'
import { wosNavigate } from './window-store'
import { registerPluginWidget, unregisterPluginWidgets } from './plugin-widgets'

/** Slug plugin "đang được inject" (plugin-store ghi trước khi <script> chạy) —
 *  dùng làm namespace mặc định cho WOS.registerWidget không tường minh. */
export const LOADING_PLUGIN_KEY = '__wosLegacyPluginSlug'

function currentLoadingSlug(): string {
  const v = (globalThis as Record<string, unknown>)[LOADING_PLUGIN_KEY]
  return typeof v === 'string' ? v : ''
}

/** Chuẩn hoá slug legacy (plugin id dạng cuid…) → [a-z0-9-] an toàn làm tiền tố type */
function safeSlug(raw: string): string {
  const s = raw.toLowerCase().replace(/[^a-z0-9-]/g, '').slice(0, 39)
  return s || 'plugin'
}

/** Context riêng của từng plugin (nhận được từ WOS.registerApp) */
export interface WosPluginContext {
  pluginId: string
  storage: {
    get: (key: string) => Promise<unknown>
    set: (key: string, value: unknown) => Promise<void>
    del: (key: string) => Promise<void>
    list: () => Promise<{ key: string; value: unknown }[]>
  }
  events: {
    on: (type: string, cb: (payload?: Record<string, unknown>) => void) => () => void
    emit: (type: string, payload?: Record<string, unknown>) => void
  }
  notify: (title: string, content?: string) => Promise<void>
  navigate: (route: string) => void
}

interface RegisterAppInput {
  /** id plugin — phải khớp wos-module.json trong gói .wos */
  id: string
  name?: string
  icon?: string
  window?: { w?: number; h?: number; minW?: number; minH?: number }
  component?: ComponentType
  mount?: (el: HTMLElement) => void | (() => void)
}

/** Đầu vào cho WOS.registerWidget — tương thích 1-1 với plugin-runtime (hệ plugin.json) */
interface RegisterWidgetInput {
  /** loại widget — duy nhất trong plugin (vd 'clock', 'bubble'…) */
  type: string
  title: string
  /** emoji ngắn (vd '🕒') — Lucide không gửi qua được ranh giới JSON */
  icon?: string
  defaultW?: number
  defaultH?: number
  minW?: number
  minH?: number
  component: ComponentType
  /** slug plugin (tuỳ chọn — mặc định tự dò từ plugin đang load) */
  slug?: string
}

interface WosGlobalApi {
  version: string
  React: typeof React
  ReactDOMClient: typeof ReactDOMClient
  registerApp: (app: RegisterAppInput) => WosPluginContext
  /** Đăng ký widget desktop từ plugin (fix lỗi 5) */
  registerWidget: (def: RegisterWidgetInput, slugArg?: string) => string
  /** Gỡ widget của plugin (mặc định: plugin đang gọi) */
  unregisterWidgets: (slug?: string) => void
}

/** plugin gọi registerApp gần nhất — fallback namespace cho registerWidget */
let lastRegisteredApp = ''

function makeContext(pluginId: string): WosPluginContext {
  return {
    pluginId,
    storage: {
      get: async (key) => {
        const res = await fetch(`/api/plugins/data?plugin=${encodeURIComponent(pluginId)}&key=${encodeURIComponent(key)}`, {
          credentials: 'same-origin',
        })
        if (!res.ok) return null
        const data = (await res.json()) as { value?: string | null }
        if (!data.value) return null
        try {
          return JSON.parse(data.value)
        } catch {
          return data.value
        }
      },
      set: async (key, value) => {
        const res = await fetch('/api/plugins/data', {
          method: 'PUT',
          headers: { 'content-type': 'application/json' },
          credentials: 'same-origin',
          body: JSON.stringify({ plugin: pluginId, key, value: JSON.stringify(value ?? null) }),
        })
        if (!res.ok) {
          const data = (await res.json().catch(() => ({}))) as { error?: string }
          throw new Error(data.error || `Lỗi lưu dữ liệu (${res.status})`)
        }
      },
      del: async (key) => {
        await fetch(`/api/plugins/data?plugin=${encodeURIComponent(pluginId)}&key=${encodeURIComponent(key)}`, {
          method: 'DELETE',
          credentials: 'same-origin',
        })
      },
      list: async () => {
        const res = await fetch(`/api/plugins/data?plugin=${encodeURIComponent(pluginId)}`, { credentials: 'same-origin' })
        if (!res.ok) return []
        const data = (await res.json()) as { entries?: { key: string; value: string }[] }
        return (data.entries || []).map((e) => {
          let value: unknown = e.value
          try {
            value = JSON.parse(e.value)
          } catch { /* giữ chuỗi */ }
          return { key: e.key, value }
        })
      },
    },
    events: {
      on: (type, cb) => bus.on(type, (ev) => cb(ev.payload)),
      emit: (type, payload) => bus.emit(type, 'plugin', payload),
    },
    notify: async (title, content) => {
      await fetch('/api/core/notifications', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ title, content: content || '', action: '' }),
      }).catch(() => {})
    },
    navigate: (route) => wosNavigate(route),
  }
}

export function setupWosGlobal(): void {
  if (typeof window === 'undefined') return
  const w = window as { WOS?: WosGlobalApi }
  if (w.WOS) return

  w.WOS = {
    version: '1.1.0',
    React,
    ReactDOMClient,

    registerApp: (app) => {
      const pluginId = String(app.id || '').replace(/^plugin:/, '')
      lastRegisteredApp = pluginId
      usePlugins.getState().registerApp({
        id: `plugin:${pluginId}`,
        name: app.name || pluginId,
        icon: app.icon || '🧩',
        window: app.window,
        component: app.component,
        mount: app.mount,
      })
      return makeContext(pluginId)
    },

    /** Đăng ký widget desktop — chung registry với plugin.json runtime (fix lỗi 5).
     *  Trả về type đầy đủ "<slug>:<type>" để plugin lưu lại nếu cần. */
    registerWidget: (def, slugArg) => {
      const raw = def?.slug || slugArg || currentLoadingSlug() || lastRegisteredApp || 'plugin'
      const slug = safeSlug(raw)
      if (!def || typeof def.type !== 'string' || !def.type) {
        console.warn('[WOS] registerWidget: thiếu def.type — bị bỏ qua')
        return ''
      }
      if (!def.component) {
        console.warn('[WOS] registerWidget: thiếu def.component — bị bỏ qua')
        return ''
      }
      registerPluginWidget(slug, {
        type: def.type,
        title: def.title || def.type,
        icon: def.icon || '🧩',
        defaultW: def.defaultW,
        defaultH: def.defaultH,
        minW: def.minW,
        minH: def.minH,
        component: def.component,
      })
      return `${slug}:${def.type}`
    },

    /** Gỡ widget của 1 plugin (mặc định: plugin đang gọi) */
    unregisterWidgets: (slugArg) => {
      const raw = slugArg || currentLoadingSlug() || lastRegisteredApp
      if (raw) unregisterPluginWidgets(safeSlug(raw))
    },
  }
}
