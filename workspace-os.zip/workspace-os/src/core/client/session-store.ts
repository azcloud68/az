'use client'

/**
 * WOS Desktop Session — tính bền vững của cửa sổ (Window Persistence).
 * Tắt browser / reload / đăng nhập lại → mở lại đúng các cửa sổ đang làm việc,
 * giữ nguyên vị trí — kích thước — route. Lưu localStorage THEO TÀI KHOẢN.
 */
import type { WosWindow } from './window-store'

export interface SessionWindow
  extends Pick<WosWindow, 'moduleId' | 'key' | 'route' | 'x' | 'y' | 'w' | 'h' | 'minimized' | 'maximized'> {
  savedAt: number
}

const PREFIX = 'wos.session.'
const MAX_WINDOWS = 14

function keyOf(uid: string): string {
  return `${PREFIX}${uid}`
}

/** Ghi phiên hiện tại (gọi debounce từ WosApp khi cửa sổ đổi) */
export function saveSession(uid: string, windows: WosWindow[]): void {
  if (typeof window === 'undefined') return
  try {
    // Giữ tối đa 14 cửa sổ gần nhất theo z (mới focus nhất đứng cuối) — bỏ phần quá
    const list: SessionWindow[] = windows
      .slice(-MAX_WINDOWS)
      .map((w) => ({
        moduleId: w.moduleId,
        key: w.key,
        route: w.route,
        x: Math.round(w.x),
        y: Math.round(w.y),
        w: Math.round(w.w),
        h: Math.round(w.h),
        minimized: w.minimized,
        maximized: w.maximized,
        savedAt: Date.now(),
      }))
    localStorage.setItem(keyOf(uid), JSON.stringify({ v: 1, savedAt: Date.now(), windows: list }))
  } catch {
    /* localStorage đầy (private mode) — bỏ qua, không crash desktop */
  }
}

/** Đọc phiên đã lưu của tài khoản (null = chưa có) */
export function loadSession(uid: string): SessionWindow[] | null {
  if (typeof window === 'undefined') return null
  try {
    const raw = localStorage.getItem(keyOf(uid))
    if (!raw) return null
    const parsed = JSON.parse(raw) as { v?: number; windows?: SessionWindow[] }
    if (!Array.isArray(parsed.windows)) return null
    return parsed.windows.filter(
      (w) => w && typeof w.moduleId === 'string' && typeof w.route === 'string' && w.w > 100 && w.h > 80,
    )
  } catch {
    return null
  }
}

/** Xoá phiên (đăng xuất muốn bắt đầu sạch) — mặc định TAÌ khoản giữ phiên như PC thật */
export function clearSession(uid: string): void {
  if (typeof window === 'undefined') return
  try {
    localStorage.removeItem(keyOf(uid))
  } catch {
    /* bỏ qua */
  }
}

/** Tuổi của phiên (ms) — quá 7 ngày không tự phục hồi */
export function sessionAge(windows: SessionWindow[]): number {
  const newest = Math.max(...windows.map((w) => w.savedAt || 0), 0)
  return newest ? Date.now() - newest : Infinity
}
