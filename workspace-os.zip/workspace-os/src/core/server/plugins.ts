/**
 * WOS Plugin Engine (Core) — cài/gỡ module ngoài (*.wos = zip manifest + bundle).
 *
 * QUY ƯỚC GÓI .wos (zip):
 *   wos-module.json  — manifest: id, name, version, description, author, icon, entry,
 *                      permissions[], window {w,h,minW,minH}
 *   main.js          — bundle IIFE, gọi WOS.registerApp({...}) khi load
 *   icon.svg / icon.png / assets… — asset tuỳ chọn (phục vụ qua /api/plugins/<id>/files/<path>)
 *
 * File plugin nằm trong STORAGE_ROOT/plugins/<id>/ — DB chỉ giữ manifest + enabled.
 * Dữ liệu plugin ghi qua PluginRecord (namespace theo pluginId, không đọc được của nhau).
 */
import { db } from '@/lib/db'
import { promises as fsp } from 'fs'
import { execFile } from 'child_process'
import { promisify } from 'util'
import path from 'path'

const execFileAsync = promisify(execFile)

export const PLUGIN_PERMISSIONS = ['storage', 'events', 'notifications', 'ui'] as const
export type PluginPermission = (typeof PLUGIN_PERMISSIONS)[number]

export interface PluginManifest {
  id: string
  name: string
  version?: string
  description?: string
  author?: string
  icon?: string // đường dẫn asset (vd "icon.svg") HOẶC emoji "🧩"
  entry?: string
  permissions?: string[]
  window?: { w?: number; h?: number; minW?: number; minH?: number }
}

const MAX_BUNDLE_BYTES = 50 * 1024 * 1024 // 50MB
const MAX_DATA_VALUE = 256 * 1024 // 256KB / giá trị
const MAX_PLUGIN_DATA = 10 * 1024 * 1024 // 10MB / plugin

export function pluginsRoot(): string {
  return path.join(process.env.STORAGE_ROOT || path.resolve(process.cwd(), 'storage'), 'plugins')
}

async function ensurePluginsRoot(): Promise<void> {
  await fsp.mkdir(pluginsRoot(), { recursive: true })
}

/** Nơi lưu plugin nguồn trong repo (seed copy vào storage lần đầu) */
export function builtinPluginsDir(): string {
  return path.join(process.cwd(), 'plugins')
}

/** Kiểm tra manifest hợp lệ — trả lỗi tiếng Việt rõ ràng cho người cài */
export function validateManifest(raw: unknown): PluginManifest {
  if (!raw || typeof raw !== 'object') throw new Error('wos-module.json phải là JSON object')
  const m = raw as Record<string, unknown>
  const id = String(m.id || '').trim().toLowerCase()
  if (!/^[a-z0-9][a-z0-9-]{1,39}$/.test(id)) {
    throw new Error('id plugin chỉ gồm a-z, 0-9, dấu gạch (2-40 ký tự), vd "hello-world"')
  }
  if (id.startsWith('plugin-')) throw new Error('id không được bắt đầu bằng "plugin-"')
  const name = String(m.name || '').trim()
  if (!name) throw new Error('Thiếu "name" trong manifest')
  const entry = String(m.entry || 'main.js')
  if (!entry.endsWith('.js') || entry.includes('..') || entry.startsWith('/')) {
    throw new Error('entry phải là file .js trong gói (vd "main.js")')
  }
  const perms = Array.isArray(m.permissions) ? m.permissions.map(String) : []
  for (const p of perms) {
    if (!PLUGIN_PERMISSIONS.includes(p as PluginPermission)) {
      throw new Error(`Permission "${p}" không hợp lệ (${PLUGIN_PERMISSIONS.join(', ')})`)
    }
  }
  return {
    id,
    name,
    version: String(m.version || '1.0.0'),
    description: String(m.description || ''),
    author: String(m.author || ''),
    icon: String(m.icon || '🧩'),
    entry,
    permissions: perms,
    window: (m.window && typeof m.window === 'object' ? m.window : {}) as PluginManifest['window'],
  }
}

/** Đọc manifest từ gói zip đã giải nén ở thư mục tạm */
async function readManifest(dir: string): Promise<PluginManifest> {
  const manifestPath = path.join(dir, 'wos-module.json')
  let raw: unknown
  try {
    raw = JSON.parse(await fsp.readFile(manifestPath, 'utf-8'))
  } catch {
    throw new Error('Gói thiếu wos-module.json (hoặc JSON lỗi)')
  }
  return validateManifest(raw)
}

/** Cài plugin từ file .wos/.zip — giải nén (unzip hệ thống), validate, move vào chỗ */
export async function installPlugin(zipPath: string): Promise<{ plugin: unknown; manifest: PluginManifest }> {
  const st = await fsp.stat(zipPath)
  if (st.size > MAX_BUNDLE_BYTES) throw new Error('Gói plugin vượt 50MB')

  const tmp = path.join(pluginsRoot(), `.wos_tmp_${Date.now()}`)
  await fsp.mkdir(tmp, { recursive: true })
  try {
    await execFileAsync('unzip', ['-o', '-q', zipPath, '-d', tmp], { maxBuffer: 16 * 1024 * 1024 })
    // zip có thể bọc 1 thư mục con — tự phát hiện
    let dir = tmp
    const entries = await fsp.readdir(tmp, { withFileTypes: true })
    const hasManifest = entries.some((e) => e.name === 'wos-module.json')
    if (!hasManifest && entries.length === 1 && entries[0].isDirectory()) {
      dir = path.join(tmp, entries[0].name)
    }
    const manifest = await readManifest(dir)
    // entry phải tồn tại trong gói
    const entry = manifest.entry || 'main.js'
    try {
      await fsp.access(path.join(dir, entry))
    } catch {
      throw new Error(`Không tìm thấy entry "${entry}" trong gói`)
    }

    // dọn gói cũ + move vào plugins/<id>
    await ensurePluginsRoot()
    const dest = path.join(pluginsRoot(), manifest.id)
    await fsp.rm(dest, { recursive: true, force: true })
    await fsp.rename(dir, dest)

    const win = manifest.window || {}
    const plugin = await db.plugin.upsert({
      where: { id: manifest.id },
      update: {
        name: manifest.name,
        version: manifest.version,
        description: manifest.description,
        author: manifest.author,
        icon: manifest.icon,
        entry: manifest.entry,
        permissions: JSON.stringify(manifest.permissions),
        windowW: typeof win.w === 'number' ? Math.round(win.w) : 520,
        windowH: typeof win.h === 'number' ? Math.round(win.h) : 560,
        enabled: true,
      },
      create: {
        id: manifest.id,
        slug: manifest.id,
        name: manifest.name,
        version: manifest.version,
        description: manifest.description,
        author: manifest.author,
        icon: manifest.icon,
        entry: manifest.entry,
        permissions: JSON.stringify(manifest.permissions),
        windowW: typeof win.w === 'number' ? Math.round(win.w) : 520,
        windowH: typeof win.h === 'number' ? Math.round(win.h) : 560,
        enabled: true,
      },
    })
    return { plugin, manifest }
  } finally {
    await fsp.rm(tmp, { recursive: true, force: true })
  }
}

/** Xoá plugin (thư mục + DB + dữ liệu PluginRecord) */
export async function uninstallPlugin(id: string): Promise<void> {
  await fsp.rm(path.join(pluginsRoot(), id), { recursive: true, force: true })
  await db.plugin.deleteMany({ where: { id } })
  await db.pluginRecord.deleteMany({ where: { pluginId: id } })
}

/** Đường dẫn tuyệt đối của 1 asset trong plugin — chống path traversal */
export function pluginAssetPath(id: string, rel: string): string {
  const root = path.resolve(pluginsRoot(), id)
  const full = path.resolve(root, (rel || '').replace(/^\/+/, ''))
  if (full !== root && !full.startsWith(root + path.sep)) throw new Error('Đường dẫn không hợp lệ')
  return full
}

/** Icon URL cho client (emoji → về nguyên, file → endpoint asset) */
export function pluginIconUrl(id: string, icon: string): string {
  if (!icon || icon.startsWith('/') === false && !/\.(svg|png|jpe?g|webp|gif)$/i.test(icon)) {
    // emoji hoặc rỗng
    return icon || '🧩'
  }
  return `/api/plugins/${id}/files/${icon.replace(/^\/+/, '')}`
}

/** Parse dòng Plugin DB → object client (JSON fields) */
export function pluginRowToJson(row: {
  id: string
  name: string
  version: string
  description: string
  author: string
  icon: string
  entry: string
  permissions: string
  windowW: number
  windowH: number
  enabled: boolean
  installedAt: Date
  updatedAt: Date
}) {
  let perms: string[] = []
  try { perms = JSON.parse(row.permissions || '[]') } catch { /* giữ [] */ }
  return {
    id: row.id,
    appId: `plugin:${row.id}`,
    name: row.name,
    version: row.version,
    description: row.description,
    author: row.author,
    icon: pluginIconUrl(row.id, row.icon),
    entry: row.entry,
    permissions: perms,
    window: { w: row.windowW, h: row.windowH },
    enabled: row.enabled,
    installedAt: row.installedAt,
    updatedAt: row.updatedAt,
  }
}

/** Giới hạn dữ liệu plugin */
export const PLUGIN_DATA_LIMITS = { maxValue: MAX_DATA_VALUE, maxTotal: MAX_PLUGIN_DATA }
