/**
 * WOS Search Engine (Core) — Global Search Ctrl+K
 * Mỗi module tự đăng ký provider (hàm search) tại đây.
 * Thêm module mới = thêm 1 entry — không sửa logic tìm kiếm.
 */
import { db } from '@/lib/db'
import { getAllModules } from './module-registry'
import type { SessionUser } from './auth'

export interface SearchResult {
  id: string
  module: string
  type: string // task | note | file | ...
  title: string
  detail: string
  action: string // deep link: "tasks" | "wiki:pageId" ...
  icon: string
  color: string
  at?: string
}

type Provider = (q: string, limit: number, userId: string) => Promise<SearchResult[]>

const like = (q: string) => ({ contains: q })

const providers = new Map<string, Provider>()
let registered = false

function registerProviders() {
  if (registered) return
  registered = true

  providers.set('tasks', async (q, limit, userId) => {
    const rows = await db.task.findMany({
      where: { ownerId: userId, OR: [{ title: like(q) }, { description: like(q) }], status: { not: 'archived' } },
      take: limit,
      orderBy: { updatedAt: 'desc' },
    })
    return rows.map((r) => ({
      id: r.id, module: 'tasks', type: 'task', title: r.title,
      detail: r.status === 'done' ? 'Đã hoàn thành' : `Trạng thái: ${r.status}`,
      action: `tasks:${r.id}`, icon: 'check-square', color: '#f59e0b', at: r.updatedAt.toISOString(),
    }))
  })

  providers.set('calendar', async (q, limit, userId) => {
    const rows = await db.calendarEvent.findMany({
      where: { ownerId: userId, OR: [{ title: like(q) }, { description: like(q) }] },
      take: limit,
      orderBy: { start: 'desc' },
    })
    return rows.map((r) => ({
      id: r.id, module: 'calendar', type: 'event', title: r.title,
      detail: new Date(r.start).toLocaleString('vi-VN'),
      action: `calendar:${r.id}`, icon: 'calendar', color: '#10b981', at: r.start.toISOString(),
    }))
  })

  providers.set('notes', async (q, limit, userId) => {
    const rows = await db.note.findMany({
      where: { ownerId: userId, OR: [{ title: like(q) }, { content: like(q) }], trashedAt: null },
      take: limit,
      orderBy: { updatedAt: 'desc' },
    })
    return rows.map((r) => ({
      id: r.id, module: 'notes', type: 'note', title: r.title,
      detail: r.content.slice(0, 80) || 'Ghi chú trống',
      action: `notes:${r.id}`, icon: 'sticky-note', color: '#eab308', at: r.updatedAt.toISOString(),
    }))
  })

  providers.set('wiki', async (q, limit, userId) => {
    const rows = await db.wikiPage.findMany({
      where: { ownerId: userId, OR: [{ title: like(q) }, { content: like(q) }], trashedAt: null },
      take: limit,
      orderBy: { updatedAt: 'desc' },
    })
    return rows.map((r) => ({
      id: r.id, module: 'wiki', type: 'wiki', title: `${r.icon} ${r.title}`,
      detail: `Phiên bản ${r.version}`,
      action: `wiki:${r.id}`, icon: 'book-open', color: '#84cc16', at: r.updatedAt.toISOString(),
    }))
  })

  providers.set('files', async (q, limit, userId) => {
    const rows = await db.fileNode.findMany({
      where: { ownerId: userId, OR: [{ name: like(q) }, { tags: like(q) }], trashedAt: null },
      take: limit,
      orderBy: { updatedAt: 'desc' },
    })
    return rows.map((r) => ({
      id: r.id, module: 'files', type: 'file', title: r.name,
      detail: r.isDir ? 'Thư mục' : r.path,
      action: `files:${encodeURIComponent(r.path)}`, icon: r.isDir ? 'folder' : 'file',
      color: '#22c55e', at: r.updatedAt.toISOString(),
    }))
  })

  providers.set('projects', async (q, limit, userId) => {
    const rows = await db.project.findMany({
      where: { ownerId: userId, OR: [{ name: like(q) }, { description: like(q) }] },
      take: limit,
      orderBy: { updatedAt: 'desc' },
    })
    return rows.map((r) => ({
      id: r.id, module: 'projects', type: 'project', title: r.name,
      detail: r.description.slice(0, 80) || `Trạng thái: ${r.status}`,
      action: `projects:${r.id}`, icon: 'folder-kanban', color: '#ea580c', at: r.updatedAt.toISOString(),
    }))
  })

  providers.set('activity', async (q, limit, userId) => {
    const rows = await db.activityLog.findMany({
      where: { userId, OR: [{ detail: like(q) }, { userName: like(q) }, { action: like(q) }] },
      take: limit,
      orderBy: { createdAt: 'desc' },
    })
    return rows.map((r) => ({
      id: r.id, module: 'activity', type: 'activity', title: r.detail || r.action,
      detail: `${r.userName} · ${r.module} · ${new Date(r.createdAt).toLocaleString('vi-VN')}`,
      action: 'activity', icon: 'activity', color: '#06b6d4', at: r.createdAt.toISOString(),
    }))
  })
}

export async function globalSearch(
  q: string,
  user: SessionUser,
  opts: { module?: string; limit?: number } = {}
): Promise<SearchResult[]> {
  registerProviders()
  const modules = await getAllModules()
  const enabled = new Set(modules.filter((m) => m.enabled).map((m) => m.manifest.id))
  const limit = opts.limit ?? 8
  const targetProviders = [...providers.entries()].filter(([id]) => {
    // 'users' chỉ admin được dùng (provider có thể bị đăng ký bởi lần search admin trước)
    if (id === 'users' && user.role !== 'admin') return false
    if (opts.module && opts.module !== 'all' && id !== opts.module) return false
    return enabled.has(id) || id === 'activity'
  })
  // viewer không tìm users; users search chỉ admin (dữ liệu hệ thống, không scope theo owner)
  if (user.role === 'admin' && (opts.module === 'users' || !opts.module || opts.module === 'all')) {
    providers.set('users', async (qq, lim) => {
      const rows = await db.user.findMany({
        where: { OR: [{ username: like(qq) }, { displayName: like(qq) }] },
        take: lim,
      })
      return rows.map((r) => ({
        id: r.id, module: 'users', type: 'user', title: r.displayName,
        detail: `@${r.username} · ${r.role}`,
        action: 'users', icon: 'users', color: '#ec4899',
      }))
    })
  }
  const results = await Promise.all(
    targetProviders.map(async ([id, fn]) => {
      try {
        return await fn(q, limit, user.id)
      } catch (err) {
        console.error(`[search:${id}]`, err)
        return []
      }
    })
  )
  return results.flat().sort((a, b) => (b.at || '').localeCompare(a.at || '')).slice(0, limit * 3)
}
