/**
 * WOS Plugin Packs — hệ thống plugin dạng .zip + thư mục riêng (v5).
 *
 * Plugin "nặng" nhiều file không thể nhét vào 1 chuỗi JSON được. Kiểu cài mới:
 *   1. Upload file .zip  → POST /api/core/plugins/install-zip (multipart 'file')
 *   2. Hoặc copy code trực tiếp vào THƯ MỤC PLUGIN: <STORAGE_ROOT>/plugins/<slug>/
 *      rồi bấm "Quét" (hoặc hệ thống tự quét khi tải danh sách).
 *
 * Cấu trúc pack hợp lệ (root của zip HOẶC 1 thư mục con duy nhất chứa tất cả):
 *   plugin.json   — manifest { slug, name, version, description, author, icon,
 *                    color, kind: 'app'|'pet', windowSize?, entry, styles?,
 *                    desktopIcon?, showDock? }
 *   <entry>.js    — mã JS chính (manifest.entry = "main.js" | "index.js" | inline JS)
 *   style.css     — (tuỳ chọn, manifest.styles: ["style.css"]) tự chèn khi chạy
 *   assets/...    — (tuỳ chọn) hình ảnh/tài nguyên — plugin lấy qua WOS.assetUrl('assets/x.png')
 *
 * Bảo mật: chống zip-slip (tên entry không được chứa ../ hoặc dẫn tuyệt đối),
 * giới hạn số file (3000) + tổng dung lượng giải nén (200MB) + entry < 500KB.
 * Plugin do ADMIN cài (tự host) — tin cậy như mã hệ thống.
 */
import { execFile } from 'child_process'
import { promises as fsp, createWriteStream, existsSync, mkdirSync } from 'fs'
import path from 'path'
import { randomBytes } from 'crypto'
import { Readable, Transform } from 'stream'
import { pipeline } from 'stream/promises'
import { db } from '@/lib/db'
import { baseStorageRoot, inspectZipSafety, removeAllSymlinks } from './storage'
import { ApiError } from './api-error'

const execFileAsync = (cmd: string, args: string[]) =>
  new Promise<{ stdout: string; stderr: string }>((resolve, reject) => {
    execFile(cmd, args, { maxBuffer: 32 * 1024 * 1024 }, (err, stdout, stderr) =>
      err ? reject(err) : resolve({ stdout: String(stdout), stderr: String(stderr) }),
    )
  })

export const MAX_ZIP_BYTES = 100 * 1024 * 1024 // 100MB nén
const MAX_FILES = 3000
const MAX_UNPACKED = 200 * 1024 * 1024 // 200MB giải nén
const MAX_ENTRY_BYTES = 500 * 1024 // entry JS tối đa 500KB
const MANIFEST_NAMES = ['plugin.json', 'wos-plugin.json', 'manifest.json']
const SLUG_RE = /^[a-z0-9][a-z0-9-]{1,38}$/

export function pluginsDir(): string {
  const dir = path.join(baseStorageRoot(), 'plugins')
  try {
    mkdirSync(dir, { recursive: true })
  } catch {
    /* đã có */
  }
  return dir
}

export interface PluginManifest {
  slug: string
  name: string
  description: string
  version: string
  author: string
  icon: string
  color: string
  kind: 'app' | 'pet'
  entry: string
  styles: string
  desktopIcon: boolean
  showDock: boolean
  windowW: number
  windowH: number
  order: number
}

/** Đọc + validate manifest JSON thô (dùng chung cho zip và JSON paste) */
export function parseManifest(raw: unknown): PluginManifest {
  if (!raw || typeof raw !== 'object') throw new ApiError('Manifest phải là JSON object')
  const m = raw as Record<string, unknown>
  const slug = String(m.slug || '').trim().toLowerCase()
  if (!SLUG_RE.test(slug)) throw new ApiError('slug hợp lệ: 2-40 ký tự a-z, 0-9, gạch ngang')
  const name = String(m.name || '').trim()
  if (!name) throw new ApiError('Thiếu "name"')
  const kind = m.kind === 'pet' ? 'pet' : 'app'
  const windowSize = (m.windowSize && typeof m.windowSize === 'object' ? m.windowSize : {}) as { w?: number; h?: number }
  return {
    slug,
    name: name.slice(0, 60),
    description: String(m.description || '').slice(0, 300),
    version: String(m.version || '1.0.0').slice(0, 20),
    author: String(m.author || '').slice(0, 80),
    icon: String(m.icon || '🧩').slice(0, 12),
    color: /^#[0-9a-fA-F]{6}$/.test(String(m.color)) ? String(m.color) : '#8b5cf6',
    kind,
    entry: String(m.entry || ''),
    styles: '',
    desktopIcon: m.desktopIcon === false ? false : true,
    showDock: Boolean(m.showDock),
    windowW: Math.max(280, Math.min(1400, Number(windowSize.w) || (kind === 'pet' ? 300 : 520))),
    windowH: Math.max(240, Math.min(1200, Number(windowSize.h) || (kind === 'pet' ? 360 : 560))),
    order: 500,
  }
}

/** Upsert plugin từ manifest + entry/styles vào DB (giữ enabled/config người dùng) */
export async function upsertPluginFromPack(
  def: PluginManifest,
  opts: { source: 'zip' | 'dir' | 'json' },
): Promise<{ created: boolean }> {
  if (def.entry.length > MAX_ENTRY_BYTES) throw new ApiError('Mã entry quá lớn (> 500KB)')
  const existing = await db.plugin.findUnique({ where: { slug: def.slug } })
  if (existing && existing.builtin) {
    throw new ApiError(`Slug "${def.slug}" trùng plugin dựng sẵn của hệ thống — đổi slug khác`)
  }
  if (existing) {
    // nâng cấp: giữ enabled/config/desktopIcon người dùng đã chỉnh, đổi mã + metadata
    await db.plugin.update({
      where: { slug: def.slug },
      data: {
        name: def.name,
        description: def.description,
        version: def.version,
        author: def.author,
        icon: def.icon,
        color: def.color,
        kind: def.kind,
        entry: def.entry,
        styles: def.styles,
        windowW: def.windowW,
        windowH: def.windowH,
        showDock: def.showDock,
      },
    })
    return { created: false }
  }
  await db.plugin.create({
    data: {
      slug: def.slug,
      name: def.name,
      description: def.description,
      version: def.version,
      author: def.author,
      icon: def.icon,
      color: def.color,
      kind: def.kind,
      entry: def.entry,
      styles: def.styles,
      config: JSON.stringify(def.kind === 'pet' ? { speed: 130, size: 1, interactions: true } : {}),
      enabled: true,
      builtin: false,
      desktopIcon: def.desktopIcon,
      showDock: def.showDock,
      windowW: def.windowW,
      windowH: def.windowH,
      order: def.order,
    },
  })
  return { created: true }
}

/** đọc file nhỏ an toàn (trong pack dir) */
async function readPackFile(packDir: string, rel: string, maxBytes: number): Promise<string> {
  const full = path.resolve(packDir, rel)
  if (!full.startsWith(path.resolve(packDir) + path.sep)) throw new ApiError('Đường dẫn file không hợp lệ')
  const st = await fsp.stat(full)
  if (!st.isFile()) throw new ApiError(`"${rel}" không phải file`)
  if (st.size > maxBytes) throw new ApiError(`File "${rel}" quá lớn (> ${Math.round(maxBytes / 1024)}KB)`)
  return fsp.readFile(full, 'utf-8')
}

/** Đọc pack trong 1 thư mục đã giải nén: manifest + entry + styles */
export async function readPackDir(packDir: string): Promise<{ dir: string; manifest: PluginManifest }> {
  // manifest ở root HOẶC trong đúng 1 thư mục con
  let manifestDir = packDir
  let manifestRaw: string | null = null
  for (const name of MANIFEST_NAMES) {
    if (existsSync(path.join(packDir, name))) {
      manifestRaw = await fsp.readFile(path.join(packDir, name), 'utf-8')
      break
    }
  }
  if (manifestRaw === null) {
    const entries = await fsp.readdir(packDir, { withFileTypes: true })
    const dirs = entries.filter((e) => e.isDirectory())
    if (dirs.length === 1) {
      const inner = path.join(packDir, dirs[0].name)
      for (const name of MANIFEST_NAMES) {
        if (existsSync(path.join(inner, name))) {
          manifestDir = inner
          manifestRaw = await fsp.readFile(path.join(inner, name), 'utf-8')
          break
        }
      }
    }
  }
  if (manifestRaw === null) throw new ApiError('Không tìm thấy plugin.json trong pack (đặt ở thư mục gốc của zip)')
  let parsed: unknown
  try {
    parsed = JSON.parse(manifestRaw)
  } catch {
    throw new ApiError('plugin.json không phải JSON hợp lệ')
  }
  const def = parseManifest(parsed)
  // entry: (a) tên file trong pack, (b) chuỗi JS inline
  const entrySpec = String((parsed as Record<string, unknown>).entry || '')
  if (entrySpec.trim() && !entrySpec.includes('\n') && entrySpec.length < 200 && existsSync(path.join(manifestDir, entrySpec))) {
    def.entry = await readPackFile(manifestDir, entrySpec, MAX_ENTRY_BYTES)
  } else if (def.entry.trim()) {
    if (def.entry.length > MAX_ENTRY_BYTES) throw new ApiError('Mã entry quá lớn (> 500KB)')
  } else {
    // fallback: main.js / index.js
    for (const f of ['main.js', 'index.js', 'entry.js', 'app.js']) {
      if (existsSync(path.join(manifestDir, f))) {
        def.entry = await readPackFile(manifestDir, f, MAX_ENTRY_BYTES)
        break
      }
    }
    if (!def.entry) throw new ApiError('Thiếu entry: khai "entry": "main.js" trong plugin.json (hoặc mã JS inline)')
  }
  // styles: manifest.styles = ["style.css"] → nối nội dung
  const stylesSpec = (parsed as Record<string, unknown>).styles
  if (Array.isArray(stylesSpec)) {
    const parts: string[] = []
    for (const s of stylesSpec.slice(0, 10)) {
      const f = String(s)
      if (existsSync(path.join(manifestDir, f))) parts.push(await readPackFile(manifestDir, f, 200 * 1024))
    }
    def.styles = parts.join('\n')
  } else if (typeof stylesSpec === 'string' && stylesSpec.trim() && existsSync(path.join(manifestDir, stylesSpec))) {
    def.styles = await readPackFile(manifestDir, stylesSpec, 200 * 1024)
  }
  return { dir: manifestDir, manifest: def }
}

/** Quét thư mục plugins/<slug>/ có plugin.json → upsert DB (idempotent) */
let scanCache = { ts: 0, count: -1 }
export async function scanPluginsDir(force = false): Promise<number> {
  if (!force && Date.now() - scanCache.ts < 15000 && scanCache.count >= 0) return scanCache.count
  const root = pluginsDir()
  let count = 0
  let found = 0
  try {
    const entries = await fsp.readdir(root, { withFileTypes: true })
    for (const e of entries) {
      if (!e.isDirectory() || e.name.startsWith('.') || e.name === 'tmp') continue
      const packDir = path.join(root, e.name)
      const hasManifest = MANIFEST_NAMES.some((n) => existsSync(path.join(packDir, n)))
      if (!hasManifest) continue
      found++
      try {
        const { manifest } = await readPackDir(packDir)
        // slug ưu tiên theo manifest; thư mục khác tên slug → vẫn cài theo slug manifest
        await upsertPluginFromPack(manifest, { source: 'dir' })
        count++
      } catch (err) {
        console.warn(`[plugins] Bỏ qua pack "${e.name}":`, err instanceof Error ? err.message : err)
      }
    }
  } catch {
    /* thư mục chưa tồn tại */
  }
  scanCache = { ts: Date.now(), count }
  void found
  return count
}

/** Lưu stream upload zip xuống file tạm, trả path (đếm byte không giữ RAM) */
export async function saveTempZip(stream: Readable): Promise<{ tmpPath: string; size: number }> {
  const tmpDir = path.join(pluginsDir(), 'tmp')
  await fsp.mkdir(tmpDir, { recursive: true })
  const tmpPath = path.join(tmpDir, `upload-${Date.now()}-${randomBytes(4).toString('hex')}.zip`)
  const counter = new (class extends Transform {
    private count = 0
    _transform(chunk: Buffer, _enc: string, cb: (err?: Error | null, data?: unknown) => void) {
      this.count += Buffer.byteLength(chunk)
      cb(null, chunk)
    }
    get bytes() {
      return this.count
    }
  })()
  await pipeline(stream, counter, createWriteStream(tmpPath))
  if (counter.bytes > MAX_ZIP_BYTES) {
    await fsp.rm(tmpPath, { force: true })
    throw new ApiError('File .zip quá lớn (> 100MB)')
  }
  return { tmpPath, size: counter.bytes }
}

/**
 * Cài plugin từ file .zip đã lưu tạm (v2.3 — dùng CHUNG cơ chế ZIP security với
 * File Manager, trước đây 2 code riêng khiến plugin zip SÓT kiểm tra symlink):
 *   1. inspectZipSafety() pre-scan: symlink entry / zip-slip / ZIP BOMB / số mục
 *   2. giải nén vào tmp riêng + removeAllSymlinks(tmp) (phòng thủ lớp 2)
 *   3. readPackDir → manifest + entry; đo dung lượng THỰC TẾ giải nén
 *   4. FILESYSTEM TRƯỚC DB (trước đây update DB rồi mới xoá+copy — cp lỗi là mất
 *      luôn plugin trên đĩa): copy pack vào .wos_stage_* → đẩy bản cũ sang
 *      .wos_old_* (rename atomic) → rename staging vào chỗ → mới update DB
 *   5. DB lỗi → rollback filesystem (đưa .wos_old_* về chỗ cũ); mọi thứ OK → xoá old
 * Thư mục .wos_* có tiền tố '.' → scanPluginsDir() tự bỏ qua (không quét nhầm).
 */
export async function installPluginZip(tmpZipPath: string): Promise<PluginManifest> {
  // 1) pre-scan an toàn DÙNG CHUNG với File Manager (symlink/zip-slip/zip-bomb/số mục)
  await inspectZipSafety(tmpZipPath, { maxEntries: MAX_FILES, maxTotalBytes: MAX_UNPACKED })
  // 2) giải nén vào tmp
  const tmpDir = path.join(pluginsDir(), 'tmp', `extract-${Date.now()}-${randomBytes(4).toString('hex')}`)
  await fsp.mkdir(tmpDir, { recursive: true })
  // staging cho bản mới + chỗ chứa bản cũ (rollback) — tên '.' + '.wos_' cho scan bỏ qua
  const staging = path.join(pluginsDir(), `.wos_stage_${randomBytes(4).toString('hex')}`)
  let oldDir = ''
  try {
    await execFileAsync('unzip', ['-o', '-q', tmpZipPath, '-d', tmpDir])
    // phòng thủ lớp 2 — xoá symlink sót lại (giống File Manager extract)
    await removeAllSymlinks(tmpDir)
    // 3) đọc pack
    const { manifest, dir: manifestDir } = await readPackDir(tmpDir)
    // 4) kiểm tra dung lượng giải nén THỰC TẾ (khai báo trong zip có thể nói dối)
    let total = 0
    await (async function walk(d: string) {
      const entries = await fsp.readdir(d, { withFileTypes: true })
      for (const e of entries) {
        const full = path.join(d, e.name)
        if (e.isDirectory()) await walk(full)
        else total += (await fsp.stat(full)).size
      }
    })(tmpDir)
    if (total > MAX_UNPACKED) throw new ApiError('Nội dung giải nén quá lớn (> 200MB)')
    // 5) filesystem trước DB: staging copy → swap → DB → rollback nếu DB fail
    await fsp.cp(manifestDir, staging, { recursive: true })
    await removeAllSymlinks(staging) // belt & suspenders — staging không chứa symlink
    const dest = path.join(pluginsDir(), manifest.slug)
    let destExists = false
    try {
      destExists = (await fsp.stat(dest)).isDirectory()
    } catch {
      destExists = false
    }
    try {
      if (destExists) {
        oldDir = path.join(pluginsDir(), `.wos_old_${manifest.slug}_${randomBytes(4).toString('hex')}`)
        await fsp.rename(dest, oldDir)
      }
      await fsp.rename(staging, dest)
      try {
        await upsertPluginFromPack(manifest, { source: 'zip' })
      } catch (err) {
        // DB fail → trả bản cũ về chỗ cũ (plugin cũ NGUYÊN VẸN, DB không đổi)
        await fsp.rm(dest, { recursive: true, force: true }).catch(() => {})
        if (oldDir) await fsp.rename(oldDir, dest).catch(() => {})
        throw err
      }
      // thành công — dọn bản cũ
      if (oldDir) await fsp.rm(oldDir, { recursive: true, force: true }).catch(() => {})
    } catch (err) {
      // swap/copy lỗi trước cả khi đụng DB → bản cũ vẫn ở dest (rename chưa xảy ra)
      // hoặc đã đẩy sang oldDir → trả về
      if (oldDir && destExists) {
        try {
          await fsp.access(dest)
        } catch {
          await fsp.rename(oldDir, dest).catch(() => {})
        }
      }
      throw err
    }
    return manifest
  } finally {
    await fsp.rm(tmpDir, { recursive: true, force: true }).catch(() => {})
    await fsp.rm(tmpZipPath, { force: true }).catch(() => {})
    await fsp.rm(staging, { recursive: true, force: true }).catch(() => {})
  }
}

/** Thư mục pack của plugin (plugins/<slug>/) — slug đã validate. Dùng cho gỡ
 *  cài đặt (DELETE). KHÔNG dùng để phục vụ asset — đó là resolvePluginAssetReal
 *  (cần lớp realpath chống symlink). */
export function pluginPackDir(slug: string): string | null {
  if (!SLUG_RE.test(slug)) return null
  return path.join(pluginsDir(), slug)
}

/** Giải path asset an toàn trong plugins/<slug>/ — LỚP 1 lexical + LỚP 2 REALPATH
 *  (v2.3): symlink nằm trong plugins/<slug>/assets trỏ RA NGOÀI (vd /etc/passwd)
 *  vẫn PASS kiểm tra lexical nhưng stat()/readFile() sẽ follow — nên phải realpath
 *  và bắt buộc đích nằm DƯỚI plugins/<slug>/ thật. Trả realpath (đã thoát symlink)
 *  hoặc null nếu không hợp lệ / không tồn tại. */
export async function resolvePluginAssetReal(slug: string, file: string): Promise<string | null> {
  if (!SLUG_RE.test(slug)) return null
  const rel = (file || '').replace(/^\/+/, '')
  if (!rel) return null // asset API chỉ phục vụ FILE, không phục vụ thư mục gốc
  if (rel.includes('\\') || rel.split('/').includes('..') || /[\0]/.test(rel)) return null
  const base = path.resolve(pluginsDir(), slug)
  const full = path.resolve(base, rel)
  if (!full.startsWith(base + path.sep)) return null
  try {
    // LỚP 2 — realpath: mọi symlink trong chuỗi được hoá giải; thoát khỏi
    // plugins/<slug>/ (kể cả qua nhiều tầng link) → từ chối
    const baseReal = await fsp.realpath(base)
    const real = await fsp.realpath(full)
    if (real !== baseReal && !real.startsWith(baseReal + path.sep)) return null
    return real
  } catch {
    return null // không tồn tại (realpath throw khi thành phần cuối chưa có)
  }
}
