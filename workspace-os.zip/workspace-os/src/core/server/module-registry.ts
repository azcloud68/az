/**
 * WOS Module Manager (Core Engine) — nguồn sự thật phía server
 * Mọi module đăng ký manifest tại đây (tương đương manifest.json chuẩn).
 * Trạng thái bật/tắt + config nằm ở bảng ModuleState — core gần như không đổi
 * khi thêm module mới: chỉ cần khai báo manifest + dựng UI riêng của module.
 */
import { db } from '@/lib/db'

export interface ModulePermission {
  admin: string[]
  member: string[]
  viewer: string[]
}

export interface ModuleManifest {
  id: string
  name: string
  description: string
  icon: string // lucide icon name
  color: string
  version: string
  order: number
  core: boolean // module lõi — không được tắt
  showSidebar: boolean
  showDock: boolean
  section: 'main' | 'admin' | 'system'
  permissions: ModulePermission
  events: string[] // các event type module phát ra
  widgets: { id: string; title: string; zone: 'top' | 'center' | 'bottom'; span: 1 | 2 | 3 | 4 }[]
  searchTypes: { id: string; label: string }[]
  settingsTabs: string[] // các tab settings của module
}

const DEFAULT_PERMS: ModulePermission = {
  admin: ['*'],
  member: ['read', 'write'],
  viewer: ['read'],
}

function manifest(m: Partial<ModuleManifest> & Pick<ModuleManifest, 'id' | 'name' | 'description'>): ModuleManifest {
  return {
    icon: 'box',
    color: '#f97316',
    version: '1.0.0',
    order: 100,
    core: false,
    showSidebar: true,
    showDock: false,
    section: 'main',
    permissions: DEFAULT_PERMS,
    events: [],
    widgets: [],
    searchTypes: [],
    settingsTabs: ['general', 'permissions', 'widgets', 'notifications', 'backup', 'logs', 'advanced'],
    ...m,
  } as ModuleManifest
}

/** Đăng ký toàn bộ module của WOS (Giai đoạn 1 + 2) */
export const MODULE_MANIFESTS: ModuleManifest[] = [
  manifest({
    id: 'dashboard',
    name: 'Dashboard',
    description: 'Tổng hợp toàn bộ Workspace bằng widget động',
    icon: 'layout-dashboard',
    color: '#f97316',
    order: 1,
    core: true,
    showDock: true,
    widgets: [],
    searchTypes: [],
  }),
  manifest({
    id: 'projects',
    name: 'Projects',
    description: 'Quản lý dự án, mốc tiến độ, thành viên',
    icon: 'folder-kanban',
    color: '#ea580c',
    order: 10,
    showDock: true,
    events: ['project.created', 'project.updated', 'project.archived', 'milestone.completed'],
    searchTypes: [{ id: 'project', label: 'Dự án' }],
    widgets: [
      { id: 'projects.active', title: 'Dự án đang chạy', zone: 'center', span: 2 },
      { id: 'projects.progress', title: 'Tiến độ dự án', zone: 'bottom', span: 2 },
    ],
  }),
  manifest({
    id: 'tasks',
    name: 'Tasks',
    description: 'Công việc: List, Kanban, Timeline, Archive',
    icon: 'check-square',
    color: '#f59e0b',
    order: 20,
    showDock: true,
    events: ['task.created', 'task.updated', 'task.completed', 'task.deleted'],
    searchTypes: [{ id: 'task', label: 'Công việc' }],
    widgets: [
      { id: 'tasks.today', title: 'Công việc hôm nay', zone: 'center', span: 2 },
      { id: 'tasks.stats', title: 'Thống kê công việc', zone: 'bottom', span: 2 },
    ],
  }),
  manifest({
    id: 'weekly',
    name: 'Công Việc Tuần',
    description: 'Lên công việc hàng tuần theo Quy trình: bước, lot, điều kiện, tick hoàn thành',
    icon: 'clipboard-list',
    color: '#3b82f6',
    order: 25,
    showDock: true,
    events: [
      'weekly.process.created', 'weekly.process.updated', 'weekly.process.deleted',
      'weekly.task.completed', 'weekly.task.passed', 'weekly.day.offline',
    ],
    searchTypes: [],
    widgets: [{ id: 'weekly.timeline', title: 'Timeline công việc tuần', zone: 'center', span: 2 }],
  }),
  manifest({
    id: 'calendar',
    name: 'Calendar',
    description: 'Lịch Day/Week/Month/Year, sự kiện lặp lại',
    icon: 'calendar',
    color: '#10b981',
    order: 30,
    showDock: true,
    events: ['event.created', 'event.updated', 'event.deleted'],
    searchTypes: [{ id: 'event', label: 'Sự kiện lịch' }],
    widgets: [{ id: 'calendar.mini', title: 'Mini Calendar', zone: 'center', span: 1 }],
  }),
  manifest({
    id: 'notes',
    name: 'Notes',
    description: 'Ghi chú Markdown, checklist, code block',
    icon: 'sticky-note',
    color: '#eab308',
    order: 40,
    showDock: true,
    events: ['note.created', 'note.updated', 'note.deleted'],
    searchTypes: [{ id: 'note', label: 'Ghi chú' }],
    widgets: [{ id: 'notes.quick', title: 'Quick Note', zone: 'center', span: 1 }],
  }),
  manifest({
    id: 'wiki',
    name: 'Wiki',
    description: 'Tri thức: thư mục, trang lồng nhau, phiên bản',
    icon: 'book-open',
    color: '#84cc16',
    order: 50,
    showDock: true,
    events: ['wiki.created', 'wiki.updated', 'wiki.deleted'],
    searchTypes: [{ id: 'wiki', label: 'Trang wiki' }],
    widgets: [{ id: 'wiki.recent', title: 'Wiki mới cập nhật', zone: 'center', span: 2 }],
  }),
  manifest({
    id: 'files',
    name: 'Files',
    description: 'Quản lý tệp: preview, share, recycle bin, quota',
    icon: 'folder',
    color: '#22c55e',
    order: 60,
    showDock: true,
    events: ['file.uploaded', 'file.updated', 'file.deleted', 'file.restored', 'file.shared'],
    searchTypes: [{ id: 'file', label: 'Tệp tin' }],
    widgets: [{ id: 'files.recent', title: 'Tệp gần đây', zone: 'center', span: 2 }],
  }),
  manifest({
    id: 'browser',
    name: 'Trình duyệt',
    description: 'Web Browser — duyệt internet trong cửa sổ WOS, tab, thanh địa chỉ, ứng dụng web',
    icon: 'globe',
    color: '#0ea5e9',
    order: 14,
    showDock: true,
    showSidebar: false,
    events: ['browser.navigated'],
    searchTypes: [],
  }),
  manifest({
    id: 'terminal',
    name: 'Terminal',
    description: 'Shell bash thật qua PTY — chạy lệnh trên máy chủ WOS (giới hạn phiên)',
    icon: 'terminal-square',
    color: '#1f2937',
    order: 15,
    showDock: true,
    showSidebar: false,
    events: [],
    searchTypes: [],
  }),
  manifest({
    id: 'monitor',
    name: 'System Monitor',
    description: 'Activity Monitor — CPU, RAM, ổ đĩa, tiến trình đang chạy trên máy',
    icon: 'gauge',
    color: '#ef4444',
    order: 16,
    showDock: true,
    showSidebar: false,
    events: [],
    searchTypes: [],
  }),
  manifest({
    id: 'downloads',
    name: 'Downloads',
    description: 'Trình quản lý tải xuống — tiến trình, tiếp lại, mở tệp/thư mục',
    icon: 'download',
    color: '#6366f1',
    order: 17,
    showDock: false,
    showSidebar: false,
    events: ['download.completed'],
    searchTypes: [],
  }),
  manifest({
    id: 'doc',
    name: 'Documents',
    description: 'Document Engine — xem PDF, DOCX, XLSX, PPTX ngay trên desktop',
    icon: 'file-text',
    color: '#f97316',
    order: 18,
    showDock: false,
    showSidebar: false,
    events: [],
    searchTypes: [],
  }),
  manifest({
    id: 'media',
    name: 'Media Player',
    description: 'Trình phát video/audio — mp4, webm, mp3, flac… với điều khiển kiểu macOS',
    icon: 'play',
    color: '#ec4899',
    order: 19,
    showDock: false,
    showSidebar: false,
    events: [],
    searchTypes: [],
  }),
  manifest({
    id: 'timeline',
    name: 'Timeline',
    description: 'Dòng thời gian hoạt động từ Event Bus',
    icon: 'git-commit-horizontal',
    color: '#14b8a6',
    order: 70,
    events: [],
    searchTypes: [],
    widgets: [{ id: 'timeline.feed', title: 'Hoạt động gần đây', zone: 'center', span: 2 }],
  }),
  manifest({
    id: 'reports',
    name: 'Reports',
    description: 'Báo cáo, thống kê, xuất PDF/Excel/CSV',
    icon: 'bar-chart-3',
    color: '#0891b2',
    order: 80,
    searchTypes: [],
    widgets: [
      { id: 'reports.statistics', title: 'Statistics', zone: 'bottom', span: 2 },
      { id: 'reports.summary', title: 'AI Summary', zone: 'bottom', span: 2 },
    ],
  }),
  manifest({
    id: 'activity',
    name: 'Activity',
    description: 'Activity Monitor — log thao tác người dùng',
    icon: 'activity',
    color: '#06b6d4',
    order: 90,
    searchTypes: [{ id: 'activity', label: 'Hoạt động' }],
    widgets: [{ id: 'activity.feed', title: 'Activity Log', zone: 'bottom', span: 2 }],
  }),
  manifest({
    id: 'notifications',
    name: 'Notifications',
    description: 'Notification Center của toàn hệ thống',
    icon: 'bell',
    color: '#f43f5e',
    order: 95,
    showDock: false,
    searchTypes: [],
    widgets: [{ id: 'notifications.recent', title: 'Thông báo mới', zone: 'top', span: 2 }],
  }),
  manifest({
    id: 'users',
    name: 'Administration',
    description: 'Users, Groups, Roles, Permissions',
    icon: 'users',
    color: '#ec4899',
    order: 110,
    section: 'admin',
    permissions: { admin: ['*'], member: [], viewer: [] },
    searchTypes: [{ id: 'user', label: 'Người dùng' }],
  }),
  manifest({
    id: 'settings',
    name: 'Settings',
    description: 'Settings Engine — cấu hình hệ thống & từng module',
    icon: 'settings',
    color: '#8b5cf6',
    order: 120,
    section: 'system',
    core: true,
    searchTypes: [],
  }),
]

export interface ModuleRuntime {
  manifest: ModuleManifest
  enabled: boolean
  config: Record<string, unknown>
  permissions: ModulePermission
}

/** Gộp manifest + trạng thái DB (cache trong RAM 5s cho Orange Pi) */
const cache = new Map<string, { ts: number; data: ModuleRuntime[] }>()
const CACHE_MS = 5000

export async function getAllModules(): Promise<ModuleRuntime[]> {
  const hit = cache.get('all')
  if (hit && Date.now() - hit.ts < CACHE_MS) return hit.data
  const states = await db.moduleState.findMany()
  const stateMap = new Map(states.map((s) => [s.moduleId, s]))
  const data = MODULE_MANIFESTS.map((m) => {
    const st = stateMap.get(m.id)
    let config: Record<string, unknown> = {}
    try {
      config = st ? (JSON.parse(st.config) as Record<string, unknown>) : {}
    } catch {
      config = {}
    }
    const perms = (config.permissions as ModulePermission | undefined) ?? m.permissions
    return { manifest: m, enabled: st ? st.enabled : true, config, permissions: perms }
  })
  cache.set('all', { ts: Date.now(), data })
  return data
}

export async function getModuleRuntime(moduleId: string): Promise<ModuleRuntime> {
  const modules = await getAllModules()
  const found = modules.find((m) => m.manifest.id === moduleId)
  if (!found) throw new Error(`Module không tồn tại: ${moduleId}`)
  return found
}

export async function setModuleEnabled(moduleId: string, enabled: boolean): Promise<void> {
  await db.moduleState.upsert({
    where: { moduleId },
    update: { enabled },
    create: { moduleId, enabled },
  })
  cache.clear()
}

export async function setModuleConfig(moduleId: string, config: Record<string, unknown>): Promise<void> {
  await db.moduleState.upsert({
    where: { moduleId },
    update: { config: JSON.stringify(config) },
    create: { moduleId, config: JSON.stringify(config) },
  })
  cache.clear()
}
