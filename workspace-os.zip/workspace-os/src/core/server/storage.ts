/**
 * WOS Storage Engine (Core) — file thật nằm trong STORAGE_ROOT
 * SQLite (FileNode) chỉ là chỉ mục metadata.
 * Bảo vệ 2 LỚP:
 *   1. Lexical (sync): safeResolve() — chặn "../" + đường dẫn tuyệt đối
 *      → CHỈ dùng cho thao tác thuần đường dẫn (basename, so sánh prefix...)
 *   2. Filesystem (async): safeResolveReal() — realpath từng thành phần,
 *      chặn SYMLINK trỏ thoát khỏi root (tấn công giải nén ZIP độc hại)
 *      → MỌI thao tác đọc/ghi thật PHẢI đi qua đây (kèm verify fd chống TOCTOU).
 *      Route KHÔNG tự gọi fs.* trên kết quả safeResolve() nữa.
 * I/O lớn đều STREAM (createReadStream / saveStream) — không phình RAM máy 2GB.
 */
import { createReadStream, createWriteStream, existsSync, mkdirSync, statSync, open as fsOpen, close as fsClose, fstat as fsFstat } from 'fs'
import { promises as fsp, constants as fsConstants } from 'fs'
import type { Stats } from 'fs'
import path from 'path'
import { Readable, Transform } from 'stream'
import { pipeline } from 'stream/promises'
import { execFile } from 'child_process'
import { promisify } from 'util'
import { randomBytes } from 'crypto'
import { currentStorageUserId } from './user-scope'
import { ApiError } from './api-error'

const execFileAsync = promisify(execFile)

/** Giới hạn 1 tệp upload — policy TẬP TRUNG ở storage layer (upload route dùng chung;
 *  đổi qua env WOS_MAX_FILE_MB, 1–4096, mặc định 256) */
export const MAX_FILE_BYTES = (() => {
  const mb = Number(process.env.WOS_MAX_FILE_MB || '256')
  return Number.isFinite(mb) && mb > 0 && mb <= 4096 ? Math.floor(mb) * 1024 * 1024 : 256 * 1024 * 1024
})()

/** Trần cứng tổng dung lượng GIẢI NÉN 1 lần (kể cả khi quota còn nhiều) — chống ZIP bomb làm đầy đĩa */
export const MAX_EXTRACT_BYTES = 2 * 1024 * 1024 * 1024

/** Mutex trong-process cho các thao tác làm thay đổi dung lượng lớn (upload, extract) —
 *  chống 2 request đồng thời cùng đọc "còn đủ quota" rồi cùng ghi vượt (race quota).
 *  WOS chạy 1 node process trên Orange Pi → mutex RAM là đủ. */
const scopeGlobal = globalThis as unknown as {
  __wosDuCache?: Map<string, { ts: number; bytes: number }>
  __wosStorageMutex?: Promise<unknown>
}
export function withStorageLock<T>(fn: () => Promise<T>): Promise<T> {
  if (!scopeGlobal.__wosStorageMutex) scopeGlobal.__wosStorageMutex = Promise.resolve()
  const run = scopeGlobal.__wosStorageMutex.then(fn)
  scopeGlobal.__wosStorageMutex = run.then(() => undefined, () => undefined)
  return run
}

export const STORAGE_CATEGORIES = [
  { name: 'Documents', label: 'Tài liệu', icon: 'file-text' },
  { name: 'Downloads', label: 'Tải xuống', icon: 'download' },
  { name: 'Pictures', label: 'Ảnh', icon: 'image' },
  { name: 'Videos', label: 'Video', icon: 'film' },
  { name: 'Projects', label: 'Dự án', icon: 'folder-git-2' },
  { name: 'AI', label: 'AI', icon: 'sparkles' },
  { name: 'Backups', label: 'Sao lưu', icon: 'archive' },
  { name: 'Shared', label: 'Chia sẻ', icon: 'users' },
]



/** Cache "đã mkdir" per user — module-scope: sống qua request, reset khi hot-reload
 *  (mỗi lần reload chạy lại mkdir 1 lần/user — rẻ, bảo đảm đủ bộ category) */
const userDirEnsured = new Set<string>()

/** Root lưu trữ TOÀN HỆ THỐNG — KHÔNG bao giờ scope theo user (plugins, sync/backup...) */
export function baseStorageRoot(): string {
  return process.env.STORAGE_ROOT || path.resolve(process.cwd(), 'storage')
}

/** Root lưu trữ HIỆN TẠI: trong ngữ cảnh user → <base>/users/<uid>, ngoài → base root.
 *  Lần đầu scope vào 1 user: tự tạo root + bộ thư mục category (1 lần/module, cache Set). */
export function storageRoot(): string {
  const base = baseStorageRoot()
  const uid = currentStorageUserId()
  if (!uid) return base
  const dir = path.join(base, 'users', uid)
  if (!userDirEnsured.has(dir)) {
    try {
      mkdirSync(dir, { recursive: true })
    } catch {
      /* đã có */
    }
    for (const c of STORAGE_CATEGORIES) {
      try {
        mkdirSync(path.join(dir, c.name), { recursive: true })
      } catch {
        /* đã có */
      }
    }
    userDirEnsured.add(dir)
  }
  return dir
}

/** Tạo bộ thư mục category cho 1 user (idempotent, lỗi bỏ qua) */
export function ensureUserDirs(userId: string): void {
  const base = baseStorageRoot()
  const userRoot = path.join(base, 'users', userId)
  try {
    mkdirSync(userRoot, { recursive: true })
  } catch {
    /* đã có */
  }
  for (const c of STORAGE_CATEGORIES) {
    try {
      mkdirSync(path.join(userRoot, c.name), { recursive: true })
    } catch {
      /* đã có */
    }
  }
}

export function ensureStorageDirs(): void {
  const root = baseStorageRoot()
  mkdirSync(root, { recursive: true })
  for (const c of STORAGE_CATEGORIES) {
    try {
      mkdirSync(path.join(root, c.name), { recursive: true })
    } catch {
      /* đã có */
    }
  }
}

/** Chống path traversal (LỚP 1 — lexical, sync): luôn resolve và bắt buộc nằm trong root HIỆN TẠI
 * (trong ngữ cảnh user → chặn thoát khỏi thư mục user, kể cả 'users/../').
 * LƯU Ý: lớp này KHÔNG chống symlink — mọi thao tác đọc/ghi thật phải đi qua safeResolveReal(). */
export function safeResolve(relPath: string): string {
  const root = path.resolve(storageRoot())
  const clean = (relPath || '').replace(/^\/+/, '')
  const full = path.resolve(root, clean)
  if (full !== root && !full.startsWith(root + path.sep)) {
    throw new ApiError('Đường dẫn không hợp lệ')
  }
  return full
}

/** LỚP 2 — filesystem: realpath toàn bộ chuỗi thành phần từ root tới đích.
 *  Bất kỳ symlink nào đưa path THOÁT khỏi root → từ chối (ZIP độc hại giải nén ra escape link).
 *  Symlink trỏ NỘI bộ storage (vô hại) vẫn được dùng.
 *  Thành phần chưa tồn tại (file mới) → kiểm tra tới tổ tiên tồn tại gần nhất. */
export async function safeResolveReal(relPath: string): Promise<string> {
  const full = safeResolve(relPath)
  const rootReal = await realpathOf(path.resolve(storageRoot()))
  let probe = full
  const tail: string[] = []
  for (;;) {
    const rp = await realpathOf(probe)
    if (rp) {
      const target = tail.length ? path.join(rp, ...tail) : rp
      if (target !== rootReal && !target.startsWith(rootReal + path.sep)) {
        throw new ApiError('Đường dẫn không hợp lệ (symlink thoát khỏi kho lưu trữ)')
      }
      return full
    }
    tail.unshift(path.basename(probe))
    const parent = path.dirname(probe)
    if (parent === probe) break
    probe = parent
  }
  return full
}

async function realpathOf(p: string): Promise<string | null> {
  try {
    return await fsp.realpath(p)
  } catch {
    return null
  }
}

/** Mở fd thô (callback-style) — cho stream mượn fd với autoClose */
function openRaw(full: string, flags: string): Promise<number> {
  return new Promise((res, rej) => fsOpen(full, flags, (err, fd) => (err ? rej(err) : res(fd))))
}
function closeRaw(fd: number): Promise<void> {
  return new Promise((res) => fsClose(fd, () => res()))
}
function fstatRaw(fd: number): Promise<Stats> {
  return new Promise((res, rej) => fsFstat(fd, (err, st) => (err ? rej(err) : res(st))))
}

/** Chống TOCTOU: sau khi mở fd, kiểm tra fd vẫn trỏ VÀO TRONG root (đọc /proc/self/fd).
 *  Lấp khoảng hở "realpath-check xong → symlink bị đổi → read/write theo path cũ".
 *  Linux (máy triển khai Orange Pi) mới có /proc — hệ khác bỏ qua một cách an toàn
 *  (đã có lớp realpath trước đó). */
async function verifyFdUnderRoot(fd: number, label: string): Promise<void> {
  let target: string
  try {
    target = await fsp.readlink(`/proc/self/fd/${fd}`)
  } catch {
    return
  }
  const rootReal = await realpathOf(path.resolve(storageRoot()))
  if (!rootReal) return
  if (target !== rootReal && !target.startsWith(rootReal + path.sep)) {
    throw new ApiError(`${label}: tệp đang mở trỏ ra ngoài kho lưu trữ (TOCTOU) — bị chặn`)
  }
}

export function toRelPath(full: string): string {
  const root = path.resolve(storageRoot())
  return path.relative(root, full).split(path.sep).join('/')
}

/** Tên file an toàn: bỏ ký tự nguy hiểm, không cho ../ */
export function sanitizeFileName(name: string): string {
  const base = path.basename(name || '').trim()
  if (!base || base === '.' || base === '..') throw new ApiError('Tên file không hợp lệ')
  return base.replace(/[/\\:*?"<>|]/g, '_').slice(0, 200)
}

const MIME_MAP: Record<string, string> = {
  '.txt': 'text/plain', '.md': 'text/markdown', '.markdown': 'text/markdown',
  '.json': 'application/json', '.csv': 'text/csv', '.xml': 'application/xml',
  '.yml': 'text/yaml', '.yaml': 'text/yaml', '.log': 'text/plain', '.sh': 'text/x-sh',
  '.js': 'text/javascript', '.ts': 'text/typescript', '.css': 'text/css', '.html': 'text/html',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif',
  '.webp': 'image/webp', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.bmp': 'image/bmp',
  '.pdf': 'application/pdf',
  '.mp4': 'video/mp4', '.webm': 'video/webm', '.mov': 'video/quicktime', '.mkv': 'video/x-matroska',
  '.mp3': 'audio/mpeg', '.wav': 'audio/wav', '.ogg': 'audio/ogg', '.flac': 'audio/flac',
  '.doc': 'application/msword', '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  '.xls': 'application/vnd.ms-excel', '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  '.ppt': 'application/vnd.ms-powerpoint', '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  '.zip': 'application/zip', '.tar': 'application/x-tar', '.gz': 'application/gzip',
}

export function mimeOf(name: string): string {
  const ext = path.extname(name || '').toLowerCase()
  return MIME_MAP[ext] || 'application/octet-stream'
}

export function formatSize(bytes: number): string {
  if (!bytes || bytes < 0) return '0 B'
  const units = ['B', 'KB', 'MB', 'GB', 'TB']
  let i = 0
  let n = bytes
  while (n >= 1024 && i < units.length - 1) {
    n /= 1024
    i++
  }
  return `${n < 10 && i > 0 ? n.toFixed(1) : Math.round(n)} ${units[i]}`
}

export async function exists(relPath: string): Promise<boolean> {
  try {
    await fsp.access(await safeResolveReal(relPath), fsConstants.F_OK)
    return true
  } catch {
    return false
  }
}

export async function isDir(relPath: string): Promise<boolean> {
  try {
    return (await fsp.stat(await safeResolveReal(relPath))).isDirectory()
  } catch {
    return false
  }
}

export async function fileSize(relPath: string): Promise<number> {
  try {
    return (await fsp.stat(await safeResolveReal(relPath))).size
  } catch {
    return 0
  }
}

/** Duyệt thư mục 1 tầng — trả về entries tương đối với relPath */
export async function listDir(relPath: string): Promise<
  { name: string; isDir: boolean; size: number; mtime: Date }[]
> {
  const full = await safeResolveReal(relPath)
  const entries = await fsp.readdir(full, { withFileTypes: true })
  const out: { name: string; isDir: boolean; size: number; mtime: Date }[] = []
  for (const e of entries) {
    // ẩn mọi thư mục làm việc nội bộ của WOS (.wos_trash_*, .wos_extract_* staging...)
    if (e.name.startsWith('.wos_')) continue
    try {
      // bỏ qua symlink (không hiển thị — tránh đánh lừa người dùng)
      const lst = await fsp.lstat(path.join(full, e.name))
      if (lst.isSymbolicLink()) continue
      const st = await fsp.stat(path.join(full, e.name))
      out.push({ name: e.name, isDir: e.isDirectory(), size: st.size, mtime: st.mtime })
    } catch {
      /* bỏ qua entry lỗi */
    }
  }
  out.sort((a, b) => (a.isDir === b.isDir ? a.name.localeCompare(b.name, 'vi') : a.isDir ? -1 : 1))
  return out
}

/** Stream upload xuống đĩa — không giữ RAM (chuẩn máy 2GB).
 *  Kiểm tra realpath tổ tiên (chống ghi xuyên symlink thoát root) + verify fd sau khi mở. */
export async function saveStream(relPath: string, stream: Readable): Promise<{ size: number }> {
  const full = await safeResolveReal(relPath)
  await fsp.mkdir(path.dirname(full), { recursive: true })
  const fd = await openRaw(full, 'w')
  try {
    await verifyFdUnderRoot(fd, 'Ghi tệp')
  } catch (e) {
    await closeRaw(fd)
    throw e
  }
  const counter = new CounterTransform()
  // stream ghi vào fd ĐÃ MỞ + ĐÃ VERIFY — path '' bị bỏ qua khi truyền fd
  await pipeline(stream, counter, createWriteStream('', { fd }))
  return { size: counter.bytes }
}

/** Đếm byte khi stream qua (không giữ buffer trong RAM) */
class CounterTransform extends Transform {
  private count = 0
  _transform(chunk: Buffer, _enc: string, cb: (err?: Error | null, data?: unknown) => void) {
    this.count += Buffer.byteLength(chunk)
    cb(null, chunk)
  }
  get bytes(): number {
    return this.count
  }
}

/** Đọc file NHỎ (≤ vài MB): config, thumbnail... — đã qua lớp realpath */
export async function readFileBuffer(relPath: string): Promise<Buffer> {
  return fsp.readFile(await safeResolveReal(relPath))
}

/** Đọc file LỚN dạng STREAM — download/preview/share (hỗ trợ Range cho video).
 *  RAM chỉ bằng 1 chunk (64KB) dù file 4GB. Mở fd riêng + verify TOCTOU — stream
 *  đọc từ fd ĐÃ MỞ nên symlink đổi giữa chừng không thể chuyển hướng luồng đọc. */
export async function readFileStream(
  relPath: string,
  opts: { start?: number; end?: number } = {}
): Promise<{ stream: Readable; size: number }> {
  const full = await safeResolveReal(relPath)
  const fd = await openRaw(full, 'r')
  let st: Stats
  try {
    await verifyFdUnderRoot(fd, 'Đọc tệp')
    st = await fstatRaw(fd)
  } catch (e) {
    await closeRaw(fd)
    throw e
  }
  if (st.isDirectory()) {
    await closeRaw(fd)
    throw new Error('Không đọc được thư mục')
  }
  return {
    // stream đọc từ fd ĐÃ MỜ + ĐÃ VERIFY (autoClose đóng fd khi stream xong) —
    // path '' bị bỏ qua khi truyền fd → symlink đổi giữa chừng không tác động
    stream: createReadStream('', {
      fd,
      autoClose: true,
      ...(opts.start != null ? { start: opts.start } : {}),
      ...(opts.end != null ? { end: opts.end } : {}),
    }),
    size: st.size,
  }
}

export async function makeDir(relPath: string): Promise<void> {
  const full = await safeResolveReal(relPath)
  await fsp.mkdir(full, { recursive: true })
}

/** Stat an toàn (đi qua realpath) — trả null nếu không tồn tại. Dùng thay fsp.stat(safeResolve(...)). */
export async function statEntry(
  relPath: string
): Promise<{ size: number; mtime: Date; birthtime: Date; isDir: boolean } | null> {
  try {
    const st = await fsp.stat(await safeResolveReal(relPath))
    return { size: st.size, mtime: st.mtime, birthtime: st.birthtime, isDir: st.isDirectory() }
  } catch {
    return null
  }
}

/** Ghi tệp văn bản NHỎ (TextViewer / newfile) — an toàn + verify fd. Trả số byte. */
export async function writeTextFile(relPath: string, content: string): Promise<{ size: number }> {
  const full = await safeResolveReal(relPath)
  await fsp.mkdir(path.dirname(full), { recursive: true })
  const handle = await fsp.open(full, 'w')
  try {
    await verifyFdUnderRoot(handle.fd, 'Ghi tệp')
    await handle.writeFile(content, 'utf-8')
  } catch (e) {
    await handle.close().catch(() => {})
    throw e
  }
  await handle.close()
  return { size: Buffer.byteLength(content) }
}

/** Tìm tên chưa dùng trong dir: "a.txt" → "a (1).txt" → "a (2).txt" (thư mục: "b (1)").
 *  Cùng logic dedup với upload — đảm bảo KHÔNG BAO GIỜ ghi đè tệp người dùng đang có. */
export async function uniqueRelPath(dir: string, name: string): Promise<string> {
  let rel = dir ? `${dir}/${name}` : name
  if (!(await exists(rel))) return rel
  const base = name.replace(/(\.[^.]+)$/, '')
  const ext = path.extname(name)
  for (let i = 1; i < 1000; i++) {
    const candidate = `${base} (${i})${ext}`
    rel = dir ? `${dir}/${candidate}` : candidate
    if (!(await exists(rel))) return rel
  }
  throw new Error('Không tìm được tên tệp chưa dùng')
}

/** Xoá thật (rm -rf trong storage) */
export async function removeEntry(relPath: string): Promise<void> {
  const full = await safeResolveReal(relPath)
  await fsp.rm(full, { recursive: true, force: true })
}

export async function moveEntry(from: string, to: string): Promise<void> {
  const src = await safeResolveReal(from)
  const dst = await safeResolveReal(to)
  rejectDescendant(src, dst)
  await fsp.mkdir(path.dirname(dst), { recursive: true })
  await fsp.rename(src, dst)
}

export async function copyEntry(from: string, to: string): Promise<void> {
  const src = await safeResolveReal(from)
  const dst = await safeResolveReal(to)
  rejectDescendant(src, dst)
  await fsp.mkdir(path.dirname(dst), { recursive: true })
  const st = await fsp.stat(src)
  if (st.isDirectory()) {
    await copyDir(src, dst)
  } else {
    await fsp.copyFile(src, dst)
  }
}

/** Chặn copy/move A → A hoặc A → bên trong A (đệ quy vô hạn A/A/A/...) */
function rejectDescendant(src: string, dst: string): void {
  if (dst === src || dst.startsWith(src + path.sep)) {
    throw new Error('Không thể sao chép / di chuyển vào chính nó hoặc thư mục con của nó')
  }
}

async function copyDir(src: string, dst: string): Promise<void> {
  await fsp.mkdir(dst, { recursive: true })
  const entries = await fsp.readdir(src, { withFileTypes: true })
  for (const e of entries) {
    const s = path.join(src, e.name)
    const d = path.join(dst, e.name)
    if (e.isSymbolicLink()) continue // bỏ qua symlink khi copy
    if (e.isDirectory()) await copyDir(s, d)
    else await fsp.copyFile(s, d)
  }
}

/** Nén thành .zip bằng binary hệ thống (zip) — nhẹ trên ARM */
export async function zipEntries(sources: string[], destRel: string): Promise<void> {
  const dst = await safeResolveReal(destRel)
  if (!dst.endsWith('.zip')) throw new ApiError('Tệp nén phải có đuôi .zip')
  const args: string[] = ['-r', '-q']
  const first = await safeResolveReal(sources[0] || '')
  // zip chạy tại cha của nguồn để giữ tên gốc
  const cwd = path.dirname(first)
  const names = sources.map((s) => path.basename(safeResolve(s)))
  await fsp.rm(dst, { force: true })
  await execFileAsync('zip', [...args, path.isAbsolute(destRel) ? dst : path.resolve(dst), ...names], { cwd, maxBuffer: 16 * 1024 * 1024 })
}

/** 1 dòng listing dài `unzip -Zl`: attr + DUNG LƯỢNG GIẢI NÉN — cùng thứ tự với `unzip -Z1` */
interface ZipLine {
  attr: string
  size: number
}

/** Parse listing dài `unzip -Zl` (cột: mode, version, os, UNCOMPRESSED-SIZE, ...) */
function parseZipLines(stdout: string): ZipLine[] {
  const out: ZipLine[] = []
  for (const line of stdout.split('\n')) {
    const m = line.match(/^([ldrwx?Ss-]{10})\s+\d+\.\d+\s+\S+\s+(\d+)\s+/)
    if (m) out.push({ attr: m[1], size: Number(m[2]) })
  }
  return out
}

/** Pre-scan tổng dung lượng giải nén KHAI BÁO của zip (đọc `unzip -Zl`, KHÔNG giải nén).
 *  Dùng chung: extract File Manager + cài plugin .zip — chặn ZIP BOMB trước khi đụng đĩa.
 *  Trả null khi zip không đọc được / listing lệch dòng (bất thường → caller nên chặn). */
export async function zipDeclaredUncompressedSize(srcAbs: string): Promise<number | null> {
  try {
    const [{ stdout: namesOut }, { stdout: listing }] = await Promise.all([
      execFileAsync('unzip', ['-Z1', srcAbs], { maxBuffer: 16 * 1024 * 1024 }),
      execFileAsync('unzip', ['-Zl', srcAbs], { maxBuffer: 16 * 1024 * 1024 }),
    ])
    const names = namesOut.split('\n').filter(Boolean)
    const lines = parseZipLines(listing)
    if (lines.length !== names.length) return null
    return lines.reduce((sum, l) => sum + l.size, 0)
  } catch {
    return null
  }
}

export interface ZipSafetyReport {
  names: string[]
  totalUncompressed: number
}

/** PRE-SCAN AN TOÀN ZIP DÙNG CHUNG (v2.3) — File Manager extract + cài plugin .zip
 *  DÙNG MỘT HÀM duy nhất (trước đây plugin zip tự kiểm riêng, sót symlink):
 *  chặn trước khi giải nén:
 *   - listing lệch dòng (zip bất thường — có thể nói dối)
 *   - entry LÀ SYMLINK (attr 'l…' — symlink trỏ /etc/passwd)
 *   - tên độc hại: tuyệt đối / '..' / '\\' / NUL / xuống dòng
 *   - quá nhiều mục (mặc định 3000)
 *   - tổng dung lượng giải nén KHAI BÁO vượt maxTotalBytes (ZIP BOMB 10MB→10GB)
 */
export async function inspectZipSafety(
  srcAbs: string,
  opts: { maxEntries?: number; maxTotalBytes?: number } = {},
): Promise<ZipSafetyReport> {
  const maxEntries = opts.maxEntries && opts.maxEntries > 0 ? opts.maxEntries : 3000
  const maxTotal = Math.min(
    opts.maxTotalBytes != null && opts.maxTotalBytes > 0 ? opts.maxTotalBytes : MAX_EXTRACT_BYTES,
    MAX_EXTRACT_BYTES,
  )
  const [{ stdout: namesOut }, { stdout: listing }] = await Promise.all([
    execFileAsync('unzip', ['-Z1', srcAbs], { maxBuffer: 16 * 1024 * 1024 }),
    execFileAsync('unzip', ['-Zl', srcAbs], { maxBuffer: 16 * 1024 * 1024 }),
  ])
  const names = namesOut.split('\n').filter(Boolean)
  const lines = parseZipLines(listing)
  if (lines.length !== names.length) {
    throw new ApiError('ZIP không đọc được danh sách mục — bị chặn vì lý do bảo mật')
  }
  if (names.length === 0) throw new ApiError('File .zip rỗng hoặc không đọc được (hỏng hoặc không phải zip)')
  if (names.length > maxEntries) throw new ApiError(`ZIP có quá nhiều mục (> ${maxEntries})`)
  let totalUncompressed = 0
  for (let i = 0; i < names.length; i++) {
    const name = names[i]
    const { attr, size } = lines[i]
    if (attr.startsWith('l')) {
      throw new ApiError(`ZIP chứa liên kết ký hiệu "${name}" — bị chặn vì lý do bảo mật`)
    }
    if (/[\0\n\r]/.test(name)) throw new ApiError('ZIP chứa tên tệp không hợp lệ')
    if (name.startsWith('/') || name.split('/').includes('..') || name.includes('\\')) {
      throw new ApiError(`ZIP chứa đường dẫn thoát "${name}" — bị chặn`)
    }
    totalUncompressed += size
  }
  if (totalUncompressed > maxTotal) {
    throw new ApiError(
      `Tổng dung lượng giải nén (${formatSize(totalUncompressed)}) vượt giới hạn cho phép (${formatSize(maxTotal)}) — chặn ZIP nén độc hại (zip bomb)`,
    )
  }
  return { names, totalUncompressed }
}

/** Quét đệ quy xoá mọi symlink trong thư mục vừa giải nén (phòng thủ lớp 2).
 *  Xuất khẩu từ v2.3 — plugin zip install DÙNG CHUNG (trước đây chỉ File Manager có). */
export async function removeAllSymlinks(dir: string): Promise<number> {
  let removed = 0
  let entries
  try {
    entries = await fsp.readdir(dir, { withFileTypes: true })
  } catch {
    return 0
  }
  for (const e of entries) {
    const full = path.join(dir, e.name)
    try {
      if (e.isSymbolicLink()) {
        await fsp.rm(full, { force: true })
        removed++
      } else if (e.isDirectory()) {
        removed += await removeAllSymlinks(full)
      }
    } catch {
      /* bỏ qua */
    }
  }
  return removed
}

/** 1 mục đã giải nén (đường dẫn rel tính từ root storage, KHÔNG chỉ tầng đầu) */
export interface ExtractedEntry {
  path: string
  name: string
  isDir: boolean
  size: number
}

/** Giải nén .zip — 5 LỚP PHÒNG THỦ:
 *  1. Pre-scan `unzip -Zl`: từ chối entry là symlink (attr 'lrwxrwxrwx')
 *  2. Pre-scan tên entry: từ chối tuyệt đối / '..' / '\\' / NUL / xuống dòng
 *  3. Pre-scan DUNG LƯỢNG GIẢI NÉN: tổng phải ≤ hạn mức còn lại (chống ZIP BOMB:
 *     zip 10MB khai 10GB → chặn TRƯỚC KHI đụng đĩa) + trần cứng MAX_EXTRACT_BYTES
 *  4. Giải nén vào thư mục STAGING riêng rồi mới chuyển sang đích → KHÔNG BAO GIỜ
 *     ghi đè tệp/thư mục người dùng đang có (đích trùng tên → tự dedup "tên (1)")
 *  5. Duyệt ĐỆ QUY toàn bộ cây vừa giải nén → trả đủ entries cho DB index TOÀN BỘ cây
 *  Lỗi giữa chừng → dọn sạch staging + cây đích (mới tạo hoàn toàn nên xoá an toàn).
 *  Caller nên bọc trong withStorageLock() để quota không bị race với upload. */
export async function unzipEntry(
  zipRel: string,
  destDirRel: string,
  opts: { maxTotalBytes?: number } = {}
): Promise<{ root: string; entries: ExtractedEntry[] }> {
  const src = await safeResolveReal(zipRel)
  const dst = await safeResolveReal(destDirRel)
  if (!src.endsWith('.zip')) throw new ApiError('Chỉ hỗ trợ giải nén tệp .zip')
  const outDir = dst.endsWith('.zip') ? dst.slice(0, -4) : dst

  // (1)+(2)+(3) pre-scan an toàn — HÀM DÙNG CHUNG inspectZipSafety() (giống hệt
  // cài plugin .zip): symlink entry / zip-slip / ZIP BOMB bị chặn TRƯỚC KHI giải nén
  await inspectZipSafety(src, { maxTotalBytes: opts.maxTotalBytes })

  // (4) staging: giải nén vào thư mục tạm RIÊNG (rỗng, của WOS) — tệp người dùng
  //     KHÔNG bị ghi đè vì mọi thứ chỉ chuyển sang đích qua rename + dedup tên
  const staging = path.join(path.dirname(outDir), `.wos_extract_${randomBytes(6).toString('hex')}`)
  await fsp.mkdir(staging, { recursive: true })
  let finalAbs = ''
  try {
    // -o chỉ ghi đè trong staging (thư mục rỗng dùng một lần) — không chạm dữ liệu user
    const { stdout } = await execFileAsync('unzip', ['-o', '-q', src, '-d', staging], { maxBuffer: 16 * 1024 * 1024 })
    void stdout
    // phòng thủ: xoá symlink sót lại (nếu binary unzip tạo mà pre-scan lỡ)
    await removeAllSymlinks(staging)

    // đích cuối: dedup tên ("project" đang có → "project (1)") — không bao giờ ghi đè
    const outDirRel = toRelPath(outDir)
    const parentRel = path.dirname(outDirRel) === '.' ? '' : path.dirname(outDirRel).split(path.sep).join('/')
    const finalRel = await uniqueRelPath(parentRel, path.basename(outDirRel))
    finalAbs = safeResolve(finalRel)
    await fsp.mkdir(finalAbs, { recursive: true })

    // chuyển từng entry TẦNG GỐC từ staging sang đích (rename cùng filesystem — rẻ)
    const top = await fsp.readdir(staging, { withFileTypes: true })
    for (const e of top) {
      await fsp.rename(path.join(staging, e.name), path.join(finalAbs, e.name))
    }
    await fsp.rm(staging, { recursive: true, force: true })

    // (5) duyệt ĐỆ QUY cây vừa giải nén → caller tạo FileNode cho TOÀN BỘ cây
    const entries: ExtractedEntry[] = []
    async function walk(abs: string, rel: string): Promise<void> {
      const st = await fsp.stat(abs)
      entries.push({ path: rel, name: path.basename(rel) || rel, isDir: st.isDirectory(), size: st.size })
      if (!st.isDirectory()) return
      for (const e of await fsp.readdir(abs, { withFileTypes: true })) {
        if (e.isSymbolicLink()) continue
        await walk(path.join(abs, e.name), rel ? `${rel}/${e.name}` : e.name)
      }
    }
    await walk(finalAbs, finalRel)
    return { root: finalRel, entries }
  } catch (err) {
    // dọn dẹp: staging + cây đích (finalAbs chỉ được tạo trong lần gọi này — xoá an toàn)
    await fsp.rm(staging, { recursive: true, force: true }).catch(() => {})
    if (finalAbs) await fsp.rm(finalAbs, { recursive: true, force: true }).catch(() => {})
    throw err
  }
}

/** Dung lượng dùng trong storage HIỆN TẠI (per-user khi scoped) — đếm đệ quy, cache 30s theo root.
 *  Truyền { fresh: true } khi ENFORCE QUOTA (upload/extract) — bỏ cache để không dùng
 *  số cũ sau khi thao tác trước vừa đổi dung lượng (kết hợp withStorageLock). */
export async function storageUsage(opts: { fresh?: boolean } = {}): Promise<number> {
  const root = path.resolve(storageRoot())
  if (!scopeGlobal.__wosDuCache) scopeGlobal.__wosDuCache = new Map()
  const caches = scopeGlobal.__wosDuCache
  const hit = caches.get(root)
  if (!opts.fresh && hit && Date.now() - hit.ts < 30000) return hit.bytes
  let bytes = 0
  async function walk(dir: string) {
    let entries
    try {
      entries = await fsp.readdir(dir, { withFileTypes: true })
    } catch {
      return
    }
    for (const e of entries) {
      const full = path.join(dir, e.name)
      if (e.isDirectory()) await walk(full)
      else {
        try {
          bytes += (await fsp.stat(full)).size
        } catch { /* bỏ qua */ }
      }
    }
  }
  await walk(root)
  caches.set(root, { ts: Date.now(), bytes })
  return bytes
}

/** Xoá cache dung lượng của root HIỆN TẠI — gọi sau khi upload/xoá để usage phản ánh ngay */
export function invalidateUsage(): void {
  const root = path.resolve(storageRoot())
  if (scopeGlobal.__wosDuCache) scopeGlobal.__wosDuCache.delete(root)
}

/** Kiểm tra tệp tồn tại khi import backup */
export function fileStat(relPath: string): { size: number; mtime: Date } | null {
  try {
    const st = statSync(safeResolve(relPath))
    return { size: st.size, mtime: st.mtime }
  } catch {
    return null
  }
}

export function storageExistsSync(): boolean {
  return existsSync(storageRoot())
}

/** Marker file báo migration dữ liệu per-user đã chạy (xem core/server/user-data.ts) */
export const PER_USER_MARKER = '.migrated-v1'
