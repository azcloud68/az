/**
 * WOS System Monitor — Engine đọc tài nguyên máy CHỐT cho System API V3.
 * Đọc thẳng /proc (Linux — Orange Pi ARM64) với fallback os.* cho môi trường dev:
 *   - resourceSnapshot(): CPU tổng + từng nhân, RAM + swap, đĩa, load, nhiệt độ,
 *     mạng (rx/tx + tốc độ/giây) — có cache delta giữa 2 lần gọi.
 *   - listProcesses(): bảng tiến trình từ /proc/[pid] (CPU% delta, RSS, uid → user).
 * Giới hạn: chỉ đọc — không có thao tác nguy hiểm nào trong file này.
 */
import { promises as fsp } from 'fs'
import os from 'os'
import { diskInfo, uptimeInfo } from './sysinfo'

export interface ResourceSnapshot {
  ts: number
  cpu: { percent: number; perCore: number[]; cores: number }
  mem: { total: number; used: number; available: number; percent: number; swapTotal: number; swapUsed: number }
  disk: { total: number; used: number; free: number; percent: number }
  load: [number, number, number]
  uptime: number
  temp: number | null
  net: { rx: number; tx: number; rxPerSec: number; txPerSec: number }
}

// ==== Cache delta CPU (tổng + từng nhân) ====
let cpuPrev: { total: number[]; idle: number[]; ts: number } | null = null
let cpuPct: { overall: number; perCore: number[] } = { overall: 0, perCore: [] }

function parseProcStat(text: string): { total: number[]; idle: number[] } {
  const lines = text.split('\n').filter((l) => /^cpu\d*\s/.test(l))
  const total: number[] = []
  const idle: number[] = []
  for (const line of lines) {
    const parts = line.split(/\s+/).slice(1).map(Number)
    const t = parts.reduce((a, b) => a + (b || 0), 0)
    const i = (parts[3] || 0) + (parts[4] || 0) // idle + iowait
    total.push(t)
    idle.push(i)
  }
  return { total, idle }
}

async function cpuSnapshot(): Promise<{ overall: number; perCore: number[] }> {
  try {
    const text = await fsp.readFile('/proc/stat', 'utf8')
    const snap = parseProcStat(text)
    const now = Date.now()
    if (cpuPrev && now - cpuPrev.ts >= 250) {
      const perCore: number[] = []
      let dTotalAll = 0
      let dIdleAll = 0
      for (let i = 0; i < snap.total.length; i++) {
        const dTotal = snap.total[i] - (cpuPrev.total[i] ?? snap.total[i])
        const dIdle = snap.idle[i] - (cpuPrev.idle[i] ?? snap.idle[i])
        if (dTotal > 0) {
          const pct = Math.max(0, Math.min(100, ((dTotal - dIdle) / dTotal) * 100))
          if (i === 0) {
            cpuPct.overall = Math.round(pct)
          } else {
            perCore.push(Math.round(pct))
          }
          if (i === 0 || cpuPrev.total.length <= 1) {
            dTotalAll += dTotal
            dIdleAll += dIdle
          }
        } else if (i > 0) {
          perCore.push(0)
        }
      }
      cpuPct = { overall: cpuPct.overall, perCore }
      cpuPrev = { ...snap, ts: now }
    } else if (!cpuPrev) {
      cpuPrev = { ...snap, ts: now }
    }
    return cpuPct
  } catch {
    // Non-Linux: ước lượng từ load average
    const cores = Math.max(1, os.cpus().length)
    const pct = Math.min(100, Math.round((os.loadavg()[0] / cores) * 100))
    return { overall: pct, perCore: Array(cores).fill(pct) }
  }
}

// ==== Mạng: /proc/net/dev với delta ====
let netPrev: { rx: number; tx: number; ts: number } | null = null

async function netSnapshot(): Promise<{ rx: number; tx: number; rxPerSec: number; txPerSec: number }> {
  try {
    const text = await fsp.readFile('/proc/net/dev', 'utf8')
    let rx = 0
    let tx = 0
    for (const line of text.split('\n').slice(2)) {
      const [iface, data] = line.split(':')
      if (!data || iface.trim() === 'lo') continue
      const cols = data.trim().split(/\s+/).map(Number)
      rx += cols[0] || 0
      tx += cols[8] || 0
    }
    const now = Date.now()
    let rxPs = 0
    let txPs = 0
    if (netPrev && now - netPrev.ts > 200) {
      const dt = (now - netPrev.ts) / 1000
      rxPs = Math.max(0, Math.round((rx - netPrev.rx) / dt))
      txPs = Math.max(0, Math.round((tx - netPrev.tx) / dt))
    }
    netPrev = { rx, tx, ts: now }
    return { rx, tx, rxPerSec: rxPs, txPerSec: txPs }
  } catch {
    return { rx: 0, tx: 0, rxPerSec: 0, txPerSec: 0 }
  }
}

/** Nhiệt độ SoC (Orange Pi: thermal_zone0; thử vài vị trí) */
export async function cpuTemp(): Promise<number | null> {
  const paths = [
    '/sys/class/thermal/thermal_zone0/temp',
    '/sys/class/hwmon/hwmon0/temp1_input',
    '/sys/devices/virtual/thermal/thermal_zone0/temp',
  ]
  for (const p of paths) {
    try {
      const raw = (await fsp.readFile(p, 'utf8')).trim()
      const v = Number(raw)
      if (Number.isFinite(v) && v > 0) return Math.round(v > 1000 ? v / 1000 : v)
    } catch {
      /* thử vị trí kế */
    }
  }
  return null
}

async function memSnapshot(): Promise<ResourceSnapshot['mem']> {
  try {
    const txt = await fsp.readFile('/proc/meminfo', 'utf8')
    const get = (k: string) => Number((txt.match(new RegExp(`${k}:\\s+(\\d+)`)) || [])[1] || 0) * 1024
    const total = get('MemTotal')
    const available = get('MemAvailable')
    const swapTotal = get('SwapTotal')
    const swapFree = get('SwapFree')
    return {
      total,
      used: total - available,
      available,
      percent: total ? Math.round(((total - available) / total) * 100) : 0,
      swapTotal,
      swapUsed: swapTotal - swapFree,
    }
  } catch {
    const total = os.totalmem()
    const free = os.freemem()
    return {
      total,
      used: total - free,
      available: free,
      percent: total ? Math.round(((total - free) / total) * 100) : 0,
      swapTotal: 0,
      swapUsed: 0,
    }
  }
}

/** Ảnh chụp tài nguyên đầy đủ — client poll mỗi 2s (Activity Monitor / MenuBar) */
export async function resourceSnapshot(): Promise<ResourceSnapshot> {
  const [cpu, mem, disk, net, temp, uptime] = await Promise.all([
    cpuSnapshot(),
    memSnapshot(),
    diskInfo(),
    netSnapshot(),
    cpuTemp(),
    Promise.resolve(os.uptime()),
  ])
  return {
    ts: Date.now(),
    cpu: { percent: cpu.overall, perCore: cpu.perCore, cores: Math.max(1, os.cpus().length) },
    mem,
    disk,
    load: os.loadavg() as [number, number, number],
    uptime,
    temp,
    net,
  }
}

// ==== Tiến trình: /proc/<pid> ====
export interface ProcInfo {
  pid: number
  name: string
  cmd: string
  user: string
  cpu: number
  rss: number // bytes
  state: string
}

/** Cache uid → username (đọc /etc/passwd 1 lần) */
let passwdCache: Map<number, string> | null = null
async function userMap(): Promise<Map<number, string>> {
  if (passwdCache) return passwdCache
  const map = new Map<number, string>()
  try {
    const txt = await fsp.readFile('/etc/passwd', 'utf8')
    for (const line of txt.split('\n')) {
      const cols = line.split(':')
      if (cols.length >= 3) {
        const uid = Number(cols[2])
        if (Number.isFinite(uid)) map.set(uid, cols[0])
      }
    }
  } catch {
    /* bỏ qua */
  }
  passwdCache = map
  return map
}

/** Cache delta CPU per-pid: utime+stime (tick = 100Hz trên Linux) */
let procCpuPrev: Map<number, { ticks: number; ts: number }> | null = null
const CLOCK_HZ = 100

export async function listProcesses(limit = 120): Promise<ProcInfo[]> {
  try {
    const entries = await fsp.readdir('/proc')
    const pids = entries.filter((e) => /^\d+$/.test(e)).map(Number)
    const now = Date.now()
    const curTicks = new Map<number, number>()
    const out: ProcInfo[] = []
    const users = await userMap()
    const me = process.pid

    await Promise.all(
      pids.map(async (pid) => {
        try {
          const statTxt = await fsp.readFile(`/proc/${pid}/stat`, 'utf8')
          // comm nằm trong (…) — có thể chứa dấu cách: tách từ dấu ) cuối
          const closeIdx = statTxt.lastIndexOf(')')
          const name = statTxt.slice(statTxt.indexOf('(') + 1, closeIdx)
          const fields = statTxt.slice(closeIdx + 2).split(' ')
          const state = fields[0] || '?'
          const utime = Number(fields[11]) || 0
          const stime = Number(fields[12]) || 0
          curTicks.set(pid, utime + stime)
          let cmd = ''
          try {
            cmd = (await fsp.readFile(`/proc/${pid}/cmdline`, 'utf8')).replace(/\0/g, ' ').trim()
          } catch {
            /* kernel thread */
          }
          let rss = 0
          try {
            const status = await fsp.readFile(`/proc/${pid}/status`, 'utf8')
            const m = status.match(/VmRSS:\s+(\d+) kB/)
            if (m) rss = Number(m[1]) * 1024
          } catch {
            /* bỏ qua */
          }
          let user = ''
          try {
            const status = await fsp.readFile(`/proc/${pid}/status`, 'utf8')
            const um = status.match(/Uid:\s+(\d+)/)
            if (um) user = users.get(Number(um[1])) || String(um[1])
          } catch {
            /* bỏ qua */
          }
          out.push({ pid, name, cmd, user, cpu: 0, rss, state })
        } catch {
          /* tiến trình biến mất giữa chừng — bỏ */
        }
        void me
      })
    )

    // CPU% delta
    let procCpu: Map<number, { ticks: number; ts: number }>
    if (procCpuPrev && now - [...procCpuPrev.values()][0]?.ts < 60000) {
      const dt = (now - [...procCpuPrev.values()][0].ts) / 1000
      for (const p of out) {
        const prev = procCpuPrev.get(p.pid)
        if (prev && dt > 0) {
          p.cpu = Math.max(0, Math.round(((curTicks.get(p.pid) || 0) - prev.ticks) / (dt * CLOCK_HZ) * 100))
        }
      }
      procCpu = new Map([...curTicks].map(([pid, ticks]) => [pid, { ticks, ts: now }]))
    } else {
      procCpu = new Map([...curTicks].map(([pid, ticks]) => [pid, { ticks, ts: now }]))
    }
    procCpuPrev = procCpu

    out.sort((a, b) => b.cpu - a.cpu || b.rss - a.rss)
    return out.slice(0, limit)
  } catch {
    return []
  }
}

/** Thông tin tĩnh về máy — dùng cho /api/system/info */
export async function systemInfo(): Promise<Record<string, unknown>> {
  let boardModel = ''
  try {
    boardModel = (await fsp.readFile('/proc/device-tree/model', 'utf8')).replace(/\0/g, '').trim()
  } catch {
    /* không phải ARM board */
  }
  const cpus = os.cpus()
  const [temp, disk, uptime] = await Promise.all([cpuTemp(), diskInfo(), uptimeInfo()])
  return {
    hostname: os.hostname(),
    platform: os.platform(),
    arch: os.arch(),
    kernel: os.release(),
    boardModel: boardModel || null,
    cpuModel: cpus[0]?.model || 'Unknown CPU',
    cores: cpus.length,
    memTotal: os.totalmem(),
    disk,
    temp,
    uptime,
    nodeVersion: process.version,
    uptimeHuman: uptime.human,
    wosVersion: '3.0.0',
  }
}
