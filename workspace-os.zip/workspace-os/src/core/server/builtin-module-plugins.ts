/**
 * BUILTIN MODULE PLUGINS (fix lỗi 7) — đóng gói 7 module thành PLUGIN CÀI SẴN.
 *
 * Trình duyệt (browser), Documents (doc), Tasks, Công Việc Tuần (weekly),
 * Calendar, Notes, Wiki giờ xuất hiện trong Settings → Plugins như plugin
 * builtin: bật/tắt được bằng một công cụ duy nhất, có version/author/metadata
 * riêng — nhưng VẪN GIỮ nguyên toàn bộ trang React của module (không viết lại
 * UI thành chuỗi JS — tránh mất tính năng + risk).
 *
 * Cơ chế "module-ref":
 *   - Plugin row: entry = "module://<moduleId>" (marker, KHÔNG phải mã JS)
 *   - app-registry.syncPluginApps(): gặp marker → KHÔNG chạy plugin-runtime,
 *     PAGES[slug] giữ nguyên import tĩnh của module + đăng ký window size.
 *   - Bật/tắt plugin → đồng bộ ModuleState.enabled của module tương ứng
 *     (hai hệ thống luôn song song, không lệch nhau).
 */
import { db } from '@/lib/db'

/** Định nghĩa plugin hóa cho 7 module (metadata khớp module-registry) */
export interface ModulePluginDef {
  slug: string // = moduleId (PAGES key)
  moduleId: string
  name: string
  description: string
  version: string
  author: string
  icon: string // emoji (plugin icon format)
  color: string
  desktopIcon: boolean
  showDock: boolean
  windowW: number
  windowH: number
  order: number
}

export const MODULE_PLUGIN_DEFS: ModulePluginDef[] = [
  {
    slug: 'browser',
    moduleId: 'browser',
    name: 'Trình duyệt',
    description: 'Web Browser — duyệt internet trong cửa sổ WOS, tab, thanh địa chỉ, ứng dụng web',
    version: '1.0.0',
    author: 'WOS Team',
    icon: '🌐',
    color: '#0ea5e9',
    desktopIcon: true,
    showDock: true,
    windowW: 1100,
    windowH: 720,
    order: 14,
  },
  {
    slug: 'doc',
    moduleId: 'doc',
    name: 'Documents',
    description: 'Document Engine — xem PDF, DOCX, XLSX, PPTX ngay trên desktop',
    version: '1.0.0',
    author: 'WOS Team',
    icon: '📄',
    color: '#ef4444',
    desktopIcon: true,
    showDock: false,
    windowW: 1200,
    windowH: 800,
    order: 18,
  },
  {
    slug: 'tasks',
    moduleId: 'tasks',
    name: 'Tasks',
    description: 'Công việc: List, Kanban, Timeline, Archive',
    version: '1.0.0',
    author: 'WOS Team',
    icon: '✅',
    color: '#f59e0b',
    desktopIcon: true,
    showDock: true,
    windowW: 1080,
    windowH: 720,
    order: 20,
  },
  {
    slug: 'weekly',
    moduleId: 'weekly',
    name: 'Công Việc Tuần',
    description: 'Lên công việc hàng tuần theo Quy trình: bước, lot, điều kiện, tick hoàn thành',
    version: '1.0.0',
    author: 'WOS Team',
    icon: '📋',
    color: '#3b82f6',
    desktopIcon: true,
    showDock: true,
    windowW: 1120,
    windowH: 760,
    order: 25,
  },
  {
    slug: 'calendar',
    moduleId: 'calendar',
    name: 'Calendar',
    description: 'Lịch Day/Week/Month/Year, sự kiện lặp lại',
    version: '1.0.0',
    author: 'WOS Team',
    icon: '📅',
    color: '#10b981',
    desktopIcon: true,
    showDock: true,
    windowW: 1080,
    windowH: 720,
    order: 30,
  },
  {
    slug: 'notes',
    moduleId: 'notes',
    name: 'Notes',
    description: 'Ghi chú Markdown, checklist, code block',
    version: '1.0.0',
    author: 'WOS Team',
    icon: '📝',
    color: '#eab308',
    desktopIcon: true,
    showDock: true,
    windowW: 940,
    windowH: 640,
    order: 40,
  },
  {
    slug: 'wiki',
    moduleId: 'wiki',
    name: 'Wiki',
    description: 'Tri thức: thư mục, trang lồng nhau, phiên bản',
    version: '1.0.0',
    author: 'WOS Team',
    icon: '📚',
    color: '#84cc16',
    desktopIcon: true,
    showDock: true,
    windowW: 1200,
    windowH: 780,
    order: 50,
  },
]

/** Nhận diện entry marker của module-plugin */
export function isModuleRefEntry(entry: string): boolean {
  return /^module:\/\/[a-z0-9-]+$/i.test((entry || '').trim())
}

/** ModuleId từ entry marker */
export function moduleRefId(entry: string): string | null {
  const m = /^module:\/\/([a-z0-9-]+)$/i.exec((entry || '').trim())
  return m ? m[1] : null
}

/** Bật/tắt module-plugin → đồng bộ ModuleState của module (giữ 2 hệ không lệch) */
export async function syncModuleStateForPlugin(slug: string, enabled: boolean): Promise<void> {
  const def = MODULE_PLUGIN_DEFS.find((d) => d.slug === slug)
  if (!def) return
  try {
    const existing = await db.moduleState.findUnique({ where: { moduleId: def.moduleId } })
    if (existing) {
      await db.moduleState.update({ where: { moduleId: def.moduleId }, data: { enabled } })
    } else {
      await db.moduleState.create({ data: { moduleId: def.moduleId, enabled } })
    }
  } catch (err) {
    console.error('[module-plugins] sync ModuleState lỗi:', err)
  }
}

/**
 * Idempotent: đăng ký 7 module-plugin vào bảng Plugin (builtin: true).
 * - enabled mặc định: theo ModuleState hiện có (nếu admin từng tắt module) → false
 * - nâng cấp: refresh metadata + version, GIỮ enabled/config người dùng
 */
export async function ensureModulePlugins(): Promise<void> {
  for (const def of MODULE_PLUGIN_DEFS) {
    const entry = `module://${def.moduleId}`
    const existing = await db.plugin.findUnique({ where: { slug: def.slug } })
    // trạng thái module hiện tại quyết định enabled lần đầu cài
    let initialEnabled = true
    if (!existing) {
      const state = await db.moduleState.findUnique({ where: { moduleId: def.moduleId } })
      if (state) initialEnabled = state.enabled
    }
    if (!existing) {
      await db.plugin.create({
        data: {
          slug: def.slug,
          name: def.name,
          description: def.description,
          version: def.version,
          author: def.author,
          icon: def.icon,
          color: def.color,
          kind: 'app',
          entry,
          config: '{}',
          enabled: initialEnabled,
          builtin: true,
          desktopIcon: def.desktopIcon,
          showDock: def.showDock,
          windowW: def.windowW,
          windowH: def.windowH,
          order: def.order,
        },
      })
      continue
    }
    // đã có (nâng cấp hệ thống): refresh metadata, giữ enabled/config người dùng
    const needsUpdate =
      existing.builtin &&
      (existing.entry !== entry ||
        existing.name !== def.name ||
        existing.description !== def.description ||
        existing.icon !== def.icon ||
        existing.color !== def.color ||
        existing.windowW !== def.windowW ||
        existing.windowH !== def.windowH)
    if (needsUpdate) {
      await db.plugin.update({
        where: { slug: def.slug },
        data: {
          name: def.name,
          description: def.description,
          icon: def.icon,
          color: def.color,
          entry,
          desktopIcon: def.desktopIcon,
          windowW: def.windowW,
          windowH: def.windowH,
        },
      })
    }
  }
}
