/**
 * Builtin Plugins — 2 plugin dựng sẵn của WOS, tự cài lần đầu GET /api/core/plugins.
 * Đây cũng là MẪU THAM CHIẾU cho developer bên ngoài viết plugin (xem docs/plugin-development.md).
 *
 * Format plugin (module-registry kiểu "cài như cài phần mềm"):
 * - entry = chuỗi JS chạy phía CLIENT qua WOS Plugin Runtime (new Function, strict mode)
 * - Runtime tiêm biến `WOS` gồm: h (React.createElement), Fragment, useState, useEffect,
 *   useRef, useMemo, useCallback, api, bus, toast, openApp, notify, emitEvent, clearCache,
 *   storage {get,set}, css (inject <style>), assetUrl, registerApp, registerPet,
 *   plugin {slug, config}
 * - Plugin KHÔNG dùng JSX (không compile lúc runtime) — dùng h('div', {...}, children).
 * - Từ v5: plugin ngoài cài qua .zip (plugin.json + main.js + assets) hoặc JSON 1 file.
 *
 * v5.1:
 * - Máy tính: chỉ nhận bàn phím khi CỬA SỔ MÁY TÍNH đang focus (chuẩn PC/macOS —
 *   gõ số trong Note/ô nhập khác không còn bị máy tính "giật" phím)
 * - Nyanko v3: nhân vật MÈO anime — bong bóng SUY NGHĨ kiểu truyện tranh hiển thị
 *   thông báo chưa đọc (≥ 23 ký tự), đuổi bướm, đi lang thang không bao giờ đứng im
 *   (watchdog chống đơ), né/nhảy lên icon, phản ứng theo chuột.
 */
import { db } from '@/lib/db'

// =====================================================================
// PLUGIN 1: Máy tính — GIAO DIỆN CHUẨN macOS (v2.1.0):
// - Kín cả cửa sổ (full-bleed, không còn vùng trắng thừa)
// - Màn hình kết quả + dòng phép tính nhỏ; bàn phím 4 cột × 5 hàng
// - Màu chuẩn: chữ số xám đậm, hàng chức năng xám nhạt hơn, phép tính cam;
//   phím đang chọn (operator) đảo màu trắng nền - cam chữ như macOS
// - Tự đổi sáng/tối theo theme hệ thống
// - BÀN PHÍM: chỉ hoạt động khi cửa sổ máy tính đang là cửa sổ FOCUS
//   (click vào app nào thì app đó nhận phím — như PC thật)
// =====================================================================
const CALCULATOR_ENTRY = String.raw`
// ===== WOS Plugin: Máy tính cầm tay (chuẩn macOS) =====
var h = WOS.h, useState = WOS.useState, useEffect = WOS.useEffect, useCallback = WOS.useCallback, useRef = WOS.useRef

WOS.css([
  '.wos-calc{display:flex;flex-direction:column;height:100%;width:100%;background:oklch(0.25 0.004 260);font-family:-apple-system,"SF Pro Display","Segoe UI","Helvetica Neue",sans-serif;user-select:none;overflow:hidden;-webkit-font-smoothing:antialiased}',
  '.wos-calc.light{background:oklch(0.965 0.002 260)}',
  '.wos-calc-display{flex:0 0 76px;display:flex;flex-direction:column;justify-content:flex-end;align-items:flex-end;padding:0 18px 10px;min-height:0;overflow:hidden}',
  '.wos-calc-expr{font-size:13px;font-weight:400;color:oklch(0.68 0 0);height:16px;line-height:16px;max-width:100%;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;font-variant-numeric:tabular-nums}',
  '.wos-calc.light .wos-calc-expr{color:oklch(0.52 0 0)}',
  '.wos-calc-main{font-size:46px;font-weight:200;color:oklch(0.97 0 0);line-height:1.04;max-width:100%;overflow:hidden;white-space:nowrap;font-variant-numeric:tabular-nums;letter-spacing:0.5px}',
  '.wos-calc.light .wos-calc-main{color:oklch(0.18 0 0)}',
  '.wos-calc-pad{flex:1;display:grid;grid-template-columns:repeat(4,1fr);grid-template-rows:repeat(5,1fr);gap:1px;padding:1px;background:oklch(1 0 0 / 14%);min-height:0}',
  '.wos-calc.light .wos-calc-pad{background:oklch(0 0 0 / 10%)}',
  '.wos-calc-btn{border:0;margin:0;font-size:20px;font-weight:400;font-family:inherit;background:oklch(0.41 0.004 260);color:oklch(0.97 0 0);cursor:pointer;display:flex;align-items:center;justify-content:center;min-width:0;min-height:0;padding:0;transition:filter .06s;outline:none;-webkit-tap-highlight-color:transparent}',
  '.wos-calc.light .wos-calc-btn{background:oklch(0.99 0 0);color:oklch(0.2 0 0);box-shadow:inset 0 0 0 1px oklch(0 0 0 / 4%)}',
  '.wos-calc-btn:hover{filter:brightness(1.22)}',
  '.wos-calc.light .wos-calc-btn:hover{filter:brightness(0.96)}',
  '.wos-calc-btn:active{filter:brightness(0.82)}',
  '.wos-calc-btn.fn{background:oklch(0.52 0.004 260);font-size:17px}',
  '.wos-calc.light .wos-calc-btn.fn{background:oklch(0.9 0.002 260);color:oklch(0.3 0 0)}',
  '.wos-calc-btn.op{background:oklch(0.7 0.17 55);color:white;font-size:23px}',
  '.wos-calc.light .wos-calc-btn.op{background:oklch(0.78 0.16 60);color:white}',
  '.wos-calc-btn.op.active{background:oklch(0.98 0 0);color:oklch(0.7 0.17 55)}',
  '.wos-calc.light .wos-calc-btn.op.active{background:oklch(0.55 0.15 55);color:white}',
  '.wos-calc-btn.zero{grid-column:span 2;justify-content:flex-start;padding-left:26%}'
].join('\n'))

function fmt(n) {
  if (n === Infinity || n === -Infinity || Number.isNaN(n)) return 'Lỗi'
  if (!isFinite(n)) return 'Lỗi'
  var s = String(Math.round(n * 1e10) / 1e10)
  if (s.length > 11) {
    return n.toExponential(6).replace(/e([+-])(\d)$/, 'e$10$2')
  }
  return s
}

function compute(a, b, op) {
  if (op === '+') return a + b
  if (op === '−') return a - b
  if (op === '×') return a * b
  if (op === '÷') return b === 0 ? NaN : a / b
  return b
}

function Calculator() {
  var st = useState({ disp: '0', acc: null, op: null, fresh: true, hist: '' })
  var disp = st[0], setDisp = st[1]
  var themeSt = useState(true)
  var dark = themeSt[0], setDark = themeSt[1]
  var rootRef = useRef(null)

  // theo dõi theme hệ thống (next-themes gắn class 'dark' trên <html>)
  useEffect(function () {
    function read() { setDark(document.documentElement.classList.contains('dark')) }
    read()
    var mo = new MutationObserver(read)
    mo.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] })
    return function () { mo.disconnect() }
  }, [])

  var press = useCallback(function (k) {
    setDisp(function (s) {
      if (k >= '0' && k <= '9') {
        if (s.fresh || s.disp === '0') return { disp: k, acc: s.acc, op: s.op, fresh: false, hist: s.hist }
        return { disp: (s.disp + k).slice(0, 13), acc: s.acc, op: s.op, fresh: false, hist: s.hist }
      }
      if (k === '.') {
        if (s.fresh) return { disp: '0.', acc: s.acc, op: s.op, fresh: false, hist: s.hist }
        if (s.disp.indexOf('.') < 0) return { disp: s.disp + '.', acc: s.acc, op: s.op, fresh: false, hist: s.hist }
        return s
      }
      if (k === 'AC') return { disp: '0', acc: null, op: null, fresh: true, hist: '' }
      if (k === '±') return { disp: s.disp === '0' ? s.disp : (s.disp[0] === '-' ? s.disp.slice(1) : '-' + s.disp), acc: s.acc, op: s.op, fresh: s.fresh, hist: s.hist }
      if (k === '%') return { disp: fmt(parseFloat(s.disp) / 100), acc: s.acc, op: s.op, fresh: false, hist: s.hist }
      if (k === '+' || k === '−' || k === '×' || k === '÷') {
        var cur = parseFloat(s.disp)
        var acc = s.acc
        if (s.op !== null && !s.fresh) { acc = compute(s.acc, cur, s.op) } else if (s.fresh && s.acc !== null && s.op) { acc = s.acc }
        else { acc = cur }
        return { disp: fmt(acc), acc: acc, op: k, fresh: true, hist: fmt(acc) + ' ' + k }
      }
      if (k === '=') {
        if (s.op === null || s.acc === null) return s
        var cur2 = s.fresh ? s.acc : parseFloat(s.disp)
        var res = compute(s.acc, cur2, s.op)
        return { disp: fmt(res), acc: null, op: null, fresh: true, hist: fmt(s.acc) + ' ' + s.op + ' ' + fmt(cur2) + ' =' }
      }
      return s
    })
  }, [setDisp])

  // BÀN PHÍM: chuẩn PC — chỉ cửa sổ máy tính ĐANG FOCUS mới nhận phím.
  // Người dùng click vào app khác (vd Notes) → cửa sổ đó focus → máy tính bỏ qua
  // toàn bộ phím, KHÔNG preventDefault → app kia nhận văn bản bình thường.
  useEffect(function () {
    function onKey (e) {
      var root = rootRef.current
      if (!root) return
      var win = root.closest ? root.closest('.wos-window') : null
      if (!win || !win.classList.contains('wos-window-focused')) return
      // phòng hờ: focus đang nằm trong ô nhập của cửa sổ khác → bỏ qua hẳn
      var t = e.target
      if (t && t.closest && t.closest('input, textarea, select, [contenteditable="true"]') && !root.contains(t)) return
      var k = e.key
      var map = { '+': '+', '-': '−', '*': '×', '/': '÷', 'Enter': '=', '=': '=', '.': '.', '%': '%', 'Escape': 'AC', 'Backspace': 'AC' }
      if (k >= '0' && k <= '9') { press(k); e.preventDefault() }
      else if (map[k]) { press(map[k]); e.preventDefault() }
    }
    window.addEventListener('keydown', onKey)
    return function () { window.removeEventListener('keydown', onKey) }
  }, [press])

  var activeOp = null
  ;['+', '−', '×', '÷'].forEach(function (o) { if (disp.op === o && disp.fresh) activeOp = o })

  var BTN = function (label, cls, key, Span) {
    return h('button', { className: cls, onClick: function () { press(key) }, 'aria-label': 'Phím ' + label }, label)
  }

  return h('div', { ref: rootRef, className: 'wos-calc' + (dark ? '' : ' light'), 'aria-label': 'Máy tính' },
    h('div', { className: 'wos-calc-display' },
      h('div', { className: 'wos-calc-expr' }, disp.hist),
      h('div', { className: 'wos-calc-main', role: 'status' }, disp.disp)
    ),
    h('div', { className: 'wos-calc-pad', role: 'group', 'aria-label': 'Bàn phím máy tính' },
      BTN('AC', 'wos-calc-btn fn', 'AC'),
      BTN('±', 'wos-calc-btn fn', '±'),
      BTN('%', 'wos-calc-btn fn', '%'),
      BTN('÷', 'wos-calc-btn op' + (activeOp === '÷' ? ' active' : ''), '÷'),
      BTN('7', 'wos-calc-btn', '7'), BTN('8', 'wos-calc-btn', '8'), BTN('9', 'wos-calc-btn', '9'),
      BTN('×', 'wos-calc-btn op' + (activeOp === '×' ? ' active' : ''), '×'),
      BTN('4', 'wos-calc-btn', '4'), BTN('5', 'wos-calc-btn', '5'), BTN('6', 'wos-calc-btn', '6'),
      BTN('−', 'wos-calc-btn op' + (activeOp === '−' ? ' active' : ''), '−'),
      BTN('1', 'wos-calc-btn', '1'), BTN('2', 'wos-calc-btn', '2'), BTN('3', 'wos-calc-btn', '3'),
      BTN('+', 'wos-calc-btn op' + (activeOp === '+' ? ' active' : ''), '+'),
      BTN('0', 'wos-calc-btn zero', '0'),
      BTN('.', 'wos-calc-btn', '.'),
      BTN('=', 'wos-calc-btn op', '=')
    )
  )
}

WOS.registerApp({ component: Calculator, windowSize: { w: 250, h: 374 } })
`

// =====================================================================
// PLUGIN 2: Nyanko v3 — CHÚ MÈO ANIME đồng hành desktop:
// - Mèo chibi cream-cam: tai cụp trong, mắt anime to, má hồng, cổ.collar chuông vàng
// - BONG BÓNG SUY NGHĨ kiểu truyện tranh (cloud + 3 bóng nhỏ dẫn xuống đầu):
//   hiện THÔNG BÁO CHƯA ĐỌC của hệ thống (rộng 238px ≥ 23 ký tự, tối đa 4 dòng)
// - DI CHUYỂN "đi lung tung" thật sự: watchdog chống đứng im (bug cũ), suy nghĩ
//   nhanh 0.5-1.1s, sprint, đổi ý giữa đường, đuổi BƯỚM (bạn bay kèm theo),
//   nhảy lên ngồi icon desktop, né con trỏ chuột, kéo-thả, gõ nhẹ → nghĩ "Meow~"
// =====================================================================
const ANIME_CAT_ENTRY = String.raw`
// ===== WOS Plugin: Nyanko — chú mèo anime desktop companion (v3) =====
var h = WOS.h, useState = WOS.useState, useEffect = WOS.useEffect, useRef = WOS.useRef

WOS.css([
  '.wos-cat-root{position:fixed;left:0;top:0;width:0;height:0;z-index:3;pointer-events:none}',
  '.wos-cat{position:absolute;width:96px;height:88px;pointer-events:auto;cursor:grab;filter:drop-shadow(0 6px 10px rgba(0,0,0,.26));will-change:transform}',
  '.wos-cat *{transform-box:fill-box}',
  '.wos-cat .wos-cat-inner{position:relative;width:100%;height:100%;transform-origin:50% 100%}',
  '.wos-cat.flip .wos-cat-inner{transform:scaleX(-1)}',
  '.wos-cat.grabbing{cursor:grabbing}',
  '.wos-cat-emote{position:absolute;right:-4px;top:-24px;font-size:17px;animation:catEmote 1.5s ease forwards;z-index:2;filter:drop-shadow(0 1px 2px rgba(0,0,0,.3))}',
  '@keyframes catEmote{0%{opacity:0;transform:translateY(8px) scale(.5)}25%{opacity:1;transform:translateY(-2px) scale(1.15)}70%{opacity:1;transform:translateY(-8px) scale(1)}100%{opacity:0;transform:translateY(-16px) scale(.9)}}',
  // đuôi ve vẩy
  '.wos-cat .wos-cat-tail{transform-origin:92% 30%}',
  '.wos-cat.walk .wos-cat-tail{animation:catTailW .34s ease-in-out infinite alternate}',
  '.wos-cat.idle .wos-cat-tail{animation:catTailS 1.7s ease-in-out infinite alternate}',
  '.wos-cat.sit .wos-cat-tail{animation:catTailS 2.1s ease-in-out infinite alternate}',
  '@keyframes catTailW{from{transform:rotate(9deg)}to{transform:rotate(-15deg)}}',
  '@keyframes catTailS{from{transform:rotate(4deg)}to{transform:rotate(-9deg)}}',
  // chân bước
  '.wos-cat .wos-cat-leg-a{transform-origin:50% 6%}',
  '.wos-cat .wos-cat-leg-b{transform-origin:50% 6%}',
  '.wos-cat.walk .wos-cat-leg-a{animation:catLegA .24s ease-in-out infinite alternate}',
  '.wos-cat.walk .wos-cat-leg-b{animation:catLegB .24s ease-in-out infinite alternate}',
  '.wos-cat.idle .wos-cat-leg-a,.wos-cat.idle .wos-cat-leg-b{animation:none;transform:rotate(0)}',
  '.wos-cat.sit .wos-cat-legs{display:none}',
  '@keyframes catLegA{from{transform:rotate(17deg)}to{transform:rotate(-17deg)}}',
  '@keyframes catLegB{from{transform:rotate(-17deg)}to{transform:rotate(17deg)}}',
  // đầu nhún + tai giật
  '.wos-cat .wos-cat-head{transform-origin:50% 92%}',
  '.wos-cat.walk .wos-cat-head{animation:catBob .3s ease-in-out infinite alternate}',
  '.wos-cat.idle .wos-cat-head{animation:catBob 2.6s ease-in-out infinite alternate}',
  '.wos-cat .wos-cat-ear-r{transform-origin:20% 90%}',
  '.wos-cat.idle .wos-cat-ear-r{animation:catEar 5.2s ease-in-out infinite}',
  '@keyframes catBob{from{transform:translateY(0) rotate(.5deg)}to{transform:translateY(-2px) rotate(-.7deg)}}',
  '@keyframes catEar{0%,88%,100%{transform:rotate(0)}91%{transform:rotate(-13deg)}94%{transform:rotate(4deg)}97%{transform:rotate(-9deg)}}',
  // mắt blink (sit → mắt híp hưởng thụ)
  '.wos-cat .wos-cat-eyes{animation:catBlink 4.8s infinite}',
  '.wos-cat.sit .wos-cat-eyes{animation:none;transform:scaleY(.26)}',
  '@keyframes catBlink{0%,93.5%,100%{transform:scaleY(1)}95.5%,97.5%{transform:scaleY(.07)}}',
  // giật mình khi chuột áp sát
  '.wos-cat.startled .wos-cat-inner{animation:catStartle .5s ease-out 1}',
  '@keyframes catStartle{0%{transform:rotate(0)}30%{transform:rotate(-6deg)}100%{transform:rotate(0)}}',
  // ===== BONG BÓNG SUY NGHĨ kiểu truyện tranh =====
  '.wos-cat-bubble{position:absolute;bottom:calc(100% + 18px);left:50%;width:238px;transform:translateX(-52%);z-index:4;animation:catBubbleIn .38s cubic-bezier(.2,1.4,.4,1) both;pointer-events:none}',
  '.wos-cat-bubble-body{position:relative;background:#fffdf8;border:2.5px solid #3b3f4d;border-radius:46% 54% 50% 48% / 54% 46% 57% 43%;padding:13px 17px 12px;box-shadow:0 6px 18px rgba(0,0,0,.18), inset 0 -4px 10px rgba(120,90,20,.06)}',
  '.wos-cat-bubble-title{font-weight:700;font-size:11px;letter-spacing:.4px;color:#b3541e;margin-bottom:3px;text-transform:uppercase;display:flex;align-items:center;gap:4px}',
  '.wos-cat-bubble-text{font-size:12.5px;line-height:1.45;color:#2a2f3c;font-weight:500;display:-webkit-box;-webkit-line-clamp:4;-webkit-box-orient:vertical;overflow:hidden;word-break:break-word}',
  '.wos-cat-bubble-tail{position:absolute;background:#fffdf8;border:2.5px solid #3b3f4d;border-radius:50%}',
  '.wos-cat-bubble-tail.t1{bottom:-10px;left:24%;width:12px;height:12px}',
  '.wos-cat-bubble-tail.t2{bottom:-21px;left:14%;width:8px;height:8px}',
  '.wos-cat-bubble-tail.t3{bottom:-29px;left:7%;width:5px;height:5px}',
  '.wos-cat-bubble.out{animation:catBubbleOut .3s ease-in both}',
  '@keyframes catBubbleIn{0%{opacity:0;transform:translateX(-52%) translateY(10px) scale(.6)}100%{opacity:1;transform:translateX(-52%) translateY(0) scale(1)}}',
  '@keyframes catBubbleOut{0%{opacity:1;transform:translateX(-52%) scale(1)}100%{opacity:0;transform:translateX(-52%) translateY(8px) scale(.7)}}',
  // ===== BƯỚM bạn đồng hành =====
  '.wos-bfly{position:absolute;width:22px;height:18px;pointer-events:none;filter:drop-shadow(0 2px 3px rgba(0,0,0,.18));will-change:transform}',
  '.wos-bfly .wos-bfly-wing-l{transform-origin:100% 50%}',
  '.wos-bfly .wos-bfly-wing-r{transform-origin:0% 50%}',
  '.wos-bfly .wos-bfly-wing-l{animation:bflyL .17s ease-in-out infinite alternate}',
  '.wos-bfly .wos-bfly-wing-r{animation:bflyR .17s ease-in-out infinite alternate}',
  '@keyframes bflyL{from{transform:scaleX(1)}to{transform:scaleX(.35)}}',
  '@keyframes bflyR{from{transform:scaleX(.35)}to{transform:scaleX(1)}}',
  '.wos-bfly .wos-bfly-bob{animation:bflyBob 1.1s ease-in-out infinite alternate}',
  '@keyframes bflyBob{from{transform:translateY(0)}to{transform:translateY(-3px)}}'
].join('\n'))

// --- SVG chú mèo chibi anime (đi 4 chân, nhìn ngang) ---
function CatSvg(h) {
  var CREAM = '#f8ead2', CREAM_D = '#edd9b8', GINGER = '#f2a65a', GINGER_D = '#e08840',
      PINK = '#f9a8c9', PINK_D = '#ec7fae', EYE = '#3f8f5c', EYE_D = '#2c6b45', DARK = '#4a3f35'
  return h('svg', { viewBox: '0 0 120 96', width: '96', height: '88', 'aria-hidden': 'true' },
    // bóng đổ
    h('ellipse', { cx: 60, cy: 90, rx: 30, ry: 5, fill: 'rgba(0,0,0,0.17)' }),
    // đuôi (vằn cam ở chóp)
    h('g', { className: 'wos-cat-tail' },
      h('path', { d: 'M92 66 Q 116 58 112 36 Q 110 24 100 22', stroke: CREAM, strokeWidth: 11, fill: 'none', strokeLinecap: 'round' }),
      h('path', { d: 'M108 33 Q 106 24 100 22', stroke: GINGER, strokeWidth: 11, fill: 'none', strokeLinecap: 'round' }),
      h('path', { d: 'M112 44 Q 113 32 103 25', stroke: GINGER_D, strokeWidth: 4, fill: 'none', strokeLinecap: 'round', opacity: '.65' })
    ),
    // chân sau + trước (2 cặp, xoay ngược pha khi đi)
    h('g', { className: 'wos-cat-legs' },
      h('g', { className: 'wos-cat-leg-a' },
        h('rect', { x: 38, y: 70, width: 10, height: 19, rx: 4.5, fill: CREAM_D })
      ),
      h('g', { className: 'wos-cat-leg-b' },
        h('rect', { x: 74, y: 70, width: 10, height: 19, rx: 4.5, fill: CREAM_D })
      ),
      h('g', { className: 'wos-cat-leg-b' },
        h('rect', { x: 50, y: 71, width: 9, height: 18, rx: 4.5, fill: CREAM })
      ),
      h('g', { className: 'wos-cat-leg-a' },
        h('rect', { x: 63, y: 71, width: 9, height: 18, rx: 4.5, fill: CREAM })
      )
    ),
    // thân + bụng + đốm cam
    h('ellipse', { cx: 62, cy: 62, rx: 31, ry: 21, fill: CREAM }),
    h('ellipse', { cx: 66, cy: 67, rx: 18, ry: 12, fill: '#fff8ea' }),
    h('path', { d: 'M74 44 Q 88 48 90 62 Q 80 58 74 52 Z', fill: GINGER, opacity: '.9' }),
    h('path', { d: 'M50 46 Q 42 52 44 62 Q 50 57 53 50 Z', fill: GINGER, opacity: '.75' }),
    // đầu to chibi
    h('g', { className: 'wos-cat-head' },
      // tai trái
      h('path', { d: 'M36 26 L 30 4 L 52 14 Z', fill: CREAM, stroke: CREAM, strokeWidth: 2, strokeLinejoin: 'round' }),
      h('path', { d: 'M38 22 L 34.5 10 L 46 15.5 Z', fill: PINK }),
      // tai phải (giật tai)
      h('g', { className: 'wos-cat-ear-r' },
        h('path', { d: 'M66 12 L 84 2 L 80 26 Z', fill: CREAM, stroke: CREAM, strokeWidth: 2, strokeLinejoin: 'round' }),
        h('path', { d: 'M69.5 13.5 L 79.5 6.5 L 77 21 Z', fill: PINK })
      ),
      // mặt
      h('circle', { cx: 57, cy: 34, r: 24.5, fill: CREAM }),
      // vằn trán
      h('path', { d: 'M53 12.5 L 55 20', stroke: GINGER, strokeWidth: 3, strokeLinecap: 'round' }),
      h('path', { d: 'M60 11.5 L 61 19.5', stroke: GINGER, strokeWidth: 3, strokeLinecap: 'round' }),
      // mắt anime to
      h('g', { className: 'wos-cat-eyes' },
        h('ellipse', { cx: 48, cy: 35, rx: 5.4, ry: 7.4, fill: EYE }),
        h('ellipse', { cx: 67, cy: 35, rx: 5.4, ry: 7.4, fill: EYE }),
        h('circle', { cx: 46, cy: 32.5, r: 1.9, fill: '#fff' }),
        h('circle', { cx: 65, cy: 32.5, r: 1.9, fill: '#fff' }),
        h('circle', { cx: 50, cy: 38.5, r: 1.05, fill: '#ffffffb0' }),
        h('circle', { cx: 69, cy: 38.5, r: 1.05, fill: '#ffffffb0' }),
        h('ellipse', { cx: 48, cy: 35, rx: 2.1, ry: 3.1, fill: EYE_D, opacity: '.38' }),
        h('ellipse', { cx: 67, cy: 35, rx: 2.1, ry: 3.1, fill: EYE_D, opacity: '.38' })
      ),
      // má hồng
      h('ellipse', { cx: 39, cy: 43, rx: 4.6, ry: 2.7, fill: PINK, opacity: '.95' }),
      h('ellipse', { cx: 75, cy: 43, rx: 4.6, ry: 2.7, fill: PINK, opacity: '.95' }),
      // mũi + miệng mèo (ω)
      h('path', { d: 'M56.5 42 L 58.5 42 L 57.5 43.6 Z', fill: PINK_D }),
      h('path', { d: 'M54 46.5 Q 55.7 48.2 57.5 46.7 Q 59.3 48.2 61 46.5', stroke: DARK, strokeWidth: 1.7, fill: 'none', strokeLinecap: 'round' }),
      // ria
      h('path', { d: 'M36 38 L 24 35.5 M36 42 L 24 43 M38 45.5 L 28 50', stroke: DARK, strokeWidth: 1.1, fill: 'none', strokeLinecap: 'round', opacity: '.6' }),
      h('path', { d: 'M79 38 L 91 35.5 M79 42 L 91 43 M77 45.5 L 87 50', stroke: DARK, strokeWidth: 1.1, fill: 'none', strokeLinecap: 'round', opacity: '.6' })
    ),
    // collar + chuông vàng
    h('path', { d: 'M45 52 Q 57 60 69 52', stroke: '#e04848', strokeWidth: 5, fill: 'none', strokeLinecap: 'round' }),
    h('circle', { cx: 57, cy: 58.5, r: 4.6, fill: '#f7c948', stroke: '#c9971f', strokeWidth: 1.2 }),
    h('path', { d: 'M54.6 59.5 L 60.4 59.5 M57 57.5 L 57 61.8', stroke: '#8f6b12', strokeWidth: 1.1, strokeLinecap: 'round' })
  )
}

// --- SVG bướm bé ---
function ButterflySvg(h) {
  return h('svg', { viewBox: '0 0 22 18', width: '22', height: '18', 'aria-hidden': 'true' },
    h('g', { className: 'wos-bfly-bob' },
      h('ellipse', { className: 'wos-bfly-wing-l', cx: 7, cy: 6.5, rx: 6, ry: 5.5, fill: '#c99cf6' }),
      h('ellipse', { className: 'wos-bfly-wing-l', cx: 7.5, cy: 12, rx: 4.2, ry: 3.6, fill: '#e3c6fd' }),
      h('ellipse', { className: 'wos-bfly-wing-r', cx: 15, cy: 6.5, rx: 6, ry: 5.5, fill: '#c99cf6' }),
      h('ellipse', { className: 'wos-bfly-wing-r', cx: 14.5, cy: 12, rx: 4.2, ry: 3.6, fill: '#e3c6fd' }),
      h('ellipse', { cx: 11, cy: 9.5, rx: 1.5, ry: 4.5, fill: '#4a3f5d' }),
      h('path', { d: 'M10 5.5 Q 8 2 6.5 1.5 M12 5.5 Q 14 2 15.5 1.5', stroke: '#4a3f5d', strokeWidth: .9, fill: 'none', strokeLinecap: 'round' })
    )
  )
}

function AnimeCat() {
  var rootRef = useRef(null)
  var catRef = useRef(null)
  var bflyRef = useRef(null)
  var cfgRef = useRef({ speed: 120, size: 1, interactions: true })
  try {
    var c = WOS.plugin.config || {}
    if (c.speed) cfgRef.current.speed = Math.max(40, Math.min(400, Number(c.speed) || 120))
    if (c.size) cfgRef.current.size = Math.max(0.5, Math.min(2.5, Number(c.size) || 1))
    if (c.interactions === false) cfgRef.current.interactions = false
  } catch (e) {}

  var emoteState = useState(null)
  var setEmote = emoteState[1]
  var bubbleState = useState(null)
  var setBubble = bubbleState[1]
  var classState = useState({ mode: 'idle', flip: false, startled: false })
  var setClass = classState[1]

  // ---- BONG BÓNG SUY NGHĨ ----
  var bubbleTimer = { t: null }
  function showThought(title, text, ms) {
    if (bubbleTimer.t) clearTimeout(bubbleTimer.t)
    setBubble({ title: title || '', text: text || '', key: Date.now() })
    bubbleTimer.t = setTimeout(function () { setBubble(null) }, ms || 9500)
  }
  function showEmote(ch, dur) {
    setEmote(ch)
    setTimeout(function () { setEmote(null) }, dur || 1500)
  }

  // ---- THÔNG BÁO CHƯA ĐỌC → bong bóng suy nghĩ ----
  // Lần sync đầu chỉ "học" các thông báo sẵn có (không spam); từ đó mỗi thông báo
  // mới xuất hiện sẽ được mèo "nghĩ" ra trong bong bóng (≥ 23 ký tự hiển thị).
  useEffect(function () {
    var stopped = false
    var seen = {}
    var first = true
    function clip(s, n) { s = String(s || ''); return s.length > n ? s.slice(0, n - 1) + '…' : s }
    function fetchUnread() {
      if (document.hidden) return
      WOS.api('/api/core/notifications?filter=unread').then(function (d) {
        if (stopped || !d || !d.notifications) return
        var list = d.notifications
        var fresh = null
        for (var i = 0; i < list.length; i++) {
          var n = list[i]
          var isNew = !seen[n.id]
          seen[n.id] = true
          if (isNew && !fresh) fresh = n
        }
        if (first) { first = false; return } // bỏ qua đợt đầu (đăng nhập)
        if (fresh) {
          var text = fresh.title + (fresh.content ? ' — ' + fresh.content : '')
          showThought('Thông báo mới', clip(text, 120), 10500)
          showEmote('✉', 1600)
        }
      }).catch(function () {})
    }
    fetchUnread()
    var iv = setInterval(fetchUnread, 30000)
    return function () { stopped = true; clearInterval(iv) }
  }, [])

  // ---- BỘ NÃO + VẬT LÝ ----
  useEffect(function () {
    var el = catRef.current
    var bfEl = bflyRef.current
    if (!el) return

    var GW = 96, GH = 88
    var W = window.innerWidth, H = window.innerHeight
    var MENUBAR = 34, DOCK = 92
    var floor = H - DOCK - 8
    var mouse = { x: -999, y: -999 }

    var s = {
      x: W * 0.32, y: floor - GH,
      tx: W * 0.62,
      vx: 0, vy: 0,
      dir: 1, air: false,
      mode: 'idle',
      timer: 1.2,
      nextThink: 0.6,
      sprint: false,
      sitOn: null,
      startleLeft: 0,
      stuckT: 0,          // watchdog: đi mà không xê dịch → đổi việc ngay
      chasingBfly: false
    }
    // bướm bạn đồng hành — mèo thỉnh thoảng đuổi theo
    var bf = { x: W * 0.5, y: H * 0.38, tx: W * 0.5, ty: H * 0.38, timer: 0, speed: 110 }
    var icons = []
    var raf = 0, last = performance.now(), running = true
    var EMOTES = ['♥', '♪', '★', '✧', '🐾']

    function refreshIcons() {
      icons = []
      try {
        var nodes = document.querySelectorAll('.wos-desktop-file, .wos-desktop-icon, .wos-widget')
        nodes.forEach(function (n) {
          var r = n.getBoundingClientRect()
          if (r.width > 0 && r.height > 0) icons.push({ x: r.left, y: r.top, w: r.width, h: r.height, el: n })
        })
      } catch (e) {}
    }
    refreshIcons()
    var iconTimer = setInterval(refreshIcons, 800)

    function setMode(m) {
      if (s.mode === m) return
      s.mode = m
      commitClass()
    }
    function commitClass() {
      setClass(function (prev) {
        var flip = s.dir < 0
        var startled = s.startleLeft > 0
        if (prev.mode !== s.mode || prev.flip !== flip || prev.startled !== startled) {
          return { mode: s.mode, flip: flip, startled: startled }
        }
        return prev
      })
    }
    function jump(v) { s.vy = -(v || 520); s.air = true }

    // ---------- quyết định việc kế tiếp ----------
    function pickNewTarget() {
      s.sprint = Math.random() < 0.28
      s.chasingBfly = false
      var roll = Math.random()
      if (roll < 0.22 && bf.y < floor - 40) {
        // đuổi bướm!
        s.chasingBfly = true
        s.sprint = true
        s.tx = Math.max(12, Math.min(W - GW - 12, bf.x - GW / 2))
        s.sitOn = null
        setMode('walk')
        return
      }
      var margin = 90
      s.tx = margin + Math.random() * Math.max(60, W - margin * 2)
      s.sitOn = null
      setMode('walk')
    }
    function idleFor(sec) {
      s.sprint = false
      s.chasingBfly = false
      s.vx = 0
      s.timer = sec || (1.2 + Math.random() * 2.2) // nghỉ NGẮN — mèo hiếu động
      setMode('idle')
      if (Math.random() < 0.3) showEmote(EMOTES[Math.floor(Math.random() * EMOTES.length)], 1700)
    }
    function findIconToSit() {
      if (!cfgRef.current.interactions || !icons.length) return false
      var target = null, best = 1e9
      for (var i = 0; i < icons.length; i++) {
        var r = icons[i]
        if (r.y + r.h > floor + 12 || r.y < MENUBAR + 34) continue
        var dx = r.x + r.w / 2 - (s.x + GW / 2)
        var d = Math.abs(dx)
        if (d < best && d < W * 0.55) { best = d; target = r }
      }
      if (!target) return false
      s.sitOn = target
      s.sprint = false
      s.chasingBfly = false
      s.tx = target.x + target.w / 2 - GW / 2
      setMode('walk')
      return true
    }
    function leaveSit() {
      s.sitOn = null
      s.y = floor - GH
      jump(380)
      setMode('walk')
      s.tx = s.x + (Math.random() < 0.5 ? -1 : 1) * (150 + Math.random() * 190)
      showEmote('♪', 1200)
    }

    function think(dt) {
      if (s.startleLeft > 0) { s.startleLeft -= dt; if (s.startleLeft <= 0) { s.startleLeft = 0; commitClass() } }
      s.nextThink -= dt
      if (s.nextThink > 0 || s.air || s.mode === 'drag') return
      s.nextThink = 0.5 + Math.random() * 0.6 // suy nghĩ NHANH — không bao giờ đơ

      // phản ứng với con trỏ chuột
      var mDx = mouse.x - (s.x + GW / 2)
      var mNear = Math.abs(mDx) < 170 && mouse.y > H * 0.45 && mouse.y < floor + 40
      if (mNear && !s.air) {
        s.dir = mDx >= 0 ? 1 : -1
        commitClass()
        if (Math.abs(mDx) < 42 && Math.random() < 0.7) {
          s.startleLeft = 0.5
          commitClass()
          showEmote('!', 900)
          jump(340)
          s.dir = mDx >= 0 ? -1 : 1
          s.tx = s.x + s.dir * (210 + Math.random() * 160)
          setMode('walk')
          return
        }
      }

      if (s.mode === 'sit') {
        if (s.timer <= 0) { leaveSit() }
        return
      }
      if (s.mode === 'idle') {
        if (s.timer <= 0) {
          var roll = Math.random()
          if (roll < 0.3 && findIconToSit()) return
          pickNewTarget()
        }
        return
      }
      // đang walk
      var dist = s.tx - s.x
      if (Math.abs(dist) < 18) {
        if (s.chasingBfly) {
          // đuổi sat bướm → nhảy vồ!
          showEmote('!', 800)
          jump(470)
          s.chasingBfly = false
          return
        }
        var roll2 = Math.random()
        if (roll2 < 0.3) idleFor()
        else if (roll2 < 0.5 && findIconToSit()) return
        else pickNewTarget()
      } else if (Math.random() < 0.2) {
        pickNewTarget() // đổi ý giữa chừng — mèo tính khí thất thường
      }
    }

    function rectHit(px, py, w, h) {
      for (var i = 0; i < icons.length; i++) {
        var r = icons[i]
        if (px + w > r.x + 6 && px < r.x + r.w - 6 && py + h > r.y + 6 && py < r.y + r.h - 6) return r
      }
      return null
    }

    function step(now) {
      if (!running) return
      var dt = Math.min(0.05, (now - last) / 1000)
      last = now
      var t = now / 1000

      // ---- bướm bay ----
      if (bfEl) {
        bf.timer -= dt
        if (bf.timer <= 0) {
          bf.timer = 1.6 + Math.random() * 2.6
          bf.tx = 40 + Math.random() * Math.max(60, W - 120)
          bf.ty = MENUBAR + 70 + Math.random() * Math.max(60, floor - MENUBAR - 160)
        }
        var bdx = bf.tx - bf.x, bdy = bf.ty - bf.y
        var bd = Math.sqrt(bdx * bdx + bdy * bdy) || 1
        bf.x += (bdx / bd) * bf.speed * dt
        bf.y += (bdy / bd) * bf.speed * dt + Math.sin(t * 6.2) * 26 * dt
        bfEl.style.transform = 'translate3d(' + Math.round(bf.x) + 'px,' + Math.round(bf.y) + 'px,0)'
      }

      // ---- mèo ----
      if (s.mode === 'sit') {
        if (s.sitOn) {
          var r = s.sitOn.el ? s.sitOn.el.getBoundingClientRect() : null
          if (!r || Math.abs(r.y + r.h - (s.y + GH)) > 70 || Math.abs(r.x - s.sitOn.x) > 90) {
            s.sitOn = null; s.air = true; s.vy = 0; setMode('walk')
          } else {
            s.x = r.x + r.width / 2 - GW / 2
            s.y = r.y + r.h - GH + 5
          }
        }
      } else if (!s.air && s.mode !== 'drag') {
        s.y = floor - GH
        var dist = s.tx - s.x
        var targetDir = dist >= 0 ? 1 : -1
        var spd = cfgRef.current.speed * (s.sprint ? 1.85 : 1)
        if (Math.abs(dist) > 18) {
          s.vx += (targetDir * spd - s.vx) * Math.min(1, dt * 6)
        } else {
          s.vx *= Math.max(0, 1 - dt * 10)
        }
        if (Math.abs(s.vx) > 1) { s.dir = s.vx > 0 ? 1 : -1 }
        // vật cản phía trước → nhảy qua hoặc đổi hướng
        var ahead = s.x + GW / 2 + s.dir * 44
        var hit = rectHit(ahead - 30, s.y + 36, 60, 50)
        if (hit) {
          var underTarget = s.sitOn && Math.abs((s.sitOn.x + s.sitOn.w / 2) - (s.x + GW / 2)) < 34
          if (underTarget) jump(560)
          else if (Math.random() < 0.72) jump(540)
          else pickNewTarget()
        }
        s.x += s.vx * dt
        if (s.x < 12) { s.x = 12; pickNewTarget() }
        if (s.x > W - GW - 12) { s.x = W - GW - 12; pickNewTarget() }

        // WATCHDOG chống đứng im: đi mà không xê dịch → đổi việc ngay
        if (s.mode === 'walk' && Math.abs(s.vx) < 2 && Math.abs(dist) > 24) {
          s.stuckT += dt
          if (s.stuckT > 1.6) { s.stuckT = 0; pickNewTarget() }
        } else {
          s.stuckT = 0
        }
        commitClass()
      } else if (s.air && s.mode !== 'drag') {
        s.vy += 1500 * dt
        s.x += s.vx * dt
        s.y += s.vy * dt
        if (s.sitOn) {
          var tr = s.sitOn.el ? s.sitOn.el.getBoundingClientRect() : null
          if (tr && s.vy > 0 && s.y >= tr.y + tr.height - GH + 5) {
            s.y = tr.y + tr.height - GH + 5
            s.x = tr.x + tr.width / 2 - GW / 2
            s.air = false; s.vy = 0
            setMode('sit')
            s.timer = 2.6 + Math.random() * 3.4
            showEmote('♥', 1800)
            try { WOS.emitEvent('cat.sat', { icon: 'desktop-icon' }) } catch (e) {}
          }
        }
        if (s.y >= floor - GH && s.vy > 0) {
          s.y = floor - GH
          s.air = false; s.vy = 0
          if (s.sitOn) s.sitOn = null
          if (s.mode !== 'idle') setMode('walk')
        }
      }

      // hẹn giờ idle/sit đếm MỖI FRAME; quá hạn lâu → force đi tiếp (an toàn tuyệt đối)
      if (s.mode === 'idle' || s.mode === 'sit') {
        s.timer -= dt
        if (s.timer < -8) { pickNewTarget() }
      }
      think(dt)
      el.style.transform = 'translate3d(' + Math.round(s.x) + 'px,' + Math.round(s.y) + 'px,0) scale(' + cfgRef.current.size + ')'
      raf = requestAnimationFrame(step)
    }
    raf = requestAnimationFrame(step)

    // ---------- tương tác chuột ----------
    var drag = null
    var downAt = 0
    function onDown(e) {
      drag = { sx: e.clientX, sy: e.clientY, ox: s.x, oy: s.y, moved: false }
      downAt = Date.now()
      s.vx = 0; s.vy = 0; s.air = false
      s.mode = 'drag'
      s.chasingBfly = false
      el.classList.add('grabbing')
      commitClass()
      el.setPointerCapture && el.setPointerCapture(e.pointerId)
    }
    function onMove(e) {
      mouse.x = e.clientX; mouse.y = e.clientY
      if (!drag) return
      if (Math.abs(e.clientX - drag.sx) > 4 || Math.abs(e.clientY - drag.sy) > 4) drag.moved = true
      if (drag.moved) {
        s.x = drag.ox + (e.clientX - drag.sx)
        s.y = drag.oy + (e.clientY - drag.sy)
        el.style.transform = 'translate3d(' + Math.round(s.x) + 'px,' + Math.round(s.y) + 'px,0) scale(' + cfgRef.current.size + ')'
      }
    }
    function onUp(e) {
      if (!drag) return
      var wasTap = !drag.moved && Date.now() - downAt < 350
      drag = null
      el.classList.remove('grabbing')
      s.y = floor - GH
      if (wasTap) {
        jump(430)
        s.mode = 'walk'
        s.vx = 0
        showEmote(['♥', '🐾', '♪', '✧'][Math.floor(Math.random() * 4)], 1400)
        // gõ nhẹ → mèo "suy nghĩ" một câu dễ thương kiểu truyện tranh
        if (Math.random() < 0.6) {
          var lines = ['Meow~ Ui, vuốt tóc ghê!', 'Nyaa~ Hôm nay trời dễ chịu quá ta...', 'Meo… có gì ăn không nhỉ?', 'Nyaa~ Đừng giận mình nhaaa', 'Meow meow… Mình muốn ngủ chút…']
          showThought('', lines[Math.floor(Math.random() * lines.length)], 4200)
        }
        try { WOS.emitEvent('cat.tapped', {}) } catch (e2) {}
      } else {
        s.dir = Math.random() < 0.5 ? 1 : -1
        s.vx = 0
        setMode('walk')
        s.tx = s.x + s.dir * (170 + Math.random() * 210)
        showEmote('?', 900)
      }
    }
    el.addEventListener('pointerdown', onDown)
    window.addEventListener('pointermove', onMove)
    window.addEventListener('pointerup', onUp)

    function onResize() { W = window.innerWidth; H = window.innerHeight; floor = H - DOCK - 8; refreshIcons() }
    window.addEventListener('resize', onResize)

    return function () {
      running = false
      cancelAnimationFrame(raf)
      clearInterval(iconTimer)
      el.removeEventListener('pointerdown', onDown)
      window.removeEventListener('pointermove', onMove)
      window.removeEventListener('pointerup', onUp)
      window.removeEventListener('resize', onResize)
    }
  }, [])

  var cur = classState[0]
  var bub = bubbleState[0]
  return h('div', { ref: rootRef, className: 'wos-cat-root', 'aria-label': 'Nyanko — chú mèo đồng hành desktop' },
    // bướm bạn (bay độc lập)
    h('div', { ref: bflyRef, className: 'wos-bfly', 'aria-hidden': 'true' }, ButterflySvg(h)),
    // mèo
    h('div', {
      ref: catRef,
      className: 'wos-cat ' + cur.mode + (cur.flip ? ' flip' : '') + (cur.startled ? ' startled' : ''),
      title: 'Nyanko đây meow! Kéo em đi chơi, bấm nhẹ để chào~'
    },
      // bong bóng suy nghĩ (truyện tranh): thân mây + 3 chấm nhỏ dẫn xuống đầu
      bub ? h('div', { className: 'wos-cat-bubble', key: bub.key },
        h('div', { className: 'wos-cat-bubble-body' },
          bub.title ? h('div', { className: 'wos-cat-bubble-title' }, '💬 ', bub.title) : null,
          h('div', { className: 'wos-cat-bubble-text' }, bub.text)
        ),
        h('span', { className: 'wos-cat-bubble-tail t1' }),
        h('span', { className: 'wos-cat-bubble-tail t2' }),
        h('span', { className: 'wos-cat-bubble-tail t3' })
      ) : null,
      emoteState[0] ? h('span', { className: 'wos-cat-emote' }, emoteState[0]) : null,
      h('div', { className: 'wos-cat-inner' }, CatSvg(h))
    )
  )
}

WOS.registerPet({ component: AnimeCat, config: { speed: 120, size: 1, interactions: true } })
`

export interface BuiltinPluginDef {
  slug: string
  name: string
  description: string
  version: string
  author: string
  icon: string
  color: string
  kind: 'app' | 'pet'
  entry: string
  desktopIcon: boolean
  showDock: boolean
  windowW: number
  windowH: number
  order: number
}

export const BUILTIN_PLUGINS: BuiltinPluginDef[] = [
  {
    slug: 'calculator',
    name: 'Máy tính',
    description: 'Máy tính chuẩn macOS: kín khít cửa sổ, đổi màu theo theme; bàn phím chỉ nhận khi cửa sổ đang focus (không giật phím app khác)',
    version: '2.1.0',
    author: 'WOS Team',
    icon: '🧮',
    color: '#1c2b4a',
    kind: 'app',
    entry: CALCULATOR_ENTRY,
    desktopIcon: true,
    showDock: false,
    windowW: 250,
    windowH: 374,
    order: 500,
  },
  {
    slug: 'anime-pet',
    name: 'Mèo Nyanko',
    description: 'Chú mèo anime đồng hành — bong bóng suy nghĩ kiểu truyện tranh hiển thị thông báo chưa đọc, đuổi bướm, đi lang thang không đứng im, né/nhảy lên icon, phản ứng theo chuột',
    version: '3.0.0',
    author: 'WOS Team',
    icon: '🐱',
    color: '#f9a8d4',
    kind: 'pet',
    entry: ANIME_CAT_ENTRY,
    desktopIcon: false, // pet không cần icon desktop — nó tự chạy trên màn hình
    showDock: false,
    windowW: 300,
    windowH: 360,
    order: 501,
  },
]

/** Idempotent: cài plugin builtin còn thiếu + đồng bộ entry khi hệ thống nâng cấp
 *  (giữ nguyên enabled/config người dùng đã chỉnh) */
export async function ensureBuiltinPlugins(): Promise<void> {
  for (const def of BUILTIN_PLUGINS) {
    const existing = await db.plugin.findUnique({ where: { slug: def.slug } })
    if (!existing) {
      await db.plugin.create({
        data: {
          slug: def.slug,
          name: def.name,
          description: def.description,
          version: def.version,
          author: def.author,
          icon: def.icon,
          color: def.color,
          kind: def.kind,
          entry: def.entry,
          config: JSON.stringify(def.kind === 'pet' ? { speed: 120, size: 1, interactions: true } : {}),
          enabled: true,
          builtin: true,
          desktopIcon: def.desktopIcon,
          showDock: def.showDock,
          windowW: def.windowW,
          windowH: def.windowH,
          order: def.order,
        },
      })
      continue
    }
    // builtin đã có: refresh mã nguồn/metadata khi khác bản hệ thống (nâng cấp tự nhiên)
    const needsUpdate =
      existing.builtin &&
      (existing.entry !== def.entry ||
        existing.version !== def.version ||
        existing.description !== def.description)
    if (needsUpdate) {
      await db.plugin.update({
        where: { slug: def.slug },
        data: {
          name: def.name,
          description: def.description,
          version: def.version,
          icon: def.icon,
          color: def.color,
          kind: def.kind,
          entry: def.entry,
          desktopIcon: def.desktopIcon,
          windowW: def.windowW,
          windowH: def.windowH,
        },
      })
    }
  }
}
