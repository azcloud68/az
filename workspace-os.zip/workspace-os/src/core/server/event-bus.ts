/**
 * WOS Event Bus (server) — trái tim kiến trúc module hoá
 * Module KHÔNG gọi module khác; mọi biến đổi nghiệp vụ phát event tại đây:
 *   - EventRecord  → Timeline module đọc
 *   - ActivityLog  → Activity module đọc
 *   - Notification → Notification Center (khi cần báo cho user)
 * Sau này thêm AI/Linux Monitor/Stock… chỉ cần đọc EventRecord, không sửa lõi.
 */
import { db } from '@/lib/db'
import type { SessionUser } from './auth'

export interface BusEvent {
  type: string // vd: task.completed
  module: string
  actor?: Pick<SessionUser, 'id' | 'displayName'> | null
  payload?: Record<string, unknown>
  /** Ghi activity log kèm event (mặc định true) */
  logActivity?: boolean
  /** Thông báo đẩy cho user (title + nội dung ngắn) */
  notify?: { title: string; content?: string; type?: 'info' | 'reminder' | 'alert' | 'system'; action?: string }
  targetType?: string
  targetId?: string
}

export async function emitEvent(ev: BusEvent): Promise<void> {
  const actorName = ev.actor?.displayName || ''
  try {
    await db.eventRecord.create({
      data: {
        type: ev.type,
        module: ev.module,
        actorId: ev.actor?.id || null,
        actorName,
        payload: JSON.stringify(ev.payload || {}),
      },
    })
    if (ev.logActivity !== false) {
      await db.activityLog.create({
        data: {
          userId: ev.actor?.id || null,
          userName: actorName,
          module: ev.module,
          action: ev.type,
          targetType: ev.targetType || '',
          targetId: ev.targetId || '',
          detail: describeEvent(ev),
        },
      })
    }
    if (ev.notify) {
      // Thông báo gắn theo user thực hiện (nếu có) — tách theo tài khoản;
      // sự kiện hệ thống không actor (vd scheduler) → userId null = toàn hệ thống
      await db.notification.create({
        data: {
          userId: ev.actor?.id || null,
          title: ev.notify.title,
          content: ev.notify.content || '',
          module: ev.module,
          type: ev.notify.type || 'info',
          action: ev.notify.action || '',
        },
      })
    }
  } catch (err) {
    console.error('[event-bus]', err)
  }
}

/** Sinh mô tả tiếng Việt cho activity log */
function describeEvent(ev: BusEvent): string {
  const p = (ev.payload || {}) as Record<string, unknown>
  const name = typeof p.title === 'string' ? p.title : typeof p.name === 'string' ? p.name : ''
  const vnMap: Record<string, string> = {
    'auth.login': 'đăng nhập',
    'auth.logout': 'đăng xuất',
    'auth.password': 'đổi mật khẩu',
    'task.created': 'tạo công việc',
    'task.updated': 'cập nhật công việc',
    'task.completed': 'hoàn thành công việc',
    'task.deleted': 'xoá công việc',
    'event.created': 'tạo sự kiện lịch',
    'event.updated': 'cập nhật sự kiện lịch',
    'event.deleted': 'xoá sự kiện lịch',
    'note.created': 'tạo ghi chú',
    'note.updated': 'cập nhật ghi chú',
    'note.deleted': 'xoá ghi chú',
    'wiki.created': 'tạo trang wiki',
    'wiki.updated': 'cập nhật wiki',
    'wiki.deleted': 'xoá trang wiki',
    'file.uploaded': 'tải lên tệp',
    'file.updated': 'cập nhật tệp',
    'file.downloaded': 'tải xuống tệp',
    'file.deleted': 'xoá tệp',
    'file.restored': 'khôi phục tệp',
    'file.shared': 'chia sẻ tệp',
    'project.created': 'tạo dự án',
    'project.updated': 'cập nhật dự án',
    'project.archived': 'lưu trữ dự án',
    'milestone.completed': 'hoàn thành mốc',
    'module.enabled': 'bật module',
    'module.disabled': 'tắt module',
    'settings.updated': 'thay đổi cấu hình',
    'user.created': 'tạo người dùng',
    'user.updated': 'cập nhật người dùng',
    'user.deleted': 'xoá người dùng',
    'group.created': 'tạo nhóm',
    'backup.exported': 'xuất sao lưu',
    'backup.imported': 'nhập sao lưu',
    'weekly.process.created': 'tạo quy trình',
    'weekly.process.updated': 'sửa quy trình',
    'weekly.process.deleted': 'xoá quy trình',
    'weekly.task.completed': 'hoàn thành việc tuần',
    'weekly.task.passed': 'pass việc tuần',
    'weekly.day.offline': 'đánh dấu ngày nghỉ',
    'sync.backup.ok': 'backup lên Drive',
    'sync.backup.error': 'backup Drive lỗi',
  }
  const action = vnMap[ev.type] || ev.type
  return name ? `${action} "${name}"` : action
}
