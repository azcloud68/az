/**
 * User Permissions — quyền hạn riêng THEO TỪNG TÀI KHOẢN:
 * { modules: string[] | null, allowFiles: boolean }
 * - modules = null → được dùng tất cả module
 * - modules = [...] → whitelist các module id được phép
 * - allowFiles = false → khoá hoàn toàn File Manager (files/upload/trash/viewer)
 * Admin đặt trong Administration → Users (dialog tạo/sửa tài khoản).
 * Cache 30s trong RAM để requireModule không phải đập DB mỗi request.
 */
import { db } from '@/lib/db'

export interface UserPermissionsData {
  modules: string[] | null
  allowFiles: boolean
}

/** Parse an toàn chuỗi/object quyền hạn → chuẩn hoá */
export function normalizePermissions(raw: unknown): UserPermissionsData | null {
  if (!raw) return null
  try {
    const obj = typeof raw === 'string' ? JSON.parse(raw) : raw
    if (!obj || typeof obj !== 'object') return null
    const out: UserPermissionsData = { modules: null, allowFiles: true }
    if (Array.isArray(obj.modules)) {
      out.modules = obj.modules.filter((m: unknown) => typeof m === 'string' && m.length > 0)
    }
    if (typeof obj.allowFiles === 'boolean') out.allowFiles = obj.allowFiles
    return out
  } catch {
    return null
  }
}

/** Chuỗi hoá để lưu DB (rỗng = không hạn chế gì) */
export function serializePermissions(p: unknown): string {
  const n = normalizePermissions(p)
  if (!n) return ''
  if (n.modules === null && n.allowFiles !== false) return ''
  return JSON.stringify(n)
}

// cache 30s theo userId — tránh query mỗi API call
const cache = new Map<string, { ts: number; data: UserPermissionsData | null }>()
const TTL = 30_000

export async function getUserPermissions(userId: string): Promise<UserPermissionsData | null> {
  const hit = cache.get(userId)
  if (hit && Date.now() - hit.ts < TTL) return hit.data
  const u = await db.user.findUnique({ where: { id: userId }, select: { permissions: true } })
  const data = normalizePermissions(u?.permissions)
  cache.set(userId, { ts: Date.now(), data })
  return data
}

/** Xoá cache khi admin đổi quyền (áp dụng gần như ngay lập tức) */
export function invalidateUserPermissions(userId?: string) {
  if (userId) cache.delete(userId)
  else cache.clear()
}

/** Tài khoản có được phép dùng module không? (null perms = tất cả) */
export function permsAllowModule(perms: UserPermissionsData | null, moduleId: string): boolean {
  if (!perms) return true
  if (moduleId === 'files' && perms.allowFiles === false) return false
  if (perms.modules !== null && !perms.modules.includes(moduleId)) return false
  return true
}
