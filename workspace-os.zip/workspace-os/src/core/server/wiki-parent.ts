/**
 * Wiki tree guards (v2.3) — dùng chung cho POST /api/modules/wiki và PATCH /[id]:
 *  - parentId phải thuộc CÙNG tài khoản (trước đây user A nhét trang vào cha của user B)
 *  - KHÔNG cho tạo VÒNG LẶP: A → B → C → A (leo cây cha từ ứng viên, gặp chính
 *    trang đang di chuyển → từ chối)
 */
import { db } from '@/lib/db'
import { ApiError } from './api-error'

/**
 * Validate parentId cho 1 trang wiki.
 * @param ownerId tài khoản hiện tại (phải là chủ của trang cha)
 * @param pageId  id trang đang tạo (null) HOẶC đang dời (cycle check) — null = tạo mới
 * @param parentId ứng viên cha (null/'' = chuyển về gốc — luôn hợp lệ)
 */
export async function assertWikiParent(
  ownerId: string,
  pageId: string | null,
  parentId: string | null | undefined,
): Promise<string | null> {
  if (!parentId) return null
  const parent = await db.wikiPage.findUnique({ where: { id: parentId } })
  if (!parent || parent.ownerId !== ownerId || parent.trashedAt) {
    throw new ApiError('Trang cha không tồn tại (hoặc không phải của bạn)', 404)
  }
  // cycle: leo lên từ CHA ứng viên — nếu gặp chính trang đang dời → vòng lặp
  type WikiNode = { id: string; parentId: string | null }
  let cur: WikiNode | null = parent
  const seen = new Set<string>() // chống dữ liệu cũ bị vòng → deadlock
  while (cur) {
    if (pageId && cur.id === pageId) {
      throw new ApiError('Không thể lồng trang vào chính nó hoặc một trang con của nó', 400)
    }
    if (seen.has(cur.id)) break
    seen.add(cur.id)
    cur = cur.parentId
      ? await db.wikiPage.findUnique({ where: { id: cur.parentId } })
      : null
  }
  return parent.id
}
