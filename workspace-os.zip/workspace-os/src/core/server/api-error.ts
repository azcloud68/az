/**
 * ApiError — lỗi CÓ CHỦ Ý hiển thị cho người dùng (thông điệp tiếng Việt + status).
 * Module LÁ (không import gì khác) để storage/plugin/sync dùng được mà không tạo
 * vòng import (api.ts → user-data.ts → storage.ts → ...).
 *
 * Quy ước từ v2.3: lỗi NỘI BỘ (Prisma/filesystem/Node/Google API...) KHÔNG dùng
 * ApiError → handle() che thành "Lỗi hệ thống" khi chạy production (xem api.ts).
 */
export class ApiError extends Error {
  status: number
  constructor(message: string, status = 400) {
    super(message)
    this.status = status
  }
}
