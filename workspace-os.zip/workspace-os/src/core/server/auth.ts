/**
 * WOS Authentication — Core Engine
 * - Mật khẩu: scrypt (node:crypto)
 * - Session: DB-backed (bảng Session) + cookie httpOnly
 * - Remember login: 30 ngày, không remember: 1 ngày
 * - Forgot password: sinh mã reset 15 phút (hiện cho admin đặt lại — self-hosted)
 */
import { createHmac, randomBytes, scryptSync, timingSafeEqual } from 'crypto'
import { cookies } from 'next/headers'
import { db } from '@/lib/db'

export const SESSION_COOKIE = 'wos_token'
const REMEMBER_MS = 30 * 24 * 3600 * 1000
const SHORT_MS = 24 * 3600 * 1000

export interface SessionUser {
  id: string
  username: string
  displayName: string
  role: string
  avatarColor: string
  email: string | null
  sessionId: string
}

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex')
  const hash = scryptSync(password, salt, 64).toString('hex')
  return `${salt}:${hash}`
}

export function verifyPassword(password: string, stored: string): boolean {
  try {
    const [salt, hash] = stored.split(':')
    if (!salt || !hash) return false
    const candidate = scryptSync(password, salt, 64)
    const expected = Buffer.from(hash, 'hex')
    return candidate.length === expected.length && timingSafeEqual(candidate, expected)
  } catch {
    return false
  }
}

async function getAuthSecret(): Promise<string> {
  if (process.env.AUTH_SECRET) return process.env.AUTH_SECRET
  const row = await db.setting.findUnique({ where: { id: 'core:auth_secret' } })
  if (row?.value) return row.value
  const secret = randomBytes(32).toString('hex')
  await db.setting.upsert({
    where: { id: 'core:auth_secret' },
    update: {},
    create: { id: 'core:auth_secret', module: 'core', key: 'auth_secret', value: secret },
  })
  return secret
}

/** Cookie = body.sig — body chứa sid (random); verify chữ ký rồi đối chiếu DB (revoke được) */
export async function createSession(
  user: { id: string; username: string },
  opts: { remember?: boolean; userAgent?: string; ip?: string } = {}
): Promise<string> {
  const secret = await getAuthSecret()
  const ttl = opts.remember ? REMEMBER_MS : SHORT_MS
  const sid = randomBytes(24).toString('hex')
  await db.session.create({
    data: {
      token: sid,
      userId: user.id,
      userAgent: opts.userAgent || '',
      ip: opts.ip || '',
      expiresAt: new Date(Date.now() + ttl),
    },
  })
  const body = Buffer.from(JSON.stringify({ sid, uid: user.id })).toString('base64url')
  const sig = createHmac('sha256', secret).update(body).digest('base64url')
  return `${body}.${sig}`
}

export async function verifySessionToken(token: string | undefined | null): Promise<SessionUser | null> {
  if (!token) return null
  const [body, sig] = token.split('.')
  if (!body || !sig) return null
  const secret = await getAuthSecret()
  const expected = createHmac('sha256', secret).update(body).digest('base64url')
  const a = Buffer.from(sig)
  const b = Buffer.from(expected)
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null
  let sid = ''
  try {
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString()) as { sid: string }
    sid = payload.sid
  } catch {
    return null
  }
  const session = await db.session.findUnique({
    where: { token: sid },
    include: { user: true },
  })
  if (!session) return null
  if (session.expiresAt.getTime() < Date.now()) {
    await db.session.delete({ where: { id: session.id } }).catch(() => {})
    return null
  }
  if (!session.user.active) return null
  return {
    id: session.user.id,
    username: session.user.username,
    displayName: session.user.displayName,
    role: session.user.role,
    avatarColor: session.user.avatarColor,
    email: session.user.email,
    sessionId: session.id,
  }
}

export async function getSession(): Promise<SessionUser | null> {
  const store = await cookies()
  return verifySessionToken(store.get(SESSION_COOKIE)?.value)
}

/** Token ngắn hạn cho DỊCH VỤ đi kèm (vd Terminal service) — chữ ký HMAC giống session
 *  nhưng có scope + expiry riêng, KHÔNG dùng làm cookie. Service đối chiếu ngược về
 *  Next qua /api/system/terminal/verify nên không cần chia sẻ secret qua env. */
export async function createServiceToken(
  scope: string,
  payload: Record<string, unknown>,
  ttlMs: number
): Promise<string> {
  const secret = await getAuthSecret()
  const body = Buffer.from(
    JSON.stringify({ scope, exp: Date.now() + ttlMs, ...payload })
  ).toString('base64url')
  const sig = createHmac('sha256', secret).update(body).digest('base64url')
  return `${body}.${sig}`
}

/** Verify service token — trả về payload nếu chữ ký + scope + hạn còn dùng */
export async function verifyServiceToken(
  token: string | undefined | null,
  scope: string
): Promise<Record<string, unknown> | null> {
  if (!token) return null
  const [body, sig] = token.split('.')
  if (!body || !sig) return null
  const secret = await getAuthSecret()
  const expected = createHmac('sha256', secret).update(body).digest('base64url')
  const a = Buffer.from(sig)
  const b = Buffer.from(expected)
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null
  try {
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString()) as Record<string, unknown>
    if (payload.scope !== scope) return null
    if (typeof payload.exp !== 'number' || payload.exp < Date.now()) return null
    return payload
  } catch {
    return null
  }
}

export function sessionCookieOptions(remember: boolean) {
  return {
    httpOnly: true,
    sameSite: 'lax' as const,
    path: '/',
    maxAge: (remember ? REMEMBER_MS : SHORT_MS) / 1000,
  }
}

export async function destroySession(): Promise<void> {
  const store = await cookies()
  const token = store.get(SESSION_COOKIE)?.value
  if (token) {
    const [body] = token.split('.')
    try {
      const payload = JSON.parse(Buffer.from(body, 'base64url').toString()) as { sid: string }
      await db.session.deleteMany({ where: { token: payload.sid } })
    } catch {
      /* bỏ qua */
    }
  }
  store.delete(SESSION_COOKIE)
}

/** Thu hồi mọi phiên của user, trừ phiên hiện tại (nếu có) */
export async function destroyAllSessions(userId: string, exceptSessionId?: string): Promise<void> {
  await db.session.deleteMany({
    where: { userId, ...(exceptSessionId ? { id: { not: exceptSessionId } } : {}) },
  })
}

/** Đổi mật khẩu — thu hồi mọi session KHÁC (giữ session hiện tại nếu truyền vào) */
export async function changePassword(userId: string, newPassword: string, exceptSessionId?: string): Promise<void> {
  await db.user.update({
    where: { id: userId },
    data: { passwordHash: hashPassword(newPassword) },
  })
  await destroyAllSessions(userId, exceptSessionId)
}

/** Sinh mã reset (15 phút) — mã KHÔNG BAO GIỜ trả qua API response.
 *  Kênh lấy mã: (1) admin xem trong Administration → Users, (2) log server
 *  (journalctl -u wos | grep WOS:reset — kênh tự cứu cho máy 1 admin; tắt bằng
 *  WOS_RESET_CODE_IN_LOG=0 nếu không muốn mã xuất hiện trong journal).
 *  Tạo mã mới → VÔ HIỆU HOÁ mọi mã cũ: tại 1 thời điểm chỉ 1 mã hợp lệ. */
export async function createResetCode(username: string): Promise<string | null> {
  const user = await db.user.findUnique({ where: { username } })
  if (!user) return null
  // chặn sinh mã dồn dập cho cùng 1 username (tối đa 3 mã / 15 phút)
  const recent = await db.passwordReset.count({
    where: { userId: user.id, createdAt: { gte: new Date(Date.now() - 15 * 60 * 1000) } },
  })
  if (recent >= 3) return null
  const code = randomBytes(4).toString('hex').toUpperCase()
  // chỉ 1 mã hợp lệ tại 1 thời điểm — mã cũ đánh dấu used ngay khi sinh mã mới
  await db.passwordReset.updateMany({
    where: { userId: user.id, usedAt: null },
    data: { usedAt: new Date() },
  })
  await db.passwordReset.create({
    data: {
      userId: user.id,
      code,
      expiresAt: new Date(Date.now() + 15 * 60 * 1000),
    },
  })
  if ((process.env.WOS_RESET_CODE_IN_LOG || '1').trim() !== '0') {
    console.log(`[WOS:reset] Mã đặt lại mật khẩu cho "${username}": ${code}`)
  }
  return code
}

export async function consumeResetCode(
  username: string,
  code: string,
  newPassword: string
): Promise<boolean> {
  const user = await db.user.findUnique({ where: { username } })
  if (!user) return false
  const reset = await db.passwordReset.findFirst({
    where: { userId: user.id, code, usedAt: null, expiresAt: { gt: new Date() } },
    orderBy: { createdAt: 'desc' },
  })
  if (!reset) return false
  await db.passwordReset.update({ where: { id: reset.id }, data: { usedAt: new Date() } })
  await changePassword(user.id, newPassword)
  return true
}
