/**
 * Streaming file response — download / preview / share dùng chung.
 * - createReadStream → Readable.toWeb → Response: RAM chỉ ~64KB/chunk dù file GB
 * - Hỗ trợ HTTP Range (video tua được) — 206 Partial Content
 * - Đã qua safeResolveReal (chống symlink thoát storage)
 */
import { NextRequest, NextResponse } from 'next/server'
import { Readable } from 'stream'
import { readFileStream, mimeOf } from './storage'

export interface StreamFileOpts {
  inline?: boolean
  filename?: string
  cacheControl?: string
}

/** Parse header Range: bytes=<start>-<end> | bytes=<start>- | bytes=-<suffix> */
function parseRange(header: string, size: number): { start: number; end: number } | 'invalid' | null {
  const m = header.match(/^bytes=(\d*)-(\d*)$/)
  if (!m) return 'invalid'
  const hasStart = m[1] !== ''
  const hasEnd = m[2] !== ''
  if (!hasStart && !hasEnd) return 'invalid'
  if (!hasStart && hasEnd) {
    // cuối file: bytes=-N
    const suffix = parseInt(m[2], 10)
    if (suffix === 0) return 'invalid'
    const start = Math.max(0, size - suffix)
    return { start, end: size - 1 }
  }
  const start = parseInt(m[1], 10)
  const end = hasEnd ? Math.min(parseInt(m[2], 10), size - 1) : size - 1
  if (start > end || start >= size) return 'invalid'
  return { start, end }
}

export async function streamFileResponse(
  req: NextRequest,
  relPath: string,
  opts: StreamFileOpts = {}
): Promise<NextResponse> {
  const inline = opts.inline ?? false
  const name = opts.filename || relPath.split('/').pop() || 'file'

  let size = 0
  try {
    const first = await readFileStream(relPath)
    size = first.size
    first.stream.destroy() // chỉ cần biết size + tồn tại; mở lại nếu có range
  } catch (err) {
    const msg = err instanceof Error ? err.message : ''
    if (msg.includes('thư mục')) {
      return NextResponse.json({ error: 'Không tải được thư mục — hãy nén thành .zip trước' }, { status: 400 })
    }
    return NextResponse.json({ error: 'Tệp không tồn tại trong thư mục của bạn' }, { status: 404 })
  }

  const headers = new Headers({
    'content-type': mimeOf(name),
    'content-disposition': `${inline ? 'inline' : 'attachment'}; filename*=UTF-8''${encodeURIComponent(name)}`,
    'cache-control': opts.cacheControl || 'private, max-age=60',
    'accept-ranges': 'bytes',
  })

  const rangeHeader = req.headers.get('range')
  if (rangeHeader) {
    const range = parseRange(rangeHeader, size)
    if (range === 'invalid') {
      headers.set('content-range', `bytes */${size}`)
      return new NextResponse(null, { status: 416, headers })
    }
    if (range) {
      const { stream } = await readFileStream(relPath, { start: range.start, end: range.end })
      headers.set('content-range', `bytes ${range.start}-${range.end}/${size}`)
      headers.set('content-length', String(range.end - range.start + 1))
      return new NextResponse(Readable.toWeb(stream) as unknown as ReadableStream, { status: 206, headers })
    }
  }

  const { stream } = await readFileStream(relPath)
  headers.set('content-length', String(size))
  return new NextResponse(Readable.toWeb(stream) as unknown as ReadableStream, { status: 200, headers })
}
