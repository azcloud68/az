/**
 * WOS User Scope — AsyncLocalStorage lưu "user đang thực thi request".
 * Storage Engine (storage.ts) đọc giá trị này để resolve thư mục gốc
 * <base>/users/<uid> cho đúng tài khoản — mọi thao tác file tự động tách theo user.
 */
import { AsyncLocalStorage } from 'node:async_hooks'

const als = new AsyncLocalStorage<string>()

/** Chạy fn trong ngữ cảnh của userId — mọi safeResolve/storageRoot bên trong scope theo user này */
export function withUserStorage<T>(userId: string, fn: () => Promise<T>): Promise<T> {
  return als.run(userId, fn)
}

/** User id hiện tại (null = ngoài ngữ cảnh user — dùng root toàn hệ thống) */
export function currentStorageUserId(): string | null {
  return als.getStore() ?? null
}
