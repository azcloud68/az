/**
 * WOS Per-User Data Migration (lazy, idempotent)
 * Chạy 1 lần đầu tiên khi có request API (xem handle() trong api.ts):
 *  1. Gán ownerId = admin đầu tiên cho mọi row null (dữ liệu legacy trước v5)
 *  2. Dời toàn bộ file cấp 1 của storage root vào users/<adminId>/ (nếu chưa từng dời)
 *  3. Bỏ unique index WorkDay(date) toàn cục → cho phép cùng 1 ngày cho nhiều tài khoản
 *     (schema file vẫn do main-agent quản — cần đồng bộ `@@unique([ownerId, date])` khi có dịp)
 * Toàn bộ bọc try/catch — migration lỗi KHÔNG được làm hỏng API.
 */
import { existsSync, mkdirSync, writeFileSync } from 'fs'
import { promises as fsp } from 'fs'
import path from 'path'
import { db } from '@/lib/db'
import { baseStorageRoot, ensureUserDirs, PER_USER_MARKER } from './storage'

function markerFile(): string {
  return path.join(baseStorageRoot(), 'users', PER_USER_MARKER)
}

/** Key của user-scoped setting: "u<userId>:<key>" (settings.ts dùng chung format) */
export function userSettingKeyPrefix(userId: string): string {
  return `u${userId}:`
}

export async function ensurePerUserData(): Promise<void> {
  const g = globalThis as unknown as { __wosPerUserDone?: boolean }
  if (g.__wosPerUserDone) return
  try {
    if (existsSync(markerFile())) {
      g.__wosPerUserDone = true
      return
    }

    // --- 1) admin đầu tiên (fallback: user bất kỳ) ---
    let admin = await db.user.findFirst({ where: { role: 'admin' }, orderBy: { createdAt: 'asc' } })
    if (!admin) admin = await db.user.findFirst({ orderBy: { createdAt: 'asc' } })
    if (!admin) return // chưa ai đăng ký — để seed tạo sau

    // --- 2) WorkDay: bỏ unique(date) toàn cục, thay bằng unique (ownerId, date) ---
    // Cần thiết vì mỗi tài khoản có ngày làm việc riêng; index cũ chặn 2 user cùng 1 ngày.
    try {
      await db.$executeRawUnsafe('DROP INDEX IF EXISTS "WorkDay_date_key"')
      await db.$executeRawUnsafe(
        'CREATE UNIQUE INDEX IF NOT EXISTS "WorkDay_ownerId_date_key" ON "WorkDay"("ownerId", "date")'
      )
    } catch (err) {
      console.error('[user-data] đổi index WorkDay thất bại:', err)
    }

    // --- 3) Gán ownerId cho mọi row legacy null ---
    const adminId = admin.id
    const assign = [
      () => db.task.updateMany({ where: { ownerId: null }, data: { ownerId: adminId } }),
      () => db.calendarEvent.updateMany({ where: { ownerId: null }, data: { ownerId: adminId } }),
      () => db.note.updateMany({ where: { ownerId: null }, data: { ownerId: adminId } }),
      () => db.wikiPage.updateMany({ where: { ownerId: null }, data: { ownerId: adminId } }),
      () => db.fileNode.updateMany({ where: { ownerId: null }, data: { ownerId: adminId } }),
      () => db.shareLink.updateMany({ where: { ownerId: null }, data: { ownerId: adminId } }),
      () => db.project.updateMany({ where: { ownerId: null }, data: { ownerId: adminId } }),
      () => db.workProcess.updateMany({ where: { ownerId: null }, data: { ownerId: adminId } }),
      () => db.workDay.updateMany({ where: { ownerId: null }, data: { ownerId: adminId } }),
    ]
    for (const fn of assign) {
      try {
        await fn()
      } catch {
        /* bảng nào lỗi thì bỏ qua, không chặn migration */
      }
    }

    // --- 4) Dời storage: mọi entry cấp 1 (trừ users/) → users/<adminId>/ ---
    const base = baseStorageRoot()
    const usersDir = path.join(base, 'users')
    const usersDirExisted = existsSync(usersDir)
    try {
      mkdirSync(usersDir, { recursive: true })
    } catch {
      /* đã có */
    }
    ensureUserDirs(adminId)
    if (!usersDirExisted) {
      const entries = await fsp.readdir(base, { withFileTypes: true }).catch(() => [] as { name: string }[])
      for (const e of entries) {
        if (e.name === 'users' || e.name === PER_USER_MARKER) continue
        try {
          await fsp.rename(path.join(base, e.name), path.join(usersDir, adminId, e.name))
        } catch {
          /* entry lỗi bỏ qua — không chặn phần còn lại */
        }
      }
    }

    // --- 5) Ghi marker + flag trong RAM ---
    try {
      writeFileSync(markerFile(), new Date().toISOString())
    } catch {
      /* chỉ mục RAM vẫn được set — server tới sẽ thử lại an toàn (idempotent) */
    }
    g.__wosPerUserDone = true
  } catch (err) {
    console.error('[user-data] migration lỗi:', err)
  }
}
