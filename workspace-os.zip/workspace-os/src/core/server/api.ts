/**
 * WOS API Gateway — helpers chung cho mọi API route
 * Chuẩn hoá response, guard auth + module enabled + permission
 */
import { NextRequest, NextResponse } from 'next/server'
import { getSession, type SessionUser } from './auth'
import { getModuleRuntime } from './module-registry'
import { ensurePerUserData } from './user-data'
import { getUserPermissions } from './user-permissions'
import { ApiError } from './api-error'

export { ApiError }

export function ok<T>(data: T, init?: ResponseInit) {
  return NextResponse.json(data as object, init)
}

export function fail(message: string, status = 400) {
  return NextResponse.json({ error: message }, { status })
}

/** Bọc handler: bắt lỗi, trả JSON chuẩn — chạy lazy migration per-user 1 lần/process.
 *  Lỗi NỘI BỘ (Prisma/filesystem/SQLite/Node...) KHÔNG lộ chi tiết ra client khi chạy
 *  production (message có thể chứa đường dẫn hệ thống /opt/workspace-os/...):
 *    - ApiError       → luôn hiển thị (lỗi nghiệp vụ có chủ ý, tiếng Việt)
 *    - Error khác     → production: "Lỗi hệ thống"; dev (hoặc WOS_DEBUG_ERRORS=1): message gốc */
export async function handle(fn: () => Promise<NextResponse>): Promise<NextResponse> {
  try {
    await ensurePerUserData()
    return await fn()
  } catch (err: unknown) {
    if (err instanceof ApiError) return fail(err.message, err.status)
    console.error('[api]', err)
    const expose = process.env.NODE_ENV !== 'production' || process.env.WOS_DEBUG_ERRORS === '1'
    const msg = expose && err instanceof Error ? err.message : 'Lỗi hệ thống'
    return fail(msg, 500)
  }
}

/** IP client — CHỈ tin header proxy khi WOS_TRUST_PROXY được cấu hình RÕ RÀNG:
 *  - 'cloudflare': server nhận traffic qua Cloudflare Tunnel → dùng cf-connecting-ip
 *    (Cloudflare edge GHI ĐÈ header này — client giả mạo không có tác dụng)
 *  - 'forwarded' : server đứng sau reverse proxy tự quản (Caddy/nginx của bạn,
 *    proxy GHI ĐÈ/APPEND X-Forwarded-For) → lấy entry CUỐI (do proxy gần nhất thêm)
 *  - mặc định (rỗng/'none'): KHÔNG tin bất kỳ header nào client tự gửi —
 *    X-Forwarded-For giả "1.1.1.1, 1.1.1.2, ..." không thể xoay IP để lách rate limit.
 *    Rate limit khi đó dồn về bucket chung 'direct' + giới hạn theo username vẫn có hiệu lực. */
export function reqIp(req: NextRequest): string {
  const trust = (process.env.WOS_TRUST_PROXY || '').trim().toLowerCase()
  if (trust === 'cloudflare') {
    return req.headers.get('cf-connecting-ip')?.split(',')[0]?.trim() || 'unknown'
  }
  if (trust === 'forwarded' || trust === 'proxy' || trust === '1' || trust === 'true') {
    const xff = req.headers.get('x-forwarded-for')
    const parts = xff ? xff.split(',').map((s) => s.trim()).filter(Boolean) : []
    if (parts.length > 0) return parts[parts.length - 1]
    return req.headers.get('x-real-ip')?.trim() || 'unknown'
  }
  return 'direct'
}

export function reqUserAgent(req: NextRequest): string {
  return (req.headers.get('user-agent') || '').slice(0, 250)
}

/** Guard 401 khi chưa đăng nhập */
export async function requireSession(): Promise<SessionUser> {
  const session = await getSession()
  if (!session) throw new ApiError('Chưa đăng nhập', 401)
  return session
}

/** Guard admin (Users, Module Manager, Backup...) */
export async function requireAdmin(): Promise<SessionUser> {
  const session = await requireSession()
  if (session.role !== 'admin') throw new ApiError('Yêu cầu quyền quản trị', 403)
  return session
}

/**
 * Guard truy cập module: module phải đang bật + role được phép + QUYỀN RIÊNG TÀI KHOẢN
 * - admin  : toàn quyền
 * - member : đọc + ghi mọi module đang bật
 * - viewer : chỉ đọc
 * - Per-account: admin có thể giới hạn từng module và khoá File Manager
 */
export async function requireModule(moduleId: string, write = false): Promise<SessionUser> {
  const session = await requireSession()
  const runtime = await getModuleRuntime(moduleId)
  if (!runtime.enabled) throw new ApiError(`Module "${runtime.manifest.name}" đã bị tắt`, 404)
  if (session.role === 'admin') return session
  // quyền riêng theo tài khoản (whitelist module + khoá file manager)
  const perms = await getUserPermissions(session.id)
  if (moduleId === 'files' && perms?.allowFiles === false) {
    throw new ApiError('File Manager đã bị khoá cho tài khoản của bạn', 403)
  }
  if (perms?.modules && !perms.modules.includes(moduleId)) {
    throw new ApiError(`Tài khoản của bạn không được phép dùng module "${runtime.manifest.name}"`, 403)
  }
  const p = runtime.permissions
  const rolePerms = p[session.role] || []
  const canWrite = rolePerms.includes('*') || rolePerms.includes('write')
  const canRead = rolePerms.includes('*') || rolePerms.includes('read') || canWrite
  if (write && !canWrite) throw new ApiError('Bạn chỉ có quyền xem module này', 403)
  if (!write && !canRead) throw new ApiError('Bạn không có quyền truy cập module này', 403)
  return session
}

/** Đọc JSON body an toàn */
export async function readJson<T = Record<string, unknown>>(req: NextRequest): Promise<T> {
  try {
    return (await req.json()) as T
  } catch {
    throw new ApiError('Dữ liệu gửi lên không hợp lệ', 400)
  }
}

/** Parse ngày từ input client (ISO string / number) — Invalid Date → 400 thay vì
 *  để Prisma throw 500 lúc create/update. Dùng cho start/end/dueAt/... */
export function parseDate(value: unknown, label = 'Ngày'): Date {
  const d = toDate(value)
  if (!d) throw new ApiError(`${label} không hợp lệ`, 400)
  return d
}

/** parseDate cho trường TUỲ CHỌN: null/'' → null; giá trị có mà sai format → 400 */
export function parseDateOrNull(value: unknown, label = 'Ngày'): Date | null {
  if (value === null || value === undefined || value === '') return null
  return parseDate(value, label)
}

function toDate(value: unknown): Date | null {
  if (value instanceof Date) return Number.isNaN(value.getTime()) ? null : value
  if (typeof value === 'number' && Number.isFinite(value)) {
    const d = new Date(value)
    return Number.isNaN(d.getTime()) ? null : d
  }
  if (typeof value === 'string') {
    const s = value.trim()
    if (!s) return null
    const d = new Date(s)
    return Number.isNaN(d.getTime()) ? null : d
  }
  return null
}
