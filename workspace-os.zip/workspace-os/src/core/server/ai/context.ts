/**
 * WOS AI Context Collector — Lớp A (dữ liệu nghiệp vụ) + M4 (live context).
 *
 * Nguyên tắc từ thiết kế:
 *  - KHÔNG gửi toàn bộ dữ liệu trong mọi lượt chat: lấy THEO câu hỏi/nguồn được bật,
 *    giới hạn bản ghi + khoảng thời gian.
 *  - Tasks/Lịch/Weekly đọc TRỰC TIẾP từ database theo ownerId của session — tránh
 *    AI "nhớ" dữ liệu cũ (M4: mỗi lượt hỏi đọc trạng thái hiện tại).
 *  - Kiểm tra module bật + quyền tài khoản trước khi thu thập (giữ nguyên guard
 *    hệ thống: admin toàn quyền, member đọc/ghi, viewer chỉ đọc, per-account whitelist).
 */
import { db } from '@/lib/db'
import { getModuleRuntime } from '@/core/server/module-registry'
import { getUserPermissions } from '@/core/server/user-permissions'
import { getUserTimezone, isoDateInTz } from '@/core/server/datetime'
import type { SessionUser } from '@/core/server/auth'

export interface ContextSourceFlags {
  tasks: boolean
  calendar: boolean
  weekly: boolean
  projects: boolean
  activeWindow: boolean
  external: boolean
}

export const DEFAULT_SOURCES: ContextSourceFlags = {
  tasks: true,
  calendar: true,
  weekly: true,
  projects: false,
  activeWindow: true,
  external: true,
}

/** Snapshot Context Registry client gửi kèm (Lớp B — cửa sổ đang mở) */
export interface ActiveContextPayload {
  activeApp?: string
  activeRoute?: string
  openApps?: Array<{ id: string; title?: string; route?: string }>
  selection?: Record<string, unknown>
}

export interface CollectedContext {
  tasks?: unknown
  calendar?: unknown
  weekly?: unknown
  projects?: unknown
  activeWindow?: unknown
  external?: unknown
}

/** Module được phép đọc với tài khoản hiện tại? (mềm — tắt module thì bỏ nguồn, không throw) */
export async function canReadModule(session: SessionUser, moduleId: string): Promise<boolean> {
  try {
    const runtime = await getModuleRuntime(moduleId)
    if (!runtime.enabled) return false
    if (session.role === 'admin') return true
    const perms = await getUserPermissions(session.id)
    if (perms?.modules && !perms.modules.includes(moduleId)) return false
    const rolePerms = runtime.permissions[session.role] || []
    return rolePerms.includes('*') || rolePerms.includes('read') || rolePerms.includes('write')
  } catch {
    return false
  }
}

function clampLimit(v: unknown, max: number, dflt: number): number {
  const n = Number(v)
  if (!Number.isFinite(n) || n <= 0) return dflt
  return Math.min(Math.floor(n), max)
}

/** Ngày ISO (YYYY-MM-DD) hôm nay theo múi giờ user */
async function todayIso(): Promise<{ tz: string; today: string }> {
  const tz = await getUserTimezone()
  return { tz, today: isoDateInTz(new Date(), tz) }
}

function addDaysIso(iso: string, days: number): string {
  const d = new Date(`${iso}T00:00:00Z`)
  d.setUTCDate(d.getUTCDate() + days)
  return d.toISOString().slice(0, 10)
}

export interface CollectOptions {
  tasks?: { status?: 'open' | 'today' | 'all'; limit?: number }
  calendar?: { from?: string; to?: string; limit?: number } // YYYY-MM-DD
  weekly?: { from?: string; to?: string; limit?: number }
  projects?: { limit?: number }
}

/** Thu thập công việc (Tasks) — chỉ ownerId = session */
export async function collectTasks(session: SessionUser, opts: CollectOptions['tasks'] = {}): Promise<unknown> {
  if (!(await canReadModule(session, 'tasks'))) return { disabled: true }
  const limit = clampLimit(opts.limit, 50, 30)
  const whereBase = { ownerId: session.id }
  const status = opts.status || 'open'
  const { today } = await todayIso()
  const startOfToday = new Date(`${today}T00:00:00`)
  const where =
    status === 'open'
      ? { ...whereBase, status: { in: ['todo', 'doing'] as string[] } }
      : status === 'today'
        ? { ...whereBase, OR: [{ status: { in: ['todo', 'doing'] as string[] } }, { dueAt: { gte: startOfToday } }] }
        : whereBase
  const tasks = await db.task.findMany({
    where,
    orderBy: [{ status: 'asc' }, { priority: 'desc' }, { dueAt: 'asc' }],
    take: limit,
    select: {
      id: true, title: true, status: true, priority: true, dueAt: true, labels: true,
      projectId: true, completedAt: true,
      subtasks: { select: { title: true, done: true }, take: 10 },
      comments: { select: { content: true, authorName: true }, orderBy: { createdAt: 'desc' as const }, take: 3 },
    },
  })
  return {
    today,
    status,
    count: tasks.length,
    tasks: tasks.map((t) => ({
      title: t.title,
      status: t.status,
      priority: t.priority,
      dueAt: t.dueAt ? t.dueAt.toISOString() : null,
      labels: safeLabels(t.labels),
      subtasks: t.subtasks.filter((s) => !s.done).map((s) => s.title),
      recentComments: t.comments.map((c) => `${c.authorName}: ${c.content}`),
    })),
  }
}

function safeLabels(raw: string): string[] {
  try {
    const v = JSON.parse(raw || '[]')
    return Array.isArray(v) ? v.map(String) : []
  } catch {
    return []
  }
}

/** Thu thập lịch — mặc định hôm qua → +7 ngày, theo múi giờ user */
export async function collectCalendar(session: SessionUser, opts: CollectOptions['calendar'] = {}): Promise<unknown> {
  if (!(await canReadModule(session, 'calendar'))) return { disabled: true }
  const limit = clampLimit(opts.limit, 60, 40)
  const { tz, today } = await todayIso()
  const from = new Date(`${opts.from || addDaysIso(today, -1)}T00:00:00`)
  const to = new Date(`${opts.to || addDaysIso(today, 7)}T23:59:59`)
  const rows = await db.calendarEvent.findMany({
    where: { ownerId: session.id, start: { gte: from, lte: to } },
    orderBy: { start: 'asc' },
    take: limit,
    select: { title: true, description: true, location: true, category: true, allDay: true, start: true, end: true, recurring: true },
  })
  return {
    today, tz,
    range: { from: from.toISOString(), to: to.toISOString() },
    count: rows.length,
    events: rows.map((e) => ({
      title: e.title,
      start: e.start.toISOString(),
      end: e.end.toISOString(),
      allDay: e.allDay,
      category: e.category,
      location: e.location || undefined,
      description: e.description ? e.description.slice(0, 200) : undefined,
      recurring: e.recurring !== 'none' ? e.recurring : undefined,
    })),
  }
}

/** Thu thập công việc tuần (Weekly) — mặc định tuần hiện tại */
export async function collectWeekly(session: SessionUser, opts: CollectOptions['weekly'] = {}): Promise<unknown> {
  if (!(await canReadModule(session, 'weekly'))) return { disabled: true }
  const { today } = await todayIso()
  // Tuần bắt đầu Thứ 2 (chuẩn weekly/lib.ts)
  const dow = (new Date(`${today}T00:00:00Z`).getUTCDay() + 6) % 7
  const weekStart = opts.from || addDaysIso(today, -dow)
  const weekEnd = opts.to || addDaysIso(weekStart, 6)
  const days = await db.workDay.findMany({
    where: { ownerId: session.id, date: { gte: weekStart, lte: weekEnd } },
    orderBy: { date: 'asc' },
    include: {
      tasks: {
        orderBy: { order: 'asc' },
        take: clampLimit(opts.limit, 120, 80),
        select: { name: true, status: true, isPrep: true, quantity: true, parentId: true, processName: true, note: true },
      },
    },
  })
  const map = days.map((d) => ({
    date: d.date,
    offline: d.offline,
    offlineNote: d.offlineNote || undefined,
    note: d.note || undefined,
    tasks: d.tasks
      .filter((t) => !t.parentId) // việc lá + nhóm chính
      .slice(0, 25)
      .map((t) => ({
        name: t.processName ? `${t.processName}: ${t.name}` : t.name,
        status: t.status,
        isPrep: t.isPrep || undefined,
        quantity: t.quantity || undefined,
        note: t.note || undefined,
      })),
  }))
  const all = days.flatMap((d) => d.tasks)
  return {
    today,
    week: { from: weekStart, to: weekEnd },
    days: map,
    stats: {
      total: all.length,
      done: all.filter((t) => t.status === 'done').length,
      pending: all.filter((t) => t.status === 'pending').length,
      passed: all.filter((t) => t.status === 'passed').length,
    },
  }
}

/** Thu thập dự án đang chạy */
export async function collectProjects(session: SessionUser, opts: CollectOptions['projects'] = {}): Promise<unknown> {
  if (!(await canReadModule(session, 'projects'))) return { disabled: true }
  const limit = clampLimit(opts.limit, 20, 10)
  const rows = await db.project.findMany({
    where: { ownerId: session.id, status: 'active' },
    orderBy: { updatedAt: 'desc' },
    take: limit,
    select: { name: true, description: true, status: true, dueDate: true, startDate: true },
  })
  return {
    count: rows.length,
    projects: rows.map((p) => ({
      name: p.name,
      status: p.status,
      startDate: p.startDate ? p.startDate.toISOString() : null,
      dueDate: p.dueDate ? p.dueDate.toISOString() : null,
      description: p.description ? p.description.slice(0, 200) : undefined,
    })),
  }
}

/** Chuẩn hoá snapshot Context Registry (Lớp B) client gửi lên */
export function normalizeActiveContext(payload: ActiveContextPayload | null | undefined): unknown {
  if (!payload) return { disabled: true }
  const openApps = Array.isArray(payload.openApps) ? payload.openApps.slice(0, 15) : []
  return {
    activeApp: String(payload.activeApp || '').slice(0, 60),
    activeRoute: String(payload.activeRoute || '').slice(0, 120),
    openApps: openApps.map((a) => ({
      id: String(a.id || '').slice(0, 60),
      title: String(a.title || a.id || '').slice(0, 80),
      route: String(a.route || '').slice(0, 120),
    })),
    selection: payload.selection && typeof payload.selection === 'object' ? payload.selection : undefined,
  }
}

/** Thu thập TẤT CẢ nguồn theo flags — dùng cho lượt chat + preview context */
export async function collectContext(
  session: SessionUser,
  flags: ContextSourceFlags,
  active: ActiveContextPayload | null | undefined,
  opts: CollectOptions = {},
): Promise<{ context: CollectedContext; used: string[]; skipped: string[] }> {
  const context: CollectedContext = {}
  const used: string[] = []
  const skipped: string[] = []
  const flagMap = flags as unknown as Record<string, boolean>
  const jobs: Array<[string, boolean, () => Promise<unknown>]> = [
    ['tasks', flags.tasks, () => collectTasks(session, opts.tasks)],
    ['calendar', flags.calendar, () => collectCalendar(session, opts.calendar)],
    ['weekly', flags.weekly, () => collectWeekly(session, opts.weekly)],
    ['projects', flags.projects, () => collectProjects(session, opts.projects)],
    // nguồn mở rộng do module/plugin đăng ký qua registerContextSource()
    ...Array.from(contextSourceRegistry.values()).map(
      (def) => [def.key, flagMap[def.key] ?? def.defaultOn, () => def.collect(session)] as [string, boolean, () => Promise<unknown>],
    ),
  ]
  for (const [key, on, fn] of jobs) {
    if (!on) {
      skipped.push(key)
      continue
    }
    try {
      const data = await fn()
      if (data && (data as { disabled?: boolean }).disabled) skipped.push(key)
      else {
        ;(context as Record<string, unknown>)[key] = data
        used.push(key)
      }
    } catch (err) {
      console.warn(`[ai-context] ${key} lỗi:`, err)
      skipped.push(key)
    }
  }
  if (flags.activeWindow && active && (active.activeApp || (active.openApps && active.openApps.length))) {
    context.activeWindow = normalizeActiveContext(active)
    used.push('activeWindow')
  } else if (flags.activeWindow) {
    skipped.push('activeWindow')
  }
  // external: do route riêng quản lý (đánh dấu untrusted + consume) — gắn ở tầng prompt
  return { context, used, skipped }
}

/* ============================================================
 * EXTENSIBILITY — nguồn context do module/plugin ĐĂNG KÝ THÊM
 * (tương lai: notes, wiki, files,CRM… muốn cho AI đọc thì đăng ký ở đây)
 * ============================================================ */

export interface ContextSourceDefinition {
  /** khoá duy nhất — trùng khoá trong flags + CollectedContext */
  key: string
  /** nhãn hiển thị (UI preview/context panel) */
  label: string
  /** mô tả ngắn nguồn này cung cấp gì */
  description?: string
  /** bật mặc định khi user chưa cấu hình? */
  defaultOn?: boolean
  /** hàm thu thập — trả undefined/null/{disabled:true} để bỏ qua */
  collect: (session: SessionUser) => Promise<unknown>
}

const contextSourceRegistry = new Map<string, ContextSourceDefinition>()

/** Đăng ký (hoặc ghi đè) một nguồn context mở rộng — gọi khi import lần đầu */
export function registerContextSource(def: ContextSourceDefinition): void {
  if (!def.key || typeof def.collect !== 'function') throw new Error('ContextSourceDefinition không hợp lệ')
  contextSourceRegistry.set(def.key, def)
}

/** Toàn bộ nguồn mở rộng đã đăng ký (cho API mô tả + docs) */
export function registeredContextSources(): ContextSourceDefinition[] {
  return Array.from(contextSourceRegistry.values())
}

/** Danh sách nguồn đầy đủ = built-in + mở rộng — cho UI render động */
export function contextSourceCatalog(): Array<{ key: string; label: string; description?: string; builtin: boolean }> {
  const builtins: Array<{ key: string; label: string; description?: string; builtin: boolean }> = [
    { key: 'tasks', label: 'Công việc', description: 'Việc còn tồn, mức ưu tiên, hạn chót', builtin: true },
    { key: 'calendar', label: 'Lịch', description: 'Sự kiện ±1 tuần', builtin: true },
    { key: 'weekly', label: 'Việc tuần', description: 'Tiến độ từng ngày trong tuần', builtin: true },
    { key: 'projects', label: 'Dự án', description: 'Dự án đang chạy', builtin: true },
    { key: 'activeWindow', label: 'App đang mở', description: 'Cửa sổ đang xem trên desktop', builtin: true },
    { key: 'external', label: 'Tab ngoài', description: 'Context extension gửi (không đáng tin)', builtin: true },
  ]
  for (const def of contextSourceRegistry.values()) {
    builtins.push({ key: def.key, label: def.label, description: def.description, builtin: false })
  }
  return builtins
}
