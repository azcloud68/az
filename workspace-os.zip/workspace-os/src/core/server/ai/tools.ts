/**
 * WOS AI Tools (Giai đoạn 3) — tool calling CÓ KIỂM SOÁT.
 *
 * Grok được phép yêu cầu server thực thi các tool đã ĐỊNH NGHĨA SẴN:
 *   get_tasks / get_calendar_events / get_weekly_tasks /
 *   search_workspace_memory / get_active_workspace_context
 *
 * Server kiểm tra quyền → thực thi (userId-scoped, giới hạn bản ghi) → trả kết quả.
 * KHÔNG cho AI gửi URL tùy ý, KHÔNG truy cập database trực tiếp, KHÔNG thao tác ghi.
 */
import type { AiToolDef, AiToolCall } from './provider'
import type { SessionUser } from '@/core/server/auth'
import { collectTasks, collectCalendar, collectWeekly, collectProjects, normalizeActiveContext, type ActiveContextPayload, type CollectOptions } from './context'
import { retrieveRelevantMemories } from './memory'

export const AI_TOOLS: AiToolDef[] = [
  {
    type: 'function',
    function: {
      name: 'get_tasks',
      description:
        'Đọc danh sách công việc (Tasks) hiện tại của người dùng. Dùng khi câu hỏi nhắc đến việc cần làm, việc còn tồn, việc đến hạn, việc khẩn cấp.',
      parameters: {
        type: 'object',
        properties: {
          status: { type: 'string', enum: ['open', 'today', 'all'], description: 'open = chưa xong (mặc định); today = liên quan hôm nay; all = mọi trạng thái' },
          limit: { type: 'number', description: 'Số bản ghi tối đa (1-50, mặc định 20)' },
        },
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'get_calendar_events',
      description:
        'Đọc sự kiện lịch của người dùng trong khoảng thời gian. Dùng khi hỏi lịch hôm nay/ngày mai/tuần này, cần chuẩn bị gì.',
      parameters: {
        type: 'object',
        properties: {
          from: { type: 'string', description: 'Ngày bắt đầu YYYY-MM-DD (mặc định hôm qua)' },
          to: { type: 'string', description: 'Ngày kết thúc YYYY-MM-DD (mặc định +7 ngày)' },
          limit: { type: 'number', description: 'Số sự kiện tối đa (1-60)' },
        },
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'get_weekly_tasks',
      description:
        'Đọc công việc tuần (Weekly) — việc theo từng ngày, trạng thái done/pending/passed, ngày nghỉ. Dùng khi hỏi tiến độ tuần, việc tuần này còn gì.',
      parameters: {
        type: 'object',
        properties: {
          from: { type: 'string', description: 'Ngày bắt đầu YYYY-MM-DD (mặc định đầu tuần hiện tại)' },
          to: { type: 'string', description: 'Ngày kết thúc YYYY-MM-DD (mặc định cuối tuần)' },
        },
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'search_workspace_memory',
      description:
        'Tìm trong bộ nhớ dài hạn của người dùng (sở thích, quyết định, dự án, việc chưa xong). Dùng khi câu hỏi nhắc thông tin đã trao đổi trước đây.',
      parameters: {
        type: 'object',
        properties: { query: { type: 'string', description: 'Từ khóa tìm kiếm' } },
        required: ['query'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'get_active_workspace_context',
      description:
        'Xem app nào đang mở trên desktop Workspace OS và route hiện tại. Dùng khi người dùng hỏi về "cái đang mở", "tab này".',
      parameters: { type: 'object', properties: {} },
    },
  },
]

export interface ToolExecContext {
  session: SessionUser
  activeContext: ActiveContextPayload | null | undefined
}

/* ============================================================
 * EXTENSIBILITY — tool AI do module/plugin ĐĂNG KÝ THÊM
 * (tương lai: tạo việc từ chat, đọc notes/wiki, tìm file…)
 * ============================================================ */

export interface AiToolRegistration {
  def: AiToolDef
  /** thực thi tool — trả chuỗi (JSON) đưa vào vòng lặp chat */
  execute: (args: Record<string, unknown>, ctx: ToolExecContext) => Promise<string>
}

const extraToolRegistry = new Map<string, AiToolRegistration>()

/** Đăng ký tool AI mới — tự xuất hiện trong whitelist vòng chat kế tiếp */
export function registerAiTool(reg: AiToolRegistration): void {
  const name = reg.def?.function?.name
  if (!name || typeof reg.execute !== 'function') throw new Error(`AiToolRegistration không hợp lệ (${name || 'thiếu name'})`)
  extraToolRegistry.set(name, reg)
}

/** Toàn bộ tool khả dụng = built-in + đăng ký — dùng thay AI_TOOLS trực tiếp */
export function availableTools(): AiToolDef[] {
  return [...AI_TOOLS, ...Array.from(extraToolRegistry.values()).map((r) => r.def)]
}

/** Tool đã đăng ký thêm (cho docs/API mô tả) */
export function registeredAiTools(): AiToolRegistration[] {
  return Array.from(extraToolRegistry.values())
}

/** Thực thi 1 tool call (server-side, permission-checked bên trong collector) */
export async function executeTool(name: string, argsJson: string, ctx: ToolExecContext): Promise<string> {
  let args: Record<string, unknown> = {}
  try {
    args = argsJson ? (JSON.parse(argsJson) as Record<string, unknown>) : {}
  } catch {
    return JSON.stringify({ error: 'Tham số tool không phải JSON hợp lệ' })
  }
  const opts: CollectOptions = {}
  try {
    switch (name) {
      case 'get_tasks':
        return JSON.stringify(
          await collectTasks(ctx.session, {
            status: ['open', 'today', 'all'].includes(String(args.status)) ? (args.status as 'open' | 'today' | 'all') : 'open',
            limit: Number(args.limit) || 20,
          }),
        )
      case 'get_calendar_events':
        return JSON.stringify(
          await collectCalendar(ctx.session, {
            from: typeof args.from === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(args.from) ? args.from : undefined,
            to: typeof args.to === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(args.to) ? args.to : undefined,
            limit: Number(args.limit) || 30,
          }),
        )
      case 'get_weekly_tasks':
        return JSON.stringify(
          await collectWeekly(ctx.session, {
            from: typeof args.from === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(args.from) ? args.from : undefined,
            to: typeof args.to === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(args.to) ? args.to : undefined,
          }),
        )
      case 'search_workspace_memory': {
        const query = String(args.query || '').slice(0, 200)
        if (!query) return JSON.stringify({ error: 'Thiếu query' })
        const rows = await retrieveRelevantMemories(ctx.session.id, query, 10)
        return JSON.stringify({
          count: rows.length,
          memories: rows.map((m) => ({ category: m.category, content: m.content, confirmed: m.confirmed, updatedAt: m.updatedAt })),
        })
      }
      case 'get_active_workspace_context':
        return JSON.stringify(normalizeActiveContext(ctx.activeContext))
      case 'get_projects':
        return JSON.stringify(await collectProjects(ctx.session, { limit: 10 }))
      default: {
        // tool mở rộng do module/plugin đăng ký qua registerAiTool()
        const extra = extraToolRegistry.get(name)
        if (extra) {
          try {
            return await extra.execute(args, ctx)
          } catch (err) {
            console.warn(`[ai-tool] ${name} (extension) lỗi:`, err)
            return JSON.stringify({ error: 'Lỗi thực thi tool mở rộng phía server' })
          }
        }
        return JSON.stringify({ error: `Tool "${name}" không tồn tại` })
      }
    }
  } catch (err) {
    console.warn(`[ai-tool] ${name} lỗi:`, err)
    return JSON.stringify({ error: 'Lỗi thực thi tool phía server' })
  }
}

/** Vòng lặp tool calling: gọi AI → có tool_calls → thực thi → gửi kết quả → lặp (tối đa 4 vòng) */
export async function runWithTools(
  baseMessages: import('./provider').AiChatMessage[],
  ctx: ToolExecContext,
  complete: (messages: import('./provider').AiChatMessage[]) => Promise<import('./provider').AiCompleteResult>,
): Promise<{ result: import('./provider').AiCompleteResult; toolTrace: Array<{ name: string; args: string; ok: boolean }>; messages: import('./provider').AiChatMessage[] }> {
  let messages = [...baseMessages]
  const toolTrace: Array<{ name: string; args: string; ok: boolean }> = []
  const MAX_ROUNDS = 4
  for (let round = 0; round < MAX_ROUNDS; round++) {
    const result = await complete(messages)
    if (!result.toolCalls || result.toolCalls.length === 0) {
      return { result, toolTrace, messages }
    }
    // thêm tin nhắn assistant chứa tool_calls
    messages.push({
      role: 'assistant',
      content: result.content || '',
      tool_calls: result.toolCalls,
    })
    for (const call of result.toolCalls) {
      const out = await executeTool(call.function.name, call.function.arguments, ctx)
      const ok = !out.includes('"error"')
      toolTrace.push({ name: call.function.name, args: call.function.arguments.slice(0, 200), ok })
      messages.push({ role: 'tool', content: out.slice(0, 12000), tool_call_id: call.id, name: call.function.name })
    }
    // vòng sau AI thấy kết quả tool → trả lời cuối
  }
  // vượt số vòng → gọi lần cuối không tools
  const final = await complete(messages)
  return { result: final, toolTrace, messages }
}

export function toolCallsOf(calls: AiToolCall[]): string {
  return calls.map((c) => c.function.name).join(', ')
}
