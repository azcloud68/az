/**
 * WOS AI Memory Service — bộ nhớ 4 tầng theo thiết kế:
 *
 *  M1 Short-term    : N tin nhắn gần nhất (query AIMessage theo maxRecentMessages)
 *  M2 Summary       : khi tổng tin nhắn vượt ngưỡng → gộp các lượt CŨ thành 1 bản
 *                     tóm tắt (mục tiêu, quyết định, việc đang làm, vấn đề chưa giải quyết)
 *  M3 Long-term     : bản ghi độc lập theo category (preference/project/decision/pending/fact),
 *                     có nguồn gốc, độ tin cậy, phiên bản + lịch sử thay đổi. Mâu thuẫn:
 *                     tạo bản mới supersede bản cũ, KHÔNG xoá âm thầm.
 *  M4 Live context  : tasks/lịch đọc trực tiếp API mỗi lượt (ở context.ts — không cache)
 *
 * Truy xuất bản đầu: từ khóa + phân loại (chưa cần embeddings — theo số lượng memory
 * thực tế của 1 người dùng, keyword scoring là đủ; nâng cấp semantic search sau).
 */
import { db } from '@/lib/db'
import { aiText } from './provider'

export const MEMORY_CATEGORIES = ['preference', 'project', 'decision', 'pending', 'fact'] as const
export type MemoryCategory = (typeof MEMORY_CATEGORIES)[number]

export const CATEGORY_LABELS: Record<string, string> = {
  preference: 'Sở thích / thói quen',
  project: 'Dự án đang làm',
  decision: 'Quyết định',
  pending: 'Việc chưa xong',
  fact: 'Thông tin',
}

export interface MemoryDraft {
  category: string
  content: string
  confidence?: number
}

/** Tách câu hỏi thành các token từ khóa (bỏ stopwords tiếng Việt + tiếng Anh phổ biến) */
const STOPWORDS = new Set([
  'của', 'và', 'là', 'có', 'được', 'cho', 'với', 'các', 'cái', 'này', 'khi', 'một', 'những', 'tôi', 'em',
  'anh', 'bạn', 'hôm', 'mai', 'qua', 'nay', 'thì', 'ra', 'vào', 'từ', 'bị', 'vì', 'nên', 'sau', 'trước',
  'what', 'when', 'where', 'which', 'who', 'whom', 'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be',
  'to', 'of', 'in', 'on', 'for', 'with', 'and', 'or', 'do', 'does', 'did', 'my', 'me', 'i', 'you',
])

function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .normalize('NFC')
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .split(/\s+/)
    .filter((t) => t.length >= 2 && !STOPWORDS.has(t))
    .slice(0, 40)
}

/** Truy xuất memory liên quan đến câu hỏi — chấm điểm từ khóa + pinned/confirmed cộng thêm */
export async function retrieveRelevantMemories(userId: string, question: string, limit = 20) {
  const rows = await db.aIMemory.findMany({
    where: { userId, supersededBy: '' },
    orderBy: [{ pinned: 'desc' }, { updatedAt: 'desc' }],
    take: 200,
  })
  const tokens = tokenize(question)
  const scored = rows.map((m) => {
    const lower = m.content.toLowerCase()
    let score = 0
    for (const t of tokens) if (lower.includes(t)) score += 2
    if (m.pinned) score += 3
    if (m.confirmed) score += 1
    score += Math.min(2, m.confidence / 50)
    return { m, score }
  })
  return scored
    .filter((s) => (s.m.pinned ? true : s.score > 0 || tokens.length === 0))
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map((s) => s.m)
}

/** Thêm 1 memory mới (dùng chung cho manual + AI extract). Mâu thuẫn cùng category:
 *  nếu bản ghi cũ tương tự ≥ 70% giống → supersede (giữ history) thay vì trùng lặp. */
export async function addMemory(
  userId: string,
  draft: MemoryDraft,
  source = 'manual',
): Promise<{ id: string; superseded?: string }> {
  const category = MEMORY_CATEGORIES.includes(draft.category as MemoryCategory) ? draft.category : 'fact'
  const content = draft.content.trim().slice(0, 500)
  if (!content) throw new Error('Nội dung bộ nhớ trống')

  // dò bản tương tự (chuỗi con / Jaccard nhẹ) để supersede
  const existing = await db.aIMemory.findMany({
    where: { userId, category, supersededBy: '' },
    orderBy: { updatedAt: 'desc' },
    take: 100,
  })
  const tokens = new Set(tokenize(content))
  for (const old of existing) {
    const oldTokens = new Set(tokenize(old.content))
    let inter = 0
    for (const t of tokens) if (oldTokens.has(t)) inter++
    const union = new Set([...tokens, ...oldTokens]).size
    const sim = union ? inter / union : 0
    if (sim >= 0.7 || old.content.toLowerCase() === content.toLowerCase()) {
      // mâu thuẫn/thay thế → bản mới supersede bản cũ, bản cũ giữ nguyên để truy vết
      const created = await db.aIMemory.create({
        data: {
          userId,
          category,
          content,
          source,
          confirmed: false,
          confidence: Math.max(30, Math.min(100, draft.confidence ?? 60)),
          history: JSON.stringify([{ at: new Date().toISOString(), from: old.content, to: content, reason: 'supersede' }]),
        },
      })
      await db.aIMemory.update({ where: { id: old.id }, data: { supersededBy: created.id } })
      return { id: created.id, superseded: old.id }
    }
  }
  const created = await db.aIMemory.create({
    data: {
      userId,
      category,
      content,
      source,
      confirmed: source === 'manual', // người dùng tự viết = đã xác nhận
      confidence: Math.max(30, Math.min(100, draft.confidence ?? (source === 'manual' ? 90 : 60))),
    },
  })
  return { id: created.id }
}

/** M2 — Tự tóm tắt khi hội thoại dài: gộp các lượt CŨ (trước summaryFromMsg mới) vào summary */
export async function autoSummarizeConversation(
  conversationId: string,
  userSetting: { provider?: string; model?: string; summarizeThreshold?: number },
): Promise<{ summarized: boolean; reason?: string }> {
  const conv = await db.aIConversation.findUnique({ where: { id: conversationId } })
  if (!conv) return { summarized: false, reason: 'not_found' }
  const threshold = Math.max(8, userSetting.summarizeThreshold || 20)
  // số tin nhắn CHƯA được gộp vào summary
  const unsummarized = conv.messageCount - conv.summaryFromMsg
  if (unsummarized < threshold) return { summarized: false, reason: 'under_threshold' }

  // lấy các lượt chưa gộp (bỏ 4 lượt cuối làm ngữ cảnh gần)
  const keepRecent = 4
  const msgs = await db.aIMessage.findMany({
    where: { conversationId },
    orderBy: { createdAt: 'asc' },
    skip: Math.max(0, conv.summaryFromMsg),
  })
  const toSummarize = msgs.slice(0, Math.max(0, msgs.length - keepRecent))
  if (toSummarize.length < 4) return { summarized: false, reason: 'too_few' }

  const transcript = toSummarize
    .filter((m) => m.role === 'user' || m.role === 'assistant')
    .map((m) => `${m.role === 'user' ? 'NGƯỜI DÙNG' : 'TRỢ LÝ'}: ${m.content.slice(0, 1500)}`)
    .join('\n\n')
    .slice(0, 24000)

  const system =
    'Bạn là bộ máy tinh gọn bộ nhớ hội thoại của Workspace OS. Viết lại bản tóm tắt TÍCH LŨY bằng tiếng Việt, ' +
    'gồm 4 mục: Mục tiêu cuộc trò chuyện; Quyết định đã thống nhất; Việc đang làm; Vấn đề chưa giải quyết. ' +
    'Nếu đã có bản tóm tắt cũ, GỘP thêm thông tin mới vào (không mất thông tin quan trọng của bản cũ). ' +
    'Tối đa 250 từ, chỉ giữ thông tin có thật trong hội thoại, không suy diễn.'
  const user =
    (conv.summary ? `BẢN TÓM TẮT HIỆN TẠI:\n${conv.summary}\n\n` : '') +
    `CÁC LƯỢT TRÒ CHUYỆN MỚI:\n${transcript}`

  try {
    const summary = await aiText(system, user, userSetting)
    if (!summary) return { summarized: false, reason: 'empty' }
    await db.aIConversation.update({
      where: { id: conversationId },
      data: {
        summary: summary.slice(0, 4000),
        summaryFromMsg: conv.summaryFromMsg + toSummarize.length,
      },
    })
    return { summarized: true }
  } catch (err) {
    console.warn('[ai-memory] summarize lỗi:', err)
    return { summarized: false, reason: 'provider_error' }
  }
}

/** M3 — Trích xuất memory từ hội thoại (AI đề xuất, người dùng xác nhận sau) */
export async function extractMemories(
  conversationId: string,
  userSetting: { provider?: string; model?: string },
): Promise<{ extracted: number }> {
  const conv = await db.aIConversation.findUnique({ where: { id: conversationId } })
  if (!conv) return { extracted: 0 }
  const msgs = await db.aIMessage.findMany({
    where: { conversationId, role: { in: ['user', 'assistant'] } },
    orderBy: { createdAt: 'desc' },
    take: 8,
  })
  if (msgs.length < 3) return { extracted: 0 }
  const transcript = msgs
    .reverse()
    .map((m) => `${m.role === 'user' ? 'NGƯỜI DÙNG' : 'TRỢ LÝ'}: ${m.content.slice(0, 1200)}`)
    .join('\n')
    .slice(0, 16000)

  const system =
    'Trích xuất các THÔNG TIN ĐÁNG NHỚ dài hạn từ hội thoại: sở thích làm việc, dự án đang làm, ' +
    'quyết định đã thống nhất, việc chưa xong, dữ kiện ổn định. Chỉ trả JSON thuần: ' +
    '{"memories":[{"category":"preference|project|decision|pending|fact","content":"...","confidence":0-100}]}. ' +
    'Tối đa 4 bản ghi, mỗi bản dưới 200 ký tự, tiếng Việt. Bỏ qua thông tin chỉ đúng trong khoảnh khắc. ' +
    'Không có gì đáng nhớ → trả {"memories":[]}.'
  try {
    const raw = await aiText(system, transcript, userSetting)
    const jsonText = raw.slice(raw.indexOf('{'), raw.lastIndexOf('}') + 1)
    const parsed = JSON.parse(jsonText) as { memories?: MemoryDraft[] }
    const list = Array.isArray(parsed.memories) ? parsed.memories.slice(0, 4) : []
    let n = 0
    for (const item of list) {
      if (!item || typeof item.content !== 'string' || !item.content.trim()) continue
      await addMemory(
        conv.userId,
        { category: String(item.category || 'fact'), content: item.content, confidence: Number(item.confidence) || 55 },
        `conversation:${conversationId}`,
      )
      n++
    }
    return { extracted: n }
  } catch (err) {
    console.warn('[ai-memory] extract lỗi:', err)
    return { extracted: 0 }
  }
}
