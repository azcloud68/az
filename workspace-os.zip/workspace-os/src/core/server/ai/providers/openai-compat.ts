/**
 * Provider "openai-compat" — CẦU NỐI TÍCH HỢP AI TƯƠNG LAI.
 *
 * Mọi dịch vụ AI có endpoint /chat/completions chuẩn OpenAI đều chạy được
 * NGAY KHÔNG CẦN VIẾT CODE — chỉ cần 3 biến môi trường trong .env:
 *
 *   AI_COMPAT_BASE_URL='http://localhost:11434/v1'   # Ollama local
 *   AI_COMPAT_API_KEY='ollama'                       # key (Ollama không cần thật)
 *   AI_COMPAT_MODEL='llama3.1:8b'                    # model mặc định
 *   AI_COMPAT_LABEL='Ollama local'                   # (tuỳ chọn) tên hiển thị
 *
 * ─────────────────── Các dịch vụ đã kiểm chứng chuẩn này ───────────────────
 *  Dịch vụ        | BASE_URL                         | Ghi chú
 *  ---------------|----------------------------------|--------------------------
 *  Ollama local   | http://localhost:11434/v1        | AI cá nhân free, offline
 *  LM Studio      | http://localhost:1234/v1         | Chạy model tải về
 *  OpenRouter     | https://openrouter.ai/api/v1     | 100+ model, trả theo lượng dùng
 *  Groq           | https://api.groq.com/openai/v1   | Siêu nhanh (Llama…)
 *  DeepSeek       | https://api.deepseek.com/v1      | Rẻ, tiếng Việt tốt
 *  Together AI    | https://api.together.xyz/v1      |
 *  vLLM self-host | http://<máy>:8000/v1             | GPU server riêng
 *  LiteLLM proxy  | http://<máy>:4000/v1             | Gateway đa provider
 *  Azure OpenAI   | gateway tương thích              | Qua LiteLLM/vLLM
 * ───────────────────────────────────────────────────────────────────────────
 * Chưa cấu hình → provider tự ẩn (isConfigured() false), hệ thống dùng provider khác.
 */
import type { AiProvider } from './types'
import type { AiCompleteOptions, AiCompleteResult, AiToolCall } from '../provider'

const BASE = (process.env.AI_COMPAT_BASE_URL || '').trim().replace(/\/+$/, '')
const KEY = (process.env.AI_COMPAT_API_KEY || '').trim()
const MODEL = (process.env.AI_COMPAT_MODEL || '').trim()
const LABEL = (process.env.AI_COMPAT_LABEL || '').trim()

function compatLabel(): string {
  if (LABEL) return LABEL
  // tự suy tên từ BASE_URL cho thân thiện
  try {
    const host = new URL(BASE).hostname
    if (host.includes('openrouter')) return 'OpenRouter (tương thích OpenAI)'
    if (host.includes('groq')) return 'Groq (tương thích OpenAI)'
    if (host.includes('deepseek')) return 'DeepSeek (tương thích OpenAI)'
    if (host.includes('together')) return 'Together AI (tương thích OpenAI)'
    if (host.includes('localhost') || host.includes('127.0.0.1')) return `AI local (${host})`
    return `OpenAI-compatible (${host})`
  } catch {
    return 'OpenAI-compatible'
  }
}

function fetchWithTimeout(url: string, init: RequestInit, ms = 120_000): Promise<Response> {
  return Promise.race([
    fetch(url, init),
    new Promise<Response>((_, reject) => setTimeout(() => reject(new Error('Hết thời gian chờ AI phản hồi')), ms)),
  ])
}

export const openaiCompatProvider: AiProvider = {
  id: 'openai-compat',
  label: compatLabel(),
  supportsTools: true, // chuẩn OpenAI có function calling

  isConfigured() {
    return Boolean(BASE && MODEL) // Ollama không cần key thật — chỉ cần BASE+MODEL
  },

  defaultModel() {
    return MODEL || 'gpt-4o-mini'
  },

  async listModels() {
    if (!BASE) return []
    try {
      const headers: Record<string, string> = { 'content-type': 'application/json' }
      if (KEY) headers.authorization = `Bearer ${KEY}`
      const res = await fetchWithTimeout(`${BASE}/models`, { headers }, 15_000)
      if (!res.ok) return MODEL ? [MODEL] : []
      const json = (await res.json()) as { data?: Array<{ id?: string }> }
      const ids = (json.data || []).map((m) => m.id || '').filter(Boolean)
      return ids.length > 0 ? ids : MODEL ? [MODEL] : []
    } catch {
      return MODEL ? [MODEL] : []
    }
  },

  async complete(opts: AiCompleteOptions, model: string): Promise<AiCompleteResult> {
    if (!BASE) throw new Error('Chưa cấu hình AI_COMPAT_BASE_URL cho provider openai-compat')
    const body: Record<string, unknown> = {
      model: model || MODEL,
      messages: opts.messages.map((m) => ({
        role: m.role,
        content: m.content,
        ...(m.tool_calls ? { tool_calls: m.tool_calls } : {}),
        ...(m.tool_call_id ? { tool_call_id: m.tool_call_id } : {}),
        ...(m.name ? { name: m.name } : {}),
      })),
      temperature: opts.temperature ?? 0.7,
      max_tokens: opts.maxTokens ?? 2048,
    }
    if (opts.tools && opts.tools.length > 0) {
      body.tools = opts.tools
      body.tool_choice = 'auto'
    }
    const headers: Record<string, string> = { 'content-type': 'application/json' }
    if (KEY) headers.authorization = `Bearer ${KEY}`
    const res = await fetchWithTimeout(`${BASE}/chat/completions`, {
      method: 'POST',
      headers,
      body: JSON.stringify(body),
    })
    if (!res.ok) {
      const text = await res.text().catch(() => '')
      throw new Error(`AI provider "${compatLabel()}" lỗi ${res.status}: ${text.slice(0, 300)}`)
    }
    const json = (await res.json()) as {
      choices?: Array<{ message?: { content?: string; tool_calls?: AiToolCall[] } }>
      usage?: { prompt_tokens?: number; completion_tokens?: number }
    }
    const msg = json.choices?.[0]?.message
    return {
      content: msg?.content || '',
      toolCalls: (msg?.tool_calls || []) as AiToolCall[],
      model: model || MODEL,
      provider: 'openai-compat',
      usage: { prompt: json.usage?.prompt_tokens, completion: json.usage?.completion_tokens },
    }
  },
}
