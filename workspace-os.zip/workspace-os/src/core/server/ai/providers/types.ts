/**
 * WOS AI Provider Contract — hợp đồng để thêm bộ máy AI mới vào Workspace OS.
 *
 * ═══════════════════════════════════════════════════════════════════════
 *  CÁCH THÊM PROVIDER AI MỚI (xem docs/ai-integration-guide.md)
 * ═══════════════════════════════════════════════════════════════════════
 *  1. Tạo file `src/core/server/ai/providers/<tên>.ts` implement AiProvider
 *  2. Gọi registerProvider(...) trong `providers/index.ts`
 *  3. Xong — provider tự xuất hiện trong /api/ai/settings + UI plugin.
 *
 *  NHANH NHẤT — KHÔNG cần viết code: mọi dịch vụ tương thích OpenAI
 *  (Ollama, LM Studio, OpenRouter, Groq, DeepSeek, vLLM, LiteLLM…)
 *  chỉ cần cấu hình 3 biến môi trường — xem providers/openai-compat.ts.
 */
import type { AiChatMessage, AiToolDef, AiCompleteOptions, AiCompleteResult } from '../provider'

/** Thông tin hiển thị của provider cho UI (KHÔNG chứa key/bí mật) */
export interface AiProviderInfo {
  id: string                    // định danh lưu trong AISetting.provider
  label: string                 // tên hiển thị (vd "Grok — x.ai")
  configured: boolean           // đã cấu hình đủ để dùng?
  defaultModel: string
  supportsTools: boolean        // có hỗ trợ function calling?
  envHint?: string              // gợi ý cấu hình khi chưa configured
}

/** Hợp đồng provider — mọi bộ máy AI phải implement đủ các method này */
export interface AiProvider {
  readonly id: string
  readonly label: string
  readonly supportsTools: boolean

  /** Đã cấu hình hợp lệ? (vd có API key) — false → hệ thống tự bỏ qua */
  isConfigured(): boolean

  /** Model mặc định khi user không chọn */
  defaultModel(): string

  /** Danh sách model khả dụng (tuỳ chọn — dùng cho UI chọn động) */
  listModels?(): Promise<string[]>

  /** Thực hiện 1 lượt chat completion */
  complete(opts: AiCompleteOptions, model: string): Promise<AiCompleteResult>
}
