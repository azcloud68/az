/**
 * Provider "xai" — Grok API (x.ai), chuẩn OpenAI chat completions.
 * Suy luận chính theo thiết kế: server proxy kiểm tra đăng nhập + rate limit
 * rồi mới chuyển tiếp. Key chỉ đọc từ env XAI_API_KEY (không lưu DB, không xuống client).
 */
import type { AiProvider } from './types'
import type { AiCompleteOptions, AiCompleteResult, AiToolCall } from '../provider'

const XAI_DEFAULT_MODEL = process.env.XAI_MODEL || 'grok-4-fast'
const XAI_BASE = (process.env.XAI_BASE_URL || 'https://api.x.ai/v1').replace(/\/+$/, '')

export function xaiKey(): string {
  return (process.env.XAI_API_KEY || '').trim()
}

/** Timeout fetch — Orange Pi 2GB RAM không treo request quá lâu */
function fetchWithTimeout(url: string, init: RequestInit, ms = 120_000): Promise<Response> {
  return Promise.race([
    fetch(url, init),
    new Promise<Response>((_, reject) => setTimeout(() => reject(new Error('Hết thời gian chờ AI phản hồi')), ms)),
  ])
}

export const xaiProvider: AiProvider = {
  id: 'xai',
  label: 'Grok — x.ai',
  supportsTools: true,

  isConfigured() {
    return Boolean(xaiKey())
  },

  defaultModel() {
    return XAI_DEFAULT_MODEL
  },

  async listModels() {
    const key = xaiKey()
    if (!key) return [XAI_DEFAULT_MODEL]
    try {
      const res = await fetchWithTimeout(`${XAI_BASE}/models`, { headers: { authorization: `Bearer ${key}` } }, 15_000)
      if (!res.ok) return [XAI_DEFAULT_MODEL]
      const json = (await res.json()) as { data?: Array<{ id?: string }> }
      const ids = (json.data || []).map((m) => m.id || '').filter(Boolean)
      return ids.length > 0 ? ids : [XAI_DEFAULT_MODEL]
    } catch {
      return [XAI_DEFAULT_MODEL]
    }
  },

  async complete(opts: AiCompleteOptions, model: string): Promise<AiCompleteResult> {
    const key = xaiKey()
    if (!key) throw new Error('Server chưa cấu hình XAI_API_KEY (Grok)')
    const body: Record<string, unknown> = {
      model,
      messages: opts.messages.map((m) => ({
        role: m.role,
        content: m.content,
        ...(m.tool_calls ? { tool_calls: m.tool_calls } : {}),
        ...(m.tool_call_id ? { tool_call_id: m.tool_call_id } : {}),
        ...(m.name ? { name: m.name } : {}),
      })),
      temperature: opts.temperature ?? 0.7,
      max_tokens: opts.maxTokens ?? 2048,
    }
    if (opts.tools && opts.tools.length > 0) {
      body.tools = opts.tools
      body.tool_choice = 'auto'
    }
    const res = await fetchWithTimeout(`${XAI_BASE}/chat/completions`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${key}` },
      body: JSON.stringify(body),
    })
    if (!res.ok) {
      const text = await res.text().catch(() => '')
      throw new Error(`Grok API lỗi ${res.status}: ${text.slice(0, 300)}`)
    }
    const json = (await res.json()) as {
      choices?: Array<{ message?: { content?: string; tool_calls?: AiToolCall[] } }>
      usage?: { prompt_tokens?: number; completion_tokens?: number }
    }
    const msg = json.choices?.[0]?.message
    return {
      content: msg?.content || '',
      toolCalls: (msg?.tool_calls || []) as AiToolCall[],
      model,
      provider: 'xai',
      usage: { prompt: json.usage?.prompt_tokens, completion: json.usage?.completion_tokens },
    }
  },
}
