/**
 * Provider "groq" — Groq Cloud API (api.groq.com), chuẩn OpenAI chat completions.
 *
 * SỬA LỖI 4: trước đây Groq chỉ dùng được qua 3 biến env AI_COMPAT_* (mờ mắt với
 * người dùng) và KHÔNG có chỗ nhập key trong UI, model cũng không rõ ràng.
 * Giờ:
 *   - Key lấy từ env GROQ_API_KEY HOẶC do admin nhập trong UI (lưu Setting
 *     module 'ai', key 'groq_api_key' — tự động bị redact khi backup vì khớp
 *     SECRET_KEY_RE /api_?key/). Key KHÔNG bao giờ trả về client.
 *   - Danh sách model mặc định cập nhật 2025-09 (llama-4, gpt-oss, kimi-k2…)
 *     + model tuỳ chỉnh do admin thêm/xoá thủ công (Setting 'groq_models')
 *     + tự lấy trực tiếp GET /models khi có key.
 */
import type { AiProvider } from './types'
import type { AiCompleteOptions, AiCompleteResult, AiToolCall } from '../provider'
import { getSetting, setSetting } from '@/core/server/settings'

const GROQ_DEFAULT_BASE = 'https://api.groq.com/openai/v1'

/** Model mặc định — cân bằng tốc độ/chất lượng trên hạ tầng LPU của Groq */
export const GROQ_DEFAULT_MODEL = 'llama-3.3-70b-versatile'

/** Model Groq khuyến nghị (cập nhật 2025-09) — dùng khi không gọi được /models */
export const GROQ_KNOWN_MODELS: string[] = [
  GROQ_DEFAULT_MODEL,
  'llama-3.1-8b-instant',
  'openai/gpt-oss-120b',
  'openai/gpt-oss-20b',
  'meta-llama/llama-4-scout-17b-16e-instruct',
  'meta-llama/llama-4-maverick-17b-128e-instruct',
  'moonshotai/kimi-k2-instruct',
  'qwen/qwen3-32b',
  'deepseek-r1-distill-llama-70b',
  'gemma2-9b-it',
]

/** Cache key nhập từ UI (Setting) — để isConfigured() chạy đồng bộ nhanh.
 *  null = chưa load lần nào (server vừa boot) → async init ở providers/index.ts
 *  sẽ gọi refreshGroqKeyCache() ngay sau khi đăng ký. */
let uiKeyCache: string | null = null
let uiBaseCache = ''
let customModelsCache: string[] | null = null

/** Nạp key + baseUrl + model tuỳ chỉnh từ Setting (chạy lúc boot + sau khi admin lưu) */
export async function refreshGroqConfig(): Promise<void> {
  try {
    uiKeyCache = String(await getSetting('ai', 'groq_api_key', '')).trim()
    uiBaseCache = String(await getSetting('ai', 'groq_base_url', '')).trim()
    const raw = String(await getSetting('ai', 'groq_models', '[]'))
    const parsed = JSON.parse(raw) as unknown
    customModelsCache = Array.isArray(parsed)
      ? parsed.filter((m): m is string => typeof m === 'string' && m.length > 0).slice(0, 60)
      : []
  } catch {
    uiKeyCache = ''
    customModelsCache = []
  }
}

/** Key hiệu dụng: env ưu tiên (deploy đúng cách), sau đó key nhập từ UI */
export async function groqKey(): Promise<string> {
  const env = (process.env.GROQ_API_KEY || '').trim()
  if (env) return env
  if (uiKeyCache === null) await refreshGroqConfig()
  return uiKeyCache || ''
}

/** baseUrl hiệu dụng: UI > env > mặc định */
export async function groqBaseUrl(): Promise<string> {
  const env = (process.env.GROQ_BASE_URL || '').trim()
  const ui = uiBaseCache || ''
  return (ui || env || GROQ_DEFAULT_BASE).replace(/\/+$/, '')
}

/** Lưu key từ UI (chuỗi rỗng = xoá). Chỉ admin mới gọi được route tương ứng. */
export async function setGroqApiKey(key: string): Promise<void> {
  const clean = String(key || '').trim().slice(0, 300)
  await setSetting('ai', 'groq_api_key', clean)
  uiKeyCache = clean
}

/** Lưu baseUrl tuỳ chỉnh (rỗng = mặc định api.groq.com) */
export async function setGroqBaseUrl(baseUrl: string): Promise<void> {
  const clean = String(baseUrl || '').trim().slice(0, 300)
  await setSetting('ai', 'groq_base_url', clean)
  uiBaseCache = clean
}

/** Lưu danh sách model tuỳ chỉnh (admin thêm/xoá tay) */
export async function setGroqCustomModels(models: string[]): Promise<void> {
  const clean = Array.from(new Set(models.map((m) => String(m || '').trim()).filter(Boolean))).slice(0, 60)
  await setSetting('ai', 'groq_models', JSON.stringify(clean))
  customModelsCache = clean
}

export async function getGroqCustomModels(): Promise<string[]> {
  if (customModelsCache === null) await refreshGroqConfig()
  return customModelsCache || []
}

/** Timeout fetch — không treo request quá lâu trên máy yếu */
function fetchWithTimeout(url: string, init: RequestInit, ms = 120_000): Promise<Response> {
  return Promise.race([
    fetch(url, init),
    new Promise<Response>((_, reject) => setTimeout(() => reject(new Error('Hết thời gian chờ AI phản hồi')), ms)),
  ])
}

/** Danh sách model gộp: tuỳ chỉnh (UI) + lấy sống từ API + danh sách khuyến nghị */
async function mergedModels(): Promise<string[]> {
  const key = await groqKey()
  const out = new Set<string>(await getGroqCustomModels())
  if (key) {
    try {
      const res = await fetchWithTimeout(`${await groqBaseUrl()}/models`, { headers: { authorization: `Bearer ${key}` } }, 15_000)
      if (res.ok) {
        const json = (await res.json()) as { data?: Array<{ id?: string }> }
        for (const m of json.data || []) if (m.id) out.add(m.id)
      }
    } catch {
      /* offline → dùng danh sách khuyến nghị */
    }
  }
  for (const m of GROQ_KNOWN_MODELS) out.add(m)
  return Array.from(out)
}

export const groqProvider: AiProvider = {
  id: 'groq',
  label: 'Groq Cloud',
  supportsTools: true,

  isConfigured() {
    if ((process.env.GROQ_API_KEY || '').trim()) return true
    return Boolean(uiKeyCache) // sau async init từ Setting
  },

  defaultModel() {
    return GROQ_DEFAULT_MODEL
  },

  async listModels() {
    return mergedModels()
  },

  async complete(opts: AiCompleteOptions, model: string): Promise<AiCompleteResult> {
    const key = await groqKey()
    if (!key) throw new Error('Groq chưa có API key — admin nhập trong Cài đặt Trợ lý AI (hoặc env GROQ_API_KEY)')
    const body: Record<string, unknown> = {
      model,
      messages: opts.messages.map((m) => ({
        role: m.role,
        content: m.content,
        ...(m.tool_calls ? { tool_calls: m.tool_calls } : {}),
        ...(m.tool_call_id ? { tool_call_id: m.tool_call_id } : {}),
        ...(m.name ? { name: m.name } : {}),
      })),
      temperature: opts.temperature ?? 0.7,
      max_tokens: opts.maxTokens ?? 2048,
    }
    if (opts.tools && opts.tools.length > 0) {
      body.tools = opts.tools
      body.tool_choice = 'auto'
    }
    const res = await fetchWithTimeout(`${await groqBaseUrl()}/chat/completions`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${key}` },
      body: JSON.stringify(body),
    })
    if (!res.ok) {
      const text = await res.text().catch(() => '')
      throw new Error(`Groq API lỗi ${res.status}: ${text.slice(0, 300)}`)
    }
    const json = (await res.json()) as {
      choices?: Array<{ message?: { content?: string; tool_calls?: AiToolCall[] } }>
      usage?: { prompt_tokens?: number; completion_tokens?: number }
    }
    const msg = json.choices?.[0]?.message
    return {
      content: msg?.content || '',
      toolCalls: (msg?.tool_calls || []) as AiToolCall[],
      model,
      provider: 'groq',
      usage: { prompt: json.usage?.prompt_tokens, completion: json.usage?.completion_tokens },
    }
  },
}
