/**
 * WOS AI Provider Registry — đăng ký trung tâm mọi bộ máy AI của Workspace OS.
 *
 * Provider được đăng ký qua registerProvider() (xem providers/index.ts).
 * Hệ thống không if/else cứng provider nữa — mọi thứ tra từ registry:
 *   - /api/ai/settings, /api/ai/status → listProviderInfos() cho UI
 *   - aiComplete() → getProvider(id).complete(...)
 * Thêm provider mới = 1 file + 1 dòng đăng ký, KHÔNG sửa lõi.
 */
import type { AiProvider, AiProviderInfo } from './types'

const registry = new Map<string, AiProvider>()

/** Đăng ký (hoặc ghi đè) một provider */
export function registerProvider(p: AiProvider): void {
  if (!p.id || typeof p.complete !== 'function') throw new Error(`Provider không hợp lệ: ${p.id}`)
  registry.set(p.id, p)
}

/** Lấy provider theo id (undefined nếu chưa đăng ký) */
export function getProvider(id: string): AiProvider | undefined {
  return registry.get(id)
}

/** Toàn bộ provider đã đăng ký */
export function allProviders(): AiProvider[] {
  return Array.from(registry.values())
}

/** Danh sách thông tin an toàn cho UI/API — không lộ key bao giờ */
export function listProviderInfos(): AiProviderInfo[] {
  return allProviders().map((p) => ({
    id: p.id,
    label: p.label,
    configured: (() => { try { return p.isConfigured() } catch { return false } })(),
    defaultModel: p.defaultModel(),
    supportsTools: p.supportsTools,
  }))
}

/** Provider mặc định: provider "chính" đầu tiên đã configured, không thì built-in cuối cùng */
export function defaultProviderId(): string {
  const all = allProviders()
  const configured = all.find((p) => p.isConfigured() && p.id !== 'zai')
  if (configured) return configured.id
  return all.length > 0 ? all[all.length - 1].id : 'zai'
}
