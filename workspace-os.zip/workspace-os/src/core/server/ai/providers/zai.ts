/**
 * Provider "zai" — SDK built-in của môi trường sandbox (z-ai-web-dev-sdk).
 * Fallback khi chưa cấu hình key riêng — giúp hệ thống chạy end-to-end ngay.
 * SDK không hỗ trợ tool calling ổn định → supportsTools: false (dùng context thu thập sẵn).
 */
import type { AiProvider } from './types'
import type { AiCompleteOptions, AiCompleteResult } from '../provider'

export const zaiProvider: AiProvider = {
  id: 'zai',
  label: 'Built-in (sandbox)',
  supportsTools: false,

  isConfigured() {
    return true // luôn sẵn sàng trong môi trường sandbox
  },

  defaultModel() {
    return 'glm-4.6'
  },

  async complete(opts: AiCompleteOptions, model: string): Promise<AiCompleteResult> {
    const { default: ZAI } = await import('z-ai-web-dev-sdk')
    const zai = await ZAI.create()
    const completion = await zai.chat.completions.create({
      model,
      messages: opts.messages.map((m) => ({ role: m.role as 'system' | 'user' | 'assistant', content: m.content })),
      temperature: opts.temperature ?? 0.7,
      thinking: { type: 'disabled' },
    })
    const content = completion.choices?.[0]?.message?.content ?? ''
    return { content, toolCalls: [], model, provider: 'zai' }
  },
}
