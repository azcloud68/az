/**
 * Rate limit trong RAM (sliding window) — đủ dùng cho single-node Orange Pi.
 * Dùng cho: forgot-password, reset-password, login brute-force...
 * key do caller tự dựng (vd: `forgot:${ip}:${username}`).
 */
const buckets = new Map<string, number[]>()

const MAX_KEYS = 5000

/** true = cho phép; false = đã vượt giới hạn */
export function checkRate(key: string, limit: number, windowMs: number): boolean {
  const now = Date.now()
  const arr = (buckets.get(key) || []).filter((ts) => now - ts < windowMs)
  if (arr.length >= limit) {
    buckets.set(key, arr)
    return false
  }
  arr.push(now)
  buckets.set(key, arr)
  sweep(now, windowMs)
  return true
}

/** Chỉ KIỂM tra (không ghi) — dùng khi chỉ đếm sự kiện THẤT BẠI (vd login):
 *  check trước khi xử lý, bump() sau khi xác thực sai → người dùng gõ đúng
 *  nhiều lần không tự khoá chính mình. */
export function exceedsRate(key: string, limit: number, windowMs: number): boolean {
  const now = Date.now()
  const arr = (buckets.get(key) || []).filter((ts) => now - ts < windowMs)
  return arr.length >= limit
}

/** Ghi 1 sự kiện vào bucket (kèm theo exceedsRate — xem ví dụ login route) */
export function bumpRate(key: string, windowMs: number): void {
  const now = Date.now()
  const arr = (buckets.get(key) || []).filter((ts) => now - ts < windowMs)
  arr.push(now)
  buckets.set(key, arr)
  sweep(now, windowMs)
}

/** dọn queue khi quá lớn (chống memory leak do key rác) */
function sweep(now: number, windowMs: number): void {
  if (buckets.size <= MAX_KEYS) return
  for (const [k, v] of buckets) {
    if (v.every((ts) => now - ts >= windowMs)) buckets.delete(k)
  }
}

/** Số lần còn lại trong cửa sổ (debug / hiển thị) */
export function remaining(key: string, limit: number, windowMs: number): number {
  const now = Date.now()
  const arr = (buckets.get(key) || []).filter((ts) => now - ts < windowMs)
  return Math.max(0, limit - arr.length)
}
