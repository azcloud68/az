/**
 * WOS Server Timezone Helper — mọi chỗ cần "hôm nay là ngày mấy" trên server
 * phải dùng timezone CẤU HÌNH (setting core:timezone, mặc định Asia/Bangkok),
 * không dùng new Date() theo múi giờ tiến trình Node (thường UTC khi deploy).
 *
 * Ảnh hưởng: Weekly (tuần hiện tại), Reports (mốc since), Scheduler sync
 * (02:00 daily / 03:00 Thứ 2 weekly) — giờ chạy theo giờ người dùng, không
 * còn lệch 7 tiếng khi Orange Pi chạy UTC.
 */
import { getSetting } from './settings'

const DEFAULT_TZ = 'Asia/Bangkok'

interface TzCache {
  tz: string
  ts: number
}
const g = globalThis as unknown as { __wosTzCache?: TzCache }
const TZ_TTL = 60_000

/** Timezone cấu hình (cache 60s — tránh query DB mỗi request) */
export async function serverTimezone(): Promise<string> {
  if (g.__wosTzCache && Date.now() - g.__wosTzCache.ts < TZ_TTL) return g.__wosTzCache.tz
  const tz = (await getSetting('core', 'timezone', DEFAULT_TZ)) || DEFAULT_TZ
  g.__wosTzCache = { tz, ts: Date.now() }
  return tz
}

/** 'YYYY-MM-DD' của THỜI ĐIỂM hiện tại theo tz (en-CA format ra ISO date) */
export function dateInTZ(d: Date, tz: string): string {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: tz,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(d)
}

/** Hôm nay ('YYYY-MM-DD') theo timezone cấu hình */
export async function serverTodayISO(): Promise<string> {
  return dateInTZ(new Date(), await serverTimezone())
}

/** Giờ + phút + thứ (0=CN..6=T7) + 'YYYY-MM-DD' hiện tại theo tz */
export function partsInTZ(d: Date, tz: string): { date: string; hour: number; minute: number; weekday: number } {
  const fmt = new Intl.DateTimeFormat('en-CA', {
    timeZone: tz,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
    weekday: 'short',
  })
  const parts = Object.fromEntries(fmt.formatToParts(d).map((p) => [p.type, p.value]))
  const wdMap: Record<string, number> = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 }
  return {
    date: `${parts.year}-${parts.month}-${parts.day}`,
    hour: Number(parts.hour) % 24,
    minute: Number(parts.minute),
    weekday: wdMap[parts.weekday as string] ?? 0,
  }
}

/** Instant (UTC ms) của 'YYYY-MM-DD giờ:phút' THEO tz — dùng cho scheduler
 *  (02:00 daily chạy lúc 02:00 giờ người dùng kể cả khi Node chạy UTC). */
export function instantAtDateInTZ(dateISO: string, hour: number, minute: number, tz: string): Date {
  const probe = new Date()
  const p = partsInTZ(probe, tz)
  const probeUTCms = Date.UTC(
    Number(p.date.slice(0, 4)),
    Number(p.date.slice(5, 7)) - 1,
    Number(p.date.slice(8, 10)),
    p.hour,
    p.minute,
    0,
  )
  const offset = probe.getTime() - probeUTCms
  const [y, m, d] = dateISO.split('-').map(Number)
  return new Date(Date.UTC(y || 2026, (m || 1) - 1, d || 1, hour, minute, 0) + offset)
}
