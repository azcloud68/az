/**
 * WOS Backup Sanitizer — che secret khi xuất/nhập backup JSON.
 *
 * Vấn đề: bảng `setting` chứa Google Drive credentials (sync:client_secret,
 * sync:refresh_token) và auth secret (core:auth_secret). Nếu export thẳng
 * xuống backup JSON thì file backup bị lộ credential khi rơi vào tay người
 * khác (tải nhầm, gửi nhầm, upload GitHub...).
 *
 * Giải pháp: mọi nơi export `setting` đều redact giá trị thành "[REDACTED]";
 * khi restore gặp "[REDACTED]" thì BỎ QUA row đó (giữ giá trị secret hiện tại
 * của hệ thống — không phá cấu hình sync đang chạy).
 */
import type { Setting } from '@prisma/client'

export const REDACTED = '[REDACTED]'

/** id của các setting chứa secret — tuyệt đối không cho ra file backup */
const SECRET_SETTING_IDS = new Set(['core:auth_secret', 'sync:client_secret', 'sync:refresh_token'])

/** key-level cho chắc chắn (kể cả row tạo tay có id khác thường) */
const SECRET_SYNC_KEYS = new Set(['client_secret', 'refresh_token'])

/** Redact một mảng row Setting trước khi đưa vào backup JSON */
export function sanitizeSettingRows(rows: Setting[]): Setting[] {
  return rows.map((row) => {
    if (SECRET_SETTING_IDS.has(row.id)) return { ...row, value: REDACTED }
    if (row.module === 'sync' && SECRET_SYNC_KEYS.has(row.key)) return { ...row, value: REDACTED }
    return row
  })
}

/** Khi restore: bỏ qua các row đã bị redact (giữ secret hiện tại của hệ thống) */
export function dropRedactedSettingRows(rows: unknown[]): unknown[] {
  return rows.filter(
    (r) => !(r && typeof r === 'object' && (r as { value?: unknown }).value === REDACTED),
  )
}

/** Filter Prisma tìm mọi row secret HIỆN TẠI trong DB (dùng trước deleteMany
 *  để backup-save chúng — row redacted không được recreate từ file) */
export function secretSettingFilter(): Record<string, unknown> {
  return {
    OR: [
      { id: { in: Array.from(SECRET_SETTING_IDS) } },
      { module: 'sync', key: { in: Array.from(SECRET_SYNC_KEYS) } },
    ],
  }
}

/** Lấy id các row bị redact trong file backup (để biết secret nào cần tạo lại) */
export function redactedIdsOf(rows: unknown[]): Set<string> {
  const ids = new Set<string>()
  for (const r of rows) {
    if (r && typeof r === 'object') {
      const row = r as { id?: unknown; value?: unknown }
      if (row.value === REDACTED && typeof row.id === 'string') ids.add(row.id)
    }
  }
  return ids
}

/** Redact một bảng dữ liệu bất kỳ (chỉ bảng 'setting' có xử lý đặc biệt) */
export function sanitizeTableForExport(table: string, rows: unknown[]): unknown[] {
  if (table !== 'setting') return rows
  return sanitizeSettingRows(rows as Setting[])
}
