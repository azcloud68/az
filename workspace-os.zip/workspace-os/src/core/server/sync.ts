/**
 * WOS Sync & Backup Engine (module 'sync') — Google Drive, in-app OAuth
 * - Không dependency ngoài: thuần fetch native (Node 22), tar hệ thống
 * - Backup: VACUUM INTO snapshot SQLite + copy storage + export JSON → tar.gz → Drive resumable upload
 * - Scheduler: singleton globalThis, tick 60s (daily 02:00 / weekly T2 03:00)
 */
import { promises as fsp } from 'fs'
import { createWriteStream } from 'fs'
import path from 'path'
import { execFile } from 'child_process'
import { promisify } from 'util'
import { randomBytes, timingSafeEqual } from 'crypto'
import { Readable, Transform } from 'stream'
import { pipeline } from 'stream/promises'
import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSettings, setSettings } from './settings'
import { emitEvent } from './event-bus'
import { baseStorageRoot } from './storage'
import { MODULE_TABLES, sanitizeBackupSettings } from './backup-tables'
import { ApiError } from './api-error'
import {
  applyBackupPayload, countMissingFiles, exportPayloadFromSqlite, validateBackupPayload,
  snapshotDbFile, snapshotStorageTree, restoreStorageTree, rollbackStorageTree,
  pathIsDir, pathIsFile,
} from './backup-restore'

const execFileAsync = promisify(execFile)

// ---------------------------------------------------------------------
// Config (Setting module 'sync')
// ---------------------------------------------------------------------

export interface SyncSources {
  db: boolean
  files: boolean
  config: boolean
}

export interface SyncConfig {
  clientId: string
  clientSecret: string
  refreshToken: string
  account: string
  sources: SyncSources
  schedule: 'off' | 'daily' | 'weekly'
  keep: number
}

export const SYNC_MODULE = 'sync'
const DRIVE_FOLDER_NAME = 'WorkspaceOS-Backup'
const OAUTH_TOKEN_URL = 'https://oauth2.googleapis.com/token'
const USERINFO_URL = 'https://www.googleapis.com/oauth2/v3/userinfo'
const DRIVE_API = 'https://www.googleapis.com/drive/v3'
const CHUNK_SIZE = 8 * 1024 * 1024 // 8MB
const DEFAULT_KEEP = 7

/** Cache module-level an toàn hot-reload (đặt trên globalThis) */
interface SyncGlobal {
  __wosSyncScheduler?: ReturnType<typeof setInterval>
  __wosSyncRunning?: boolean
  __wosRestoreRunning?: boolean
  __wosSyncToken?: { token: string; exp: number }
  __wosSyncFolder?: { id: string; ts: number }
  /** OAuth state (CSRF) — sessionId admin → { state, exp }, TTL 10 phút, dùng 1 lần */
  __wosOAuthStates?: Map<string, { state: string; exp: number }>
}
function syncGlobal(): SyncGlobal {
  return globalThis as unknown as SyncGlobal
}

export async function getSyncConfig(): Promise<SyncConfig> {
  const s = await getSettings(SYNC_MODULE)
  let sources: SyncSources = { db: true, files: true, config: true }
  try {
    const parsed = JSON.parse(s.sources || '') as Partial<SyncSources>
    if (parsed && typeof parsed === 'object') {
      sources = { db: !!parsed.db, files: !!parsed.files, config: !!parsed.config }
    }
  } catch {
    /* giữ mặc định */
  }
  const schedule = (['off', 'daily', 'weekly'] as const).includes(s.schedule as 'off' | 'daily' | 'weekly')
    ? (s.schedule as 'off' | 'daily' | 'weekly')
    : 'off'
  const keep = Number.parseInt(s.keep || '', 10)
  return {
    clientId: s.client_id || '',
    clientSecret: s.client_secret || '',
    refreshToken: s.refresh_token || '',
    account: s.account || '',
    sources,
    schedule,
    keep: Number.isFinite(keep) && keep > 0 ? keep : DEFAULT_KEEP,
  }
}

export async function saveSyncConfig(patch: Partial<Omit<SyncConfig, 'keep'>> & { keep?: number }): Promise<SyncConfig> {
  const cur = await getSyncConfig()
  const next: SyncConfig = {
    clientId: patch.clientId !== undefined ? patch.clientId : cur.clientId,
    clientSecret: patch.clientSecret !== undefined ? patch.clientSecret : cur.clientSecret,
    refreshToken: patch.refreshToken !== undefined ? patch.refreshToken : cur.refreshToken,
    account: patch.account !== undefined ? patch.account : cur.account,
    sources: patch.sources ? { ...cur.sources, ...patch.sources } : cur.sources,
    schedule: patch.schedule !== undefined ? patch.schedule : cur.schedule,
    keep: patch.keep !== undefined ? patch.keep : cur.keep,
  }
  await setSettings(SYNC_MODULE, {
    client_id: next.clientId,
    client_secret: next.clientSecret,
    refresh_token: next.refreshToken,
    account: next.account,
    sources: JSON.stringify(next.sources),
    schedule: next.schedule,
    keep: String(next.keep),
  })
  // Credential/token đổi → bỏ cache access token cũ
  syncGlobal().__wosSyncToken = undefined
  return next
}

/** Origin công khai của request (qua gateway Caddy: ưu tiên x-forwarded-host/proto) */
export function requestOrigin(req: NextRequest): string {
  const host = req.headers.get('x-forwarded-host')?.split(',')[0]?.trim()
  const proto = req.headers.get('x-forwarded-proto')?.split(',')[0]?.trim()
  if (host) return `${proto || 'https'}://${host}`
  try {
    return new URL(req.url).origin
  } catch {
    return req.nextUrl.origin
  }
}

// ---------------------------------------------------------------------
// Google OAuth — CSRF state + refresh token flow (cache access token 5 phút)
// ---------------------------------------------------------------------

const OAUTH_STATE_TTL_MS = 10 * 60 * 1000

function stateEquals(a: string, b: string): boolean {
  const ba = Buffer.from(a, 'utf8')
  const bb = Buffer.from(b, 'utf8')
  if (ba.length !== bb.length) return false
  return timingSafeEqual(ba, bb)
}

/** /gdrive/start gọi: sinh state 32 byte random, GẮN VỚI sessionId admin (TTL 10 phút).
 *  Mỗi start mới đè state cũ — 1 session chỉ có 1 flow đang mở. */
export function createOAuthState(sessionId: string): string {
  const g = syncGlobal()
  if (!g.__wosOAuthStates) g.__wosOAuthStates = new Map()
  const now = Date.now()
  // dọn entry hết hạn (lazy)
  for (const [k, v] of g.__wosOAuthStates) {
    if (v.exp <= now) g.__wosOAuthStates.delete(k)
  }
  const state = randomBytes(32).toString('hex')
  g.__wosOAuthStates.set(sessionId, { state, exp: now + OAUTH_STATE_TTL_MS })
  return state
}

/** /gdrive/callback gọi: state PHẢI khớp state đã sinh cho CHÍNH session này,
 *  còn hiệu lực — và bị TIÊU THU 1 lần (sai cũng tiêu thu — chống dò brute-force).
 *  Chặn CSRF: callback link do attacker tự dựng (code của Drive attacker) không
 *  thể mang state hợp lệ của session admin → từ chối trước khi đổi code. */
export function consumeOAuthState(sessionId: string, state: string): boolean {
  const g = syncGlobal()
  const entry = g.__wosOAuthStates?.get(sessionId)
  if (!entry) return false
  g.__wosOAuthStates?.delete(sessionId) // consume 1 lần
  return entry.exp > Date.now() && stateEquals(entry.state, state)
}

export async function getAccessToken(cfg?: SyncConfig): Promise<string> {
  const c = cfg ?? (await getSyncConfig())
  if (!c.clientId || !c.clientSecret || !c.refreshToken) {
    throw new ApiError('Chưa kết nối Google Drive (thiếu Client ID/Secret hoặc refresh token)')
  }
  const g = syncGlobal()
  if (g.__wosSyncToken && g.__wosSyncToken.exp > Date.now()) return g.__wosSyncToken.token
  const body = new URLSearchParams({
    client_id: c.clientId,
    client_secret: c.clientSecret,
    refresh_token: c.refreshToken,
    grant_type: 'refresh_token',
  })
  const res = await fetch(OAUTH_TOKEN_URL, {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body,
    signal: AbortSignal.timeout(30000),
  })
  if (!res.ok) {
    const text = await res.text().catch(() => '')
    throw new ApiError(`Làm mới token Google thất bại (${res.status}): ${text.slice(0, 200)}`, 502)
  }
  const data = (await res.json()) as { access_token?: string; expires_in?: number }
  if (!data.access_token) throw new ApiError('Google không trả về access_token', 502)
  // cache tối đa 5 phút trong RAM
  const ttlMs = Math.min(data.expires_in || 3600, 300) * 1000
  g.__wosSyncToken = { token: data.access_token, exp: Date.now() + ttlMs }
  return data.access_token
}

/** Bearer call tiện ích cho các route (list/download/about) */
export async function driveFetch(url: string, init: RequestInit = {}, timeoutMs = 30000): Promise<Response> {
  const token = await getAccessToken()
  return fetch(url, {
    ...init,
    headers: { ...(init.headers || {}), authorization: `Bearer ${token}` },
    signal: AbortSignal.timeout(timeoutMs),
  })
}

// ---------------------------------------------------------------------
// Drive helpers — folder WorkspaceOS-Backup, list, prune
// ---------------------------------------------------------------------

function safeDriveId(id: string): string {
  if (!/^[A-Za-z0-9_-]{5,}$/.test(id)) throw new ApiError('Drive file id không hợp lệ')
  return id
}

async function ensureDriveFolder(accessToken: string): Promise<string> {
  const g = syncGlobal()
  if (g.__wosSyncFolder && Date.now() - g.__wosSyncFolder.ts < 10 * 60 * 1000) return g.__wosSyncFolder.id
  const q = encodeURIComponent(
    `name = "${DRIVE_FOLDER_NAME}" and mimeType = "application/vnd.google-apps.folder" and trashed = false and "root" in parents`,
  )
  const res = await fetch(`${DRIVE_API}/files?q=${q}&fields=files(id,name)&pageSize=5`, {
    headers: { authorization: `Bearer ${accessToken}` },
    signal: AbortSignal.timeout(30000),
  })
  if (!res.ok) {
    const text = await res.text().catch(() => '')
    throw new ApiError(`Tìm thư mục backup trên Drive thất bại (${res.status}): ${text.slice(0, 200)}`, 502)
  }
  const data = (await res.json()) as { files?: { id?: string }[] }
  let id = data.files?.[0]?.id || ''
  if (!id) {
    const createRes = await fetch(`${DRIVE_API}/files`, {
      method: 'POST',
      headers: { authorization: `Bearer ${accessToken}`, 'content-type': 'application/json' },
      body: JSON.stringify({ name: DRIVE_FOLDER_NAME, mimeType: 'application/vnd.google-apps.folder' }),
      signal: AbortSignal.timeout(30000),
    })
    if (!createRes.ok) {
      const text = await createRes.text().catch(() => '')
      throw new ApiError(`Tạo thư mục backup trên Drive thất bại (${createRes.status}): ${text.slice(0, 200)}`, 502)
    }
    const created = (await createRes.json()) as { id?: string }
    id = created.id || ''
  }
  if (!id) throw new ApiError('Không xác định được thư mục backup trên Drive', 502)
  g.__wosSyncFolder = { id, ts: Date.now() }
  return id
}

export interface DriveBackupFile {
  id: string
  name: string
  size: number
  modifiedTime: string
}

/** Danh sách tệp backup trong folder WorkspaceOS-Backup (tối đa 50, mới nhất trước) */
export async function listDriveBackups(): Promise<DriveBackupFile[]> {
  const cfg = await getSyncConfig()
  if (!cfg.refreshToken) return []
  const accessToken = await getAccessToken(cfg)
  const folderId = await ensureDriveFolder(accessToken)
  const q = encodeURIComponent(`'${folderId}' in parents and trashed = false`)
  const res = await fetch(
    `${DRIVE_API}/files?q=${q}&orderBy=createdTime desc&pageSize=50&fields=files(id,name,size,createdTime)`,
    { headers: { authorization: `Bearer ${accessToken}` }, signal: AbortSignal.timeout(30000) },
  )
  if (!res.ok) {
    const text = await res.text().catch(() => '')
    throw new ApiError(`Đọc danh sách tệp Drive thất bại (${res.status}): ${text.slice(0, 200)}`, 502)
  }
  const data = (await res.json()) as {
    files?: { id?: string; name?: string; size?: string; createdTime?: string }[]
  }
  return (data.files || [])
    .filter((f) => f.id)
    .map((f) => ({
      id: f.id as string,
      name: f.name || '',
      size: Number(f.size || 0),
      modifiedTime: f.createdTime || '',
    }))
}

/** Giữ `keep` bản mới nhất trong folder, xoá phần dư (best-effort) */
async function pruneBackups(accessToken: string, folderId: string, keep: number): Promise<void> {
  const safeKeep = Math.max(1, Math.min(50, keep || DEFAULT_KEEP))
  const q = encodeURIComponent(`'${folderId}' in parents and trashed = false`)
  const res = await fetch(`${DRIVE_API}/files?q=${q}&orderBy=createdTime desc&pageSize=100&fields=files(id)`, {
    headers: { authorization: `Bearer ${accessToken}` },
    signal: AbortSignal.timeout(30000),
  })
  if (!res.ok) throw new ApiError(`Đọc danh sách backup để dọn dẹp thất bại (${res.status})`, 502)
  const data = (await res.json()) as { files?: { id?: string }[] }
  const extras = (data.files || []).filter((f) => f.id).slice(safeKeep)
  for (const f of extras) {
    try {
      const del = await fetch(`${DRIVE_API}/files/${f.id}`, {
        method: 'DELETE',
        headers: { authorization: `Bearer ${accessToken}` },
        signal: AbortSignal.timeout(30000),
      })
      if (!del.ok && del.status !== 204) console.error('[sync]', `Xoá bản cũ ${f.id} thất bại (${del.status})`)
    } catch (err) {
      console.error('[sync]', err)
    }
  }
}

// ---------------------------------------------------------------------
// Backup engine
// ---------------------------------------------------------------------

/** Cùng bảng export + redact secret như /api/core/backup (dùng chung backup-tables.ts) */
async function buildConfigExport(by: string): Promise<string> {
  const data: Record<string, unknown> = {
    _meta: { app: 'Workspace OS', version: '1.1.0', exportedAt: new Date().toISOString(), by, redacted: true },
  }
  for (const table of MODULE_TABLES) {
    const rows = await (db as unknown as Record<string, { findMany: () => Promise<unknown[]> }>)[table].findMany()
    data[table] = table === 'setting' ? sanitizeBackupSettings(rows as { id: string; value: string }[]) : rows
  }
  return JSON.stringify(data, null, 1)
}

/** Đường dẫn tuyệt đối tới file SQLite từ DATABASE_URL (file:./x hoặc file:/x) */
function databaseFile(): string {
  const raw = (process.env.DATABASE_URL || '').trim()
  if (!raw) return path.resolve(process.cwd(), 'db/custom.db')
  const noScheme = raw.startsWith('file:') ? raw.slice(5) : raw
  const clean = noScheme.split('?')[0]
  return path.isAbsolute(clean) ? clean : path.resolve(process.cwd(), clean)
}

async function dirExists(p: string): Promise<boolean> {
  try {
    return (await fsp.stat(p)).isDirectory()
  } catch {
    return false
  }
}

async function countFiles(dir: string): Promise<number> {
  let entries
  try {
    entries = await fsp.readdir(dir, { withFileTypes: true })
  } catch {
    return 0
  }
  let n = 0
  for (const e of entries) {
    if (e.isDirectory()) n += await countFiles(path.join(dir, e.name))
    else if (e.isFile()) n++
  }
  return n
}

function backupFileName(now = new Date()): string {
  const p = (n: number) => String(n).padStart(2, '0')
  return `wos-backup-${now.getFullYear()}-${p(now.getMonth() + 1)}-${p(now.getDate())}-${p(now.getHours())}${p(now.getMinutes())}${p(now.getSeconds())}.tar.gz`
}

/**
 * Resumable upload lên Drive:
 * 1. POST /upload/drive/v3/files?uploadType=resumable → Location
 * 2. ≤ 8MB: PUT 1 lần; lớn hơn: PUT tuần tự từng chunk 8MB kèm Content-Range,
 *    mỗi chunk chờ 200/201 (xong) hoặc 308 (tiếp tục)
 * Trả về remote file id (parse JSON của response cuối).
 */
async function uploadResumable(
  accessToken: string,
  filePath: string,
  fileName: string,
  folderId: string,
): Promise<string> {
  const initRes = await fetch(`${DRIVE_API}/upload/drive/v3/files?uploadType=resumable`, {
    method: 'POST',
    headers: { authorization: `Bearer ${accessToken}`, 'content-type': 'application/json' },
    body: JSON.stringify({ name: fileName, parents: [folderId] }),
    signal: AbortSignal.timeout(30000),
  })
  if (!initRes.ok) {
    const text = await initRes.text().catch(() => '')
    throw new Error(`Khởi tạo upload Drive thất bại (${initRes.status}): ${text.slice(0, 200)}`)
  }
  await initRes.arrayBuffer().catch(() => {})
  const location = initRes.headers.get('location')
  if (!location) throw new Error('Google Drive không trả về Location cho resumable upload')

  const total = (await fsp.stat(filePath)).size
  let remoteId = ''

  if (total > 0 && total <= CHUNK_SIZE) {
    const buf = await fsp.readFile(filePath)
    const res = await fetch(location, {
      method: 'PUT',
      headers: { 'content-type': 'application/octet-stream' },
      body: new Uint8Array(buf),
      signal: AbortSignal.timeout(120000),
    })
    const text = await res.text().catch(() => '')
    if (res.status !== 308 && !res.ok) {
      throw new Error(`Upload lên Drive thất bại (${res.status}): ${text.slice(0, 200)}`)
    }
    try {
      remoteId = (JSON.parse(text) as { id?: string }).id || ''
    } catch {
      /* response rỗng */
    }
  } else {
    const fh = await fsp.open(filePath, 'r')
    try {
      const buf = Buffer.alloc(CHUNK_SIZE)
      let offset = 0
      while (offset < total) {
        const len = Math.min(CHUNK_SIZE, total - offset)
        const { bytesRead } = await fh.read(buf, 0, len, offset)
        if (bytesRead <= 0) break
        const res = await fetch(location, {
          method: 'PUT',
          headers: {
            'content-type': 'application/octet-stream',
            'content-range': `bytes ${offset}-${offset + bytesRead - 1}/${total}`,
          },
          body: new Uint8Array(buf.subarray(0, bytesRead)),
          signal: AbortSignal.timeout(120000),
        })
        const text = await res.text().catch(() => '')
        if (res.status === 308) {
          offset += bytesRead
          continue
        }
        if (!res.ok) {
          throw new Error(`Upload chunk lên Drive thất bại (${res.status}): ${text.slice(0, 200)}`)
        }
        try {
          remoteId = (JSON.parse(text) as { id?: string }).id || ''
        } catch {
          /* response rỗng */
        }
        offset += bytesRead
        break // đã nhận 2xx → upload hoàn tất
      }
    } finally {
      await fh.close()
    }
  }

  if (!remoteId) throw new Error('Không xác định được tệp trên Drive sau khi upload')
  return remoteId
}

/**
 * Chạy một lần backup đầy đủ: DB + storage + config JSON → tar.gz → Drive.
 * Chống chạy chồng bằng cờ module-level. Luôn dọn thư mục tạm.
 */
export async function runBackup(
  trigger: 'manual' | 'schedule',
  actor?: { id: string; displayName: string } | null,
): Promise<string | null> {
  const g = syncGlobal()
  if (g.__wosSyncRunning) {
    console.error('[sync]', 'Backup đang chạy — bỏ qua lời gọi mới')
    return null
  }
  g.__wosSyncRunning = true
  let runId = ''
  const tmpDir = path.join(path.dirname(path.resolve(baseStorageRoot())), 'wos-backup-tmp')
  try {
    const cfg = await getSyncConfig()
    runId = (await db.backupRun.create({ data: { trigger, status: 'running', provider: 'gdrive' } })).id
    if (!cfg.refreshToken) throw new Error('Chưa kết nối Google Drive — hãy kết nối trong Settings → Sync')
    if (!cfg.sources.db && !cfg.sources.files && !cfg.sources.config) {
      throw new Error('Chưa chọn nguồn dữ liệu nào (DB / Tệp / Cấu hình)')
    }

    // 1. Chuẩn bị thư mục tạm (xoá nội dung cũ)
    await fsp.rm(tmpDir, { recursive: true, force: true })
    await fsp.mkdir(tmpDir, { recursive: true })
    let fileCount = 0

    // 2. DB: VACUUM INTO snapshot an toàn khi đang mở, rồi copy vào tmp/db/wos.db
    if (cfg.sources.db) {
      try {
        const dbFile = databaseFile()
        await fsp.access(dbFile).catch(() => {
          throw new Error(`Không tìm thấy file database: ${dbFile}`)
        })
        const snapshot = path.join(tmpDir, 'wos-snapshot.sqlite')
        const sql = `VACUUM INTO '${snapshot.replace(/'/g, "''")}'`
        await db.$executeRawUnsafe(sql)
        await fsp.mkdir(path.join(tmpDir, 'db'), { recursive: true })
        await fsp.copyFile(snapshot, path.join(tmpDir, 'db', 'wos.db'))
        await fsp.rm(snapshot, { force: true })
        fileCount++
      } catch (err) {
        console.error('[sync]', err)
        throw new Error(`Snapshot database thất bại: ${err instanceof Error ? err.message : 'lỗi không xác định'}`)
      }
    }

    // 3. Files: copy TOÀN BỘ storage mọi user (root hệ thống — không scope theo ALS)
    if (cfg.sources.files) {
      const srcRoot = path.resolve(baseStorageRoot())
      if (await dirExists(srcRoot)) {
        await fsp.cp(srcRoot, path.join(tmpDir, 'files'), {
          recursive: true,
          filter: (src: string) => src !== tmpDir,
        })
        fileCount += await countFiles(path.join(tmpDir, 'files'))
      }
    }

    // 4. Config: export JSON metadata (giống /api/core/backup)
    if (cfg.sources.config) {
      const json = await buildConfigExport(actor?.displayName || 'system')
      await fsp.mkdir(path.join(tmpDir, 'config'), { recursive: true })
      await fsp.writeFile(path.join(tmpDir, 'config', 'wos-export.json'), json, 'utf-8')
      fileCount++
    }

    // 4b. manifest.json — ĐÁNH VERSION DB + files CÙNG MỘT THỜI ĐIỂM (v2.3):
    //     restore đọc manifest để biết bản tar này snapshot những gì, tạo lúc nào —
    //     DB (db/wos.db) và files/ luôn đi CÙNG NHAU trong 1 tar → hết lệch pha
    const manifest = {
      app: 'Workspace OS',
      wosVersion: '2.3',
      backupRunId: runId,
      createdAt: new Date().toISOString(),
      trigger,
      sources: cfg.sources,
      fileCount,
      by: actor?.displayName || 'system',
    }
    await fsp.writeFile(path.join(tmpDir, 'manifest.json'), JSON.stringify(manifest, null, 2), 'utf-8')

    // 5. Đóng gói tar.gz — chỉ nén các thư mục nguồn tồn tại (kèm manifest.json)
    const include: string[] = ['manifest.json']
    for (const name of ['db', 'files', 'config']) {
      if (await dirExists(path.join(tmpDir, name))) include.push(name)
    }
    if (include.length === 0) throw new Error('Không có dữ liệu nào để sao lưu')
    const fileName = backupFileName()
    const tarPath = path.join(tmpDir, fileName)
    await execFileAsync('tar', ['-czf', tarPath, '-C', tmpDir, ...include], { maxBuffer: 16 * 1024 * 1024 })
    const size = (await fsp.stat(tarPath)).size

    // 6. Upload resumable lên folder WorkspaceOS-Backup
    const accessToken = await getAccessToken(cfg)
    const folderId = await ensureDriveFolder(accessToken)
    const remoteId = await uploadResumable(accessToken, tarPath, fileName, folderId)

    await db.backupRun.update({
      where: { id: runId },
      data: { fileName, size, fileCount, remoteId, status: 'ok', finishedAt: new Date() },
    })

    // 7. Giữ `keep` bản mới nhất (best-effort, không làm fail backup đã thành công)
    try {
      await pruneBackups(accessToken, folderId, cfg.keep)
    } catch (err) {
      console.error('[sync]', err)
    }

    await emitEvent({
      type: 'sync.backup.ok',
      module: SYNC_MODULE,
      actor: actor ? { id: actor.id, displayName: actor.displayName } : null,
      payload: { title: fileName, size, fileCount, trigger, remoteId },
      notify: { title: 'Backup Drive thành công', content: `${fileName} • ${fileCount} tệp`, type: 'system' },
    })
    return runId
  } catch (err) {
    console.error('[sync]', err)
    const message = (err instanceof Error ? err.message : 'Lỗi không xác định').slice(0, 500)
    if (runId) {
      await db.backupRun
        .update({ where: { id: runId }, data: { status: 'error', error: message, finishedAt: new Date() } })
        .catch(() => {})
      await emitEvent({
        type: 'sync.backup.error',
        module: SYNC_MODULE,
        actor: actor ? { id: actor.id, displayName: actor.displayName } : null,
        payload: { message, trigger },
        notify: { title: 'Backup Drive lỗi', content: message.slice(0, 200), type: 'alert' },
      }).catch(() => {})
    }
    return null
  } finally {
    await fsp.rm(tmpDir, { recursive: true, force: true }).catch(() => {})
    g.__wosSyncRunning = false
  }
}

// ---------------------------------------------------------------------
// Restore từ bản backup tar.gz trên Google Drive (v2.3)
// ---------------------------------------------------------------------

export interface DriveRestoreResult {
  restored: number
  legacy: boolean
  missingFiles: number
  snapshotDb: string | null
  snapshotStorage: string | null
  filesRestored: boolean
}

/**
 * Khôi phục TOÀN HỆ THỐNG từ 1 bản backup tar.gz trên Drive — DB + storage files
 * ĐỒNG THỜI (vấn đề "DB restore xong mà files không khớp" của bản ≤ v2.2):
 *   1. Tải tar.gz về thư mục làm việc tạm (stream — không phình RAM)
 *   2. Pre-scan tên entry tar (tuyệt đối / '..' → chặn) rồi giải nén vào staging
 *   3. Đọc manifest.json (bản ≥ v2.3); bản cũ không có → chế độ legacy (vẫn chạy)
 *   4. DB payload: config/wos-export.json nếu có, không thì đọc db/wos.db (python3)
 *   5. SNAPSHOT trước: file DB + cây storage (tar.gz) vào db/snapshots/ — cứu vãn được
 *   6. Filesystem TRƯỚC: storage hiện tại → holding dir; files/ của backup → root
 *      (cp lỗi → tự rollback ngay tại chỗ)
 *   7. DB SAU: $transaction nguyên tử (Group FK + giữ secret như /api/core/backup)
 *      — DB lỗi → rollback filesystem (holding trở lại root)
 *   8. Thành công: dọn holding + staging, trả kèm số fileNode thiếu tệp (chẩn đoán)
 * Chỉ 1 restore/backup chạy tại 1 thời điểm (cờ globalThis). Nên chạy lúc ít
 * người dùng (upload trong lúc restore có thể rơi vào cây vừa bị thay).
 */
export async function restoreDriveBackup(
  driveFileId: string,
  actor?: { id: string; displayName: string } | null,
): Promise<DriveRestoreResult> {
  const g = syncGlobal()
  if (g.__wosSyncRunning || g.__wosRestoreRunning) {
    throw new ApiError('Backup/restore khác đang chạy — thử lại sau ít phút', 409)
  }
  g.__wosRestoreRunning = true
  const workDir = path.join(path.dirname(path.resolve(baseStorageRoot())), 'wos-restore-tmp', `restore-${Date.now()}-${randomBytes(3).toString('hex')}`)
  try {
    safeDriveId(driveFileId)
    await fsp.mkdir(workDir, { recursive: true })

    // 1) tải tar.gz về workDir (stream qua counter — không giữ RAM)
    const res = await driveFetch(`https://www.googleapis.com/drive/v3/files/${driveFileId}?alt=media`, {}, 300000)
    if (!res.ok || !res.body) {
      const text = res.ok ? '' : await res.text().catch(() => '')
      throw new ApiError(`Tải bản backup từ Drive thất bại (${res.status}) ${text.slice(0, 150)}`.trim(), 502)
    }
    const tarPath = path.join(workDir, 'backup.tar.gz')
    let downloaded = 0
    const counter = new (class extends Transform {
      _transform(chunk: Buffer, _enc: string, cb: (err?: Error | null, data?: unknown) => void) {
        downloaded += Buffer.byteLength(chunk)
        cb(null, chunk)
      }
    })()
    await pipeline(Readable.fromWeb(res.body as unknown as import('stream/web').ReadableStream<Uint8Array>), counter, createWriteStream(tarPath))

    // 2) pre-scan tên entry tar — chặn đường dẫn tuyệt đối / '..' trước khi giải nén
    const { stdout: listOut } = await execFileAsync('tar', ['-tzf', tarPath], { maxBuffer: 16 * 1024 * 1024 })
    for (const line of listOut.split('\n')) {
      const name = line.trim()
      if (!name) continue
      if (name.startsWith('/') || name.split('/').includes('..')) {
        throw new ApiError('Bản backup chứa đường dẫn không an toàn — bị chặn')
      }
    }
    const stageDir = path.join(workDir, 'stage')
    await fsp.mkdir(stageDir, { recursive: true })
    await execFileAsync('tar', ['-xzf', tarPath, '-C', stageDir], { maxBuffer: 16 * 1024 * 1024 })

    // 3) manifest (bản ≥ v2.3 luôn có; bản cũ → legacy)
    let legacy = false
    const manifestPath = path.join(stageDir, 'manifest.json')
    if (await pathIsFile(manifestPath)) {
      try {
        const mf = JSON.parse(await fsp.readFile(manifestPath, 'utf-8')) as { app?: string; createdAt?: string }
        if (mf.app !== 'Workspace OS') throw new ApiError('Bản backup không phải của Workspace OS')
      } catch (err) {
        if (err instanceof ApiError) throw err
        throw new ApiError('manifest.json trong bản backup không đọc được (hỏng?)')
      }
    } else {
      legacy = true
    }

    // 4) DB payload: ưu tiên config/wos-export.json; không có → đọc db/wos.db (python3)
    let payload: Record<string, Record<string, unknown>[]>
    const jsonPath = path.join(stageDir, 'config', 'wos-export.json')
    if (await pathIsFile(jsonPath)) {
      try {
        payload = JSON.parse(await fsp.readFile(jsonPath, 'utf-8')) as Record<string, Record<string, unknown>[]>
      } catch {
        throw new ApiError('File wos-export.json trong bản backup không đọc được (hỏng?)')
      }
      if (!payload._meta || (payload._meta as { app?: string }).app !== 'Workspace OS') {
        throw new ApiError('File sao lưu không hợp lệ (thiếu _meta Workspace OS)')
      }
    } else {
      const dbFile = path.join(stageDir, 'db', 'wos.db')
      if (!(await pathIsFile(dbFile))) {
        throw new ApiError('Bản backup không chứa dữ liệu DB (cần db/wos.db hoặc config/wos-export.json — bật nguồn khi backup)')
      }
      // payload từ SQLite của CHÍNH hệ thống này (manifest đã kiểm app ở trên)
      payload = await exportPayloadFromSqlite(dbFile)
    }
    payload = validateBackupPayload(payload as unknown as Record<string, unknown>)

    // 5) snapshot TRƯỚC restore — cả DB lẫn storage (best-effort, không chặn)
    const snapDb = await snapshotDbFile()
    const snapStorage = await snapshotStorageTree()

    // 6)+(7) filesystem trước (holding + rollback riêng), DB sau (rollback FS nếu DB fail)
    const filesDir = path.join(stageDir, 'files')
    const hasFiles = await pathIsDir(filesDir)
    const holdingDir = path.join(workDir, 'holding')
    let restored = 0
    if (hasFiles) {
      await restoreStorageTree(filesDir, holdingDir)
      try {
        restored = (await applyBackupPayload(payload)).restored
      } catch (err) {
        await rollbackStorageTree(holdingDir) // DB fail → storage quay về như cũ
        throw err
      }
    } else {
      restored = (await applyBackupPayload(payload)).restored
    }

    // 8) chẩn đoán fileNode thiếu tệp + dọn holding
    const missingFiles = await countMissingFiles(payload)
    if (hasFiles) {
      await fsp.rm(holdingDir, { recursive: true, force: true }).catch(() => {})
    }

    await emitEvent({
      type: 'sync.restore.ok',
      module: SYNC_MODULE,
      actor: actor ? { id: actor.id, displayName: actor.displayName } : null,
      payload: { rows: restored, files: hasFiles, legacy, missingFiles, downloaded },
      notify: { title: 'Khôi phục backup hoàn tất', content: `${restored} dòng dữ liệu${hasFiles ? ' + toàn bộ tệp' : ''}${missingFiles > 0 ? ` • ${missingFiles} tệp thiếu trên đĩa` : ''}`, type: 'system' },
    }).catch(() => {})

    return { restored, legacy, missingFiles, snapshotDb: snapDb, snapshotStorage: snapStorage, filesRestored: hasFiles }
  } finally {
    g.__wosRestoreRunning = false
    await fsp.rm(workDir, { recursive: true, force: true }).catch(() => {})
  }
}

// ---------------------------------------------------------------------
// Scheduler — singleton qua globalThis, tick 60s
// ---------------------------------------------------------------------

function atToday(now: Date, hour: number, minute: number): Date {
  return new Date(now.getFullYear(), now.getMonth(), now.getDate(), hour, minute, 0, 0)
}

function mondayAt(now: Date, hour: number, minute: number): Date {
  const idx = (now.getDay() + 6) % 7 // 0 = Thứ 2
  return new Date(now.getFullYear(), now.getMonth(), now.getDate() - idx, hour, minute, 0, 0)
}

async function schedulerTick(): Promise<void> {
  const cfg = await getSyncConfig()
  if (cfg.schedule === 'off' || !cfg.refreshToken) return
  const now = new Date()
  const target = cfg.schedule === 'daily' ? atToday(now, 2, 0) : mondayAt(now, 3, 0)
  if (now < target) return // chưa tới giờ chạy trong kỳ hiện tại
  // Hạ tốc độ thử lại: kỳ hiện tại đã có lần chạy (dù lỗi) < 60 phút trước thì đợi
  const lastAttempt = await db.backupRun.findFirst({
    where: { trigger: 'schedule' },
    orderBy: { startedAt: 'desc' },
  })
  if (lastAttempt && Date.now() - lastAttempt.startedAt.getTime() < 60 * 60 * 1000) return
  // Chạy khi lần schedule THÀNH CÔNG gần nhất nằm trước mốc của kỳ hiện tại
  const lastOk = await db.backupRun.findFirst({
    where: { trigger: 'schedule', status: 'ok' },
    orderBy: { startedAt: 'desc' },
  })
  if (lastOk && lastOk.startedAt >= target) return
  await runBackup('schedule')
}

/** Khởi động scheduler (idempotent) — gọi trong route GET status */
export function ensureScheduler(): void {
  const g = syncGlobal()
  if (g.__wosSyncScheduler) return
  try {
    const timer = setInterval(() => {
      void schedulerTick().catch((err) => console.error('[sync]', err))
    }, 60_000)
    if (typeof (timer as unknown as { unref?: () => void }).unref === 'function') {
      ;(timer as unknown as { unref: () => void }).unref()
    }
    g.__wosSyncScheduler = timer
  } catch (err) {
    console.error('[sync]', err)
  }
}

// export cho route download
export { safeDriveId }
