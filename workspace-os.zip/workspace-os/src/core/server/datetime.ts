/**
 * DateTime helpers theo MÚI GIỜ cấu hình (Setting core:timezone, mặc định Asia/Bangkok).
 * Vấn đề: server (Orange Pi) thường chạy UTC trong khi user ở UTC+7 → mọi ranh giới
 * "ngày hôm nay / đầu ngày / năm hiện tại" lệch 7 tiếng (00:00–06:59 sai ngày).
 * Giải pháp: mọi API tính ngày theo tz cấu hình, KHÔNG dùng giờ local của process.
 *
 * QUYẾT ĐỊNH THIẾT KẾ (đã chốt): timezone là thiết đặt GLOBAL toàn hệ thống
 * (admin đặt trong Settings → core:timezone), KHÔNG phải per-user — WOS hướng tới
 * workspace cá nhân / gia đình ở cùng 1 múi giờ. Muốn per-user sau này: thêm cột
 * User.timezone rồi hàm này đọc theo session thay vì Setting.
 */
import { db } from '@/lib/db'

const DEFAULT_TZ = 'Asia/Bangkok'

let tzCache: { ts: number; value: string } | null = null
const TZ_TTL = 60_000

/** Múi giờ cấu hình GLOBAL trong Settings (core:timezone) — cache 60s */
export async function getUserTimezone(): Promise<string> {
  if (tzCache && Date.now() - tzCache.ts < TZ_TTL) return tzCache.value
  let value = DEFAULT_TZ
  try {
    const row = await db.setting.findUnique({ where: { id: 'core:timezone' } })
    if (row?.value) {
      // xác thực tz hợp lệ bằng cách dựng formatter thử
      new Intl.DateTimeFormat('en-US', { timeZone: row.value })
      value = row.value
    }
  } catch {
    value = DEFAULT_TZ
  }
  tzCache = { ts: Date.now(), value }
  return value
}

export function invalidateTimezoneCache(): void {
  tzCache = null
}

/** 'YYYY-MM-DD' của thời điểm d THEO múi giờ tz (không phụ thuộc TZ của process) */
export function isoDateInTz(d: Date, tz: string): string {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: tz,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(d)
  return parts // en-CA mặc định trả yyyy-mm-dd
}

/** Năm hiện tại theo múi giờ người dùng */
export function yearInTz(d: Date, tz: string): number {
  return Number(new Intl.DateTimeFormat('en-US', { timeZone: tz, year: 'numeric' }).format(d))
}

/** Thời điểm UTC của 00:00 THEO MÚI GIỜ tz của ngày hôm nay trừ `daysBack` ngày */
export function startOfDayInTz(daysBack: number, tz: string): Date {
  const now = new Date()
  const ymd = isoDateInTz(now, tz)
  const [y, m, d] = ymd.split('-').map(Number)
  // 00:00 theo tz ≈ lấy UTC midnight rồi hiệu chỉnh offset — dựng bằng cách giải offset thực tế
  const guess = new Date(Date.UTC(y, m - 1, d) - daysBack * 86400000)
  const offset = tzOffsetMs(guess, tz)
  return new Date(guess.getTime() - offset)
}

/** Offset (ms) của tz tại thời điểm d — dương khi tz chạy trước UTC */
function tzOffsetMs(d: Date, tz: string): number {
  const parts = tzWallParts(d, tz)
  const asUTC = Date.UTC(
    Number(parts.year), Number(parts.month) - 1, Number(parts.day),
    Number(parts.hour === '24' ? '0' : parts.hour), Number(parts.minute), Number(parts.second)
  )
  return asUTC - d.getTime()
}

/** Thành phần "đồng hồ treo tường" của d THEO tz (y/mo/day/h/mi/s/ms) */
interface WallParts {
  y: number
  mo: number
  day: number
  h: number
  mi: number
  s: number
  ms: number
}
function tzWallParts(d: Date, tz: string): Record<string, string> {
  const dtf = new Intl.DateTimeFormat('en-US', {
    timeZone: tz,
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit',
    hour12: false,
  })
  return dtf.formatToParts(d).reduce<Record<string, string>>((acc, p) => {
    if (p.type !== 'literal') acc[p.type] = p.value
    return acc
  }, {})
}

function wallOf(d: Date, tz: string): WallParts {
  const p = tzWallParts(d, tz)
  return {
    y: Number(p.year),
    mo: Number(p.month),
    day: Number(p.day),
    h: Number(p.hour === '24' ? '0' : p.hour),
    mi: Number(p.minute),
    s: Number(p.second),
    ms: d.getMilliseconds(),
  }
}

/** Dựng thời điểm tuyệt đối từ thành phần đồng hồ theo tz (round-trip offset, DST-safe) */
function fromWall(p: WallParts, tz: string): Date {
  const asUtc = Date.UTC(p.y, p.mo - 1, p.day, p.h, p.mi, p.s, p.ms)
  const off1 = tzOffsetMs(new Date(asUtc), tz)
  let ts = asUtc - off1
  const off2 = tzOffsetMs(new Date(ts), tz)
  if (off2 !== off1) ts = asUtc - off2 // biên DST hiếm — hiệu chỉnh vòng 2
  return new Date(ts)
}

/** Cộng n NGÀY theo LỊCH của tz (DST-SAFE): giữ nguyên giờ treo tường kể cả khi
 *  DST làm ngày dài 23h/25h. Cộng ms thuần (+86400000) sẽ lệch giờ ở múi giờ có DST
 *  (Việt Nam/Thái không có DST nhưng code này đúng cho mọi tz tương lai).
 *  Dùng cho recurrence daily/weekly của Calendar. */
export function addDaysInTz(d: Date, days: number, tz: string): Date {
  const p = wallOf(d, tz)
  return fromWall({ ...p, day: p.day + days }, tz)
}

/** Cộng n THÁNG theo LỊCH của tz + CHẶN cuối tháng (31/01 + 1 = 28/02) — DST-safe,
 *  đúng kể cả khi server chạy UTC. Dùng cho recurrence monthly (n=12 → yearly). */
export function addMonthsInTz(d: Date, months: number, tz: string): Date {
  const p = wallOf(d, tz)
  // ngày cuối của tháng đích (day 0 của tháng kế tiếp — Date.UTC tự chuẩn hoá tháng 13+/0-)
  const lastOfTarget = new Date(Date.UTC(p.y, p.mo - 1 + months + 1, 0)).getUTCDate()
  return fromWall({ ...p, mo: p.mo + months, day: Math.min(p.day, lastOfTarget) }, tz)
}
