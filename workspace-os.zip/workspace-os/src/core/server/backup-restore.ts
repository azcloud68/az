/**
 * WOS Backup Restore Engine — dùng chung cho:
 *  - POST /api/core/backup        (JSON metadata restore)
 *  - POST /api/modules/sync       (action=restore: tar.gz Google Drive)
 *
 * Bảo đảm nguyên tắc v2.3:
 *  1. Group/User FK: User KHÔNG nằm trong MODULE_TABLES (an toàn: không lộ hash
 *     mật khẩu) nhưng User.groupId → Group.id — nên TRƯỚC khi deleteMany('group')
 *     phải updateMany({ groupId: null }) nếu không transaction restore bị FK rollback.
 *  2. DB nguyên tử trong $transaction (lỗi giữa chừng → rollback toàn bộ).
 *  3. Filesystem (storage/) swap qua holding dir: DB fail → rollback FS —
 *     DB + files KHÔNG bao giờ ở trạng thái nửa vời (vấn đề "backup gồm SQLite +
 *     storage nhưng restore chỉ đụng DB" của bản ≤ v2.2).
 *  4. Snapshot TRƯỚC restore (db + storage) để admin tự cứu được khi sai lầm.
 */
import { promises as fsp } from 'fs'
import path from 'path'
import { execFile } from 'child_process'
import { promisify } from 'util'
import { db } from '@/lib/db'
import { baseStorageRoot } from './storage'
import { ApiError } from './api-error'
import {
  MODULE_TABLES, skipRestoreSetting, topoSortByParent,
  isForbiddenSetting, isRedactedSetting, REDACTED,
} from './backup-tables'

const execFileAsync = promisify(execFile)

/** Bảng có dòng tự tham chiếu (cần topo-sort cha trước con khi import) */
export const SELF_REF_TABLES = new Set(['wikiPage', 'workStep', 'workTask'])

/** Trần dung lượng storage để snapshot trước restore (tar.gz) — vượt thì bỏ qua
 *  snapshot (best-effort) và báo warning, vẫn restore được */
const MAX_STORAGE_SNAPSHOT_BYTES = 8 * 1024 * 1024 * 1024

export function isBackupMeta(v: unknown): v is { app?: string } {
  return Boolean(v) && typeof v === 'object'
}

/** Validate payload JSON restore: mọi bảng phải hợp lệ, mọi giá trị phải là mảng.
 *  Trả payload đã lọc — hoặc throw ApiError (400) hiện thẳng cho admin. */
export function validateBackupPayload(
  body: Record<string, unknown>,
): Record<string, Record<string, unknown>[]> {
  const payload: Record<string, Record<string, unknown>[]> = {}
  for (const [k, v] of Object.entries(body)) {
    if (k === '_meta') continue
    if (!(MODULE_TABLES as readonly string[]).includes(k)) {
      throw new ApiError(`Bảng không được hỗ trợ trong backup: "${k}"`)
    }
    if (!Array.isArray(v)) throw new ApiError(`Dữ liệu bảng "${k}" không hợp lệ`)
    payload[k] = v.filter((r) => r && typeof r === 'object' && !Array.isArray(r)) as Record<string, unknown>[]
  }
  return payload
}

/** Đường dẫn tuyệt đối tới file SQLite từ DATABASE_URL (file:./x hoặc file:/x) */
export function databaseFile(): string {
  const raw = (process.env.DATABASE_URL || '').trim()
  if (!raw) return path.resolve(process.cwd(), 'db/custom.db')
  const noScheme = raw.startsWith('file:') ? raw.slice(5) : raw
  const clean = noScheme.split('?')[0]
  return path.isAbsolute(clean) ? clean : path.resolve(process.cwd(), clean)
}

/** Thư mục chứa snapshot pre-restore (ngang hàng file DB) */
function snapshotsDir(): string {
  return path.join(path.dirname(databaseFile()), 'snapshots')
}

/** Snapshot DB file trước khi restore (best-effort — python sqlite backup API
 *  an toàn với WAL; fallback copy thường). Thất bại KHÔNG chặn restore. */
export async function snapshotDbFile(): Promise<string | null> {
  try {
    const dbFile = databaseFile()
    const dir = snapshotsDir()
    await fsp.mkdir(dir, { recursive: true })
    const dest = path.join(dir, `pre-restore-${new Date().toISOString().replace(/[:.]/g, '-')}.db`)
    try {
      await execFileAsync('python3', [
        '-c',
        `import sqlite3;s=sqlite3.connect(${JSON.stringify(dbFile)});d=sqlite3.connect(${JSON.stringify(dest)});s.backup(d);d.close();s.close()`,
      ])
    } catch {
      await fsp.copyFile(dbFile, dest)
    }
    return dest
  } catch (err) {
    console.warn('[backup] snapshot DB trước restore thất bại (best-effort):', err)
    return null
  }
}

/** Áp payload vào DB — TOÀN BỘ trong 1 TRANSACTION + giữ secret HIỆN TẠI xuyên qua
 *  restore (backup đã redact/bỏ chúng; không giữ thì mọi session chết).
 *  ⚠️ Mọi lệnh trong callback PHẢI dùng tx (transaction client) — dùng db toàn cục
 *  sẽ chạy NGOÀI transaction (mất tính nguyên tử).
 *  Trả { restored }. Caller chịu trách nhiệm snapshot + filesystem rollback. */
export async function applyBackupPayload(
  payload: Record<string, Record<string, unknown>[]>,
): Promise<{ restored: number }> {
  let restored = 0
  await db.$transaction(
    async (tx) => {
      const txAny = tx as unknown as Record<string, {
        deleteMany: () => Promise<unknown>
        createMany: (a: { data: unknown }) => Promise<unknown>
        updateMany: (a: { data: unknown }) => Promise<unknown>
      }>
      // Giữ lại secret HIỆN TẠI xuyên qua restore (auth_secret + credential sync)
      const currentSettings = await tx.setting.findMany()
      const secretsToKeep = currentSettings.filter(
        (r) => isForbiddenSetting(r) || isRedactedSetting(r) || r.value === REDACTED
      )
      // 0) FK Group/User: User không thuộc MODULE_TABLES nhưng User.groupId → Group.id
      //    vẫn còn trỏ — phải tháo TRƯỚC khi deleteMany('group'), nếu không
      //    transaction restore bị FK từ chối và rollback cả batch
      await txAny.user.updateMany({ data: { groupId: null } })
      // 1) xoá theo thứ tự CON TRƯỚC CHA (đảo ngược MODULE_TABLES)
      for (const table of [...MODULE_TABLES].reverse()) {
        await txAny[table].deleteMany()
      }
      // 2) insert CHA TRƯỚC CON; bảng tự tham chiếu → topo-sort theo parentId
      for (const table of MODULE_TABLES) {
        let rows = payload[table] || []
        if (table === 'setting') rows = rows.filter((r) => !skipRestoreSetting(r as { id?: string; key?: string; value?: string }))
        if (SELF_REF_TABLES.has(table)) rows = topoSortByParent(rows)
        for (let i = 0; i < rows.length; i += 50) {
          await txAny[table].createMany({ data: rows.slice(i, i + 50) })
        }
        restored += rows.length
      }
      // 3) phục hồi lại secret hiện tại đã giữ ở trên
      if (secretsToKeep.length > 0) {
        await tx.setting.createMany({ data: secretsToKeep })
        restored += secretsToKeep.length
      }
    },
    // restore lớn (nghìn dòng + SQLite chậm) — timeout mặc định 5s là không đủ
    { timeout: 120_000, maxWait: 10_000 }
  )
  return { restored }
}

/** Đếm fileNode trỏ tới tệp KHÔNG tồn tại trên đĩa — chẩn đoán trung thực sau khi
 *  restore METADATA (JSON backup không chứa blob tệp; muốn cả tệp dùng bản Drive). */
export async function countMissingFiles(
  payload: Record<string, Record<string, unknown>[]>,
): Promise<number> {
  const rows = payload['fileNode'] || []
  let missing = 0
  const base = baseStorageRoot()
  for (const r of rows) {
    const ownerId = typeof r.ownerId === 'string' ? r.ownerId : ''
    const p = typeof r.path === 'string' ? r.path : ''
    if (!ownerId || !p) continue // legacy row không định vị được — không đếm
    try {
      await fsp.access(path.join(base, 'users', ownerId, p))
    } catch {
      missing++
    }
  }
  return missing
}

// ---------------------------------------------------------------------
// Đọc DB SQLite của bản backup (tar không có config/wos-export.json)
// ---------------------------------------------------------------------

/**
 * Đọc các bảng module từ 1 file SQLite (python3 — có sẵn trên Orange Pi) →
 * payload JSON cùng format với bản export của GET /api/core/backup:
 *  - BOOLEAN → true/false (SQLite lưu 0/1)
 *  - DATETIME → ISO string (Prisma lưu epoch-ms trong SQLite)
 */
export async function exportPayloadFromSqlite(
  dbFile: string,
): Promise<Record<string, Record<string, unknown>[]>> {
  const script = [
    'import sqlite3, json, sys',
    'from datetime import datetime, timezone',
    'con = sqlite3.connect(sys.argv[1])',
    'con.row_factory = sqlite3.Row',
    'tables = json.loads(sys.argv[2])',
    'out = {}',
    'for t in tables:',
    '    rows = []',
    '    try:',
    '        info = list(con.execute(\'PRAGMA table_info("%s")\' % t))',
    '        bools = {r["name"] for r in info if "BOOL" in (r["type"] or "").upper()}',
    '        dates = {r["name"] for r in info if "DATETIME" in (r["type"] or "").upper()}',
    '        for r in con.execute(\'SELECT * FROM "%s"\' % t):',
    '            d = dict(r)',
    '            for k in bools:',
    '                if d.get(k) is not None: d[k] = bool(d[k])',
    '            for k in dates:',
    '                if d.get(k) is not None:',
    '                    d[k] = datetime.fromtimestamp(int(d[k]) / 1000, tz=timezone.utc).isoformat().replace("+00:00", "Z")',
    '            rows.append(d)',
    '    except Exception:',
    '        rows = []',
    '    out[t] = rows',
    'print(json.dumps(out, default=str))',
  ].join('\n')
  let stdout: string
  try {
    const res = await execFileAsync('python3', ['-c', script, dbFile, JSON.stringify([...MODULE_TABLES])], {
      maxBuffer: 128 * 1024 * 1024,
    })
    stdout = res.stdout
  } catch (err) {
    console.error('[backup] python3 đọc SQLite backup thất bại:', err)
    throw new ApiError('Không đọc được database trong bản backup (cần python3 trên máy) — bật nguồn "Cấu hình" khi backup để có wos-export.json', 500)
  }
  return JSON.parse(stdout) as Record<string, Record<string, unknown>[]>
}

// ---------------------------------------------------------------------
// Filesystem: snapshot + swap storage có rollback
// ---------------------------------------------------------------------

async function dirExists(p: string): Promise<boolean> {
  try {
    return (await fsp.stat(p)).isDirectory()
  } catch {
    return false
  }
}

async function fileExists(p: string): Promise<boolean> {
  try {
    return (await fsp.stat(p)).isFile()
  } catch {
    return false
  }
}

async function dirSize(dir: string): Promise<number> {
  let total = 0
  let entries
  try {
    entries = await fsp.readdir(dir, { withFileTypes: true })
  } catch {
    return 0
  }
  for (const e of entries) {
    const full = path.join(dir, e.name)
    if (e.isDirectory()) total += await dirSize(full)
    else {
      try {
        total += (await fsp.stat(full)).size
      } catch { /* bỏ qua */ }
    }
  }
  return total
}

/** Snapshot CÂY STORAGE (tar.gz) trước restore — best-effort vào db/snapshots/.
 *  Vượt trần dung lượng / tar lỗi → null + warning (KHÔNG chặn restore). */
export async function snapshotStorageTree(): Promise<string | null> {
  try {
    const root = path.resolve(baseStorageRoot())
    if (!(await dirExists(root))) return null
    const size = await dirSize(root)
    if (size > MAX_STORAGE_SNAPSHOT_BYTES) {
      console.warn(`[backup] snapshot storage bỏ qua (quá lớn: ${Math.round(size / 1024 / 1024)}MB > 8GB)`)
      return null
    }
    const dir = snapshotsDir()
    await fsp.mkdir(dir, { recursive: true })
    const dest = path.join(dir, `pre-restore-${new Date().toISOString().replace(/[:.]/g, '-')}-storage.tar.gz`)
    await execFileAsync('tar', ['-czf', dest, '-C', path.dirname(root), path.basename(root)], {
      maxBuffer: 16 * 1024 * 1024,
    })
    return dest
  } catch (err) {
    console.warn('[backup] snapshot storage trước restore thất bại (best-effort):', err)
    return null
  }
}

/**
 * Swap storage root sang nội dung của bản backup:
 *   root hiện tại → holdingDir (rename — nhanh, cùng filesystem)
 *   filesDir (trong tar đã giải) → copy đệ quy vào root
 * Lỗi giữa chừng khi COPY → tự rollback (trả holding về root) rồi throw.
 * Thành công → caller xoá holding SAU khi DB cũng áp xong (rollbackStorageTree
 * nếu DB fail). Giữ thunk nhỏ để caller điều phối.
 */
export async function restoreStorageTree(filesDir: string, holdingDir: string): Promise<void> {
  const root = path.resolve(baseStorageRoot())
  await fsp.mkdir(root, { recursive: true })
  await fsp.mkdir(holdingDir, { recursive: true })
  // 1) chuyển TOÀN BỘ nội dung root hiện tại sang holding
  for (const e of await fsp.readdir(root)) {
    await fsp.rename(path.join(root, e), path.join(holdingDir, e))
  }
  // 2) copy cây files/ từ backup vào root — lỗi → rollback ngay tại đây
  try {
    await fsp.cp(filesDir, root, { recursive: true })
  } catch (err) {
    await rollbackStorageTree(holdingDir)
    throw err
  }
}

/** Rollback: bỏ nội dung root HIỆN TẠI (bản restore dở), trả holding về root.
 *  Dùng khi DB apply thất bại SAU khi storage đã swap xong. */
export async function rollbackStorageTree(holdingDir: string): Promise<void> {
  const root = path.resolve(baseStorageRoot())
  try {
    for (const e of await fsp.readdir(root)) {
      await fsp.rm(path.join(root, e), { recursive: true, force: true }).catch(() => {})
    }
    for (const e of await fsp.readdir(holdingDir)) {
      await fsp.rename(path.join(holdingDir, e), path.join(root, e)).catch(() => {})
    }
  } catch (err) {
    console.error('[backup] rollback storage THẤT BẠI — dữ liệu cũ còn ở:', holdingDir, err)
  }
}

export { dirExists as pathIsDir, fileExists as pathIsFile }
