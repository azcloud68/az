/**
 * WOS System Info — đọc CPU/RAM/Đĩa từ /proc (chuẩn Orange Pi ARM64)
 * Dùng cho widget Disk Usage + Reports + Administration
 */
import { promises as fsp } from 'fs'
import os from 'os'
import { baseStorageRoot } from './storage'

interface CpuSnap { total: number; idle: number }
let lastCpuSnap: CpuSnap | null = null
let lastCpuPct: number | null = null
let lastSnapAt = 0

async function readCpuSnap(): Promise<CpuSnap> {
  const txt = await fsp.readFile('/proc/stat', 'utf8')
  const cpu = txt.split('\n')[0]?.split(/\s+/).slice(1).map(Number) || []
  const total = cpu.reduce((a, b) => a + (b || 0), 0)
  const idle = (cpu[3] || 0) + (cpu[4] || 0)
  return { total, idle }
}

export async function cpuPercent(): Promise<number> {
  try {
    const now = Date.now()
    const snap = await readCpuSnap()
    if (lastCpuSnap && now - lastSnapAt >= 300) {
      const dTotal = snap.total - lastCpuSnap.total
      const dIdle = snap.idle - lastCpuSnap.idle
      if (dTotal > 0) lastCpuPct = Math.max(0, Math.min(100, ((dTotal - dIdle) / dTotal) * 100))
      lastCpuSnap = snap
      lastSnapAt = now
    } else if (!lastCpuSnap) {
      lastCpuSnap = snap
      lastSnapAt = now
    }
    return Math.round(lastCpuPct ?? 0)
  } catch {
    const load = os.loadavg()[0]
    return Math.min(100, Math.round((load / Math.max(1, os.cpus().length)) * 100))
  }
}

export interface MemInfo { total: number; used: number; percent: number }

export async function memInfo(): Promise<MemInfo> {
  try {
    const txt = await fsp.readFile('/proc/meminfo', 'utf8')
    const get = (k: string) => Number((txt.match(new RegExp(`${k}:\\s+(\\d+)`)) || [])[1] || 0) * 1024
    const total = get('MemTotal')
    const available = get('MemAvailable')
    const used = total - available
    return { total, used, percent: total ? Math.round((used / total) * 100) : 0 }
  } catch {
    const total = os.totalmem()
    const used = total - os.freemem()
    return { total, used, percent: total ? Math.round((used / total) * 100) : 0 }
  }
}

export interface DiskInfo { total: number; used: number; free: number; percent: number; storageBytes: number }

export async function diskInfo(): Promise<DiskInfo> {
  const osStat = await fsp.statfs(os.platform() === 'win32' ? process.cwd() : '/')
  const total = Number(osStat.blocks) * Number(osStat.bsize)
  const free = Number(osStat.bavail) * Number(osStat.bsize)
  const used = total - free
  let storageBytes = 0
  try {
    const du = await fsp.readdir(baseStorageRoot(), { withFileTypes: true })
    storageBytes = du.length // chỉ đếm số entry cho nhẹ; Reports tính kỹ hơn
  } catch {
    storageBytes = 0
  }
  return {
    total,
    used,
    free,
    percent: total ? Math.round((used / total) * 100) : 0,
    storageBytes,
  }
}

export async function uptimeInfo(): Promise<{ seconds: number; human: string }> {
  const seconds = Math.round(os.uptime())
  const d = Math.floor(seconds / 86400)
  const h = Math.floor((seconds % 86400) / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  return { seconds, human: d > 0 ? `${d} ngày ${h} giờ` : h > 0 ? `${h} giờ ${m} phút` : `${m} phút` }
}

export interface SysStats {
  cpu: number
  mem: MemInfo
  disk: DiskInfo
  uptime: { seconds: number; human: string }
  platform: string
  arch: string
  hostname: string
  loadavg: number[]
  at: string
}

export async function sysStats(): Promise<SysStats> {
  const [cpu, mem, disk, uptime] = await Promise.all([cpuPercent(), memInfo(), diskInfo(), uptimeInfo()])
  return {
    cpu,
    mem,
    disk,
    uptime,
    platform: os.platform(),
    arch: os.arch(),
    hostname: os.hostname(),
    loadavg: os.loadavg().map((n) => Math.round(n * 100) / 100),
    at: new Date().toISOString(),
  }
}
