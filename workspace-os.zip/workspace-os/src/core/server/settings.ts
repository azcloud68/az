/**
 * WOS Settings Engine (Core) — kho key/value theo scope module
 * "Không còn một trang Settings duy nhất — mỗi module tự đăng ký setting."
 * Per-user (vd module appearance): key lưu dạng "u<userId>:<key>" — mỗi tài khoản
 * một bộ giá trị riêng; row legacy (không prefix) làm giá trị mặc định fallback.
 */
import { db } from '@/lib/db'

/** Key của user-scoped setting (đồng bộ format với core/server/user-data.ts) */
function userPrefix(userId: string): string {
  return `u${userId}:`
}

/** Nhận diện key có phải user-scoped của user KHÁC (u<cuid>:...) hay không */
const USER_SCOPED_KEY = /^u[a-z0-9]{16,}:/

export async function getSetting(module: string, key: string, fallback = ''): Promise<string> {
  const row = await db.setting.findUnique({ where: { id: `${module}:${key}` } })
  return row?.value ?? fallback
}

export async function getSettings(module: string, userId?: string): Promise<Record<string, string>> {
  const rows = await db.setting.findMany({ where: { module } })
  const out: Record<string, string> = {}
  if (!userId) {
    for (const r of rows) out[r.key] = r.value
    return out
  }
  // Per-user: legacy (không prefix) làm mặc định → per-user của user này đè lên
  const prefix = userPrefix(userId)
  for (const r of rows) {
    if (r.key.startsWith(prefix) || USER_SCOPED_KEY.test(r.key)) continue
    out[r.key] = r.value
  }
  for (const r of rows) {
    if (r.key.startsWith(prefix)) out[r.key.slice(prefix.length)] = r.value
  }
  return out
}

export async function setSetting(module: string, key: string, value: string, userId?: string): Promise<void> {
  if (userId) {
    const k = userPrefix(userId) + key
    await db.setting.upsert({
      where: { id: `${module}:${k}` },
      update: { value, updatedAt: new Date() },
      create: { id: `${module}:${k}`, module, key: k, value },
    })
    return
  }
  await db.setting.upsert({
    where: { id: `${module}:${key}` },
    update: { value, updatedAt: new Date() },
    create: { id: `${module}:${key}`, module, key, value },
  })
}

export async function setSettings(module: string, values: Record<string, string>, userId?: string): Promise<void> {
  for (const [key, value] of Object.entries(values)) {
    await setSetting(module, key, value, userId)
  }
}

export async function deleteSettings(module: string): Promise<void> {
  await db.setting.deleteMany({ where: { module } })
}

/** Settings mặc định khi seed */
export const DEFAULT_SETTINGS: Record<string, Record<string, string>> = {
  core: {
    workspace_name: 'Workspace OS',
    timezone: 'Asia/Bangkok',
    language: 'vi',
    date_format: 'dd/MM/yyyy',
    weather_city: 'Hồ Chí Minh',
    weather_lat: '10.762622',
    weather_lon: '106.660172',
    quota_gb: '20',
    ai_summary: 'on',
  },
  dashboard: { widgets_top: '', widgets_center: '', widgets_bottom: '', greeting: 'auto' },
  tasks: { default_view: 'list', default_priority: 'medium', quick_add: 'on' },
  calendar: { first_day: 'monday', show_holidays: 'on', day_start: '8' },
  notes: { autosave: 'on', font_size: '15' },
  wiki: { allow_anonymous_read: 'off' },
  files: { default_view: 'grid', preview_inline: 'on' },
  projects: { card_style: 'progress' },
  timeline: { group_by: 'day', limit: '100' },
  notifications: { browser: 'on', toast: 'on', reminder: 'on', email: 'off', email_to: '' },
  reports: { export_format: 'csv' },
  search: { hotkey: 'ctrl+k', limit: '24' },
  backup: { auto: 'off', keep: '5' },
}
