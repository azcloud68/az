/**
 * WOS Mailer (fix lỗi 8) — gửi email thông báo qua SMTP (Gmail App Password hoặc SMTP riêng).
 *
 * Kiến trúc:
 *   event-bus.emitEvent(notify) ─┬─► db.notification (Notification Center — như cũ)
 *                                └─► maybeEnqueueEmail()  ──► EmailQueue (pending)
 *                                                            │
 *   ensureMailScheduler() (60s tick) ─────────────────────────┴─► flushEmailQueue()
 *        - immediate  : gửi ngay trong tick kế tiếp (≤ 60s)
 *        - digest 15m/1h/ngày: GỘP các notification cùng người nhận trong 1 cửa sổ
 *          thời gian thành MỘT email (mergeKey + windowKey) — hết cảnh spam hộp thư.
 *
 * Cấu hình (module 'notifications' trong Setting — UI ở Settings → Notification):
 *   email_smtp_host (vd smtp.gmail.com) | email_smtp_port (465/587)
 *   email_smtp_user (tên đăng nhập Gmail) | email_smtp_password (App Password 16 ký tự)
 *   email_from (hiện thị "Workspace OS <user@gmail.com>") | email_to (địa chỉ nhận)
 *   email_mode: immediate | digest15 | digest60 | daily
 *   email_events (JSON): bật/tắt thông báo theo nhóm sự kiện (task/calendar/files/system/plugin)
 *
 * Bảo mật: password nằm trong Setting, key khớp SECRET_KEY_RE (/password/) nên
 * tự động bị redact khi export backup; API GET không bao giờ trả password.
 */
import nodemailer from 'nodemailer'
import type { Transporter } from 'nodemailer'
import { db } from '@/lib/db'
import { getSetting } from './settings'

export interface MailConfig {
  host: string
  port: number
  secure: boolean
  user: string
  password: string
  from: string
  to: string
  mode: 'immediate' | 'digest15' | 'digest60' | 'daily'
  enabled: boolean
  events: Record<string, boolean>
}

/** Nhóm sự kiện mặc định — user bật/tắt từng nhóm trong Settings */
export const DEFAULT_EMAIL_EVENTS: Record<string, boolean> = {
  tasks: true,      // công việc (tạo/hoàn thành/nhắc hẹn)
  calendar: true,   // sự kiện lịch
  files: true,      // tải lên / chia sẻ tệp
  system: true,     // backup, module, cài đặt, người dùng
  plugin: true,     // thông báo từ plugin
}

/** Map module → nhóm sự kiện email */
const MODULE_TO_GROUP: Record<string, string> = {
  tasks: 'tasks',
  calendar: 'calendar',
  files: 'files',
  core: 'system',
  settings: 'system',
  users: 'system',
  sync: 'system',
  notifications: 'system',
  backup: 'system',
}

function safeParseEvents(raw: string): Record<string, boolean> {
  try {
    const parsed = JSON.parse(raw || '{}') as Record<string, unknown>
    const out = { ...DEFAULT_EMAIL_EVENTS }
    for (const k of Object.keys(DEFAULT_EMAIL_EVENTS)) {
      if (typeof parsed[k] === 'boolean') out[k] = parsed[k] as boolean
    }
    return out
  } catch {
    return { ...DEFAULT_EMAIL_EVENTS }
  }
}

/** Đọc cấu hình SMTP từ Setting module 'notifications' */
export async function getMailConfig(): Promise<MailConfig> {
  const [
    host, port, user, password, from, to, mode, emailOn, eventsRaw,
  ] = await Promise.all([
    getSetting('notifications', 'email_smtp_host', ''),
    getSetting('notifications', 'email_smtp_port', '465'),
    getSetting('notifications', 'email_smtp_user', ''),
    getSetting('notifications', 'email_smtp_password', ''),
    getSetting('notifications', 'email_from', ''),
    getSetting('notifications', 'email_to', ''),
    getSetting('notifications', 'email_mode', 'immediate'),
    getSetting('notifications', 'email', 'off'),
    getSetting('notifications', 'email_events', JSON.stringify(DEFAULT_EMAIL_EVENTS)),
  ])
  const portNum = Number(port) || 465
  const m = (mode || 'immediate').trim()
  return {
    host: host.trim(),
    port: portNum,
    secure: portNum === 465, // 465 = SMTPS; 587 = STARTTLS (nodemailer tự nâng cấp)
    user: user.trim(),
    password,
    from: from.trim(),
    to: to.trim(),
    mode: (['immediate', 'digest15', 'digest60', 'daily'].includes(m) ? m : 'immediate') as MailConfig['mode'],
    enabled: emailOn === 'on',
    events: safeParseEvents(eventsRaw),
  }
}

/** Có cấu hình đủ để gửi không? */
export function mailReady(cfg: MailConfig): boolean {
  return Boolean(cfg.host && cfg.user && cfg.password && cfg.to)
}

let transporter: Transporter | null = null
let transporterKey = ''

/** Lấy transporter (cache theo cấu hình — đổi cấu hình là tạo lại) */
async function getTransporter(cfg: MailConfig): Promise<Transporter> {
  const key = `${cfg.host}:${cfg.port}:${cfg.user}:${cfg.password ? 'k' : ''}`
  if (transporter && transporterKey === key) return transporter
  if (transporter) {
    try { transporter.close() } catch { /* bỏ qua */ }
  }
  transporter = nodemailer.createTransport({
    host: cfg.host,
    port: cfg.port,
    secure: cfg.secure,
    auth: { user: cfg.user, pass: cfg.password },
    // Orange Pi tự ký + mạng chậm — tăng thời gian chịu đựng
    connectionTimeout: 20_000,
    greetingTimeout: 15_000,
    socketTimeout: 30_000,
  })
  transporterKey = key
  return transporter
}

/** Thư có giao diện đẹp thống nhất (text + HTML) */
function buildLetter(items: { title: string; content: string; module: string }[], cfg: MailConfig) {
  const list = items
    .map(
      (i) =>
        `<tr><td style="padding:10px 14px;border-bottom:1px solid #eee;">
          <div style="font-size:14px;font-weight:600;color:#1f2937;">${escapeHtml(i.title)}</div>
          ${i.content ? `<div style="font-size:13px;color:#6b7280;margin-top:4px;">${escapeHtml(i.content)}</div>` : ''}
          <div style="font-size:11px;color:#9ca3af;margin-top:4px;">Nhóm: ${escapeHtml(i.module)}</div>
        </td></tr>`,
    )
    .join('')
  const subject = items.length === 1 ? items[0].title : `📦 ${items.length} thông báo Workspace OS`
  const html = `<!doctype html><html><body style="margin:0;background:#f4f5f7;font-family:-apple-system,Segoe UI,Roboto,Arial,sans-serif;">
  <div style="max-width:560px;margin:24px auto;background:#fff;border-radius:14px;overflow:hidden;border:1px solid #e5e7eb;">
    <div style="padding:18px 24px;background:linear-gradient(135deg,#7c3aed,#a855f7);color:#fff;">
      <div style="font-size:17px;font-weight:700;">🖥️ Workspace OS</div>
      <div style="font-size:12px;opacity:.85;">Thông báo hệ thống${cfg.mode !== 'immediate' ? ' (bản gộp)' : ''}</div>
    </div>
    <table style="width:100%;border-collapse:collapse;">${list}</table>
    <div style="padding:14px 24px;font-size:11px;color:#9ca3af;">
      Email này do Workspace OS gửi theo cài đặt của bạn — đổi trong <b>Settings → Notification</b>.
    </div>
  </div></body></html>`
  const text = items.map((i) => `• ${i.title}${i.content ? ` — ${i.content}` : ''}`).join('\n')
  return { subject, html, text }
}

function escapeHtml(s: string): string {
  return String(s || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c] || c)
}

/** Thực gửi 1 email */
export async function sendMail(cfg: MailConfig, items: { title: string; content: string; module: string }[]): Promise<void> {
  if (!mailReady(cfg)) throw new Error('Chưa cấu hình đầy đủ SMTP (host / tài khoản / mật khẩu / địa chỉ nhận)')
  const tp = await getTransporter(cfg)
  const letter = buildLetter(items, cfg)
  const from = cfg.from || cfg.user
  await tp.sendMail({
    from: /^.*<.*>$/.test(from) ? from : `Workspace OS <${from}>`,
    to: cfg.to,
    subject: letter.subject,
    text: letter.text,
    html: letter.html,
  })
}

/** Kiểm tra kết nối SMTP (không gửi thư) — dùng cho nút "Kiểm tra" */
export async function verifyMail(cfg: MailConfig): Promise<void> {
  const tp = await getTransporter(cfg)
  await tp.verify()
}

/** Chu kỳ cửa sổ digest (ms) */
function windowMs(mode: MailConfig['mode']): number {
  if (mode === 'daily') return 24 * 60 * 60 * 1000
  if (mode === 'digest60') return 60 * 60 * 1000
  if (mode === 'digest15') return 15 * 60 * 1000
  return 0
}

/** Nhãn cửa sổ gộp — items cùng nhãn + cùng người nhận gộp 1 email */
function windowKeyFor(mode: MailConfig['mode'], at = new Date()): string {
  const ms = windowMs(mode)
  if (!ms) return `i-${at.getTime()}` // immediate: mỗi email riêng
  const bucket = Math.floor(at.getTime() / ms) * ms
  const d = new Date(bucket)
  const pad = (n: number) => String(n).padStart(2, '0')
  if (mode === 'daily') return `d-${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`
  if (mode === 'digest60') return `h-${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}`
  return `q-${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}-${pad(d.getMinutes())}`
}

/** Sự kiện này có thuộc nhóm được phép gửi email không? */
function groupAllowed(ev: { module: string }, cfg: MailConfig): boolean {
  const group = MODULE_TO_GROUP[ev.module] ?? 'plugin'
  return cfg.events[group] !== false
}

/**
 * Enqueue email cho 1 notification (gọi từ event-bus khi tạo notify).
 * Không bao giờ ném lỗi — email là kênh phụ, lỗi phải im lặng (đã log trong queue).
 */
export async function maybeEnqueueEmail(params: {
  userId: string | null
  notify: { title: string; content?: string; type?: string }
  ev: { module: string }
}): Promise<void> {
  try {
    const cfg = await getMailConfig()
    if (!cfg.enabled || !mailReady(cfg)) return
    if (!groupAllowed(params.ev, cfg)) return
    await db.emailQueue.create({
      data: {
        userId: params.userId,
        toEmail: cfg.to,
        title: String(params.notify.title || '').slice(0, 300),
        content: String(params.notify.content || '').slice(0, 2000),
        module: params.ev.module || 'core',
        type: params.notify.type || 'info',
        mergeKey: String(params.userId || 'all'),
        windowKey: windowKeyFor(cfg.mode),
      },
    })
  } catch (err) {
    console.error('[mailer] enqueue lỗi:', err)
  }
}

/* ───────────────────────────── Scheduler ───────────────────────────── */

let schedulerStarted = false
let flushing = false

/** Gửi mọi email đang chờ theo chế độ gộp — an toàn chạy đè (mutex) */
export async function flushEmailQueue(): Promise<{ sent: number; merged: number; failed: number }> {
  if (flushing) return { sent: 0, merged: 0, failed: 0 }
  flushing = true
  let sent = 0
  let merged = 0
  let failed = 0
  try {
    const cfg = await getMailConfig()
    if (!cfg.enabled) return { sent, merged, failed }
    if (!mailReady(cfg)) return { sent, merged, failed }

    // Gom pending theo (mergeKey, windowKey) — mỗi nhóm 1 email
    const pending = await db.emailQueue.findMany({
      where: { status: 'pending' },
      orderBy: { createdAt: 'asc' },
      take: 200,
    })
    if (pending.length === 0) return { sent, merged, failed }

    const groups = new Map<string, typeof pending>()
    for (const row of pending) {
      const key = `${row.mergeKey}::${row.windowKey}`
      const arr = groups.get(key) || []
      arr.push(row)
      groups.set(key, arr)
    }

    for (const [, rows] of groups) {
      const items = rows.map((r) => ({ title: r.title, content: r.content, module: r.module }))
      try {
        await sendMail(cfg, items)
        await db.emailQueue.updateMany({
          where: { id: { in: rows.map((r) => r.id) } },
          data: { status: 'sent', sentAt: new Date() },
        })
        sent += rows.length
        if (rows.length > 1) merged += rows.length - 1
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err)
        // tăng attempts — quá 5 lần → đánh dấu failed hẳn (hết vòng thử lại)
        for (const r of rows) {
          const attempts = r.attempts + 1
          await db.emailQueue
            .update({
              where: { id: r.id },
              data: { attempts, error: msg.slice(0, 500), status: attempts >= 5 ? 'failed' : 'pending' },
            })
            .catch(() => {})
        }
        failed += rows.length
        console.error('[mailer] gửi lỗi:', msg)
      }
    }
    return { sent, merged, failed }
  } finally {
    flushing = false
  }
}

/** Bật scheduler gửi email (chạy 1 lần / tiến trình — tick mỗi 60 giây) */
export function ensureMailScheduler(): void {
  if (schedulerStarted) return
  schedulerStarted = true
  const tick = async () => {
    try {
      const r = await flushEmailQueue()
      if (r.sent > 0) console.log(`[mailer] đã gửi ${r.sent} email (${r.merged} gộp)`)
    } catch {
      /* im lặng — tick sau thử lại */
    }
  }
  setInterval(tick, 60_000)
  setTimeout(tick, 15_000) // chạy sớm lần đầu sau khi server lên
}

/** Dọn email cũ (giữ 30 ngày) — gọi định kỳ */
export async function pruneEmailQueue(): Promise<void> {
  const cutoff = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
  await db.emailQueue.deleteMany({ where: { createdAt: { lt: cutoff } } }).catch(() => {})
}
