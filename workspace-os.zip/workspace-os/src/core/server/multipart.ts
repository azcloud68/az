/**
 * Multipart/form-data STREAM parser — file KHÔNG bao giờ nằm nguyên trong RAM.
 * RAM tối đa ≈ 1 chunk (64KB) + boundary tail, bất kể file 200MB hay 2GB.
 * Thay cho req.formData() (undici buffer toàn bộ file vào bộ nhớ → OOM máy 2GB).
 */
import { Writable } from 'stream'

export interface PartInfo {
  field: string
  filename: string
  contentType: string
}

export interface MultipartSink {
  /** Bắt đầu 1 part kiểu file — trả về writable để parser đẩy content vào (null = bỏ qua part) */
  onFileStart(info: PartInfo): Promise<Writable | null>
  /** Part file kết thúc (writable đã end) */
  onFileEnd?(info: PartInfo): Promise<void>
  /** Field thường (text, nhỏ, ≤ 1MB) */
  onField?(name: string, value: string): void
}

const CR = 13
const LF = 10
const MAX_FIELD = 1024 * 1024
const MAX_HEADERS = 64 * 1024

/** Ghi tuần tự vào write stream, chờ drain — không phình RAM */
export function writeChunk(ws: Writable, chunk: Buffer): Promise<void> {
  return new Promise((resolve, reject) => {
    const onErr = (err: Error) => reject(err)
    ws.once('error', onErr)
    if (ws.write(chunk)) {
      ws.removeListener('error', onErr)
      return resolve()
    }
    ws.once('drain', () => {
      ws.removeListener('error', onErr)
      resolve()
    })
  })
}

function parseHeaderLines(lines: string[]): PartInfo & { isFile: boolean } {
  let field = ''
  let filename = ''
  let contentType = ''
  let isFile = false
  for (const line of lines) {
    const idx = line.indexOf(':')
    if (idx < 0) continue
    const key = line.slice(0, idx).trim().toLowerCase()
    const val = line.slice(idx + 1).trim()
    if (key === 'content-disposition') {
      isFile = /filename=/i.test(val)
      const nm = val.match(/name="((?:[^"\\]|\\.)*)"/)
      if (nm) field = nm[1]
      const fn = val.match(/filename="((?:[^"\\]|\\.)*)"/)
      if (fn) filename = fn[1]
    } else if (key === 'content-type') {
      contentType = val
    }
  }
  return { field, filename, contentType, isFile }
}

/**
 * Parse body multipart từ stream. Ném lỗi khi: thiếu boundary, body đứt giữa chừng,
 * header part > 64KB, field text > 1MB. File content KHÔNG giới hạn ở parser
 * (route tự giới hạn theo quota / MAX_FILE qua writable của mình).
 */
export async function parseMultipartStream(
  body: ReadableStream<Uint8Array> | null,
  contentTypeHeader: string,
  sink: MultipartSink
): Promise<void> {
  const m = (contentTypeHeader || '').match(/boundary="?([^";,]+)"?/i)
  if (!m || !body) throw new Error('Yêu cầu phải là multipart/form-data')
  const boundary = Buffer.from(`--${m[1]}`)
  const DELIM = Buffer.concat([Buffer.from('\r\n'), boundary]) // \r\n--BOUNDARY

  const reader = body.getReader()
  let buf = Buffer.alloc(0)
  let state: 'preamble' | 'headers' | 'content' = 'preamble'
  let currentWs: Writable | null = null
  let currentInfo: PartInfo | null = null
  let fieldChunks: Buffer[] = []
  let fieldLen = 0

  async function readMore(): Promise<boolean> {
    const { done, value } = await reader.read()
    if (done || !value) return false
    buf = buf.length ? Buffer.concat([buf, Buffer.from(value)]) : Buffer.from(value)
    return true
  }

  /** Đảm bảo buf có tối thiểu n byte — trả false nếu body hết */
  async function ensure(n: number): Promise<boolean> {
    while (buf.length < n) {
      if (!(await readMore())) return false
    }
    return true
  }

  async function deliver(chunk: Buffer): Promise<void> {
    if (currentWs) {
      await writeChunk(currentWs, chunk)
    } else if (currentInfo) {
      fieldLen += chunk.length
      if (fieldLen > MAX_FIELD) throw new Error('Field quá lớn (> 1MB)')
      fieldChunks.push(chunk)
    }
  }

  /** Kết thúc part hiện tại: end writable (file) hoặc trả field (text) */
  async function endPart(): Promise<void> {
    if (currentWs) {
      const ws = currentWs
      await new Promise<void>((resolve, reject) => {
        ws.once('error', reject)
        ws.end(() => {
          ws.removeListener('error', reject)
          resolve()
        })
      })
      if (sink.onFileEnd && currentInfo) await sink.onFileEnd(currentInfo)
    } else if (currentInfo && sink.onField) {
      sink.onField(currentInfo.field, Buffer.concat(fieldChunks).toString('utf-8'))
    }
    currentWs = null
    currentInfo = null
    fieldChunks = []
    fieldLen = 0
  }

  for (;;) {
    if (state === 'preamble') {
      const idx = buf.indexOf(boundary)
      if (idx < 0) {
        // giữ tail phòng boundary bị cắt giữa 2 chunk
        const keep = boundary.length - 1
        if (buf.length > keep) buf = buf.slice(buf.length - keep)
        if (!(await readMore())) throw new Error('Multipart không hợp lệ (thiếu boundary đầu)')
        continue
      }
      buf = buf.slice(idx + boundary.length)
      if (!(await ensure(2))) throw new Error('Multipart không hợp lệ (sau boundary đầu)')
      if (buf[0] === 45 && buf[1] === 45) return // --BOUNDARY-- : body rỗng
      if (buf[0] === CR && buf[1] === LF) buf = buf.slice(2)
      state = 'headers'
      continue
    }

    if (state === 'headers') {
      const end = buf.indexOf('\r\n\r\n')
      if (end < 0) {
        if (buf.length > MAX_HEADERS) throw new Error('Header của part quá dài')
        if (!(await readMore())) throw new Error('Multipart đứt (đang đọc header part)')
        continue
      }
      const lines = buf.slice(0, end).toString('utf-8').split('\r\n').filter(Boolean)
      buf = buf.slice(end + 4)
      const parsed = parseHeaderLines(lines)
      if (parsed.isFile) {
        currentInfo = { field: parsed.field, filename: parsed.filename, contentType: parsed.contentType }
        currentWs = await sink.onFileStart(currentInfo)
      } else {
        currentInfo = { field: parsed.field, filename: parsed.filename, contentType: parsed.contentType }
        currentWs = null
        fieldChunks = []
        fieldLen = 0
      }
      state = 'content'
      continue
    }

    // state === 'content'
    const idx = buf.indexOf(DELIM)
    if (idx >= 0) {
      await deliver(buf.slice(0, idx))
      buf = buf.slice(idx + DELIM.length)
      await endPart()
      if (!(await ensure(2))) throw new Error('Multipart đứt (sau kết thúc part)')
      if (buf[0] === 45 && buf[1] === 45) return // --BOUNDARY--
      if (buf[0] === CR && buf[1] === LF) buf = buf.slice(2)
      state = 'headers'
      continue
    }
    // chưa thấy delimiter: đẩy phần lớn, giữ tail phòng delimiter bị cắt
    const keep = DELIM.length - 1
    if (buf.length > keep) {
      const out = buf.slice(0, buf.length - keep)
      buf = buf.slice(buf.length - keep)
      await deliver(out)
    }
    if (!(await readMore())) throw new Error('Multipart đứt (đang đọc nội dung part)')
  }
}
