/**
 * Backup engine — dùng chung cho /api/core/backup (JSON) và Google Drive sync.
 * - MODULE_TABLES: ĐỦ bảng dữ liệu người dùng (kể cả Weekly + Plugin + Layout)
 *   nhưng KHÔNG chứa User/Session/PasswordReset (an toàn: không lộ hash mật khẩu)
 * - sanitizeBackupSettings(): redact secret trước khi xuất file
 * - restoreSettingRow(): bỏ qua secret đã redact + không bao giờ đè auth_secret
 */
import type { Prisma } from '@prisma/client'

/** Thứ tự insert: CHA trước CON (FK); thứ tự delete sẽ đảo ngược */
export const MODULE_TABLES = [
  'task', 'subtask', 'taskComment', 'taskHistory',
  'calendarEvent', 'note', 'wikiPage', 'wikiVersion',
  'fileNode', 'shareLink', 'project', 'projectMilestone', 'projectMember',
  'workProcess', 'workStep', 'workPrep', 'workDay', 'workTask',
  'setting', 'moduleState', 'eventRecord', 'activityLog', 'notification',
  'group', 'plugin', 'userLayout',
] as const

export type BackupTable = (typeof MODULE_TABLES)[number]
export type BackupDb = Record<BackupTable, unknown>

/** Marker giá trị secret đã bị thay trong file export */
export const REDACTED = '[REDACTED]'

const SECRET_KEY_RE = /secret|token|password|private_key|api_?key/i

/** Key setting nhạy cảm — KHÔNG xuất file backup (bỏ hẳn) */
export function isForbiddenSetting(row: { id?: string; key?: string; module?: string }): boolean {
  const id = row.id || ''
  if (id === 'core:auth_secret') return true
  return false
}

/** Key setting chứa credential — xuất dưới dạng [REDACTED] (restore giữ giá trị hiện tại) */
export function isRedactedSetting(row: { id?: string; key?: string }): boolean {
  const k = row.key || row.id || ''
  return SECRET_KEY_RE.test(k)
}

/** Lọc + redact các dòng setting trước khi ghi vào file backup */
export function sanitizeBackupSettings(rows: { id: string; module?: string; key?: string; value: string }[]): { id: string; module?: string; key?: string; value: string }[] {
  return rows
    .filter((r) => !isForbiddenSetting(r))
    .map((r) => (isRedactedSetting(r) ? { ...r, value: REDACTED } : r))
}

/** Khi import: dòng nào bị bỏ qua? (secret đã redact / auth_secret — giữ giá trị server hiện tại) */
export function skipRestoreSetting(row: { id?: string; key?: string; value?: string }): boolean {
  if (!row.id) return true
  if (isForbiddenSetting(row)) return true
  if (row.value === REDACTED) return true
  return false
}

/** Sắp xếp dòng tự tham chiếu (parentId) cha-trước-con — insert an toàn FK */
export function topoSortByParent<T extends Record<string, unknown>>(rows: T[], idKey = 'id', parentKey = 'parentId'): T[] {
  const byId = new Map<string, T>()
  for (const r of rows) {
    const id = String(r[idKey] ?? '')
    if (id) byId.set(id, r)
  }
  const out: T[] = []
  const emitted = new Set<string>()
  let pending = [...rows]
  for (;;) {
    const ready = pending.filter((r) => {
      const pid = r[parentKey] == null ? null : String(r[parentKey])
      return pid == null || pid === '' || emitted.has(pid) || !byId.has(pid)
    })
    if (ready.length === 0) break
    for (const r of ready) {
      emitted.add(String(r[idKey] ?? ''))
      out.push(r)
    }
    pending = pending.filter((r) => !ready.includes(r))
  }
  // vòng lặp tham chiếu / cha thiếu — gắn cuối cùng (FK sẽ hụt → transaction rollback sạch)
  out.push(...pending)
  return out
}

export type PrismaTx = Prisma.TransactionClient
