import { WosApp } from '@/components/wos/WosApp'

export default function Home() {
  return <WosApp />
}
