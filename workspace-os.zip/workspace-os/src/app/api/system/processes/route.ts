import { NextRequest } from 'next/server'
import { handle, ok, fail, requireSession, readJson } from '@/core/server/api'
import { listProcesses } from '@/core/server/system-monitor'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** GET /api/system/processes — bảng tiến trình (CPU%, RSS, user, cmdline) — như PC.
 *  POST /api/system/processes { pid, signal? } — KILL tiến trình: CHỈ ADMIN,
 *  chặn pid 1 + pid của chính server WOS (tránh tự sát remote). */
export async function GET(req: NextRequest) {
  return handle(async () => {
    await requireSession()
    const limit = Math.min(300, Math.max(20, Number(req.nextUrl.searchParams.get('limit')) || 120))
    return ok({ processes: await listProcesses(limit), me: process.pid })
  })
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    if (session.role !== 'admin') return fail('Chỉ quản trị viên mới được kết thúc tiến trình', 403)
    const body = await readJson<{ pid?: number; signal?: string }>(req)
    const pid = Number(body.pid)
    if (!Number.isInteger(pid) || pid <= 1) return fail('PID không hợp lệ')
    if (pid === process.pid) return fail('Không thể kết thúc chính tiến trình WOS')
    const signal = body.signal === 'kill' ? 'SIGKILL' : 'SIGTERM'
    try {
      process.kill(pid, signal)
    } catch (err) {
      return fail(`Không kết thúc được tiến trình ${pid} — ${err instanceof Error ? err.message : 'lỗi'}`, 404)
    }
    return ok({ pid, signal })
  })
}
