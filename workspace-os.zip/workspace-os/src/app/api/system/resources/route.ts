import { handle, ok, requireSession } from '@/core/server/api'
import { resourceSnapshot } from '@/core/server/system-monitor'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** GET /api/system/resources — tài nguyên live (CPU per-core, RAM, disk, net, temp).
 *  Client poll mỗi 2s (Activity Monitor app + chỉ báo MenuBar). Cache delta nằm
 *  trong engine — gọi liên tục mới ra CPU%/mạng chính xác. */
export async function GET() {
  return handle(async () => {
    await requireSession()
    return ok(await resourceSnapshot())
  })
}
