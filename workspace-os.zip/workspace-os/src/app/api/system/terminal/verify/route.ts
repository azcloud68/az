import { NextRequest } from 'next/server'
import { handle, ok, fail, readJson } from '@/core/server/api'
import { verifyServiceToken } from '@/core/server/auth'
import { db } from '@/lib/db'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** POST /api/system/terminal/verify — NỘI BỘ: Terminal service đối chiếu token trước khi
 *  mở shell. Kiểm: chữ ký HMAC (scope 'terminal') + hạn dùng + SESSION CÒN SỐNG trong DB
 *  (đăng xuất / thu hồi phiên → terminal đóng theo). Không cần cookie — service gọi
 *  trực tiếp từ localhost. */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const body = await readJson<{ token?: string }>(req)
    const payload = await verifyServiceToken(body.token, 'terminal')
    if (!payload) return fail('Token không hợp lệ hoặc đã hết hạn', 401)
    const sid = String(payload.sid || '')
    // sid có thể là id dòng Session (từ SessionUser.sessionId) hoặc token ngẫu nhiên
    // (từ cookie) — dò cả hai để chắc chắn
    const session = sid
      ? await db.session.findFirst({ where: { OR: [{ id: sid }, { token: sid }] }, include: { user: true } })
      : null
    if (!session || session.expiresAt.getTime() < Date.now() || !session.user.active) {
      return fail('Phiên đăng nhập đã kết thúc', 401)
    }
    return ok({
      ok: true,
      uid: session.user.id,
      role: session.user.role,
      user: session.user.username,
      sessionId: session.id,
    })
  })
}
