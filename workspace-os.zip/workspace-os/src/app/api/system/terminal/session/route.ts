import { handle, ok, fail, requireModule } from '@/core/server/api'
import { createServiceToken } from '@/core/server/auth'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** POST /api/system/terminal/session — cấp token ngắn hạn (10 phút) cho Terminal
 *  service. Token được service MANG LẠI đối chiếu ngược qua /api/system/terminal/verify
 *  (kiểm cả session còn sống trong DB) — không chia sẻ secret qua env giữa 2 tiến trình.
 *
 *  KẾT NỐI (v6.2 — tự dò thay vì tin env mù):
 *   mode 'proxy'   → qua Next rewrite /terminal-ws (cùng origin — qua được Cloudflare
 *                    Tunnel/Caddy; polling). Kiểm chứng bằng cách tự fetch CHÍNH origin
 *                    của mình: nếu rewrite chưa được bật lúc build (cài lại zip bằng tay,
 *                    .env cũ…) thì tự động rơi xuống mode khác thay vì chết kết nối.
 *   mode 'direct'  → thẳng http://<host>:<cổng service> (LAN; WebSocket thật).
 *   mode 'gateway' → qua Caddy ?XTransformPort (sandbox dev).
 *   mode 'none'    → service không lên — trả lời kèm hướng dẫn systemctl.
 */
const TOKEN_TTL = 10 * 60 * 1000

interface ProbeResult {
  alive: boolean
  isTerminal: boolean
}

/** Dò 1 URL: trả lời phải là terminal service (JSON health hoặc engine.io) */
async function probe(url: string): Promise<ProbeResult> {
  try {
    const res = await fetch(url, {
      signal: AbortSignal.timeout(2500),
      redirect: 'manual',
      headers: { 'user-agent': 'wos-terminal-probe' },
    })
    const body = await res.text().catch(() => '')
    const isTerminal = body.includes('wos-terminal') || body.includes('Transport unknown')
    return { alive: true, isTerminal }
  } catch {
    return { alive: false, isTerminal: false }
  }
}

export async function POST() {
  return handle(async () => {
    const session = await requireModule('terminal')
    if (session.role === 'viewer') return fail('Tài khoản chỉ đọc không dùng được Terminal', 403)
    const token = await createServiceToken(
      'terminal',
      { sid: session.sessionId, uid: session.id, role: session.role, user: session.username },
      TOKEN_TTL,
    )

    const proxyPath = process.env.WOS_TERMINAL_PATH || '/terminal-ws'
    const servicePort = Number(
      process.env.WOS_TERMINAL_PROXY_PORT || process.env.WOS_TERMINAL_PORT || 3005,
    )
    const ownPort = Number(process.env.PORT || 3000)

    // 1) Next rewrite /terminal-ws (ưu tiên cao nhất — cùng origin, an toàn qua tunnel)
    const viaProxy = await probe(`http://127.0.0.1:${ownPort}${proxyPath}`)
    if (viaProxy.isTerminal) {
      return ok({ token, mode: 'proxy', path: proxyPath, port: servicePort })
    }

    // 2) Terminal service trực tiếp trên cổng riêng (LAN)
    const direct = await probe(`http://127.0.0.1:${servicePort}${proxyPath}`)
    if (direct.isTerminal) {
      return ok({ token, mode: 'direct', path: proxyPath, port: servicePort })
    }

    // 3) Caddy gateway (sandbox dev — ?XTransformPort)
    const gwPort = Number(process.env.WOS_TERMINAL_PORT || 3005)
    const gateway = await probe(`http://127.0.0.1:${gwPort}/`)
    if (gateway.isTerminal) {
      return ok({ token, mode: 'gateway', path: '/', port: gwPort })
    }

    // Không tìm thấy đường nào — báo lỗi rõ nguyên nhân + hướng xử trí
    if (direct.alive && !direct.isTerminal) {
      return fail(
        'Cổng ' + servicePort + ' có chương trình khác đang trả lời (không phải wos-terminal). Kiểm tra: systemctl status wos-terminal',
        502,
      )
    }
    return fail(
      'Terminal service chưa chạy trên máy chủ. Khởi động: sudo systemctl restart wos-terminal (xem log: journalctl -u wos-terminal -e)',
      502,
    )
  })
}
