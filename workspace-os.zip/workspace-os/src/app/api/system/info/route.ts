import { handle, ok, requireSession } from '@/core/server/api'
import { systemInfo } from '@/core/server/system-monitor'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** GET /api/system/info — thông tin tĩnh máy chủ (hostname, CPU model, board, kernel…)
 *  Cho System Monitor + Settings → Hệ thống. Bất kỳ ai đã đăng nhập đều xem được
 *  (như mọi PC: user nào cũng xem About This Computer). */
export async function GET() {
  return handle(async () => {
    await requireSession()
    return ok(await systemInfo())
  })
}
