/**
 * /api/modules/sync/gdrive/files — danh sách tệp backup trong folder WorkspaceOS-Backup
 */
import { handle, ok, requireSession } from '@/core/server/api'
import { listDriveBackups } from '@/core/server/sync'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET() {
  return handle(async () => {
    await requireSession()
    const files = await listDriveBackups()
    return ok({ files })
  })
}
