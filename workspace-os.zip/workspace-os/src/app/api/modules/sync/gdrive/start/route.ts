/**
 * /api/modules/sync/gdrive/start — bắt đầu OAuth Google Drive (admin)
 * Trả consent URL: scope drive.file + userinfo.email, access_type=offline, prompt=consent.
 * v2.3: kèm STATE CSRF (random 32 byte, gắn sessionId admin, TTL 10 phút) —
 * callback chỉ nhận code do CHÍNH flow này khởi phát (chặn attack code của Drive khác).
 */
import { NextRequest } from 'next/server'
import { handle, ok, fail, requireAdmin } from '@/core/server/api'
import { getSyncConfig, requestOrigin, createOAuthState } from '@/core/server/sync'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireAdmin()
    const cfg = await getSyncConfig()
    if (!cfg.clientId || !cfg.clientSecret) {
      return fail('Chưa nhập Client ID / Client Secret — lưu thông tin Google Cloud trước')
    }
    const redirectUri = `${requestOrigin(req)}/api/modules/sync/gdrive/callback`
    const state = createOAuthState(session.sessionId)
    const params = new URLSearchParams({
      client_id: cfg.clientId,
      redirect_uri: redirectUri,
      response_type: 'code',
      scope: 'https://www.googleapis.com/auth/drive.file https://www.googleapis.com/auth/userinfo.email',
      access_type: 'offline',
      prompt: 'consent',
      state,
    })
    return ok({ url: `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}` })
  })
}
