/**
 * /api/modules/sync/gdrive/callback — Google redirect về đây sau consent
 * Guard: session admin phải còn hợp lệ (cookie same-origin đi kèm redirect).
 * v2.3 — Guard STATE CSRF: state param phải khớp state do /start sinh cho CHÍNH
 * session này (còn hiệu lực 10 phút, tiêu thu 1 lần). Chặn kịch bản attacker tự
 * dựng flow để nhét authorization code (Drive của attacker) vào callback khi
 * admin đang đăng nhập — server từng đổi code đó và lưu refresh_token của người khác.
 * Đổi code lấy token, lưu refresh_token + email, redirect về `${origin}/?sync=ok`.
 * Lỗi bất kỳ → redirect `${origin}/?sync=error&message=...`
 */
import { NextRequest, NextResponse } from 'next/server'
import { getSession } from '@/core/server/auth'
import { getSyncConfig, saveSyncConfig, requestOrigin, consumeOAuthState } from '@/core/server/sync'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

function redirectError(origin: string, message: string): NextResponse {
  const url = `${origin}/?sync=error&message=${encodeURIComponent(message)}`
  return NextResponse.redirect(url, 302)
}

export async function GET(req: NextRequest) {
  const origin = requestOrigin(req)
  try {
    // Guard: người mở link phải là admin đang đăng nhập
    const session = await getSession()
    if (!session || session.role !== 'admin') {
      return redirectError(origin, 'Phiên quản trị không còn hợp lệ — hãy đăng nhập lại rồi bấm "Kết nối Google Drive" lần nữa')
    }

    const denied = req.nextUrl.searchParams.get('error')
    if (denied) {
      return redirectError(origin, `Bạn từ chối uỷ quyền: ${denied}`)
    }

    // v2.3 — STATE CSRF: bắt buộc TRƯỚC KHI đổi code (tiêu thu 1 lần kể cả khi sai)
    const state = req.nextUrl.searchParams.get('state') || ''
    if (!state || !consumeOAuthState(session.sessionId, state)) {
      return redirectError(origin, 'Phiên kết nối không còn hiệu lực hoặc không khớp (anti-CSRF state) — hãy bấm "Kết nối Google Drive" lần nữa')
    }

    const code = req.nextUrl.searchParams.get('code')
    if (!code) return redirectError(origin, 'Không nhận được mã uỷ quyền từ Google')

    const cfg = await getSyncConfig()
    if (!cfg.clientId || !cfg.clientSecret) {
      return redirectError(origin, 'Chưa cấu hình Client ID / Client Secret')
    }

    // Đổi code lấy token (redirect_uri phải trùng khớp lúc start)
    const redirectUri = `${origin}/api/modules/sync/gdrive/callback`
    const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: cfg.clientId,
        client_secret: cfg.clientSecret,
        redirect_uri: redirectUri,
        grant_type: 'authorization_code',
      }),
      signal: AbortSignal.timeout(30000),
    })
    if (!tokenRes.ok) {
      const text = await tokenRes.text().catch(() => '')
      console.error('[sync]', `Đổi code thất bại (${tokenRes.status}): ${text.slice(0, 300)}`)
      return redirectError(origin, `Đổi mã uỷ quyền thất bại (${tokenRes.status}) — kiểm tra lại Redirect URI khớp chính xác với Google Cloud Console`)
    }
    const tok = (await tokenRes.json()) as { access_token?: string; refresh_token?: string }
    if (!tok.access_token || !tok.refresh_token) {
      return redirectError(origin, 'Google không trả về refresh_token — hãy bấm "Kết nối Google Drive" và đồng ý lại (chọn tài khoản đang dùng)')
    }

    // Lấy email tài khoản (best-effort)
    let account = ''
    try {
      const userRes = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
        headers: { authorization: `Bearer ${tok.access_token}` },
        signal: AbortSignal.timeout(30000),
      })
      if (userRes.ok) {
        account = ((await userRes.json()) as { email?: string }).email || ''
      }
    } catch (err) {
      console.error('[sync]', err)
    }

    await saveSyncConfig({ refreshToken: tok.refresh_token, account })
    return NextResponse.redirect(`${origin}/?sync=ok`, 302)
  } catch (err) {
    console.error('[sync]', err)
    return redirectError(origin, err instanceof Error ? err.message : 'Lỗi kết nối Google Drive')
  }
}
