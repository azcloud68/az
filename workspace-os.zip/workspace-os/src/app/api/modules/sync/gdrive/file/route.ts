/**
 * /api/modules/sync/gdrive/file?id=...&name=... — tải tệp backup từ Drive về máy
 * Stream alt=media (Bearer) → Response attachment.
 * Timeout 5 phút (tệp tar.gz lớn cần nhiều thời gian hơn 30s).
 */
import { NextRequest, NextResponse } from 'next/server'
import { fail, handle, requireSession } from '@/core/server/api'
import { driveFetch, safeDriveId } from '@/core/server/sync'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  return handle(async () => {
    await requireSession()
    const id = req.nextUrl.searchParams.get('id') || ''
    try {
      safeDriveId(id)
    } catch {
      return fail('Drive file id không hợp lệ')
    }
    const name = (req.nextUrl.searchParams.get('name') || `wos-backup-${id}.tar.gz`)
      .replace(/[\r\n"/\\]/g, '_')
      .slice(0, 200)

    const res = await driveFetch(
      `https://www.googleapis.com/drive/v3/files/${id}?alt=media`,
      {},
      300000,
    )
    const body = res.body
    if (!res.ok || !body) {
      const text = res.ok ? '' : await res.text().catch(() => '')
      console.error('[sync]', `Tải tệp Drive ${id} thất bại (${res.status})`)
      return fail(`Tải tệp từ Google Drive thất bại (${res.status}) ${text.slice(0, 150)}`.trim(), res.status === 404 ? 404 : 502)
    }
    return new NextResponse(body, {
      headers: {
        'content-type': res.headers.get('content-type') || 'application/octet-stream',
        'content-disposition': `attachment; filename="${name}"`,
        'cache-control': 'no-store',
      },
    })
  })
}
