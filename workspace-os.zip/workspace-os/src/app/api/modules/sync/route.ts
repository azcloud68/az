/**
 * /api/modules/sync — trạng thái, cấu hình, hành động Sync & Backup Google Drive
 * GET  (session)  : config (che secret/token) + drive_usage + 15 run gần nhất + khởi scheduler
 * PUT  (admin)    : lưu client_id/client_secret/sources/schedule/keep
 * POST (admin)    : action 'backup-now' | 'disconnect' | 'restore'
 */
import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { handle, ok, fail, readJson, requireSession, requireAdmin } from '@/core/server/api'
import { getSyncConfig, saveSyncConfig, runBackup, ensureScheduler, getAccessToken, restoreDriveBackup } from '@/core/server/sync'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

interface DriveUsage {
  limit: number
  usage: number
  usageInDrive: number
}

/** GET — trạng thái sync (đăng nhập là xem được) */
export async function GET() {
  return handle(async () => {
    await requireSession()
    ensureScheduler()
    const cfg = await getSyncConfig()

    let drive_usage: DriveUsage | null = null
    if (cfg.refreshToken) {
      try {
        const token = await getAccessToken(cfg)
        const res = await fetch('https://www.googleapis.com/drive/v3/about?fields=storageQuota', {
          headers: { authorization: `Bearer ${token}` },
          signal: AbortSignal.timeout(30000),
        })
        if (res.ok) {
          const data = (await res.json()) as {
            storageQuota?: { limit?: string; usage?: string; usageInDrive?: string }
          }
          const q = data.storageQuota || {}
          drive_usage = {
            limit: Number(q.limit || 0),
            usage: Number(q.usage || 0),
            usageInDrive: Number(q.usageInDrive || 0),
          }
        }
      } catch (err) {
        console.error('[sync]', err)
      }
    }

    const history = await db.backupRun.findMany({ orderBy: { startedAt: 'desc' }, take: 15 })
    return ok({
      config: {
        has_client_id: !!cfg.clientId,
        has_secret: !!cfg.clientSecret,
        has_token: !!cfg.refreshToken,
        account: cfg.account,
        sources: cfg.sources,
        schedule: cfg.schedule,
        keep: cfg.keep,
        drive_usage,
      },
      history,
    })
  })
}

/** PUT — lưu cấu hình (admin) */
export async function PUT(req: NextRequest) {
  return handle(async () => {
    await requireAdmin()
    const body = await readJson<Record<string, unknown>>(req)

    const patch: {
      clientId?: string
      clientSecret?: string
      sources?: { db: boolean; files: boolean; config: boolean }
      schedule?: 'off' | 'daily' | 'weekly'
      keep?: number
    } = {}

    if (body.client_id !== undefined) {
      if (typeof body.client_id !== 'string') return fail('client_id không hợp lệ')
      patch.clientId = body.client_id.trim()
    }
    if (body.client_secret !== undefined) {
      if (typeof body.client_secret !== 'string') return fail('client_secret không hợp lệ')
      const secret = body.client_secret.trim()
      if (secret) patch.clientSecret = secret // để trống = giữ secret cũ
    }
    if (body.sources !== undefined) {
      const s = body.sources as Record<string, unknown>
      if (!s || typeof s !== 'object') return fail('sources không hợp lệ')
      patch.sources = {
        db: s.db === true,
        files: s.files === true,
        config: s.config === true,
      }
      if (!patch.sources.db && !patch.sources.files && !patch.sources.config) {
        return fail('Phải chọn ít nhất một nguồn dữ liệu (DB / Tệp / Cấu hình)')
      }
    }
    if (body.schedule !== undefined) {
      const v = String(body.schedule)
      if (!['off', 'daily', 'weekly'].includes(v)) return fail('schedule phải là off | daily | weekly')
      patch.schedule = v as 'off' | 'daily' | 'weekly'
    }
    if (body.keep !== undefined) {
      const n = typeof body.keep === 'number' ? body.keep : Number.parseInt(String(body.keep), 10)
      if (!Number.isFinite(n) || n < 1 || n > 50) return fail('Số bản giữ lại phải từ 1 đến 50')
      patch.keep = Math.floor(n)
    }
    if (Object.keys(patch).length === 0) return fail('Không có trường nào để lưu')

    const saved = await saveSyncConfig(patch)
    return ok({ ok: true, schedule: saved.schedule, keep: saved.keep })
  })
}

/** POST — hành động (admin): backup-now | disconnect | restore
 *  restore (v2.3): khôi phục DB + storage files ĐỒNG THỜI từ bản tar.gz trên Drive —
 *  body { action: 'restore', fileId: '<Drive file id>' } (id lấy từ GET danh sách).
 *  Chạy ĐỒNG BỘ (tar lớn mất phút) — không fire-and-forget như backup-now. */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAdmin()
    const body = await readJson<{ action?: string; fileId?: string }>(req)
    const action = body.action

    if (action === 'backup-now') {
      // fire-and-forget: UI poll GET để theo dõi BackupRun
      void runBackup('manual', { id: session.id, displayName: session.displayName })
      return ok({ started: true })
    }

    if (action === 'restore') {
      const fileId = typeof body.fileId === 'string' ? body.fileId.trim() : ''
      if (!fileId) return fail('Thiếu fileId của bản backup trên Drive')
      const result = await restoreDriveBackup(fileId, { id: session.id, displayName: session.displayName })
      return ok({
        ok: true,
        restored: result.restored,
        filesRestored: result.filesRestored,
        legacyBackup: result.legacy,
        missingFiles: result.missingFiles,
        snapshotDb: result.snapshotDb,
        snapshotStorage: result.snapshotStorage,
      })
    }

    if (action === 'disconnect') {
      await saveSyncConfig({ refreshToken: '', account: '' })
      return ok({ ok: true, disconnected: true })
    }

    return fail('Hành động không hợp lệ (backup-now | disconnect | restore)')
  })
}

