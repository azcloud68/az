import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireModule, handle, ok } from '@/core/server/api'
import { storageUsage } from '@/core/server/storage'
import { withUserStorage } from '@/core/server/user-scope'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const vnDate = (d: Date) => d.toISOString().slice(0, 10)

/** GET /api/modules/reports?days=30 — tổng hợp số liệu CỦA TÀI KHOẢN cho trang Reports */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireModule('reports')
    const days = Math.min(Math.max(Number(req.nextUrl.searchParams.get('days') || 30), 1), 365)
    const since = new Date(Date.now() - days * 86400000)

    const [tasksDone, projects, notesCount, wikiCount, filesCount, eventsCount, filesByParent] = await Promise.all([
      db.task.findMany({ where: { ownerId: session.id, status: 'done', completedAt: { gte: since } }, select: { completedAt: true, priority: true, title: true } }),
      db.project.findMany({ where: { ownerId: session.id }, include: { milestones: true } }),
      db.note.count({ where: { trashedAt: null, ownerId: session.id } }),
      db.wikiPage.count({ where: { trashedAt: null, ownerId: session.id } }),
      db.fileNode.count({ where: { trashedAt: null, ownerId: session.id } }),
      db.eventRecord.count({ where: { actorId: session.id } }),
      db.fileNode.groupBy({ by: ['parent'], where: { trashedAt: null, ownerId: session.id }, _count: true, _sum: { size: true } }),
    ])

    const daily = new Map<string, number>()
    for (let i = days - 1; i >= 0; i--) {
      daily.set(vnDate(new Date(Date.now() - i * 86400000)), 0)
    }
    for (const t of tasksDone) {
      if (t.completedAt) {
        const key = vnDate(t.completedAt)
        if (daily.has(key)) daily.set(key, (daily.get(key) || 0) + 1)
      }
    }

    const byPriority: Record<string, number> = { low: 0, medium: 0, high: 0, urgent: 0 }
    for (const t of tasksDone) byPriority[t.priority] = (byPriority[t.priority] || 0) + 1

    // Dung lượng theo thư mục của TÀI KHOẢN (ALS scope storage root theo user)
    const storageBytes = await withUserStorage(session.id, () => storageUsage())

    return ok({
      days,
      totalDone: tasksDone.length,
      daily: [...daily.entries()].map(([date, count]) => ({ date, count })),
      byPriority,
      projects: projects.map((p) => {
        const done = p.milestones.filter((m) => m.done).length
        return {
          name: p.name,
          status: p.status,
          milestones: p.milestones.length,
          milestoneDone: done,
          progress: p.milestones.length ? Math.round((done / p.milestones.length) * 100) : 0,
        }
      }),
      counters: { notes: notesCount, wiki: wikiCount, files: filesCount, events: eventsCount },
      storageBytes,
      storageByFolder: filesByParent.map((f) => ({ folder: f.parent || '(gốc)', count: f._count, bytes: f._sum.size || 0 })),
    })
  })
}
