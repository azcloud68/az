import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { can, authDenied } from '@/lib/auth'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

// AI Summary — tóm tắt tình hình làm việc bằng LLM (server-side only)
export async function GET() {
  if (!(await can('reports', 'view'))) return authDenied()
  try {
    const since = new Date(Date.now() - 7 * 86400000)
    const [tasksDone, tasksOpen, tasksUrgent, events, projects, activity] = await Promise.all([
      db.task.findMany({ where: { completedAt: { gte: since } }, select: { title: true, priority: true } }),
      db.task.count({ where: { status: { in: ['todo', 'doing'] } } }),
      db.task.count({ where: { status: { in: ['todo', 'doing'] }, priority: 'urgent' } }),
      db.eventRecord.count({ where: { createdAt: { gte: since } } }),
      db.project.findMany({ where: { status: 'active' }, select: { name: true, status: true } }),
      db.activityLog.groupBy({ by: ['module'], _count: true, where: { createdAt: { gte: since } } }),
    ])

    const context = {
      tuan_nay: {
        cong_viec_hoan_thanh: tasksDone.length,
        cong_viec_mo: tasksOpen,
        cong_viec_khan_cap: tasksUrgent,
        tong_su_kien: events,
        du_an_dang_chay: projects.map(p => p.name),
        hoat_dong_theo_module: activity.map(a => ({ module: a.module, so_luong: a._count })),
        cong_viec_dau_tien_hoan_thanh: tasksDone.slice(0, 12).map(t => t.title),
      },
    }

    let summary = ''
    try {
      const { default: ZAI } = await import('z-ai-web-dev-sdk')
      const zai = await ZAI.create()
      const completion = await zai.chat.completions.create({
        messages: [
          {
            role: 'assistant',
            content: 'Bạn là trợ lý phân tích của Workspace OS. Viết tóm tắt tình hình làm việc tuần qua bằng tiếng Việt, ngắn gọn 4-6 câu, đi thẳng vào số liệu, kết thúc bằng 1 đề xuất hành động cụ thể.',
          },
          { role: 'user', content: JSON.stringify(context) },
        ],
        thinking: { type: 'disabled' },
      })
      summary = completion.choices[0]?.message?.content ?? ''
    } catch {
      summary = '' // fallback bên dưới
    }

    if (!summary) {
      const sorted = [...activity].sort((a, b) => b._count - a._count)
      const topModule = sorted[0] ?? null
      summary = `Tuần qua bạn đã hoàn thành ${tasksDone.length} công việc, hiện còn ${tasksOpen} việc đang mở (trong đó ${tasksUrgent} việc khẩn cấp). ` +
        `Hệ thống ghi nhận ${events} hoạt động${topModule ? `, tập trung nhiều nhất ở module "${topModule.module}" (${topModule._count} thao tác)` : ''}. ` +
        `${projects.length ? `Hiện có ${projects.length} dự án đang chạy: ${projects.map(p => p.name).join(', ')}. ` : 'Hiện không có dự án nào đang chạy. '}` +
        `Đề xuất: ưu tiên xử lý ${tasksUrgent > 0 ? `${tasksUrgent} việc khẩn cấp trước` : 'các việc đến hạn trong 48 giờ tới'}.`
    }

    return NextResponse.json({ summary, stats: context.tuan_nay, generatedAt: new Date().toISOString() })
  } catch (e) {
    console.error('[ai-summary]', e)
    return NextResponse.json({ error: 'Không tạo được tóm tắt' }, { status: 500 })
  }
}

