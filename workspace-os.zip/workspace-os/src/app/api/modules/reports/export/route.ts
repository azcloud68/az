import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireModule, handle, ok, fail } from '@/core/server/api'
import { storageUsage } from '@/core/server/storage'
import { withUserStorage } from '@/core/server/user-scope'
import { emitEvent } from '@/core/server/event-bus'
import { getUserTimezone, startOfDayInTz, isoDateInTz } from '@/core/server/datetime'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

interface ReportRow {
  [key: string]: string | number | null
}

function toCsv(rows: ReportRow[]): string {
  if (rows.length === 0) return ''
  const headers = Object.keys(rows[0])
  const esc = (v: unknown) => {
    const s = v == null ? '' : String(v)
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s
  }
  return [headers.join(','), ...rows.map((r) => headers.map((h) => esc(r[h])).join(','))].join('\n')
}

function toXml(rows: ReportRow[], sheet: string): string {
  const headers = rows.length ? Object.keys(rows[0]) : []
  const esc = (v: unknown) =>
    String(v == null ? '' : v)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
  const rowXml = rows
    .map((r) => `<Row>${headers.map((h) => `<Cell><Data ss:Type="String">${esc(r[h])}</Data></Cell>`).join('')}</Row>`)
    .join('')
  return `<?xml version="1.0"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
<Worksheet ss:Name="${esc(sheet)}"><Table>
<Row>${headers.map((h) => `<Cell><Data ss:Type="String">${esc(h)}</Data></Cell>`).join('')}</Row>
${rowXml}
</Table></Worksheet></Workbook>`
}

/** Xuất báo cáo — dùng chung cho GET (window.open trực tiếp tải file)
 *  và POST (fetch blob). Dữ liệu chỉ đọc — GET an toàn. */
async function exportReport(req: NextRequest): Promise<NextResponse> {
  const session = await requireModule('reports')
  const sp = req.nextUrl.searchParams
  const tz = await getUserTimezone()
  const vnDate = (d: Date) => isoDateInTz(d, tz)
    const type = sp.get('type') || 'csv'
    const report = sp.get('report') || 'tasks'
    let rows: ReportRow[] = []
    let name = report

    if (report === 'tasks') {
      const tasks = await db.task.findMany({ where: { ownerId: session.id }, orderBy: { createdAt: 'desc' } })
      rows = tasks.map((t) => ({
        'Tiêu đề': t.title,
        'Trạng thái': t.status,
        'Ưu tiên': t.priority,
        'Hạn chót': t.dueAt ? vnDate(t.dueAt) : '',
        'Hoàn thành': t.completedAt ? vnDate(t.completedAt) : '',
        'Lặp lại': t.repeat,
        'Tạo lúc': vnDate(t.createdAt),
      }))
      name = 'cong-viec'
    } else if (report === 'projects') {
      const projects = await db.project.findMany({ where: { ownerId: session.id }, include: { milestones: true } })
      rows = projects.map((p) => {
        const done = p.milestones.filter((m) => m.done).length
        return {
          'Dự án': p.name,
          'Trạng thái': p.status,
          'Mô tả': p.description,
          'Số mốc': p.milestones.length,
          'Mốc hoàn thành': done,
          'Tiến độ %': p.milestones.length ? Math.round((done / p.milestones.length) * 100) : 0,
          'Bắt đầu': p.startDate ? vnDate(p.startDate) : '',
          'Hạn': p.dueDate ? vnDate(p.dueDate) : '',
        }
      })
      name = 'du-an'
    } else if (report === 'storage') {
      // Dung lượng + nhóm thư mục của TÀI KHOẢN (ALS scope root theo user)
      const usage = await withUserStorage(session.id, () => storageUsage())
      const nodes = await db.fileNode.groupBy({ by: ['parent'], where: { trashedAt: null, ownerId: session.id }, _count: true, _sum: { size: true } })
      rows = nodes.map((n) => ({
        'Thư mục': n.parent || '(gốc)',
        'Số tệp': n._count,
        'Dung lượng (B)': n._sum.size || 0,
      }))
      rows.push({ 'Thư mục': 'TỔNG', 'Số tệp': nodes.reduce((a, b) => a + b._count, 0), 'Dung lượng (B)': usage })
      name = 'luu-tru'
    } else {
      // daily | weekly | monthly — công việc hoàn thành (ranh giới đầu ngày theo MÚI GIỜ người dùng)
      const days = report === 'daily' ? 1 : report === 'weekly' ? 7 : 30
      const since = startOfDayInTz(days - 1, tz)
      const tasks = await db.task.findMany({ where: { ownerId: session.id, completedAt: { gte: since } }, orderBy: { completedAt: 'asc' } })
      rows = tasks.map((t) => ({
        'Ngày': t.completedAt ? vnDate(t.completedAt) : '',
        'Công việc': t.title,
        'Ưu tiên': t.priority,
      }))
      name = `bao-cao-${report}`
    }

    await emitEvent({
      type: 'settings.updated',
      module: 'reports',
      actor: { id: session.id, displayName: session.displayName },
      payload: { name: `xuất ${report}.${type}` },
      logActivity: true,
    })

    if (type === 'json') {
      return new NextResponse(JSON.stringify(rows, null, 1), {
        headers: { 'content-type': 'application/json; charset=utf-8', 'content-disposition': `attachment; filename="${name}.json"` },
      })
    }
    if (type === 'excel') {
      return new NextResponse(toXml(rows, 'Báo cáo WOS'), {
        headers: { 'content-type': 'application/vnd.ms-excel; charset=utf-8', 'content-disposition': `attachment; filename="${name}.xls"` },
      })
    }
    return new NextResponse('\ufeff' + toCsv(rows), {
      headers: { 'content-type': 'text/csv; charset=utf-8', 'content-disposition': `attachment; filename="${name}.csv"` },
    })
}

/** GET /api/modules/reports/export?type=csv|excel|json&report=tasks|projects|storage|daily|weekly|monthly
 *  Frontend gọi window.open(GET) — tải trực tiếp từ trình duyệt. */
export async function GET(req: NextRequest) {
  return handle(() => exportReport(req))
}

/** POST — tương đương GET (fetch → blob → download) */
export async function POST(req: NextRequest) {
  return handle(() => exportReport(req))
}
