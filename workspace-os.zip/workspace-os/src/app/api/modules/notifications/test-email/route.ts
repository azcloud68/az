import { NextRequest } from 'next/server'
import { requireSession, handle, ok, fail, readJson } from '@/core/server/api'
import { getMailConfig, mailReady, sendMail, verifyMail, flushEmailQueue } from '@/core/server/mailer'
import { db } from '@/lib/db'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/**
 * POST /api/modules/notifications/test-email (fix lỗi 8) — ADMIN:
 *   { action: 'verify' }   → kiểm tra kết nối SMTP (không gửi thư)
 *   { action: 'send' }     → gửi email thử ngay tới địa chỉ trong settings
 *   { action: 'flush' }    → đẩy ngay mọi email đang chờ (không đợi scheduler 60s)
 *   { action: 'stats' }    → thống kê queue (pending/sent/failed) + trạng thái cấu hình
 */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    if (session.role !== 'admin') return fail('Chỉ quản trị viên được kiểm tra email', 403)
    const body = await readJson<{ action?: string }>(req)
    const action = body.action || 'send'
    const cfg = await getMailConfig()

    if (action === 'stats') {
      const [pending, sent, failed] = await Promise.all([
        db.emailQueue.count({ where: { status: 'pending' } }),
        db.emailQueue.count({ where: { status: 'sent' } }),
        db.emailQueue.count({ where: { status: 'failed' } }),
      ])
      return ok({
        enabled: cfg.enabled,
        ready: mailReady(cfg),
        mode: cfg.mode,
        events: cfg.events,
        queue: { pending, sent, failed },
        maskedUser: cfg.user ? cfg.user.replace(/(.{2}).*(@.*)/, '$1***$2') : '',
        to: cfg.to,
      })
    }

    if (action === 'verify') {
      if (!mailReady(cfg)) return fail('Chưa cấu hình đủ: SMTP host, tài khoản, mật khẩu ứng dụng, địa chỉ nhận')
      try {
        await verifyMail(cfg)
        return ok({ ok: true, message: 'Kết nối SMTP thành công — sẵn sàng gửi email' })
      } catch (err) {
        return fail(`Không kết nối được SMTP: ${err instanceof Error ? err.message : ''}`)
      }
    }

    if (action === 'flush') {
      const r = await flushEmailQueue()
      return ok({ ok: true, ...r })
    }

    // mặc định: gửi email thử
    if (!mailReady(cfg)) {
      return fail('Chưa cấu hình đủ SMTP — điền Host, Tài khoản, Mật khẩu ứng dụng, Email nhận rồi Lưu')
    }
    try {
      await sendMail(cfg, [
        {
          title: '✉️ Email thử từ Workspace OS',
          content: `Đây là email kiểm tra gửi lúc ${new Date().toLocaleString('vi-VN')}. Nếu bạn nhận được thư này, kênh thông báo email đã hoạt động bình thường.`,
          module: 'notifications',
        },
      ])
      return ok({ ok: true, message: `Đã gửi email thử tới ${cfg.to}` })
    } catch (err) {
      return fail(`Gửi thất bại: ${err instanceof Error ? err.message : ''}`)
    }
  })
}
