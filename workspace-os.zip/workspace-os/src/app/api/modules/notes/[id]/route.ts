import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireModule, handle, ok, fail, readJson } from '@/core/server/api'
import { emitEvent } from '@/core/server/event-bus'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** GET — chi tiết 1 ghi chú (cửa sổ riêng note:<id>) — chỉ chủ sở hữu */
export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireModule('notes')
    const { id } = await ctx.params
    const note = await db.note.findUnique({ where: { id } })
    if (!note || note.ownerId !== session.id) return fail('Ghi chú không tồn tại', 404)
    return ok({ note })
  })
}

/** PATCH — cập nhật ghi chú (title, content, pinned, tags, restore, trash) */
export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireModule('notes', true)
    const { id } = await ctx.params
    const body = await readJson<Record<string, unknown>>(req)
    const note = await db.note.findUnique({ where: { id } })
    if (!note || note.ownerId !== session.id) return fail('Ghi chú không tồn tại', 404)
    const data: Record<string, unknown> = {}
    if (body.title !== undefined) data.title = String(body.title).trim() || 'Không tiêu đề'
    if (body.content !== undefined) data.content = String(body.content)
    if (body.pinned !== undefined) data.pinned = Boolean(body.pinned)
    if (body.tags !== undefined && Array.isArray(body.tags)) data.tags = JSON.stringify(body.tags)
    if (body.trashed !== undefined) data.trashedAt = body.trashed ? new Date() : null
    await db.note.update({ where: { id }, data })
    if (body.trashed === true) {
      await emitEvent({
        type: 'note.deleted',
        module: 'notes',
        actor: { id: session.id, displayName: session.displayName },
        payload: { title: note.title },
      })
    } else {
      await emitEvent({
        type: 'note.updated',
        module: 'notes',
        actor: { id: session.id, displayName: session.displayName },
        payload: { title: (data.title as string) || note.title },
        logActivity: body.content !== undefined ? false : true,
      })
    }
    return ok({ ok: true })
  })
}

/** DELETE — xoá vĩnh viễn */
export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireModule('notes', true)
    const { id } = await ctx.params
    const note = await db.note.findUnique({ where: { id } })
    if (!note || note.ownerId !== session.id) return fail('Ghi chú không tồn tại', 404)
    await db.note.delete({ where: { id } })
    await emitEvent({
      type: 'note.deleted',
      module: 'notes',
      actor: { id: session.id, displayName: session.displayName },
      payload: { title: note.title },
    })
    return ok({ ok: true })
  })
}
