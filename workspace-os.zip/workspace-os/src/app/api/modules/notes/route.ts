import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireModule, handle, ok, fail, readJson } from '@/core/server/api'
import { emitEvent } from '@/core/server/event-bus'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** GET /api/modules/notes?trash=1&q= — danh sách ghi chú của tài khoản hiện tại */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireModule('notes')
    const sp = req.nextUrl.searchParams
    const trash = sp.get('trash') === '1'
    const q = sp.get('q')
    const notes = await db.note.findMany({
      where: {
        ownerId: session.id,
        trashedAt: trash ? { not: null } : null,
        ...(q ? { OR: [{ title: { contains: q } }, { content: { contains: q } }] } : {}),
      },
      orderBy: [{ pinned: 'desc' }, { updatedAt: 'desc' }],
    })
    return ok({ notes })
  })
}

/** POST — tạo ghi chú */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireModule('notes', true)
    const body = await readJson<{ title?: string; content?: string; tags?: string[] }>(req)
    const note = await db.note.create({
      data: {
        ownerId: session.id,
        title: (body.title || '').trim() || 'Ghi chú mới',
        content: body.content || '',
        tags: JSON.stringify(Array.isArray(body.tags) ? body.tags : []),
      },
    })
    await emitEvent({
      type: 'note.created',
      module: 'notes',
      actor: { id: session.id, displayName: session.displayName },
      payload: { title: note.title },
      targetId: note.id,
      targetType: 'note',
    })
    return ok({ note })
  })
}

/** PUT — quick note từ Dashboard widget (tạo hoặc cập nhật theo id) */
export async function PUT(req: NextRequest) {
  return handle(async () => {
    const session = await requireModule('notes', true)
    const body = await readJson<{ id?: string; content?: string }>(req)
    if (body.id) {
      const existing = await db.note.findUnique({ where: { id: body.id } })
      if (!existing || existing.ownerId !== session.id) return fail('Ghi chú không tồn tại', 404)
      const note = await db.note.update({ where: { id: body.id }, data: { content: body.content || '' } })
      return ok({ note })
    }
    const note = await db.note.create({
      data: {
        ownerId: session.id,
        title: `Quick note ${new Date().toLocaleDateString('vi-VN')}`,
        content: body.content || '',
        tags: JSON.stringify(['quick']),
      },
    })
    await emitEvent({
      type: 'note.created',
      module: 'notes',
      actor: { id: session.id, displayName: session.displayName },
      payload: { title: note.title },
      logActivity: false,
    })
    return ok({ note })
  })
}
