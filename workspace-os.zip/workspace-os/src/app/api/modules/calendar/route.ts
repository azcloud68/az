import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireModule, handle, ok, fail, readJson, ApiError, parseDate, parseDateOrNull } from '@/core/server/api'
import { emitEvent } from '@/core/server/event-bus'
import { getUserTimezone, yearInTz, addDaysInTz, addMonthsInTz, isoDateInTz } from '@/core/server/datetime'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const CATEGORIES = ['general', 'work', 'personal', 'meeting', 'holiday']
const RECURS = ['none', 'daily', 'weekly', 'monthly', 'yearly']

function parseExceptions(raw: string): Set<string> {
  try {
    const arr = JSON.parse(raw || '[]')
    return new Set(Array.isArray(arr) ? arr.map(String) : [])
  } catch {
    return new Set()
  }
}

/** GET /api/modules/calendar?from=&to= — sự kiện của tài khoản trong khoảng + mở rộng recurring
 *  - monthly: clamp ngày cuối tháng (31/01 → 28-29/02)
 *  - exceptions: ngày bị xoá khỏi chuỗi ('xoá 1 lần') không hiện lại
 *  - mọi ranh giới ngày tính theo múi giờ người dùng (Setting core:timezone) */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireModule('calendar')
    const tz = await getUserTimezone()
    // Ngày dạng YYYY-MM-DD theo MÚI GIỜ người dùng — khớp với ngày client hiển thị
    const ymd = (d: Date) => isoDateInTz(d, tz)
    const sp = req.nextUrl.searchParams
    const from = sp.get('from') ? parseDate(sp.get('from'), 'from') : new Date(Date.now() - 30 * 86400000)
    const to = sp.get('to') ? parseDate(sp.get('to'), 'to') : new Date(Date.now() + 60 * 86400000)
    const rows = await db.calendarEvent.findMany({
      where: {
        ownerId: session.id,
        OR: [
          { start: { gte: from, lte: to } },
          { recurring: { not: 'none' }, start: { lte: to }, OR: [{ recurrenceEnd: null }, { recurrenceEnd: { gte: from } }] },
        ],
      },
      orderBy: { start: 'asc' },
    })
    // Mở rộng recurring trong khoảng thời gian
    const events: Record<string, unknown>[] = []
    for (const row of rows) {
      const except = parseExceptions(row.exceptions)
      // ngày gốc nằm trong exceptions (đã "xoá 1 lần") → ẩn luôn, chuỗi vẫn chạy
      if (!except.has(ymd(new Date(row.start)))) events.push({ ...row, occurrenceStart: row.start })
      if (row.recurring === 'none') continue
      const limit = 90 // chống nổ
      let cursor = new Date(row.start)
      const end = row.recurrenceEnd && row.recurrenceEnd < to ? row.recurrenceEnd : to
      let count = 0
      while (cursor < end && count < limit) {
        // DST-SAFE: cộng theo LỊCH tz người dùng (giữ nguyên giờ treo tường),
        // không cộng ms thuần +86400000 (sẽ lệch giờ ở múi giờ có DST)
        if (row.recurring === 'daily') cursor = addDaysInTz(cursor, 1, tz)
        else if (row.recurring === 'weekly') cursor = addDaysInTz(cursor, 7, tz)
        else if (row.recurring === 'monthly') cursor = addMonthsInTz(cursor, 1, tz)
        else cursor = addMonthsInTz(cursor, 12, tz) // yearly — cùng cơ chế chặn cuối tháng
        count++
        if (cursor >= from && cursor <= to && !except.has(ymd(cursor))) {
          events.push({ ...row, id: `${row.id}#r${count}`, occurrenceStart: cursor, isOccurrence: true })
        }
      }
    }
    // Ngày lễ Việt Nam trong năm HIỆN TẠI THEO MÚI GIỜ người dùng (server có thể chạy UTC)
    const year = yearInTz(new Date(), tz)
    const holidays = [
      { title: 'Tết Dương lịch', date: `${year}-01-01` },
      { title: 'Ngày Thương binh liệt sĩ', date: `${year}-07-27` },
      { title: 'Quốc khánh', date: `${year}-09-02` },
      { title: 'Ngày Nhà giáo Việt Nam', date: `${year}-11-20` },
    ]
    return ok({ events, holidays })
  })
}

/** POST — tạo sự kiện */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireModule('calendar', true)
    const body = await readJson<Record<string, unknown>>(req)
    const title = String(body.title || '').trim()
    if (!title) return fail('Nhập tiêu đề sự kiện')
    if (!body.start) return fail('Chọn thời gian bắt đầu')
    const start = parseDate(body.start, 'Thời gian bắt đầu')
    const end = body.end ? parseDate(body.end, 'Thời gian kết thúc') : new Date(start.getTime() + 3600000)
    // projectId phải là project CỦA CHÍNH tài khoản (như tasks — v2.3)
    let projectId: string | null = null
    if (body.projectId) {
      projectId = String(body.projectId)
      const project = await db.project.findFirst({ where: { id: projectId, ownerId: session.id }, select: { id: true } })
      if (!project) return fail('Dự án không tồn tại (hoặc không phải của bạn)', 404)
    }
    const event = await db.calendarEvent.create({
      data: {
        ownerId: session.id,
        title,
        description: String(body.description || ''),
        location: String(body.location || ''),
        category: CATEGORIES.includes(String(body.category)) ? String(body.category) : 'general',
        color: String(body.color || ''),
        allDay: Boolean(body.allDay),
        start,
        end: end < start ? start : end,
        recurring: RECURS.includes(String(body.recurring)) ? String(body.recurring) : 'none',
        recurrenceEnd: parseDateOrNull(body.recurrenceEnd, 'Ngày kết thúc lặp lại'),
        reminderMinutes: body.reminderMinutes != null ? Number(body.reminderMinutes) : null,
        projectId,
      },
    })
    await emitEvent({
      type: 'event.created',
      module: 'calendar',
      actor: { id: session.id, displayName: session.displayName },
      payload: { title },
      targetId: event.id,
      targetType: 'event',
    })
    return ok({ event })
  })
}
