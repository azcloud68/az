import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireModule, handle, ok, fail, readJson, parseDate, parseDateOrNull } from '@/core/server/api'
import { emitEvent } from '@/core/server/event-bus'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const CATEGORIES = ['general', 'work', 'personal', 'meeting', 'holiday']
const RECURS = ['none', 'daily', 'weekly', 'monthly', 'yearly']

/** PATCH — cập nhật sự kiện */
export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireModule('calendar', true)
    const { id } = await ctx.params
    const body = await readJson<Record<string, unknown>>(req)
    const event = await db.calendarEvent.findUnique({ where: { id } })
    if (!event || event.ownerId !== session.id) return fail('Sự kiện không tồn tại', 404)
    const data: Record<string, unknown> = {}
    if (body.title !== undefined && String(body.title).trim()) data.title = String(body.title).trim()
    if (body.description !== undefined) data.description = String(body.description)
    if (body.location !== undefined) data.location = String(body.location)
    if (body.category !== undefined && CATEGORIES.includes(String(body.category))) data.category = String(body.category)
    if (body.color !== undefined) data.color = String(body.color)
    if (body.allDay !== undefined) data.allDay = Boolean(body.allDay)
    if (body.start !== undefined) data.start = parseDate(body.start, 'Thời gian bắt đầu')
    if (body.end !== undefined) data.end = parseDate(body.end, 'Thời gian kết thúc')
    if (body.recurring !== undefined && RECURS.includes(String(body.recurring))) data.recurring = String(body.recurring)
    if (body.recurrenceEnd !== undefined) data.recurrenceEnd = parseDateOrNull(body.recurrenceEnd, 'Ngày kết thúc lặp lại')
    if (body.reminderMinutes !== undefined) data.reminderMinutes = body.reminderMinutes != null ? Number(body.reminderMinutes) : null
    await db.calendarEvent.update({ where: { id }, data })
    await emitEvent({
      type: 'event.updated',
      module: 'calendar',
      actor: { id: session.id, displayName: session.displayName },
      payload: { title: (data.title as string) || event.title },
      targetId: id,
      targetType: 'event',
    })
    return ok({ ok: true })
  })
}

/** DELETE — xoá sự kiện
 *  - DELETE /{id}                → xoá TOÀN BỘ chuỗi
 *  - DELETE /{id}?occurrence=YYYY-MM-DD → chỉ xoá 1 lần trong chuỗi (lưu vào exceptions) */
export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireModule('calendar', true)
    const { id } = await ctx.params
    const event = await db.calendarEvent.findUnique({ where: { id } })
    if (!event || event.ownerId !== session.id) return fail('Sự kiện không tồn tại', 404)

    const occurrence = req.nextUrl.searchParams.get('occurrence')
    if (occurrence && /^\d{4}-\d{2}-\d{2}$/.test(occurrence) && event.recurring !== 'none') {
      let excepts: string[] = []
      try {
        const arr = JSON.parse(event.exceptions || '[]')
        if (Array.isArray(arr)) excepts = arr.map(String)
      } catch {
        excepts = []
      }
      if (!excepts.includes(occurrence)) excepts.push(occurrence)
      await db.calendarEvent.update({ where: { id }, data: { exceptions: JSON.stringify(excepts) } })
      await emitEvent({
        type: 'event.updated',
        module: 'calendar',
        actor: { id: session.id, displayName: session.displayName },
        payload: { title: `${event.title} (bỏ lần ${occurrence})` },
        targetId: id,
        targetType: 'event',
      })
      return ok({ ok: true, occurrence, exceptions: excepts })
    }

    await db.calendarEvent.delete({ where: { id } })
    await emitEvent({
      type: 'event.deleted',
      module: 'calendar',
      actor: { id: session.id, displayName: session.displayName },
      payload: { title: event.title },
    })
    return ok({ ok: true })
  })
}
