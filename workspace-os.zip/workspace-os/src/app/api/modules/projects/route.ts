import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireModule, handle, ok, fail, readJson, parseDateOrNull } from '@/core/server/api'
import { emitEvent } from '@/core/server/event-bus'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** GET — danh sách dự án của tài khoản + tiến độ (đếm task cùng chủ) */
export async function GET() {
  return handle(async () => {
    const session = await requireModule('projects')
    const projects = await db.project.findMany({
      where: { ownerId: session.id },
      orderBy: { updatedAt: 'desc' },
      include: {
        milestones: { orderBy: { position: 'asc' } },
        members: true,
        _count: { select: { milestones: true, members: true } },
      },
    })
    const tasks = await db.task.groupBy({ by: ['projectId', 'status'], where: { ownerId: session.id }, _count: true })
    const out = projects.map((p) => {
      const counts = { todo: 0, doing: 0, done: 0 }
      for (const t of tasks) {
        if (t.projectId === p.id && t.status !== 'archived') {
          counts[t.status as keyof typeof counts] = counts[t.status as keyof typeof counts] || 0
          counts[t.status as keyof typeof counts] += t._count
        }
      }
      const total = counts.todo + counts.doing + counts.done
      const milestoneDone = p.milestones.filter((m) => m.done).length
      const taskProgress = total ? Math.round((counts.done / total) * 100) : 0
      const milestoneProgress = p.milestones.length ? Math.round((milestoneDone / p.milestones.length) * 100) : 0
      return { ...p, taskCounts: counts, taskProgress, milestoneProgress, taskTotal: total }
    })
    return ok({ projects: out })
  })
}

/** POST — tạo dự án */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireModule('projects', true)
    const body = await readJson<Record<string, unknown>>(req)
    const name = String(body.name || '').trim()
    if (!name) return fail('Nhập tên dự án')
    const project = await db.project.create({
      data: {
        ownerId: session.id,
        name,
        description: String(body.description || ''),
        color: String(body.color || '#f97316'),
        icon: String(body.icon || 'folder'),
        startDate: parseDateOrNull(body.startDate, 'Ngày bắt đầu'),
        dueDate: parseDateOrNull(body.dueDate, 'Hạn chót'),
        members: {
          create: { userId: session.id, userName: session.displayName, role: 'owner' },
        },
      },
    })
    await emitEvent({
      type: 'project.created',
      module: 'projects',
      actor: { id: session.id, displayName: session.displayName },
      payload: { name },
      targetId: project.id,
      targetType: 'project',
    })
    return ok({ project })
  })
}
