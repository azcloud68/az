import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireModule, handle, ok, fail, readJson, parseDateOrNull } from '@/core/server/api'
import { emitEvent } from '@/core/server/event-bus'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const STATUSES = ['active', 'paused', 'done', 'archived']

/** GET — chi tiết dự án (chỉ chủ sở hữu): milestones, members, tasks, events */
export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireModule('projects')
    const { id } = await ctx.params
    const project = await db.project.findUnique({
      where: { id },
      include: {
        milestones: { orderBy: { position: 'asc' } },
        members: { orderBy: { role: 'asc' } },
      },
    })
    if (!project || project.ownerId !== session.id) return fail('Dự án không tồn tại', 404)
    const [tasks, events] = await Promise.all([
      db.task.findMany({ where: { projectId: id, ownerId: session.id }, orderBy: { position: 'asc' } }),
      db.calendarEvent.findMany({ where: { projectId: id, ownerId: session.id }, orderBy: { start: 'asc' } }),
    ])
    return ok({ project, tasks, events })
  })
}

/** PATCH — cập nhật dự án / milestone / member */
export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireModule('projects', true)
    const { id } = await ctx.params
    const body = await readJson<Record<string, unknown>>(req)
    const project = await db.project.findUnique({ where: { id } })
    if (!project || project.ownerId !== session.id) return fail('Dự án không tồn tại', 404)

    // --- milestone ops ---
    if (body.op === 'milestone.add') {
      const title = String(body.title || '').trim()
      if (!title) return fail('Nhập tiêu đề mốc')
      const maxPos = await db.projectMilestone.aggregate({ where: { projectId: id }, _max: { position: true } })
      const m = await db.projectMilestone.create({
        data: { projectId: id, title, position: (maxPos._max.position || 0) + 1, dueAt: parseDateOrNull(body.dueAt, 'Hạn mốc') },
      })
      return ok({ milestone: m })
    }
    if (body.op === 'milestone.toggle') {
      const milestone = await db.projectMilestone.findUnique({ where: { id: String(body.milestoneId) } })
      if (!milestone || milestone.projectId !== id) return fail('Mốc không tồn tại', 404)
      await db.projectMilestone.update({ where: { id: milestone.id }, data: { done: !milestone.done } })
      if (!milestone.done) {
        await emitEvent({
          type: 'milestone.completed',
          module: 'projects',
          actor: { id: session.id, displayName: session.displayName },
          payload: { title: milestone.title, name: project.name },
          notify: { title: 'Hoàn thành mốc', content: `${milestone.title} — ${project.name}`, action: `projects:${id}` },
        })
      }
      return ok({ ok: true })
    }
    if (body.op === 'milestone.delete') {
      // Kiểm tra mốc THỰC SỰ thuộc project này (chặn xoá mốc của project/user khác qua id)
      const milestone = await db.projectMilestone.findUnique({ where: { id: String(body.milestoneId) } })
      if (!milestone || milestone.projectId !== id) return fail('Mốc không tồn tại', 404)
      await db.projectMilestone.delete({ where: { id: milestone.id } })
      return ok({ ok: true })
    }
    if (body.op === 'member.add') {
      const userName = String(body.userName || '').trim()
      if (!userName) return fail('Nhập tên thành viên')
      const m = await db.projectMember.create({
        data: { projectId: id, userName, role: ['owner', 'member', 'viewer'].includes(String(body.role)) ? String(body.role) : 'member' },
      })
      return ok({ member: m })
    }
    if (body.op === 'member.remove') {
      // Kiểm tra thành viên THỰC SỰ thuộc project này (chặn xoá chéo project/user khác)
      const member = await db.projectMember.findUnique({ where: { id: String(body.memberId) } })
      if (!member || member.projectId !== id) return fail('Thành viên không tồn tại', 404)
      await db.projectMember.delete({ where: { id: member.id } })
      return ok({ ok: true })
    }

    // --- project fields ---
    const data: Record<string, unknown> = {}
    if (body.name !== undefined && String(body.name).trim()) data.name = String(body.name).trim()
    if (body.description !== undefined) data.description = String(body.description)
    if (body.color !== undefined) data.color = String(body.color)
    if (body.icon !== undefined) data.icon = String(body.icon)
    if (body.startDate !== undefined) data.startDate = parseDateOrNull(body.startDate, 'Ngày bắt đầu')
    if (body.dueDate !== undefined) data.dueDate = parseDateOrNull(body.dueDate, 'Hạn chót')
    if (body.expectedEndDate !== undefined) data.expectedEndDate = parseDateOrNull(body.expectedEndDate, 'Dự kiến kết thúc')
    if (body.actualEndDate !== undefined) data.actualEndDate = parseDateOrNull(body.actualEndDate, 'Ngày kết thúc thực tế')
    if (body.status !== undefined && STATUSES.includes(String(body.status))) data.status = String(body.status)
    await db.project.update({ where: { id }, data })
    await emitEvent({
      type: body.status === 'archived' ? 'project.archived' : 'project.updated',
      module: 'projects',
      actor: { id: session.id, displayName: session.displayName },
      payload: { name: (data.name as string) || project.name },
      targetId: id,
      targetType: 'project',
    })
    return ok({ ok: true })
  })
}

/** DELETE — xoá dự án (task mất liên kết) */
export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireModule('projects', true)
    const { id } = await ctx.params
    const project = await db.project.findUnique({ where: { id } })
    if (!project || project.ownerId !== session.id) return fail('Dự án không tồn tại', 404)
    await db.task.updateMany({ where: { projectId: id, ownerId: session.id }, data: { projectId: null } })
    await db.calendarEvent.updateMany({ where: { projectId: id, ownerId: session.id }, data: { projectId: null } })
    await db.project.delete({ where: { id } })
    await emitEvent({
      type: 'project.updated',
      module: 'projects',
      actor: { id: session.id, displayName: session.displayName },
      payload: { name: project.name },
      logActivity: false,
    })
    return ok({ ok: true })
  })
}
