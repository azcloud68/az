import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireModule, handle, ok, fail, readJson } from '@/core/server/api'
import { emitEvent } from '@/core/server/event-bus'
import { assertWikiParent } from '@/core/server/wiki-parent'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const MAX_CONTENT_BYTES = 500 * 1024 // 500KB

/**
 * Sanitize HTML trước khi lưu wiki (thuần string/regex, không dependency):
 * - Xoá cặp thẻ <script>…</script> / <style>…</style> (kèm cả thẻ rời không đóng)
 * - Xoá mọi attribute on* (onclick, onerror, onload…)
 * - Trung hoà href/src dạng javascript: (hoặc vbscript:/data:text/html)
 */
function sanitizeHtml(html: string): string {
  let out = html
  // Xoá cả khối script/style (dù thẻ lồng escape tuỳ biến: < script >, </SCRIPT >)
  out = out.replace(/<\s*(script|style)\b[^>]*>[\s\S]*?<\s*\/\s*\1\s*>/gi, '')
  // Xoá thẻ script/style rời (mở mà không đóng, hoặc tự đóng)
  out = out.replace(/<\s*\/?\s*(script|style)\b[^>]*>/gi, '')
  // Xoá attribute on* = "…" | '…' | bare
  out = out.replace(/\son[a-z]+\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/gi, '')
  // Trung hoà href/src javascript:/vbscript: (tránh XSS qua href/src)
  out = out.replace(
    /(\s(?:href|src)\s*=\s*)(?:"\s*(?:javascript|vbscript|data\s*:\s*text\/html)[^"]*"|'\s*(?:javascript|vbscript|data\s*:\s*text\/html)[^']*'|\s*(?:javascript|vbscript)[^\s>]*)/gi,
    '$1""'
  )
  return out
}

/** GET — chi tiết trang + lịch sử phiên bản (kèm content để "Xem thử" và so sánh diff) — chỉ chủ sở hữu */
export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireModule('wiki')
    const { id } = await ctx.params
    const page = await db.wikiPage.findUnique({
      where: { id },
      include: {
        versions: {
          orderBy: { version: 'desc' },
          take: 30,
          select: { id: true, version: true, title: true, authorName: true, createdAt: true, content: true },
        },
      },
    })
    if (!page || page.trashedAt || page.ownerId !== session.id) return fail('Trang không tồn tại', 404)
    return ok({ page })
  })
}

/** PATCH — lưu trang (tự tạo version mới khi nội dung đổi). Content được sanitize trước khi lưu. */
export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireModule('wiki', true)
    const { id } = await ctx.params
    const body = await readJson<{ title?: string; content?: string; icon?: string; position?: number; trashed?: boolean; parentId?: string | null }>(req)
    const page = await db.wikiPage.findUnique({ where: { id } })
    if (!page || page.ownerId !== session.id) return fail('Trang không tồn tại', 404)

    if (body.trashed !== undefined) {
      await db.wikiPage.update({ where: { id }, data: { trashedAt: body.trashed ? new Date() : null } })
      await emitEvent({
        type: body.trashed ? 'wiki.deleted' : 'wiki.updated',
        module: 'wiki',
        actor: { id: session.id, displayName: session.displayName },
        payload: { title: page.title },
      })
      return ok({ ok: true })
    }

    const data: Record<string, unknown> = {}
    if (body.title !== undefined && String(body.title).trim()) data.title = String(body.title).trim()
    if (body.icon !== undefined) data.icon = String(body.icon) || '📄'
    if (body.position !== undefined) data.position = Number(body.position) || 0
    if (body.parentId !== undefined) {
      // v2.3 — parentId phải thuộc CÙNG tài khoản + KHÔNG tạo vòng lặp A→B→C→A
      data.parentId = await assertWikiParent(session.id, id, body.parentId || null)
    }

    let contentChanged = false
    if (body.content !== undefined) {
      const raw = String(body.content)
      if (raw.length > MAX_CONTENT_BYTES) return fail(`Nội dung quá dài (tối đa ${MAX_CONTENT_BYTES / 1024}KB)`, 413)
      const clean = sanitizeHtml(raw)
      contentChanged = clean !== page.content
      if (contentChanged) {
        data.content = clean
        const nextVersion = page.version + 1
        data.version = nextVersion
        await db.wikiVersion.create({
          data: {
            pageId: id,
            version: nextVersion,
            title: String(body.title || page.title),
            content: clean,
            authorName: session.displayName,
          },
        })
      }
    }
    await db.wikiPage.update({ where: { id }, data })
    await emitEvent({
      type: 'wiki.updated',
      module: 'wiki',
      actor: { id: session.id, displayName: session.displayName },
      payload: { title: (data.title as string) || page.title },
      targetId: id,
      targetType: 'wiki',
      logActivity: contentChanged,
    })
    return ok({ ok: true, version: data.version })
  })
}

/** DELETE — xoá vĩnh viễn (kèm versions + con trỏ con lên cha) */
export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireModule('wiki', true)
    const { id } = await ctx.params
    const page = await db.wikiPage.findUnique({ where: { id } })
    if (!page || page.ownerId !== session.id) return fail('Trang không tồn tại', 404)
    await db.wikiPage.updateMany({ where: { parentId: id, ownerId: session.id }, data: { parentId: page.parentId } })
    await db.wikiPage.delete({ where: { id } })
    await emitEvent({
      type: 'wiki.deleted',
      module: 'wiki',
      actor: { id: session.id, displayName: session.displayName },
      payload: { title: page.title },
    })
    return ok({ ok: true })
  })
}

/** PUT — khôi phục phiên bản cũ */
export async function PUT(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireModule('wiki', true)
    const { id } = await ctx.params
    const body = await readJson<{ version?: number }>(req)
    const page = await db.wikiPage.findUnique({ where: { id } })
    if (!page || page.ownerId !== session.id || !body.version) return fail('Dữ liệu không hợp lệ')
    const ver = await db.wikiVersion.findFirst({ where: { pageId: id, version: body.version } })
    if (!ver) return fail('Phiên bản không tồn tại', 404)
    const nextVersion = page.version + 1
    await db.wikiPage.update({
      where: { id },
      data: { title: ver.title, content: ver.content, version: nextVersion },
    })
    await db.wikiVersion.create({
      data: { pageId: id, version: nextVersion, title: ver.title, content: ver.content, authorName: session.displayName },
    })
    await emitEvent({
      type: 'wiki.updated',
      module: 'wiki',
      actor: { id: session.id, displayName: session.displayName },
      payload: { title: `khôi phục phiên bản ${body.version}` },
      targetId: id,
    })
    return ok({ ok: true })
  })
}
