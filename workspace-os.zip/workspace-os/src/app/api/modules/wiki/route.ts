import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireModule, handle, ok, fail, readJson } from '@/core/server/api'
import { emitEvent } from '@/core/server/event-bus'
import { assertWikiParent } from '@/core/server/wiki-parent'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** GET — toàn bộ cây wiki của tài khoản (page phẳng, client tự dựng tree) */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireModule('wiki')
    const withTrash = req.nextUrl.searchParams.get('trash') === '1'
    const pages = await db.wikiPage.findMany({
      where: { ownerId: session.id, ...(withTrash ? { trashedAt: { not: null } } : { trashedAt: null }) },
      orderBy: [{ parentId: 'asc' }, { position: 'asc' }],
      select: {
        id: true, parentId: true, title: true, icon: true, position: true,
        version: true, trashedAt: true, createdAt: true, updatedAt: true,
      },
    })
    return ok({ pages })
  })
}

/** POST — tạo trang wiki (parentId null = thư mục gốc). v2.3: parentId phải thuộc
 *  CÙNG tài khoản (chống nhét trang vào cây của user khác). */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireModule('wiki', true)
    const body = await readJson<{ title?: string; parentId?: string | null; icon?: string; content?: string }>(req)
    const title = (body.title || '').trim()
    if (!title) return fail('Nhập tiêu đề trang')
    const parentId = await assertWikiParent(session.id, null, body.parentId || null)
    const maxPos = await db.wikiPage.aggregate({ where: { parentId, ownerId: session.id }, _max: { position: true } })
    const page = await db.wikiPage.create({
      data: {
        ownerId: session.id,
        title,
        parentId,
        icon: body.icon || '📄',
        content: body.content || '',
        position: (maxPos._max.position || 0) + 1,
      },
    })
    if (body.content) {
      await db.wikiVersion.create({
        data: { pageId: page.id, version: 1, title, content: body.content, authorName: session.displayName },
      })
    }
    await emitEvent({
      type: 'wiki.created',
      module: 'wiki',
      actor: { id: session.id, displayName: session.displayName },
      payload: { title },
      targetId: page.id,
      targetType: 'wiki',
    })
    return ok({ page })
  })
}
