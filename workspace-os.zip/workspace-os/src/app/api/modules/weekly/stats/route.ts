import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireModule, handle, ok } from '@/core/server/api'
import { addDaysISO, isISODate, weekStartISO } from '@/modules/weekly/lib'
import { getUserTimezone, isoDateInTz } from '@/core/server/datetime'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/**
 * GET /api/modules/weekly/stats?from&to — thống kê từng ngày của TÀI KHOẢN (tính trực tiếp từ DB)
 * Trả về: days[] (per-day) + summary (tổng khoảng).
 */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireModule('weekly')
    const sp = req.nextUrl.searchParams
    const tz = await getUserTimezone()
    const today = isoDateInTz(new Date(), tz)
    let from = isISODate(sp.get('from')) ? (sp.get('from') as string) : weekStartISO(today)
    let to = isISODate(sp.get('to')) ? (sp.get('to') as string) : addDaysISO(from, 6)
    if (from > to) {
      const tmp = from
      from = to
      to = tmp
    }

    const days = await db.workDay.findMany({
      where: { date: { gte: from, lte: to }, ownerId: session.id },
      include: { tasks: { select: { id: true, parentId: true, status: true } } },
      orderBy: { date: 'asc' },
    })

    const list = days.map((d) => {
      // Chỉ đếm VIỆC LÁ (task không là cha của task nào) — nhóm là tổng hợp từ con
      const parentIds = new Set(d.tasks.map((t) => t.parentId).filter((p): p is string => Boolean(p)))
      const leaves = d.tasks.filter((t) => !parentIds.has(t.id))
      const total = leaves.length
      const done = leaves.filter((t) => t.status === 'done').length
      const passed = leaves.filter((t) => t.status === 'passed').length
      const pending = total - done - passed
      return {
        date: d.date,
        offline: d.offline,
        offlineNote: d.offlineNote,
        total,
        done,
        passed,
        pending,
        rate: total ? Math.round((done / total) * 100) : 0,
      }
    })

    const total = list.reduce((s, d) => s + d.total, 0)
    const done = list.reduce((s, d) => s + d.done, 0)
    const passed = list.reduce((s, d) => s + d.passed, 0)
    const pending = list.reduce((s, d) => s + d.pending, 0)

    return ok({
      from,
      to,
      days: list,
      summary: {
        days: list.length,
        offlineDays: list.filter((d) => d.offline).length,
        total,
        done,
        passed,
        pending,
        rate: total ? Math.round((done / total) * 100) : 0,
      },
    })
  })
}
