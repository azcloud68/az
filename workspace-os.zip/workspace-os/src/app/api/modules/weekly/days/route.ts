import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireModule, handle, ok, fail, readJson } from '@/core/server/api'
import { addDaysISO, isISODate, weekStartISO } from '@/modules/weekly/lib'
import { getUserTimezone, isoDateInTz } from '@/core/server/datetime'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

interface DaySummary {
  date: string
  offline: boolean
  offlineNote?: string
  note?: string
  total: number
  done: number
  passed: number
  pending: number
  rate: number
  tasks?: unknown[]
}

/** Đọc + chuẩn hoá khoảng from..to (mặc định: tuần hiện tại THEO MÚI GIỜ người dùng) */
async function readRange(sp: URLSearchParams): Promise<{ from: string; to: string }> {
  const tz = await getUserTimezone()
  const today = isoDateInTz(new Date(), tz)
  const from = isISODate(sp.get('from')) ? (sp.get('from') as string) : weekStartISO(today)
  const to = isISODate(sp.get('to')) ? (sp.get('to') as string) : addDaysISO(from, 6)
  return from < to ? { from, to } : { from: to, to: from }
}

/** Tính thống kê 1 ngày — CHỈ ĐẾM VIỆC LÁ (nhóm là tổng hợp từ con, không tính vào tổng) */
function summarize(
  date: string,
  offline: boolean,
  tasks: { id: string; parentId: string | null; status: string }[],
  extra: Record<string, unknown> = {},
): DaySummary {
  const parentIds = new Set(tasks.map((t) => t.parentId).filter((p): p is string => Boolean(p)))
  const leaves = tasks.filter((t) => !parentIds.has(t.id))
  const total = leaves.length
  const done = leaves.filter((t) => t.status === 'done').length
  const passed = leaves.filter((t) => t.status === 'passed').length
  const pending = leaves.filter((t) => t.status === 'pending').length
  return {
    date,
    offline,
    total,
    done,
    passed,
    pending,
    rate: total ? Math.round((done / total) * 100) : 0,
    ...extra,
  }
}

/** Lấy WorkDay theo (date + ownerId) — tự tạo nếu chưa có (mỗi tài khoản 1 ngày riêng) */
async function getOrCreateDay(date: string, ownerId: string) {
  const existing = await db.workDay.findFirst({ where: { date, ownerId } })
  if (existing) return existing
  return db.workDay.create({ data: { date, ownerId } })
}

/** order tiếp theo trong 1 ngày */
async function nextOrder(dayId: string): Promise<number> {
  const agg = await db.workTask.aggregate({ where: { dayId }, _max: { order: true } })
  return (agg._max.order || 0) + 1
}

/**
 * GET /api/modules/weekly/days?from&to[&withTasks=1]
 * Tổng hợp từng ngày của TÀI KHOẢN trong khoảng; withTasks=1 → kèm danh sách việc (phẳng, có parentId).
 */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireModule('weekly')
    const { from, to } = await readRange(req.nextUrl.searchParams)
    const withTasks = req.nextUrl.searchParams.get('withTasks') === '1'
    const days = await db.workDay.findMany({
      where: { date: { gte: from, lte: to }, ownerId: session.id },
      include: {
        tasks: withTasks
          ? { orderBy: [{ order: 'asc' }, { createdAt: 'asc' }, { id: 'asc' }] }
          : { select: { id: true, parentId: true, status: true } },
      },
      orderBy: { date: 'asc' },
    })
    const list: DaySummary[] = days.map((d) =>
      summarize(
        d.date,
        d.offline,
        d.tasks.map((t) => ({ id: t.id, parentId: t.parentId, status: t.status })),
        {
          offlineNote: d.offlineNote,
          note: d.note,
          ...(withTasks ? { tasks: d.tasks } : {}),
        },
      ),
    )
    return ok({ from, to, days: list })
  })
}

/**
 * POST /api/modules/weekly/days — các action trong ngày:
 *  - {action:'add-process', date, processId, lotCount?}  sinh việc từ quy trình theo CÂY BƯỚC
 *      (bước có con → WorkTask cha làm NHÓM tổng hợp; bước lá → việc tick được),
 *      + prep lùi ngày
 *  - {action:'add-task', date, name}                     thêm việc tay
 *  - {action:'add-prep', date, prepId | processId+prepName | taskId}  thêm lần pha chuẩn bị
 *  - {action:'reorder', taskId, direction:'up'|'down'}   đổi thứ tự trong nhóm anh em
 */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireModule('weekly', true)
    const body = await readJson<Record<string, unknown>>(req)
    const action = String(body.action || '')

    // ========================= THÊM QUY TRÌNH VÀO NGÀY =========================
    if (action === 'add-process') {
      const date = body.date
      if (!isISODate(date)) return fail('Ngày không hợp lệ (YYYY-MM-DD)')
      const processId = String(body.processId || '')
      const process = await db.workProcess.findUnique({
        where: { id: processId },
        include: { steps: { orderBy: { order: 'asc' } }, preps: { orderBy: { order: 'asc' } } },
      })
      if (!process || process.ownerId !== session.id) return fail('Quy trình không tồn tại', 404)

      const lotOverride =
        body.lotCount !== undefined && body.lotCount !== null && String(body.lotCount) !== ''
          ? Math.max(1, Number(body.lotCount) || 1)
          : null

      // 1) Việc chính: duyệt cây bước depth-first (cha trước, con ngay sau cha)
      const day = await getOrCreateDay(date, session.id)
      const startOrder = await nextOrder(day.id)

      const stepById = new Map(process.steps.map((s) => [s.id, s]))
      const childrenOf = new Map<string, string[]>()
      const rootStepIds: string[] = []
      for (const s of process.steps) {
        const pid = s.parentId && stepById.has(s.parentId) && s.parentId !== s.id ? s.parentId : null
        if (pid) {
          childrenOf.set(pid, [...(childrenOf.get(pid) || []), s.id])
        } else {
          rootStepIds.push(s.id)
        }
      }

      let order = startOrder
      let addedTasks = 0
      let addedGroups = 0
      const createdIds: string[] = []

      const createForSteps = async (
        tx: Pick<typeof db, 'workTask'>,
        stepIds: string[],
        parentTaskId: string | null,
      ): Promise<void> => {
        for (const sid of stepIds) {
          const s = stepById.get(sid)!
          const kids = childrenOf.get(sid) || []
          const isGroup = kids.length > 0
          const lot = lotOverride ?? s.lotCount
          const task = await tx.workTask.create({
            data: {
              dayId: day.id,
              parentId: parentTaskId,
              processId: process.id,
              processName: process.name,
              stepId: s.id,
              name: s.name,
              ...(isGroup ? {} : { lotCount: lot, rowsPerLot: s.rowsPerLot, quantity: lot * s.rowsPerLot }),
              isPrep: false,
              status: 'pending',
              note: s.note,
              order: order++,
            },
          })
          createdIds.push(task.id)
          addedTasks++
          if (isGroup) {
            addedGroups++
            await createForSteps(tx, kids, task.id)
          }
        }
      }

      await db.$transaction(async (tx) => {
        await createForSteps(tx, rootStepIds, null)
      })

      // 2) Điều kiện chuẩn bị: sinh việc prep vào ngày (date − offsetDays), tự tạo WorkDay
      const prepCreated: { date: string; name: string }[] = []
      for (const prep of process.preps) {
        if (prep.offsetDays <= 0) continue
        const prepDate = addDaysISO(date, -prep.offsetDays)
        const prepDay = await getOrCreateDay(prepDate, session.id)
        const rounds = await db.workTask.findMany({
          where: { dayId: prepDay.id, processId: process.id, isPrep: true, name: prep.name },
          select: { prepRound: true },
        })
        const round = rounds.length ? Math.max(...rounds.map((r) => r.prepRound)) + 1 : 1
        await db.workTask.create({
          data: {
            dayId: prepDay.id,
            processId: process.id,
            processName: process.name,
            name: prep.name,
            isPrep: true,
            prepRound: round,
            status: 'pending',
            note: prep.detail,
            order: await nextOrder(prepDay.id),
          },
        })
        prepCreated.push({ date: prepDate, name: prep.name })
      }

      return ok({
        ok: true,
        date,
        dayId: day.id,
        addedSteps: addedTasks,
        addedGroups,
        createdIds,
        lotCount: lotOverride,
        preps: prepCreated,
      })
    }

    // ========================= THÊM VIỆC TAY =========================
    if (action === 'add-task') {
      const date = body.date
      if (!isISODate(date)) return fail('Ngày không hợp lệ (YYYY-MM-DD)')
      const name = String(body.name || '').trim()
      if (!name) return fail('Nhập tên việc')
      // parentId tuỳ chọn: việc CON nằm trong việc mẹ (cùng ngày, cùng tài khoản)
      let parentId: string | null = null
      if (body.parentId !== undefined && body.parentId !== null && String(body.parentId).trim()) {
        const pId = String(body.parentId).trim()
        const parent = await db.workTask.findUnique({ where: { id: pId } })
        if (!parent) return fail('Việc mẹ không tồn tại', 404)
        const parentDay = await db.workDay.findUnique({ where: { id: parent.dayId } })
        if (!parentDay || parentDay.ownerId !== session.id || parentDay.date !== date)
          return fail('Việc mẹ phải cùng ngày với việc con')
        parentId = pId
      }
      const day = await getOrCreateDay(date, session.id)
      const task = await db.workTask.create({
        data: {
          dayId: day.id,
          name,
          status: 'pending',
          parentId,
          order: await nextOrder(day.id),
        },
      })
      // trả kèm tên việc mẹ để UI cập nhật cây ngay
      let parentName: string | null = null
      if (parentId) {
        const p = await db.workTask.findUnique({ where: { id: parentId }, select: { name: true } })
        parentName = p?.name || null
      }
      return ok({ ok: true, task, parentName })
    }

    // ========================= THÊM LẦN PHA (PREP) =========================
    if (action === 'add-prep') {
      const date = body.date
      if (!isISODate(date)) return fail('Ngày không hợp lệ (YYYY-MM-DD)')

      // (a) Nhân bản trực tiếp từ 1 task prep có sẵn → prepRound++
      if (body.taskId) {
        const source = await db.workTask.findUnique({ where: { id: String(body.taskId) } })
        if (!source || !source.isPrep) return fail('Việc chuẩn bị không tồn tại', 404)
        const sourceDay = await db.workDay.findUnique({ where: { id: source.dayId } })
        if (!sourceDay || sourceDay.ownerId !== session.id) return fail('Việc chuẩn bị không tồn tại', 404)
        const day = await getOrCreateDay(date, session.id)
        const rounds = await db.workTask.findMany({
          where: { dayId: day.id, processId: source.processId, isPrep: true, name: source.name },
          select: { prepRound: true },
        })
        const round = rounds.length ? Math.max(...rounds.map((r) => r.prepRound)) + 1 : 1
        const task = await db.workTask.create({
          data: {
            dayId: day.id,
            processId: source.processId,
            processName: source.processName,
            name: source.name,
            isPrep: true,
            prepRound: round,
            status: 'pending',
            note: source.note,
            order: await nextOrder(day.id),
          },
        })
        return ok({ ok: true, task })
      }

      // (b) Tìm prep template theo prepId, hoặc tên gần đúng trong quy trình (cùng tài khoản)
      let prep: { id: string; name: string; detail: string; processId: string } | null = null
      if (body.prepId) {
        const found = await db.workPrep.findUnique({
          where: { id: String(body.prepId) },
          include: { process: true },
        })
        if (found && found.process.ownerId === session.id) prep = found
      }
      const processId = String(body.processId || '')
      if (!prep && body.prepName && processId) {
        const owned = await db.workProcess.findUnique({ where: { id: processId } })
        if (!owned || owned.ownerId !== session.id) return fail('Quy trình không tồn tại', 404)
        const q = String(body.prepName).trim().toLowerCase()
        const candidates = await db.workPrep.findMany({ where: { processId }, orderBy: { order: 'asc' } })
        prep =
          candidates.find((p) => p.name.toLowerCase() === q) ||
          candidates.find(
            (p) => p.name.toLowerCase().includes(q) || q.includes(p.name.toLowerCase()),
          ) ||
          null
      }
      if (!prep) return fail('Không tìm thấy điều kiện chuẩn bị trong quy trình')

      const process = await db.workProcess.findUnique({ where: { id: prep.processId } })
      const day = await getOrCreateDay(date, session.id)
      const rounds = await db.workTask.findMany({
        where: { dayId: day.id, processId: prep.processId, isPrep: true, name: prep.name },
        select: { prepRound: true },
      })
      const round = rounds.length ? Math.max(...rounds.map((r) => r.prepRound)) + 1 : 1
      const task = await db.workTask.create({
        data: {
          dayId: day.id,
          processId: prep.processId,
          processName: process?.name || '',
          name: prep.name,
          isPrep: true,
          prepRound: round,
          status: 'pending',
          note: prep.detail,
          order: await nextOrder(day.id),
        },
      })
      return ok({ ok: true, task })
    }

    // ========================= ĐỔI THỨ TỰ VIỆC =========================
    if (action === 'reorder') {
      const taskId = String(body.taskId || '')
      const direction = String(body.direction || 'up') === 'down' ? 'down' : 'up'
      const task = await db.workTask.findUnique({ where: { id: taskId } })
      if (!task) return fail('Việc không tồn tại', 404)
      const taskDay = await db.workDay.findUnique({ where: { id: task.dayId } })
      if (!taskDay || taskDay.ownerId !== session.id) return fail('Việc không tồn tại', 404)

      const dayTasks = await db.workTask.findMany({
        where: { dayId: task.dayId },
        orderBy: [{ order: 'asc' }, { createdAt: 'asc' }, { id: 'asc' }],
        select: { id: true, parentId: true },
      })
      const ids = new Set(dayTasks.map((t) => t.id))

      // Nhóm anh em: cùng parentId hiệu dụng (mồ côi / parentId ngoài ngày → gốc)
      const effParent = (t: { id: string; parentId: string | null }) =>
        t.parentId && ids.has(t.parentId) && t.parentId !== t.id ? t.parentId : null
      const target = dayTasks.find((t) => t.id === task.id)!
      const siblings = dayTasks.filter((t) => effParent(t) === effParent(target)).map((t) => t.id)
      const idx = siblings.indexOf(task.id)
      const swapWith = direction === 'up' ? idx - 1 : idx + 1
      if (idx < 0 || swapWith < 0 || swapWith >= siblings.length) {
        return ok({ ok: true, moved: false }) // đã ở mép nhóm anh em — không đổi
      }
      ;[siblings[idx], siblings[swapWith]] = [siblings[swapWith], siblings[idx]]

      // Đánh lại order 1..n theo duyệt cây depth-first (gốc → con) giữ nguyên cây
      const childrenMap = new Map<string | null, string[]>()
      for (const t of dayTasks) {
        const pid = effParent(t)
        childrenMap.set(pid, [...(childrenMap.get(pid) || []), t.id])
      }
      // hoán đổi vị trí 2 anh em trong danh sách con của cha chúng
      const pid = effParent(target)
      childrenMap.set(pid, siblings)

      const updates: { id: string; order: number }[] = []
      const walk = (parent: string | null) => {
        for (const id of childrenMap.get(parent) || []) {
          updates.push({ id, order: updates.length + 1 })
          walk(id)
        }
      }
      walk(null)
      await db.$transaction(updates.map((u) => db.workTask.update({ where: { id: u.id }, data: { order: u.order } })))
      return ok({ ok: true, moved: true })
    }

    return fail('Action không hợp lệ')
  })
}
