import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireModule, handle, ok, fail, readJson, ApiError } from '@/core/server/api'
import { emitEvent } from '@/core/server/event-bus'
import { AUTO_PASS_NOTE, isISODate } from '@/modules/weekly/lib'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/**
 * Tính lại trạng thái mọi việc NHÓM (có con) trong 1 ngày:
 * mọi con done/passed → nhóm done (+completedAt), ngược lại pending.
 * Xử lý sâu trước (nhiều cấp) để nhóm cha tính trên trạng thái nhóm con đã cập nhật.
 */
async function recomputeDayGroups(dayId: string): Promise<void> {
  const all = await db.workTask.findMany({
    where: { dayId },
    select: { id: true, parentId: true, status: true },
  })
  const ids = new Set(all.map((t) => t.id))
  const byId = new Map(all.map((t) => [t.id, t]))
  const groupIds = [
    ...new Set(
      all.map((t) => t.parentId).filter((p): p is string => !!p && ids.has(p)),
    ),
  ]
  if (groupIds.length === 0) return

  // depth của từng nhóm (xa gốc nhất xử lý trước)
  const depthOf = (id: string): number => {
    let d = 0
    let cur = byId.get(id)
    while (cur?.parentId && ids.has(cur.parentId) && cur.parentId !== cur.id) {
      d++
      cur = byId.get(cur.parentId)
    }
    return d
  }
  const ordered = [...groupIds].sort((a, b) => depthOf(b) - depthOf(a))

  for (const gid of ordered) {
    const children = await db.workTask.findMany({
      where: { parentId: gid },
      select: { status: true },
    })
    if (children.length === 0) continue // nhóm rỗng → bỏ (sẽ tự dọn khi xoá con cuối)
    const current = byId.get(gid)
    if (current?.status === 'passed') continue // pass tay (legacy) → không đè
    const settled = children.every((c) => c.status === 'done' || c.status === 'passed')
    const next = settled ? 'done' : 'pending'
    if (current?.status === next) continue
    await db.workTask.update({
      where: { id: gid },
      data: { status: next, completedAt: next === 'done' ? new Date() : null },
    })
  }
}

/** GET /api/modules/weekly/days/[date] — WorkDay của tài khoản + danh sách việc (sort theo order) */
export async function GET(_req: NextRequest, ctx: { params: Promise<{ date: string }> }) {
  return handle(async () => {
    const session = await requireModule('weekly')
    const { date } = await ctx.params
    if (!isISODate(date)) throw new ApiError('Ngày không hợp lệ (YYYY-MM-DD)', 400)
    const day = await db.workDay.findFirst({
      where: { date, ownerId: session.id },
      include: { tasks: { orderBy: [{ order: 'asc' }, { createdAt: 'asc' }, { id: 'asc' }] } },
    })
    if (!day) return ok({ day: null, tasks: [] })
    return ok({ day, tasks: day.tasks })
  })
}

/**
 * PATCH /api/modules/weekly/days/[date] — {offline?, offlineNote?, note?}
 * Bật Offline: mọi việc pending (trừ việc NHÓM) → passed + note "Nghỉ làm — auto pass",
 * rồi tính lại nhóm theo con. Bỏ Offline: việc pass đúng note đó quay lại pending + tính lại nhóm.
 */
export async function PATCH(req: NextRequest, ctx: { params: Promise<{ date: string }> }) {
  return handle(async () => {
    const session = await requireModule('weekly', true)
    const { date } = await ctx.params
    if (!isISODate(date)) throw new ApiError('Ngày không hợp lệ (YYYY-MM-DD)', 400)
    const body = await readJson<Record<string, unknown>>(req)

    // Ngày chưa có record của tài khoản → tự tạo (cho phép đặt offline trước cho ngày nghỉ)
    let day = await db.workDay.findFirst({ where: { date, ownerId: session.id } })
    if (!day) day = await db.workDay.create({ data: { date, ownerId: session.id } })

    const data: { note?: string; offlineNote?: string; offline?: boolean } = {}
    if (body.note !== undefined) data.note = String(body.note)
    if (body.offlineNote !== undefined) data.offlineNote = String(body.offlineNote)

    let wentOffline = false
    if (body.offline !== undefined) {
      const nextOffline = Boolean(body.offline)
      if (nextOffline && !day.offline) {
        // Auto pass mọi việc pending (trừ nhóm tổng hợp — nhóm tính lại theo con) + note chuẩn
        wentOffline = true
        const dayTasks = await db.workTask.findMany({
          where: { dayId: day.id },
          select: { id: true, parentId: true },
        })
        const dayIds = new Set(dayTasks.map((t) => t.id))
        const groupIds = [
          ...new Set(
            dayTasks.map((t) => t.parentId).filter((p): p is string => !!p && dayIds.has(p)),
          ),
        ]
        await db.workTask.updateMany({
          where: { dayId: day.id, status: 'pending', id: { notIn: groupIds } },
          data: { status: 'passed', note: AUTO_PASS_NOTE },
        })
      } else if (!nextOffline && day.offline) {
        // Hoàn tác: việc pass đúng note chuẩn → quay lại pending
        await db.workTask.updateMany({
          where: { dayId: day.id, status: 'passed', note: AUTO_PASS_NOTE },
          data: { status: 'pending', note: '' },
        })
      }
      data.offline = nextOffline
    }

    const updated = await db.workDay.update({ where: { id: day.id }, data })
    if (body.offline !== undefined) {
      // tính lại nhóm sau khi (bỏ) offline — nhóm phản chiếu đúng trạng thái con
      await recomputeDayGroups(day.id)
    }
    const withTasks = await db.workDay.findUnique({
      where: { id: day.id },
      include: { tasks: { orderBy: [{ order: 'asc' }, { createdAt: 'asc' }, { id: 'asc' }] } },
    })
    if (wentOffline) {
      await emitEvent({
        type: 'weekly.day.offline',
        module: 'weekly',
        actor: { id: session.id, displayName: session.displayName },
        payload: { title: date, note: updated.offlineNote },
        targetId: updated.id,
        targetType: 'workday',
        notify: {
          title: 'Đánh dấu ngày nghỉ',
          content: `${date} — mọi việc còn lại đã được tự động pass`,
          type: 'info',
          action: 'weekly',
        },
      })
    }
    return ok({ day: withTasks })
  })
}

/** DELETE — xoá ngày của tài khoản + toàn bộ việc trong ngày (cascade) */
export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ date: string }> }) {
  return handle(async () => {
    const session = await requireModule('weekly', true)
    const { date } = await ctx.params
    if (!isISODate(date)) throw new ApiError('Ngày không hợp lệ (YYYY-MM-DD)', 400)
    const day = await db.workDay.findFirst({ where: { date, ownerId: session.id } })
    if (!day) return fail('Ngày không tồn tại', 404)
    await db.workDay.delete({ where: { id: day.id } })
    return ok({ ok: true })
  })
}
