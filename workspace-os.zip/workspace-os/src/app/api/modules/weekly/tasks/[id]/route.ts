import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireModule, handle, ok, fail, readJson } from '@/core/server/api'
import { emitEvent } from '@/core/server/event-bus'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const STATUSES = ['pending', 'done', 'passed']

/**
 * Tính lại trạng thái việc NHÓM cha (đệ quy lên nhiều cấp):
 * mọi con done/passed → cha done (+completedAt), ngược lại pending.
 * Trả về danh sách nhóm đã đổi trạng thái (cho response + event).
 */
async function recomputeParentChain(
  startParentId: string | null,
  actor?: { id: string; displayName: string },
): Promise<{ id: string; name: string; status: string }[]> {
  const changed: { id: string; name: string; status: string }[] = []
  let parentId = startParentId
  let guard = 0
  while (parentId && guard++ < 50) {
    const parent = await db.workTask.findUnique({
      where: { id: parentId },
      include: { children: { select: { status: true } } },
    })
    if (!parent) break
    if (parent.children.length === 0) break
    if (parent.status === 'passed') break // pass tay (legacy) → không đè
    const settled = parent.children.every((c) => c.status === 'done' || c.status === 'passed')
    const next = settled ? 'done' : 'pending'
    if (parent.status !== next) {
      const updated = await db.workTask.update({
        where: { id: parent.id },
        data: { status: next, completedAt: next === 'done' ? new Date() : null },
      })
      changed.push({ id: updated.id, name: updated.name, status: updated.status })
      if (next === 'done' && actor) {
        // nhóm tự hoàn thành → event (không notify để tránh spam)
        await emitEvent({
          type: 'weekly.task.completed',
          module: 'weekly',
          actor,
          payload: { title: updated.name, auto: true },
          targetId: updated.id,
          targetType: 'worktask',
          logActivity: false,
        })
      }
    }
    parentId = parent.parentId
  }
  return changed
}

/**
 * PATCH /api/modules/weekly/tasks/[id] — {status?, note?, name?, quantity?}
 * - status done   → completedAt = now, emit weekly.task.completed
 * - status passed → bắt buộc có lý do (note), emit weekly.task.passed
 * - status pending→ trả về chờ làm
 * - việc NHÓM (có con) không đổi status trực tiếp — tổng hợp tự động từ việc con (400)
 * - tick việc con xong → tính lại chuỗi cha (đệ quy nhiều cấp)
 */
export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireModule('weekly', true)
    const { id } = await ctx.params
    const body = await readJson<Record<string, unknown>>(req)
    const task = await db.workTask.findUnique({
      where: { id },
      include: { children: { select: { id: true } } },
    })
    if (!task) return fail('Việc không tồn tại', 404)
    const taskDay = await db.workDay.findUnique({ where: { id: task.dayId } })
    if (!taskDay || taskDay.ownerId !== session.id) return fail('Việc không tồn tại', 404)

    const isGroup = task.children.length > 0

    const data: { name?: string; note?: string; quantity?: number; status?: string; completedAt?: Date | null } = {}
    if (body.name !== undefined) {
      const name = String(body.name).trim()
      if (!name) return fail('Tên việc không được để trống')
      data.name = name
    }
    if (body.note !== undefined) data.note = String(body.note)
    if (body.quantity !== undefined) {
      const q = Number(body.quantity)
      if (Number.isFinite(q) && q >= 0) data.quantity = Math.floor(q)
    }

    if (body.status !== undefined) {
      const status = String(body.status)
      if (!STATUSES.includes(status)) return fail('Trạng thái không hợp lệ (pending | done | passed)')
      if (isGroup) {
        return fail('Việc nhóm tổng hợp tự động từ việc con — tick từng việc con để cập nhật tiến độ', 400)
      }
      if (status === 'passed') {
        const reason = body.note !== undefined ? String(body.note).trim() : task.note.trim()
        if (!reason) return fail('Nhập lý do để pass việc này')
        if (body.note !== undefined) data.note = reason
      }
      data.status = status
      data.completedAt = status === 'done' ? new Date() : null
    }

    const updated = await db.workTask.update({ where: { id }, data })

    // Việc con đổi trạng thái → tính lại chuỗi việc cha (nhiều cấp)
    let parentsChanged: { id: string; name: string; status: string }[] = []
    if (data.status !== undefined && task.parentId) {
      parentsChanged = await recomputeParentChain(task.parentId, {
        id: session.id,
        displayName: session.displayName,
      })
    }

    // Event server theo spec: chỉ completed / passed
    const evType =
      data.status === 'done' && task.status !== 'done'
        ? 'weekly.task.completed'
        : data.status === 'passed' && task.status !== 'passed'
          ? 'weekly.task.passed'
          : ''
    if (evType) {
      await emitEvent({
        type: evType,
        module: 'weekly',
        actor: { id: session.id, displayName: session.displayName },
        payload: { title: updated.name, note: updated.note },
        targetId: id,
        targetType: 'worktask',
        notify:
          evType === 'weekly.task.completed'
            ? { title: 'Hoàn thành việc tuần', content: updated.name, type: 'info', action: 'weekly' }
            : undefined,
      })
    }
    return ok({ task: updated, parents: parentsChanged })
  })
}

/**
 * DELETE — xoá 1 việc (nhóm → cascade cả cây con) — việc phải thuộc ngày của tài khoản.
 * Xoá việc con cuối của nhóm → tự dọn nhóm cha rỗng (đệ quy lên).
 */
export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireModule('weekly', true)
    const { id } = await ctx.params
    const task = await db.workTask.findUnique({ where: { id } })
    if (!task) return fail('Việc không tồn tại', 404)
    const taskDay = await db.workDay.findUnique({ where: { id: task.dayId } })
    if (!taskDay || taskDay.ownerId !== session.id) return fail('Việc không tồn tại', 404)

    const removedGroups: string[] = []
    await db.$transaction(async (tx) => {
      await tx.workTask.delete({ where: { id } })
      // dọn nhóm cha rỗng (đệ quy) + tính lại nhóm còn con
      let parentId = task.parentId
      let guard = 0
      while (parentId && guard++ < 50) {
        const parent = await tx.workTask.findUnique({
          where: { id: parentId },
          include: { children: { select: { id: true, status: true } } },
        })
        if (!parent) break
        if (parent.children.length === 0) {
          await tx.workTask.delete({ where: { id: parent.id } })
          removedGroups.push(parent.id)
          parentId = parent.parentId
          continue
        }
        const settled = parent.children.every((c) => c.status === 'done' || c.status === 'passed')
        const next = settled ? 'done' : 'pending'
        if (parent.status !== next && parent.status !== 'passed') {
          await tx.workTask.update({
            where: { id: parent.id },
            data: { status: next, completedAt: next === 'done' ? new Date() : null },
          })
        }
        parentId = parent.parentId
      }
    })
    return ok({ ok: true, removedGroups })
  })
}
