import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireModule, handle, ok, fail, readJson, ApiError } from '@/core/server/api'
import { emitEvent } from '@/core/server/event-bus'
import { parseStepTree, parsePrepRows, type StepTreeRow } from '@/modules/weekly/lib'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** Tạo WorkStep theo cây nhiều cấp (cha trước con) trong transaction */
async function createStepTree(
  tx: Pick<typeof db, 'workStep'>,
  processId: string,
  rows: StepTreeRow[],
): Promise<number> {
  const tmpToId = new Map<string, string>()
  for (const r of rows) {
    const parentId = r.parentTmpId ? tmpToId.get(r.parentTmpId) : undefined
    const step = await tx.workStep.create({
      data: {
        processId,
        parentId: parentId || null,
        name: r.name,
        lotCount: r.lotCount,
        rowsPerLot: r.rowsPerLot,
        note: r.note,
        order: r.order,
      },
    })
    tmpToId.set(r.tmpId, step.id)
  }
  return rows.length
}

/** GET /api/modules/weekly/processes/[id] — chi tiết + steps (phẳng kèm parentId) + preps — chỉ chủ sở hữu */
export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireModule('weekly')
    const { id } = await ctx.params
    const process = await db.workProcess.findUnique({
      where: { id },
      include: {
        steps: { orderBy: { order: 'asc' } },
        preps: { orderBy: { order: 'asc' } },
      },
    })
    if (!process || process.ownerId !== session.id) throw new ApiError('Quy trình không tồn tại', 404)
    return ok({ process })
  })
}

/**
 * PATCH — cập nhật field quy trình; gửi kèm mảng steps/preps thì
 * GHI ĐÈ toàn bộ (xoá hết — cascade cả cây con — rồi tạo lại theo cây gửi lên, nguyên tử).
 * steps: phẳng kèm id/parentId tạm HOẶC lồng children (nhiều cấp).
 */
export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireModule('weekly', true)
    const { id } = await ctx.params
    const body = await readJson<Record<string, unknown>>(req)
    const process = await db.workProcess.findUnique({ where: { id } })
    if (!process || process.ownerId !== session.id) return fail('Quy trình không tồn tại', 404)

    const stepRows = Array.isArray(body.steps) ? parseStepTree(body.steps) : null
    const prepRows = Array.isArray(body.preps) ? parsePrepRows(body.preps) : null

    const updated = await db.$transaction(async (tx) => {
      const data: Record<string, unknown> = {}
      if (body.name !== undefined) {
        const name = String(body.name).trim()
        if (!name) throw new ApiError('Tên quy trình không được để trống', 400)
        data.name = name
      }
      if (body.description !== undefined) data.description = String(body.description)
      if (body.color !== undefined) data.color = String(body.color)
      if (body.icon !== undefined) data.icon = String(body.icon)
      if (body.order !== undefined) data.order = Number(body.order) || 0
      await tx.workProcess.update({ where: { id }, data })

      if (stepRows) {
        // Ghi đè cây bước: deleteMany toàn bộ (cascade con) + tạo lại cây mới
        await tx.workStep.deleteMany({ where: { processId: id } })
        await createStepTree(tx, id, stepRows)
      }
      if (prepRows) {
        await tx.workPrep.deleteMany({ where: { processId: id } })
        await tx.workPrep.createMany({ data: prepRows.map((p) => ({ ...p, processId: id })) })
      }
      return tx.workProcess.findUnique({
        where: { id },
        include: { steps: { orderBy: { order: 'asc' } }, preps: { orderBy: { order: 'asc' } } },
      })
    })

    if (!updated) return fail('Quy trình không tồn tại', 404)

    await emitEvent({
      type: 'weekly.process.updated',
      module: 'weekly',
      actor: { id: session.id, displayName: session.displayName },
      payload: { title: updated.name },
      targetId: id,
      targetType: 'workprocess',
    })
    return ok({ process: updated })
  })
}

/** DELETE — xoá quy trình (cascade steps + preps) */
export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireModule('weekly', true)
    const { id } = await ctx.params
    const process = await db.workProcess.findUnique({ where: { id } })
    if (!process || process.ownerId !== session.id) return fail('Quy trình không tồn tại', 404)
    await db.workProcess.delete({ where: { id } })
    await emitEvent({
      type: 'weekly.process.deleted',
      module: 'weekly',
      actor: { id: session.id, displayName: session.displayName },
      payload: { title: process.name },
      targetId: id,
      targetType: 'workprocess',
    })
    return ok({ ok: true })
  })
}
