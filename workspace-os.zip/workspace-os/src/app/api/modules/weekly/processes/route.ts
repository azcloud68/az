import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireModule, handle, ok, fail, readJson } from '@/core/server/api'
import { emitEvent } from '@/core/server/event-bus'
import { parseStepTree, parsePrepRows, type StepTreeRow } from '@/modules/weekly/lib'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/**
 * Tạo WorkStep theo cây (nhiều cấp) từ danh sách phẳng depth-first.
 * Cha luôn đứng trước con (bảo đảm bởi parseStepTree) → tạo tuần tự,
 * map tmpId → id thật để gắn parentId. Dùng trong transaction.
 */
async function createStepTree(
  tx: Pick<typeof db, 'workStep'>,
  processId: string,
  rows: StepTreeRow[],
): Promise<string[]> {
  const tmpToId = new Map<string, string>()
  const created: string[] = []
  for (const r of rows) {
    const parentId = r.parentTmpId ? tmpToId.get(r.parentTmpId) : undefined
    const step = await tx.workStep.create({
      data: {
        processId,
        parentId: parentId || null,
        name: r.name,
        lotCount: r.lotCount,
        rowsPerLot: r.rowsPerLot,
        note: r.note,
        order: r.order,
      },
    })
    tmpToId.set(r.tmpId, step.id)
    created.push(step.id)
  }
  return created
}

/** GET /api/modules/weekly/processes — danh sách quy trình của tài khoản + bước/điều kiện */
export async function GET() {
  return handle(async () => {
    const session = await requireModule('weekly')
    const processes = await db.workProcess.findMany({
      where: { ownerId: session.id },
      orderBy: [{ order: 'asc' }, { createdAt: 'asc' }],
      include: {
        _count: { select: { steps: true, preps: true } },
        steps: {
          orderBy: { order: 'asc' },
          select: { id: true, parentId: true, name: true, lotCount: true, rowsPerLot: true },
        },
        preps: { orderBy: { order: 'asc' }, select: { id: true, name: true, offsetDays: true } },
      },
    })
    return ok({ processes })
  })
}

/** POST — tạo quy trình (kèm steps dạng cây + preps) */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireModule('weekly', true)
    const body = await readJson<Record<string, unknown>>(req)
    const name = String(body.name || '').trim()
    if (!name) return fail('Nhập tên quy trình')

    const stepRows = parseStepTree(Array.isArray(body.steps) ? body.steps : [])
    const preps = parsePrepRows(Array.isArray(body.preps) ? body.preps : [])

    const maxOrder = await db.workProcess.aggregate({ where: { ownerId: session.id }, _max: { order: true } })
    const process = await db.$transaction(async (tx) => {
      const created = await tx.workProcess.create({
        data: {
          ownerId: session.id,
          name,
          description: String(body.description || ''),
          color: String(body.color || '#3b82f6'),
          icon: String(body.icon || '🧪'),
          order: (maxOrder._max.order || 0) + 1,
          preps: { create: preps },
        },
      })
      await createStepTree(tx, created.id, stepRows)
      return tx.workProcess.findUnique({
        where: { id: created.id },
        include: {
          steps: { orderBy: { order: 'asc' } },
          preps: { orderBy: { order: 'asc' } },
        },
      })
    })
    if (!process) return fail('Không tạo được quy trình', 500)
    await emitEvent({
      type: 'weekly.process.created',
      module: 'weekly',
      actor: { id: session.id, displayName: session.displayName },
      payload: { title: process.name, steps: stepRows.length, preps: preps.length },
      targetId: process.id,
      targetType: 'workprocess',
    })
    return ok({ process })
  })
}
