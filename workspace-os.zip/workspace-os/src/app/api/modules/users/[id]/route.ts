import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { can, authDenied, permDenied, getSessionUser, hashPassword, listSessions } from '@/lib/auth'
import { logActivity } from '@/lib/server/event-bus'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

type Params = { params: Promise<{ id: string }> }

export async function GET(_req: NextRequest, { params }: Params) {
  const me = await can('users', 'view')
  if (!me) {
    const u = await getSessionUser()
    if (!u) return authDenied()
    return permDenied()
  }
  const { id } = await params
  const user = await db.user.findUnique({
    where: { id },
    select: { id: true, username: true, email: true, displayName: true, role: true, avatarColor: true, active: true, createdAt: true },
  })
  if (!user) return NextResponse.json({ error: 'Không tìm thấy' }, { status: 404 })
  const sessions = await listSessions(id)
  return NextResponse.json({ user, sessions: sessions.map(s => ({ id: s.id, ip: s.ip, userAgent: s.userAgent, createdAt: s.createdAt, expiresAt: s.expiresAt })) })
}

export async function PATCH(req: NextRequest, { params }: Params) {
  const me = await can('users', 'manage')
  if (!me) {
    const u = await getSessionUser()
    if (!u) return authDenied()
    return permDenied()
  }
  const { id } = await params
  const body = await req.json() as Record<string, unknown>
  const target = await db.user.findUnique({ where: { id } })
  if (!target) return NextResponse.json({ error: 'Không tìm thấy' }, { status: 404 })
  const data: Record<string, unknown> = {}
  if ('displayName' in body) data.displayName = String(body.displayName ?? '')
  if ('email' in body) data.email = body.email ? String(body.email) : null
  if ('role' in body && ['admin', 'member', 'viewer'].includes(String(body.role))) {
    if (target.id === me.id && String(body.role) !== 'admin') {
      return NextResponse.json({ error: 'Không thể tự hạ quyền của chính mình' }, { status: 400 })
    }
    data.role = String(body.role)
  }
  if ('active' in body) {
    if (target.id === me.id && !body.active) return NextResponse.json({ error: 'Không thể tự khoá chính mình' }, { status: 400 })
    data.active = Boolean(body.active)
    if (!body.active) await db.session.deleteMany({ where: { userId: id } })
  }
  if ('password' in body && body.password) {
    const pw = String(body.password)
    if (pw.length < 6) return NextResponse.json({ error: 'Mật khẩu tối thiểu 6 ký tự' }, { status: 400 })
    data.passwordHash = hashPassword(pw)
    await db.session.deleteMany({ where: { userId: id } })
  }
  const updated = await db.user.update({ where: { id }, data })
  await logActivity({ userId: me.id, userName: me.displayName, module: 'users', action: 'update', targetType: 'user', targetId: id, detail: `Cập nhật người dùng ${target.username}` })
  return NextResponse.json({ user: { ...updated, passwordHash: undefined } })
}

export async function DELETE(_req: NextRequest, { params }: Params) {
  const me = await can('users', 'manage')
  if (!me) {
    const u = await getSessionUser()
    if (!u) return authDenied()
    return permDenied()
  }
  const { id } = await params
  if (id === me.id) return NextResponse.json({ error: 'Không thể xoá chính mình' }, { status: 400 })
  const target = await db.user.findUnique({ where: { id } })
  if (!target) return NextResponse.json({ error: 'Không tìm thấy' }, { status: 404 })
  await db.user.delete({ where: { id } })
  await logActivity({ userId: me.id, userName: me.displayName, module: 'users', action: 'delete', targetType: 'user', targetId: id, detail: `Xoá người dùng ${target.username}` })
  return NextResponse.json({ ok: true })
}
