import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { can, authDenied, permDenied, getSessionUser, hashPassword, avatarSeedColor } from '@/lib/auth'
import { logActivity } from '@/lib/server/event-bus'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET() {
  const user = await can('users', 'view')
  if (!user) {
    const u = await getSessionUser()
    if (!u) return authDenied()
    return permDenied()
  }
  const [users, groups] = await Promise.all([
    db.user.findMany({ orderBy: { createdAt: 'asc' }, select: { id: true, username: true, email: true, displayName: true, role: true, avatarColor: true, active: true, groupId: true, createdAt: true, updatedAt: true } }),
    db.group.findMany({ include: { users: { select: { id: true } } } }),
  ])
  return NextResponse.json({ users, groups, roles: ['admin', 'member', 'viewer'] })
}

export async function POST(req: NextRequest) {
  const user = await can('users', 'manage')
  if (!user) {
    const u = await getSessionUser()
    if (!u) return authDenied()
    return permDenied()
  }
  const body = await req.json() as Record<string, unknown>
  const username = String(body.username ?? '').trim().toLowerCase()
  const password = String(body.password ?? '')
  if (!/^[a-z0-9_.-]{3,32}$/.test(username)) return NextResponse.json({ error: 'Tên đăng nhập 3-32 ký tự (a-z, 0-9, . _ -)' }, { status: 400 })
  if (password.length < 6) return NextResponse.json({ error: 'Mật khẩu tối thiểu 6 ký tự' }, { status: 400 })
  const exists = await db.user.findUnique({ where: { username } })
  if (exists) return NextResponse.json({ error: 'Tên đăng nhập đã tồn tại' }, { status: 400 })
  const displayName = String(body.displayName ?? username)
  const created = await db.user.create({
    data: {
      username, passwordHash: hashPassword(password), displayName,
      email: body.email ? String(body.email) : null,
      role: ['admin', 'member', 'viewer'].includes(String(body.role)) ? String(body.role) : 'member',
      avatarColor: avatarSeedColor(username),
    },
  })
  await logActivity({ userId: user.id, userName: user.displayName, module: 'users', action: 'create', targetType: 'user', targetId: created.id, detail: `Tạo người dùng ${username}` })
  return NextResponse.json({ user: { ...created, passwordHash: undefined } })
}
