import { NextRequest } from 'next/server'
import { requireModule, handle, ok } from '@/core/server/api'
import { safeResolveReal, readFileBuffer, mimeOf, isDir } from '@/core/server/storage'
import { withUserStorage } from '@/core/server/user-scope'
import { promises as fsp } from 'fs'
import path from 'path'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const TEXT_EXT = ['.txt', '.md', '.markdown', '.json', '.csv', '.xml', '.yml', '.yaml', '.log', '.sh', '.js', '.ts', '.css', '.html']
const MAX_TEXT = 1024 * 256 // 256KB text preview

/** GET /api/modules/files/preview?path= — text trả JSON, binary trỏ URL inline
 *  (URL đó stream + hỗ trợ Range — RAM an toàn với video/ảnh lớn). */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireModule('files')
    return withUserStorage(session.id, async () => {
      const rel = req.nextUrl.searchParams.get('path') || ''
      const full = await safeResolveReal(rel)
      if (await isDir(rel)) return ok({ type: 'dir' })
      const ext = path.extname(full).toLowerCase()
      const mime = mimeOf(full)
      const st = await fsp.stat(full)

      if (TEXT_EXT.includes(ext) && st.size <= MAX_TEXT) {
        const buf = await readFileBuffer(rel)
        return ok({ type: 'text', mime, size: st.size, content: buf.toString('utf-8') })
      }
      return ok({
        type: 'binary',
        mime,
        size: st.size,
        url: `/api/modules/files/download?path=${encodeURIComponent(rel)}&inline=1`,
      })
    })
  })
}
