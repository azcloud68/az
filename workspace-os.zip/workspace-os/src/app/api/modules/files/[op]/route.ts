import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireModule, handle, ok, fail, readJson } from '@/core/server/api'
import { emitEvent } from '@/core/server/event-bus'
import {
  safeResolveReal, sanitizeFileName, listDir, makeDir, moveEntry, copyEntry, removeEntry,
  exists, mimeOf, storageUsage, zipEntries, unzipEntry, STORAGE_CATEGORIES,
  statEntry, writeTextFile, readFileBuffer, withStorageLock, invalidateUsage,
} from '@/core/server/storage'
import { withUserStorage } from '@/core/server/user-scope'
import { getSetting } from '@/core/server/settings'
import { randomBytes } from 'crypto'
import path from 'path'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

type OpBody = Record<string, unknown> & {
  path?: string
  to?: string
  name?: string
  paths?: string[]
  tags?: string[]
  favorite?: boolean
  label?: string
  expiresDays?: number
}

/** where boundary chuẩn: path === p HOẶC path nằm trong p/... (không chấp nhận 'ABC2' khi xoá 'ABC') */
function subtreeWhere(uid: string, p: string) {
  return { ownerId: uid, OR: [{ path: p }, { path: { startsWith: p + '/' } }] }
}

/** Đích có nằm trong nguồn (hoặc trùng nguồn) không? — chặn copy/move A → A/con */
function isIntoItself(from: string, to: string): boolean {
  return to === from || to.startsWith(from + '/')
}

/** Cập nhật lại toàn bộ cây FileNode sau rename/move:
 *  node gốc nhận path mới + tên mới; node CON nhận path = đích + phần đuôi cũ
 *  (KHÔNG đè path của con thành đúng path cha — giữ /a.pdf), name của con giữ nguyên. */
async function retargetTree(uid: string, from: string, to: string, rootName: string): Promise<void> {
  const nodes = await db.fileNode.findMany({
    where: subtreeWhere(uid, from),
    select: { id: true, path: true },
  })
  await db.$transaction(
    nodes.map((n) => {
      const newPath = n.path === from ? to : to + n.path.slice(from.length)
      const parentDir = path.dirname(newPath) === '.' ? '' : path.dirname(newPath).split(path.sep).join('/')
      return db.fileNode.update({
        where: { id: n.id },
        data: {
          path: newPath,
          parent: parentDir,
          ...(n.path === from ? { name: rootName } : {}),
        },
      })
    })
  )
}

/**
 * GET /api/modules/files/[op] — op: list | tree | trash | search | usage | info | read
 * Toàn bộ thao tác chạy trong withUserStorage(session.id): mọi đường dẫn file
 * tự resolve vào storage/users/<uid>/ + mọi query FileNode lọc theo ownerId.
 */
export async function GET(req: NextRequest, ctx: { params: Promise<{ op: string }> }) {
  return handle(async () => {
    const session = await requireModule('files')
    return withUserStorage(session.id, async () => {
      const { op } = await ctx.params
      const sp = req.nextUrl.searchParams

      if (op === 'list') {
        const dir = sp.get('dir') || ''
        const entries = await listDir(dir)
        const metas = await db.fileNode.findMany({
          where: { parent: dir, ownerId: session.id },
          select: { path: true, favorite: true, tags: true, version: true, viewedAt: true, trashedAt: true },
        })
        const metaMap = new Map(metas.map((m) => [m.path, m]))
        return ok({
          dir,
          categories: STORAGE_CATEGORIES,
          // Ẩn mục đang ở trong thùng rác (trashedAt !== null) — DB là nguồn sự thật
          entries: entries
            .map((e) => {
              const rel = dir ? `${dir}/${e.name}` : e.name
              return { e, rel, meta: metaMap.get(rel) }
            })
            .filter(({ rel }) => {
              const m = metaMap.get(rel)
              return !m || !m.trashedAt // chưa có row DB (chưa index) hoặc chưa bị xoá
            })
            .map(({ e, rel, meta }) => ({
              name: e.name,
              path: rel,
              isDir: e.isDir,
              size: e.size,
              mtime: e.mtime,
              mime: mimeOf(e.name),
              favorite: meta?.favorite ?? false,
              tags: meta ? (JSON.parse(meta.tags || '[]') as string[]) : [],
              version: meta?.version ?? 1,
              viewedAt: meta?.viewedAt ?? null,
            })),
        })
      }

      if (op === 'trash') {
        const nodes = await db.fileNode.findMany({ where: { trashedAt: { not: null }, ownerId: session.id }, orderBy: { trashedAt: 'desc' } })
        const existOnDisk: typeof nodes = []
        for (const n of nodes) {
          if (await exists(n.path)) existOnDisk.push(n)
        }
        return ok({ trash: existOnDisk })
      }

      if (op === 'favorites') {
        const nodes = await db.fileNode.findMany({ where: { favorite: true, trashedAt: null, ownerId: session.id }, orderBy: { updatedAt: 'desc' } })
        return ok({ favorites: nodes })
      }

      if (op === 'search') {
        const q = (sp.get('q') || '').toLowerCase().trim()
        if (!q) return ok({ results: [] })
        // Tìm ĐỆ QUY toàn bộ cây thư mục thật của USER trên đĩa + gộp metadata DB
        // (mọi truy cập đĩa đi qua safeResolveReal — chống symlink)
        const fsp = await import('fs').then((m) => m.promises)
        const results: {
          name: string; path: string; isDir: boolean; size: number; mtime: Date;
          mime: string; favorite: boolean; tags: string[]; version: number; viewedAt: Date | null
        }[] = []
        const MAX = 200
        async function walk(rel: string, depth: number): Promise<void> {
          if (results.length >= MAX || depth > 6) return
          const full = await safeResolveReal(rel)
          let entries
          try {
            entries = await fsp.readdir(full, { withFileTypes: true })
          } catch {
            return
          }
          for (const e of entries) {
            if (e.name.startsWith('.wos_')) continue
            if (e.isSymbolicLink()) continue // bỏ qua symlink (không đánh index)
            const childRel = rel ? `${rel}/${e.name}` : e.name
            let st
            try {
              st = await fsp.stat(await safeResolveReal(childRel))
            } catch {
              continue
            }
            if (e.name.toLowerCase().includes(q)) {
              const node = await db.fileNode.findUnique({ where: { ownerId_path: { ownerId: session.id, path: childRel } } })
              results.push({
                name: e.name,
                path: childRel,
                isDir: e.isDirectory(),
                size: st.size,
                mtime: st.mtime,
                mime: mimeOf(e.name),
                favorite: node?.favorite ?? false,
                tags: node ? (JSON.parse(node.tags || '[]') as string[]) : [],
                version: node?.version ?? 1,
                viewedAt: node?.viewedAt ?? null,
              })
              if (results.length >= MAX) return
            }
            if (e.isDirectory() && !e.name.startsWith('.')) await walk(childRel, depth + 1)
          }
        }
        await walk('', 0)
        return ok({ results })
      }

      if (op === 'usage') {
        // Quota lấy từ Setting core:quota_gb (admin đổi được) — KHÔNG tin tham số client
        const usage = await storageUsage()
        const quotaGb = Number(await getSetting('core', 'quota_gb', '20')) || 20
        const quota = quotaGb * 1024 * 1024 * 1024
        return ok({ usage, quota, quotaGb })
      }

      if (op === 'info') {
        const rel = sp.get('path') || ''
        const node = await db.fileNode.findUnique({ where: { ownerId_path: { ownerId: session.id, path: rel } } })
        const fs = await statEntry(rel)
        return ok({ node, fs })
      }

      // Đọc nội dung tệp văn bản (cho TextViewer) — qua safeResolveReal + verify fd
      if (op === 'read') {
        const rel = sp.get('path') || ''
        const st = await statEntry(rel)
        if (!st) return fail('Tệp không tồn tại', 404)
        if (st.isDir) return fail('Không đọc được thư mục')
        if (st.size > 2 * 1024 * 1024) return fail('Tệp quá lớn (> 2MB) — dùng tải xuống')
        const content = (await readFileBuffer(rel)).toString('utf-8')
        return ok({ path: rel, name: path.basename(rel), content, size: st.size, mtime: st.mtime, mime: mimeOf(rel) })
      }

      return fail('Thao tác không hợp lệ')
    })
  })
}

/**
 * POST /api/modules/files/[op] — op: newfile | write | view | mkdir | rename | copy
 *   | move | trash | restore | delete | favorite | tag | compress | extract
 *   | share | unshare | empty-trash
 */
export async function POST(req: NextRequest, ctx: { params: Promise<{ op: string }> }) {
  return handle(async () => {
    const session = await requireModule('files', true)
    return withUserStorage(session.id, async () => {
      const { op } = await ctx.params
      const body = await readJson<OpBody>(req)
      const actor = { id: session.id, displayName: session.displayName }
      const uid = session.id

      switch (op) {
        case 'newfile': {
          const dir = String(body.path || '')
          const name = sanitizeFileName(String(body.name || ''))
          const content = String(body.content ?? '')
          await safeResolveReal(dir)
          const rel = dir ? `${dir}/${name}` : name
          if (await exists(rel)) return fail('Tệp đã tồn tại')
          await makeDir(dir)
          await writeTextFile(rel, content)
          // DB fail → rollback FS (tệp do mình vừa tạo — xoá an toàn)
          try {
            await db.fileNode.upsert({
              where: { ownerId_path: { ownerId: uid, path: rel } },
              update: {},
              create: { ownerId: uid, path: rel, name, parent: dir, isDir: false, size: Buffer.byteLength(content), mime: mimeOf(name) },
            })
          } catch (err) {
            await removeEntry(rel).catch(() => {})
            throw err
          }
          await emitEvent({
            type: 'file.uploaded',
            module: 'files',
            actor,
            payload: { name },
            logActivity: false,
          })
          return ok({ path: rel })
        }

        // Ghi nội dung tệp văn bản (TextViewer lưu) — safeResolveReal + verify fd
        case 'write': {
          const rel = String(body.path || '')
          const content = String(body.content ?? '')
          if (!rel || !(await exists(rel))) return fail('Tệp không tồn tại', 404)
          if (Buffer.byteLength(content, 'utf-8') > 2 * 1024 * 1024) return fail('Nội dung quá lớn (> 2MB)')
          await writeTextFile(rel, content)
          const size = Buffer.byteLength(content, 'utf-8')
          // Ghi đè nội dung xong mới bump metadata — nếu DB lỗi thì nội dung đã lưu,
          // version không tăng (lần lưu sau tự đồng bộ) — không có đường hư dữ liệu
          const node = await db.fileNode.upsert({
            where: { ownerId_path: { ownerId: uid, path: rel } },
            update: { size, version: { increment: 1 }, trashedAt: null },
            create: {
              ownerId: uid,
              path: rel,
              name: path.basename(rel),
              parent: path.dirname(rel) === '.' ? '' : path.dirname(rel).split(path.sep).join('/'),
              isDir: false,
              size,
              mime: mimeOf(rel),
            },
          })
          await emitEvent({
            type: 'file.updated',
            module: 'files',
            actor,
            payload: { name: path.basename(rel) },
            logActivity: false,
          })
          return ok({ ok: true, path: rel, size: node.size, version: node.version })
        }

        case 'view': {
          // Đánh dấu lần xem gần nhất (sắp xếp "Recently viewed")
          const p = String(body.path || '')
          const st = await statEntry(p)
          if (!st) return fail('Tệp không tồn tại')
          await db.fileNode.upsert({
            where: { ownerId_path: { ownerId: uid, path: p } },
            update: { viewedAt: new Date() },
            create: {
              ownerId: uid,
              path: p,
              name: path.basename(p),
              parent: path.dirname(p) === '.' ? '' : path.dirname(p),
              isDir: st.isDir,
              size: st.size,
              mime: mimeOf(p),
              viewedAt: new Date(),
            },
          })
          return ok({ ok: true })
        }

        case 'mkdir': {
          const dir = String(body.path || '')
          const name = sanitizeFileName(String(body.name || ''))
          await safeResolveReal(dir)
          const rel = dir ? `${dir}/${name}` : name
          if (await exists(rel)) return fail('Thư mục đã tồn tại')
          await makeDir(rel)
          try {
            await db.fileNode.upsert({
              where: { ownerId_path: { ownerId: uid, path: rel } },
              update: {},
              create: { ownerId: uid, path: rel, name, parent: dir, isDir: true },
            })
          } catch (err) {
            await removeEntry(rel).catch(() => {})
            throw err
          }
          return ok({ path: rel })
        }

        case 'rename': {
          const from = String(body.path || '')
          const name = sanitizeFileName(String(body.name || ''))
          const parent = path.dirname(from) === '.' ? '' : path.dirname(from).split(path.sep).join('/')
          const to = parent ? `${parent}/${name}` : name
          if (await exists(to)) return fail('Tên đã tồn tại')
          await moveEntry(from, to)
          // FS đã đổi tên xong → DB fail phải HOÀN TÁC FS (không để disk=B mà DB=A)
          try {
            await retargetTree(uid, from, to, name)
          } catch (err) {
            await moveEntry(to, from).catch((rbErr) => {
              console.error('[files] Rollback rename thất bại — cần kiểm tra thủ công:', from, '→', to, rbErr)
            })
            throw err
          }
          await emitEvent({ type: 'file.updated', module: 'files', actor, payload: { name }, logActivity: false })
          return ok({ path: to })
        }

        case 'copy': {
          const from = String(body.path || '')
          const to = String(body.to || '')
          if (!from || !to) return fail('Thiếu đường dẫn')
          if (isIntoItself(from, to)) return fail('Không thể sao chép vào chính nó hoặc thư mục con của nó')
          if (await exists(to)) return fail('Đích đã tồn tại')
          await copyEntry(from, to)
          // FS đã copy xong → DB fail phải xoá BẢN SAO (bản gốc không bao giờ bị động tới)
          try {
            const st = await statEntry(to)
            await db.fileNode.upsert({
              where: { ownerId_path: { ownerId: uid, path: to } },
              update: {},
              create: {
                ownerId: uid,
                path: to,
                name: path.basename(to),
                parent: path.dirname(to) === '.' ? '' : path.dirname(to).split(path.sep).join('/'),
                isDir: st?.isDir ?? false,
                size: st?.size ?? 0,
                mime: mimeOf(to),
              },
            })
            // copy thư mục → copy cả metadata (favorite/tags) của con, đổi tiền tố path
            const descendants = await db.fileNode.findMany({ where: subtreeWhere(uid, from), select: { path: true, name: true, parent: true, isDir: true, size: true, mime: true, favorite: true, tags: true } })
            if (descendants.length > 1) {
              await db.fileNode.createMany({
                data: descendants
                  .filter((d) => d.path !== from)
                  .map((d) => ({
                    ownerId: uid,
                    path: to + d.path.slice(from.length),
                    name: d.name,
                    parent: path.dirname(to + d.path.slice(from.length)) === '.' ? '' : path.dirname(to + d.path.slice(from.length)).split(path.sep).join('/'),
                    isDir: d.isDir,
                    size: d.size,
                    mime: d.mime,
                    favorite: d.favorite,
                    tags: d.tags,
                  })),
              })
            }
          } catch (err) {
            await removeEntry(to).catch(() => {})
            throw err
          }
          await emitEvent({ type: 'file.updated', module: 'files', actor, payload: { name: `copy ${path.basename(to)}` } })
          return ok({ path: to })
        }

        case 'move': {
          const from = String(body.path || '')
          const to = String(body.to || '')
          if (!from || !to) return fail('Thiếu đường dẫn')
          if (isIntoItself(from, to)) return fail('Không thể di chuyển vào chính nó hoặc thư mục con của nó')
          if (await exists(to)) return fail('Đích đã tồn tại')
          await moveEntry(from, to)
          // FS đã di chuyển xong → DB fail phải HOÀN TÁC FS (move ngược về chỗ cũ)
          try {
            await retargetTree(uid, from, to, path.basename(to))
          } catch (err) {
            await moveEntry(to, from).catch((rbErr) => {
              console.error('[files] Rollback move thất bại — cần kiểm tra thủ công:', from, '→', to, rbErr)
            })
            throw err
          }
          await emitEvent({ type: 'file.updated', module: 'files', actor, payload: { name: `move ${path.basename(to)}` } })
          return ok({ path: to })
        }

        case 'trash': {
          const paths = Array.isArray(body.paths) ? body.paths.map(String) : [String(body.path || '')]
          const now = new Date()
          for (const p of paths) {
            if (!p) continue
            await db.fileNode.updateMany({ where: subtreeWhere(uid, p), data: { trashedAt: now } })
          }
          await emitEvent({
            type: 'file.deleted',
            module: 'files',
            actor,
            payload: { name: path.basename(String(paths[0] || '')) },
          })
          return ok({ ok: true, count: paths.filter(Boolean).length })
        }

        case 'restore': {
          const paths = Array.isArray(body.paths) ? body.paths.map(String) : [String(body.path || '')]
          for (const p of paths) {
            if (!p) continue
            await db.fileNode.updateMany({ where: subtreeWhere(uid, p), data: { trashedAt: null } })
          }
          await emitEvent({
            type: 'file.restored',
            module: 'files',
            actor,
            payload: { name: path.basename(String(paths[0] || '')) },
          })
          return ok({ ok: true })
        }

        case 'delete': {
          const paths = Array.isArray(body.paths) ? body.paths.map(String) : [String(body.path || '')]
          for (const p of paths) {
            if (!p) continue
            await removeEntry(p)
            await db.fileNode.deleteMany({ where: subtreeWhere(uid, p) })
          }
          await emitEvent({
            type: 'file.deleted',
            module: 'files',
            actor,
            payload: { name: path.basename(String(paths[0] || '')) },
          })
          return ok({ ok: true })
        }

        case 'empty-trash': {
          const nodes = await db.fileNode.findMany({ where: { trashedAt: { not: null }, ownerId: uid } })
          for (const n of nodes) {
            await removeEntry(n.path).catch(() => {})
          }
          await db.fileNode.deleteMany({ where: { trashedAt: { not: null }, ownerId: uid } })
          return ok({ ok: true, count: nodes.length })
        }

        case 'favorite': {
          const p = String(body.path || '')
          const node = await db.fileNode.findUnique({ where: { ownerId_path: { ownerId: uid, path: p } } })
          if (!node) {
            const st = await statEntry(p)
            if (!st) return fail('Tệp không tồn tại')
            await db.fileNode.create({
              data: { ownerId: uid, path: p, name: path.basename(p), parent: path.dirname(p) === '.' ? '' : path.dirname(p), isDir: st.isDir, favorite: Boolean(body.favorite) },
            })
          } else {
            await db.fileNode.update({ where: { ownerId_path: { ownerId: uid, path: p } }, data: { favorite: Boolean(body.favorite) } })
          }
          return ok({ ok: true })
        }

        case 'tag': {
          const p = String(body.path || '')
          const tags = Array.isArray(body.tags) ? body.tags.map(String) : []
          const existing = await db.fileNode.findUnique({ where: { ownerId_path: { ownerId: uid, path: p } } })
          if (!existing) return fail('Tệp không tồn tại trong chỉ mục')
          await db.fileNode.update({ where: { ownerId_path: { ownerId: uid, path: p } }, data: { tags: JSON.stringify(tags) } })
          return ok({ ok: true })
        }

        case 'compress': {
          const sources = Array.isArray(body.paths) ? body.paths.map(String) : [String(body.path || '')]
          if (!sources[0]) return fail('Chưa chọn tệp để nén')
          const dir = path.dirname(sources[0]) === '.' ? '' : path.dirname(sources[0]).split(path.sep).join('/')
          const base = path.basename(sources[0]).replace(/\.zip$/, '')
          let dest = dir ? `${dir}/${base}.zip` : `${base}.zip`
          let i = 1
          while (await exists(dest)) {
            dest = dir ? `${dir}/${base} (${i}).zip` : `${base} (${i}).zip`
            i++
          }
          await zipEntries(sources, dest)
          const st = await statEntry(dest)
          if (!st) return fail('Nén thất bại — không tìm thấy tệp kết quả')
          try {
            await db.fileNode.upsert({
              where: { ownerId_path: { ownerId: uid, path: dest } },
              update: {},
              create: { ownerId: uid, path: dest, name: path.basename(dest), parent: dir, size: st.size, mime: 'application/zip' },
            })
          } catch (err) {
            await removeEntry(dest).catch(() => {})
            throw err
          }
          invalidateUsage()
          await emitEvent({
            type: 'file.updated',
            module: 'files',
            actor,
            payload: { name: path.basename(dest) },
            notify: { title: 'Nén tệp hoàn tất', content: path.basename(dest) },
          })
          return ok({ path: dest })
        }

        case 'extract': {
          const p = String(body.path || '')
          if (!p.endsWith('.zip')) return fail('Chỉ giải nén được tệp .zip')
          // Quota lấy từ Setting (không tin client) + usage FRESH (bỏ cache) + mutex
          // withStorageLock — 2 request extract/upload đồng thời không cùng thấy
          // "còn đủ chỗ" rồi cùng ghi vượt quota (race condition).
          const quotaGb = Number(await getSetting('core', 'quota_gb', '20')) || 20
          const quotaBytes = quotaGb * 1024 * 1024 * 1024
          const locked = await withStorageLock(async () => {
            const usage = await storageUsage({ fresh: true })
            const remaining = Math.max(0, quotaBytes - usage)
            if (remaining <= 0) return { quotaFail: true as const }
            // trần chống zip bomb áp bên trong unzipEntry: min(quota còn lại, trần cứng 2GB)
            return { result: await unzipEntry(p, p, { maxTotalBytes: remaining }) }
          })
          if ('quotaFail' in locked) {
            return fail(`Vượt hạn mức lưu trữ (${quotaGb} GB) — không còn chỗ để giải nén`, 413)
          }
          const { result } = locked
          // index DB TOÀN BỘ cây đệ quy (không chỉ tầng đầu như trước)
          try {
            for (const e of result.entries) {
              const parent = path.dirname(e.path) === '.' ? '' : path.dirname(e.path).split(path.sep).join('/')
              await db.fileNode.upsert({
                where: { ownerId_path: { ownerId: uid, path: e.path } },
                update: {},
                create: { ownerId: uid, path: e.path, name: e.name, parent, isDir: e.isDir, size: e.size, mime: mimeOf(e.name) },
              })
            }
          } catch (err) {
            // DB fail → rollback FS: cây vừa giải nén do mình tạo hoàn toàn (dedup
            // đảm bảo không trùng tệp cũ) nên xoá an toàn, không mất dữ liệu user
            await removeEntry(result.root).catch(() => {})
            invalidateUsage()
            throw err
          }
          invalidateUsage()
          await emitEvent({
            type: 'file.updated',
            module: 'files',
            actor,
            payload: { name: `extract ${path.basename(p)}` },
            notify: { title: 'Giải nén hoàn tất', content: `${result.entries.length} mục từ ${path.basename(p)} → ${result.root}` },
          })
          return ok({ extracted: result.entries.map((e) => e.name), root: result.root, count: result.entries.length })
        }

        case 'share': {
          const p = String(body.path || '')
          if (!p || !(await exists(p))) return fail('Tệp không tồn tại')
          const token = randomBytes(12).toString('hex')
          const expiresDays = Number(body.expiresDays || 0)
          const link = await db.shareLink.create({
            data: {
              token,
              ownerId: uid,
              path: p,
              label: String(body.label || path.basename(p)),
              expiresAt: expiresDays > 0 ? new Date(Date.now() + expiresDays * 86400000) : null,
            },
          })
          await emitEvent({
            type: 'file.shared',
            module: 'files',
            actor,
            payload: { name: path.basename(p) },
            targetId: token,
            targetType: 'share',
          })
          return ok({ link, url: `/api/modules/files/share/${token}` })
        }

        case 'unshare': {
          const token = String(body.path || '')
          await db.shareLink.deleteMany({ where: { token, ownerId: uid } })
          return ok({ ok: true })
        }

        case 'links': {
          const links = await db.shareLink.findMany({ where: { ownerId: uid }, orderBy: { createdAt: 'desc' }, take: 100 })
          return ok({ links })
        }

        default:
          return fail('Thao tác không hợp lệ')
      }
    })
  })
}
