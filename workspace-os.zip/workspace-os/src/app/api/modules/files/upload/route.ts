import { NextRequest } from 'next/server'
import { PassThrough } from 'stream'
import { db } from '@/lib/db'
import { requireModule, handle, ok, fail } from '@/core/server/api'
import { ApiError } from '@/core/server/api-error'
import { emitEvent } from '@/core/server/event-bus'
import { parseMultipartStream } from '@/core/server/multipart'
import {
  saveStream,
  uniqueRelPath,
  sanitizeFileName,
  mimeOf,
  makeDir,
  removeEntry,
  storageUsage,
  withStorageLock,
  invalidateUsage,
  MAX_FILE_BYTES,
} from '@/core/server/storage'
import { withUserStorage } from '@/core/server/user-scope'
import { getSetting } from '@/core/server/settings'
import path from 'path'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/**
 * POST /api/modules/files/upload?dir=Desktop — upload multipart (field 'files').
 * Desktop drag-drop + Files manager + Wallpaper + Wiki ảnh + Settings Icons đều dùng route này.
 *
 * STREAM toàn trình qua parseMultipartStream (RAM ≈ 64KB/chunk — chuẩn máy 2GB,
 * thay cho req.formData() buffer cả file vào RAM như bản cũ):
 *   browser ──multipart stream──► parser ──PassThrough──► saveStream() → đĩa
 *   (saveStream: safeResolveReal + verify fd — chống path traversal / symlink thoát root)
 *
 * Giới hạn: MAX_FILE_BYTES/tệp (env WOS_MAX_FILE_MB, mặc định 256MB) + quota
 * tổng (Setting core:quota_gb) — kiểm trong withStorageLock chống race như op extract.
 * Không bao giờ ghi đè tệp cũ: uniqueRelPath thêm " (n)" khi trùng tên.
 * Response: { files: [{name, path, size}], count } — tương thích mọi consumer.
 */

/** PassThrough có đếm byte — vượt trần thì destroy để dừng stream ngay lập tức */
class LimitPassThrough extends PassThrough {
  private count = 0
  onFatal?: (e: ApiError) => void
  constructor(
    private readonly fileLimit: number,
    private readonly roomLeft: number
  ) {
    super()
  }
  _transform(chunk: Buffer, enc: string, cb: (err?: Error | null, data?: unknown) => void) {
    this.count += Buffer.byteLength(chunk)
    if (this.count > this.fileLimit) {
      const e = new ApiError(`Tệp vượt quá ${Math.floor(this.fileLimit / 1048576)}MB`, 413)
      if (this.onFatal) this.onFatal(e)
      this.destroy(e)
      return
    }
    if (this.count > this.roomLeft) {
      const e = new ApiError('Vượt hạn mức lưu trữ — không còn chỗ để tải lên', 413)
      if (this.onFatal) this.onFatal(e)
      this.destroy(e)
      return
    }
    cb(null, chunk)
  }
}

interface SavedFile {
  name: string
  path: string
  size: number
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireModule('files', true)
    return withUserStorage(session.id, async () => {
      // lý do destroy đầu tiên (quá tải / vượt quota) — ưu tiên khi báo lỗi,
      // vì lỗi gốc có thể bị Node thay bằng 'write after destroy' trên đường truyền ra ngoài
      let fatal: ApiError | null = null
      const dir = req.nextUrl.searchParams.get('dir') || ''
      // dir hợp lệ: relative, không '..', không tuyệt đối (chống path traversal)
      if (dir.includes('..') || dir.startsWith('/') || dir.startsWith('\\')) {
        return fail('Thư mục đích không hợp lệ')
      }
      const ctype = req.headers.get('content-type') || ''
      if (!ctype.toLowerCase().includes('multipart/form-data')) {
        return fail('Yêu cầu phải là multipart/form-data')
      }
      await makeDir(dir).catch(() => {})

      const quotaGb = Number(await getSetting('core', 'quota_gb', '20')) || 20
      const quotaBytes = quotaGb * 1024 * 1024 * 1024

      const saved: SavedFile[] = []
      // tệp đã mở fd nhưng chưa xong (cleanup khi lỗi giữa chừng)
      const opened: { rel: string; done: Promise<{ size: number }> }[] = []

      try {
        // Mutex + usage FRESH — 2 request upload/extract đồng thời không cùng thấy
        // "còn đủ chỗ" rồi cùng ghi vượt quota (race condition) — giống op extract.
        await withStorageLock(async () => {
          const usage = await storageUsage({ fresh: true })
          let roomLeft = Math.max(0, quotaBytes - usage)

          await parseMultipartStream(req.body, ctype, {
            onFileStart: async (info) => {
              let clean: string
              try {
                clean = sanitizeFileName(info.filename || 'untitled')
              } catch {
                clean = 'untitled'
              }
              // tránh ghi đè tệp đang có: "a.txt" → "a (1).txt"
              const rel = await uniqueRelPath(dir, clean)
              const pt = new LimitPassThrough(MAX_FILE_BYTES, roomLeft)
              pt.onFatal = (e) => {
                fatal = fatal || e
              }
              const done = saveStream(rel, pt).catch((err: unknown) => {
                // destroy từ LimitPassThrough mang ApiError — giữ nguyên message/status
                throw err instanceof ApiError ? err : new ApiError('Ghi tệp xuống đĩa thất bại', 500)
              })
              opened.push({ rel, done })
              return pt
            },
            onFileEnd: async () => {
              const last = opened[opened.length - 1]
              if (!last) return
              const { size } = await last.done
              roomLeft -= size
              saved.push({ name: path.basename(last.rel), path: last.rel, size })
            },
          })
        })
      } catch (err) {
        // lỗi giữa chừng → xoá SỔ các tệp chưa hoàn tất (mình vừa tạo — an toàn)
        for (const f of opened) {
          if (!saved.some((s) => s.path === f.rel)) await removeEntry(f.rel).catch(() => {})
        }
        const e = fatal || (err instanceof ApiError ? err : null)
        if (e) return fail(e.message, e.status || 400)
        throw err
      }

      if (saved.length === 0) return fail('Không có tệp nào trong trường "files"')

      // FS đã ghi xong → index DB; DB fail → rollback FS (tệp do mình vừa tạo)
      for (const f of saved) {
        try {
          await db.fileNode.upsert({
            where: { ownerId_path: { ownerId: session.id, path: f.path } },
            update: { size: f.size, trashedAt: null },
            create: {
              ownerId: session.id,
              path: f.path,
              name: f.name,
              parent: dir,
              isDir: false,
              size: f.size,
              mime: mimeOf(f.name),
            },
          })
        } catch (err) {
          for (const g of saved) await removeEntry(g.path).catch(() => {})
          throw err
        }
      }

      invalidateUsage()
      await emitEvent({
        type: 'file.uploaded',
        module: 'files',
        actor: { id: session.id, displayName: session.displayName },
        payload: {
          name: saved.length === 1 ? saved[0].name : `${saved.length} tệp`,
          files: saved.map((s) => s.name),
        },
        logActivity: true,
      })
      return ok({ files: saved, count: saved.length })
    })
  })
}
