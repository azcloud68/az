import { NextRequest } from 'next/server'
import { requireModule, handle } from '@/core/server/api'
import { emitEvent } from '@/core/server/event-bus'
import { streamFileResponse } from '@/core/server/file-response'
import { withUserStorage } from '@/core/server/user-scope'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** GET /api/modules/files/download?path=Documents/CV.pdf[&inline=1] — STREAM file của TÀI KHOẢN
 *  (createReadStream → Response, hỗ trợ Range — không phình RAM với file GB). */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireModule('files')
    return withUserStorage(session.id, async () => {
      const rel = req.nextUrl.searchParams.get('path') || ''
      const inline = req.nextUrl.searchParams.get('inline') === '1'
      if (!rel) return streamFileResponse(req, rel) // → 404
      const res = await streamFileResponse(req, rel, { inline })
      if (res.status === 200 || res.status === 206) {
        await emitEvent({
          type: 'file.downloaded',
          module: 'files',
          actor: { id: session.id, displayName: session.displayName },
          payload: { name: rel.split('/').pop() || '' },
          logActivity: true,
        })
      }
      return res
    })
  })
}
