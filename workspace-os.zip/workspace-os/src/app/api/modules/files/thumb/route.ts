import { NextRequest, NextResponse } from 'next/server'
import { requireModule, handle } from '@/core/server/api'
import { safeResolve, mimeOf } from '@/core/server/storage'
import { createHash } from 'crypto'
import { promises as fsp } from 'fs'
import path from 'path'
import sharp from 'sharp'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const THUMB_DIR = '.wos_thumbs'
const IMAGE_MIMES = ['image/png', 'image/jpeg', 'image/webp', 'image/gif', 'image/bmp', 'image/avif']

/**
 * GET /api/modules/files/thumb?path=&w=320 — thumbnail ảnh (sharp, WebP) có cache trên đĩa.
 * Dùng trong grid Files + icon desktop: xem trước ảnh không tải bản gốc nặng.
 * Ảnh GIF vẫn trả gốc (giữ animation). SVG trả nguyên file.
 */
export async function GET(req: NextRequest) {
  return handle(async () => {
    await requireModule('files')
    const rel = req.nextUrl.searchParams.get('path') || ''
    const w = Math.min(720, Math.max(48, Number(req.nextUrl.searchParams.get('w') || 320)))
    const full = safeResolve(rel)
    const mime = mimeOf(full)

    if (!IMAGE_MIMES.includes(mime) && mime !== 'image/svg+xml') {
      return NextResponse.json({ error: 'Không phải tệp ảnh' }, { status: 400 })
    }
    // SVG / GIF: trả nội dung gốc (vector hoặc animation)
    if (mime === 'image/svg+xml' || mime === 'image/gif') {
      const buf = await fsp.readFile(full)
      return new NextResponse(new Uint8Array(buf), {
        headers: { 'content-type': mime, 'cache-control': 'private, max-age=86400' },
      })
    }

    // Cache theo (path + mtime + w)
    const st = await fsp.stat(full)
    const key = createHash('sha1').update(`${rel}:${st.mtimeMs}:${st.size}:${w}`).digest('hex')
    const thumbPath = path.join(path.dirname(full), THUMB_DIR, `${key}.webp`)
    try {
      await fsp.access(thumbPath)
    } catch {
      await fsp.mkdir(path.dirname(thumbPath), { recursive: true })
      await sharp(full).rotate().resize({ width: w, withoutEnlargement: true }).webp({ quality: 78 }).toFile(thumbPath)
    }
    const out = await fsp.readFile(thumbPath)
    return new NextResponse(new Uint8Array(out), {
      headers: { 'content-type': 'image/webp', 'cache-control': 'private, max-age=86400' },
    })
  })
}
