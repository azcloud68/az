import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { handle, fail } from '@/core/server/api'
import { streamFileResponse } from '@/core/server/file-response'
import { withUserStorage } from '@/core/server/user-scope'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** GET /api/modules/files/share/[token] — link công khai (STREAM + hỗ trợ Range).
 * File giải theo thư mục của chủ sở hữu link (ownerId); link legacy (owner null)
 * đọc ở root như cũ. Vẫn giữ đếm lượt tải. */
export async function GET(req: NextRequest, ctx: { params: Promise<{ token: string }> }) {
  return handle(async () => {
    const { token } = await ctx.params
    const link = await db.shareLink.findUnique({ where: { token } })
    if (!link) return fail('Liên kết không tồn tại', 404)
    if (link.expiresAt && link.expiresAt.getTime() < Date.now()) return fail('Liên kết đã hết hạn', 410)

    const res = link.ownerId
      ? await withUserStorage(link.ownerId, () => streamFileResponse(req, link.path))
      : await streamFileResponse(req, link.path)

    if (res.status === 200 || res.status === 206) {
      await db.shareLink.update({ where: { token }, data: { downloads: { increment: 1 } } }).catch(() => {})
    }
    return res
  })
}
