import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { can, authDenied, permDenied, getSessionUser } from '@/lib/auth'
import { logActivity } from '@/lib/server/event-bus'
import { makeShareToken, safeJoin, normRel } from '@/lib/server/storage'
import { promises as fs } from 'fs'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET() {
  if (!(await can('files', 'view'))) return authDenied()
  const links = await db.shareLink.findMany({ orderBy: { createdAt: 'desc' }, take: 100 })
  return NextResponse.json({ links })
}

export async function POST(req: NextRequest) {
  const user = await can('files', 'edit')
  if (!user) {
    const u = await getSessionUser()
    if (!u) return authDenied()
    return permDenied()
  }
  const { path: relPath, label, days } = await req.json() as { path?: string; label?: string; days?: number }
  const rel = normRel(relPath ?? '')
  try {
    await fs.stat(safeJoin(rel))
  } catch {
    return NextResponse.json({ error: 'Không tìm thấy file' }, { status: 404 })
  }
  const token = await makeShareToken()
  const link = await db.shareLink.create({
    data: {
      token, path: rel, label: label ?? rel.split('/').pop() ?? '',
      expiresAt: days && days > 0 ? new Date(Date.now() + days * 86400000) : null,
    },
  })
  await logActivity({ userId: user.id, userName: user.displayName, module: 'files', action: 'share', targetType: 'file', detail: `Tạo link chia sẻ cho ${rel}` })
  return NextResponse.json({ link })
}

export async function DELETE(req: NextRequest) {
  const user = await can('files', 'edit')
  if (!user) {
    const u = await getSessionUser()
    if (!u) return authDenied()
    return permDenied()
  }
  const id = req.nextUrl.searchParams.get('id') ?? ''
  await db.shareLink.deleteMany({ where: { id } })
  return NextResponse.json({ ok: true })
}
