import { NextRequest, NextResponse } from 'next/server'
import { requireModule, handle, ok, fail } from '@/core/server/api'
import { getSyncConfig, driveFetch } from '@/core/server/sync'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const DRIVE_API = 'https://www.googleapis.com/drive/v3'
const DL_TIMEOUT = 300000

/**
 * Ổ ĐĨA MẠNG — Google Drive trong app Files (dùng token OAuth của Settings → Sync):
 *   GET /api/modules/files/gdrive?status=1            → { connected, account } (probe nhẹ)
 *   GET /api/modules/files/gdrive?folder=<id|root>    → liệt kê thư mục (folder trước, tên A→Z)
 *   GET /api/modules/files/gdrive?download=<fileId>   → stream tệp (alt=media, attachment)
 * Chỉ admin (Drive token là cấu hình workspace trong Settings → Sync & Backup).
 */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireModule('files')
    if (session.role !== 'admin') return fail('Ổ đĩa mạng Google Drive chỉ dành cho quản trị viên', 403)

    const sp = req.nextUrl.searchParams

    // ---- probe trạng thái kết nối ----
    if (sp.get('status') === '1') {
      try {
        const cfg = await getSyncConfig()
        const connected = Boolean(cfg.clientId && cfg.clientSecret && cfg.refreshToken)
        return ok({ connected, account: (connected ? cfg.account : '') || '' })
      } catch {
        return ok({ connected: false, account: '' })
      }
    }

    // ---- stream tải tệp ----
    const downloadId = sp.get('download')
    if (downloadId) {
      if (!/^[A-Za-z0-9_-]{5,}$/.test(downloadId)) return fail('Drive file id không hợp lệ')
      const res = await driveFetch(`${DRIVE_API}/files/${downloadId}?alt=media`, {}, DL_TIMEOUT)
      if (!res.ok || !res.body) return fail(`Không tải được tệp từ Drive (${res.status})`, 502)
      const name = req.nextUrl.searchParams.get('name') || 'drive-file'
      return new NextResponse(res.body, {
        headers: {
          'content-type': res.headers.get('content-type') || 'application/octet-stream',
          'content-disposition': `attachment; filename*=UTF-8''${encodeURIComponent(name)}`,
        },
      })
    }

    // ---- liệt kê thư mục ----
    const folder = sp.get('folder') || 'root'
    if (!/^[A-Za-z0-9_-]{5,}$/.test(folder) && folder !== 'root') return fail('ID thư mục Drive không hợp lệ')
    const q = encodeURIComponent(
      folder === 'root' ? 'trashed = false' : `'${folder}' in parents and trashed = false`,
    )
    const fields = encodeURIComponent(
      'files(id,name,mimeType,size,modifiedTime)',
    )
    const res = await driveFetch(
      `${DRIVE_API}/files?q=${q}&fields=${fields}&pageSize=200&orderBy=folder,name`,
    )
    if (!res.ok) {
      const text = await res.text().catch(() => '')
      return fail(`Liệt kê Google Drive lỗi (${res.status}): ${text.slice(0, 180)}`, 502)
    }
    const data = (await res.json()) as {
      files?: { id: string; name: string; mimeType: string; size?: string; modifiedTime?: string }[]
    }
    const entries = (data.files || []).map((f) => ({
      id: f.id,
      name: f.name,
      isDir: f.mimeType === 'application/vnd.google-apps.folder',
      size: Number(f.size || 0),
      mtime: f.modifiedTime || '',
      mime: f.mimeType,
    }))
    return ok({ folder, entries })
  })
}
