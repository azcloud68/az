import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireModule, handle, ok, fail, readJson } from '@/core/server/api'
import { emitEvent } from '@/core/server/event-bus'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** POST — bình luận vào task (task phải thuộc tài khoản hiện tại) */
export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireModule('tasks', true)
    const { id } = await ctx.params
    const body = await readJson<{ content?: string }>(req)
    const content = (body.content || '').trim()
    if (!content) return fail('Nhập nội dung bình luận')
    const task = await db.task.findUnique({ where: { id } })
    if (!task || task.ownerId !== session.id) return fail('Công việc không tồn tại', 404)
    const comment = await db.taskComment.create({
      data: { taskId: id, authorName: session.displayName, content },
    })
    await db.taskHistory.create({
      data: { taskId: id, userName: session.displayName, action: 'comment', detail: `Bình luận: "${content.slice(0, 40)}"` },
    })
    await emitEvent({
      type: 'task.updated',
      module: 'tasks',
      actor: { id: session.id, displayName: session.displayName },
      payload: { title: task.title },
      logActivity: false,
    })
    return ok({ comment })
  })
}

/** DELETE ?commentId= — xoá bình luận (chỉ comment của task thuộc tài khoản) */
export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireModule('tasks', true)
    const { id } = await ctx.params
    const commentId = req.nextUrl.searchParams.get('commentId')
    if (!commentId) return fail('Thiếu commentId')
    const comment = await db.taskComment.findUnique({ where: { id: commentId }, include: { task: true } })
    if (!comment || comment.task.ownerId !== session.id) return fail('Bình luận không tồn tại', 404)
    await db.taskComment.delete({ where: { id: commentId } })
    void id
    return ok({ ok: true })
  })
}
