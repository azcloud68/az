import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireModule, handle, ok, fail, readJson, ApiError, parseDateOrNull } from '@/core/server/api'
import { emitEvent } from '@/core/server/event-bus'
import { getUserTimezone, addDaysInTz, addMonthsInTz } from '@/core/server/datetime'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const STATUSES = ['todo', 'doing', 'done', 'archived']
const PRIORITIES = ['low', 'medium', 'high', 'urgent']
const REPEATS = ['none', 'daily', 'weekly', 'monthly']

/** Validate projectId phải là project CỦA CHÍNH tài khoản (v2.3 — trước đây user A
 *  gán task của mình vào projectId của user B được, sai integrity dữ liệu) */
async function assertOwnedProject(projectId: string, ownerId: string): Promise<void> {
  const project = await db.project.findFirst({
    where: { id: projectId, ownerId },
    select: { id: true },
  })
  if (!project) throw new ApiError('Dự án không tồn tại (hoặc không phải của bạn)', 404)
}

/** GET /api/modules/tasks/[id] — chi tiết 1 task (chủ sở hữu mới thấy) */
export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireModule('tasks')
    const { id } = await ctx.params
    const task = await db.task.findUnique({
      where: { id },
      include: {
        subtasks: { orderBy: { position: 'asc' } },
        comments: { orderBy: { createdAt: 'asc' } },
        histories: { orderBy: { createdAt: 'desc' } },
      },
    })
    if (!task || task.ownerId !== session.id) throw new ApiError('Công việc không tồn tại', 404)
    return ok({ task })
  })
}

/** PATCH — cập nhật task / hoàn thành / chuyển kanban */
export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireModule('tasks', true)
    const { id } = await ctx.params
    const body = await readJson<Record<string, unknown>>(req)
    const task = await db.task.findUnique({ where: { id } })
    if (!task || task.ownerId !== session.id) return fail('Công việc không tồn tại', 404)

    const data: Record<string, unknown> = {}
    const changes: string[] = []
    if (body.title !== undefined && String(body.title).trim()) {
      data.title = String(body.title).trim()
      changes.push('đổi tiêu đề')
    }
    if (body.description !== undefined) {
      data.description = String(body.description)
      changes.push('mô tả')
    }
    if (body.priority !== undefined && PRIORITIES.includes(String(body.priority))) {
      data.priority = String(body.priority)
      changes.push(`ưu tiên ${body.priority}`)
    }
    if (body.labels !== undefined && Array.isArray(body.labels)) {
      data.labels = JSON.stringify(body.labels)
    }
    if (body.dueAt !== undefined) data.dueAt = parseDateOrNull(body.dueAt, 'Hạn chót')
    if (body.reminderAt !== undefined) data.reminderAt = parseDateOrNull(body.reminderAt, 'Nhắc việc')
    if (body.repeat !== undefined && REPEATS.includes(String(body.repeat))) data.repeat = String(body.repeat)
    if (body.projectId !== undefined) {
      if (body.projectId) {
        const pid = String(body.projectId)
        await assertOwnedProject(pid, session.id)
        data.projectId = pid
      } else {
        data.projectId = null
      }
    }
    if (body.position !== undefined) data.position = Number(body.position) || 0

    let eventType = 'task.updated'
    if (body.status !== undefined && STATUSES.includes(String(body.status))) {
      const next = String(body.status)
      data.status = next
      if (next === 'done' && task.status !== 'done') {
        data.completedAt = new Date()
        eventType = 'task.completed'
        changes.push('hoàn thành')
        // Repeat: sinh task kế tiếp (DST-safe — cộng theo LỊCH tz cấu hình,
        // giữ nguyên giờ treo tường; 31/01 + 1 tháng = 28/02)
        if (task.repeat !== 'none' && task.dueAt) {
          const tz = await getUserTimezone()
          let nextDue = new Date(task.dueAt)
          if (task.repeat === 'daily') nextDue = addDaysInTz(nextDue, 1, tz)
          if (task.repeat === 'weekly') nextDue = addDaysInTz(nextDue, 7, tz)
          if (task.repeat === 'monthly') nextDue = addMonthsInTz(nextDue, 1, tz)
          await db.task.create({
            data: {
              ownerId: task.ownerId,
              title: task.title,
              description: task.description,
              priority: task.priority,
              labels: task.labels,
              dueAt: nextDue,
              repeat: task.repeat,
              projectId: task.projectId,
              position: task.position,
            },
          })
        }
      } else if (task.status === 'done' && next !== 'done') {
        data.completedAt = null
      } else {
        changes.push(`chuyển sang ${next}`)
      }
    }

    await db.task.update({ where: { id }, data })
    if (changes.length || eventType !== 'task.updated') {
      await db.taskHistory.create({
        data: { taskId: id, userName: session.displayName, action: eventType.split('.')[1], detail: changes.join(', ') || 'cập nhật' },
      })
    }
    await emitEvent({
      type: eventType,
      module: 'tasks',
      actor: { id: session.id, displayName: session.displayName },
      payload: { title: (data.title as string) || task.title },
      targetId: id,
      targetType: 'task',
      notify: eventType === 'task.completed' ? { title: 'Hoàn thành công việc', content: (data.title as string) || task.title, type: 'info', action: 'tasks' } : undefined,
    })
    return ok({ ok: true })
  })
}

/** DELETE — xoá task (kèm subtasks, comments do Cascade) */
export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireModule('tasks', true)
    const { id } = await ctx.params
    const task = await db.task.findUnique({ where: { id } })
    if (!task || task.ownerId !== session.id) return fail('Công việc không tồn tại', 404)
    await db.task.delete({ where: { id } })
    await emitEvent({
      type: 'task.deleted',
      module: 'tasks',
      actor: { id: session.id, displayName: session.displayName },
      payload: { title: task.title },
    })
    return ok({ ok: true })
  })
}
