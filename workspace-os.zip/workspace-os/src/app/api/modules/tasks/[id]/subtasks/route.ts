import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireModule, handle, ok, fail, readJson } from '@/core/server/api'
import { emitEvent } from '@/core/server/event-bus'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** POST — thêm subtask (task cha phải thuộc tài khoản hiện tại) */
export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireModule('tasks', true)
    const { id } = await ctx.params
    const body = await readJson<{ title?: string }>(req)
    const title = (body.title || '').trim()
    if (!title) return fail('Nhập tiêu đề công việc con')
    const task = await db.task.findUnique({ where: { id } })
    if (!task || task.ownerId !== session.id) return fail('Công việc không tồn tại', 404)
    const maxPos = await db.subtask.aggregate({ where: { taskId: id }, _max: { position: true } })
    const subtask = await db.subtask.create({
      data: { taskId: id, title, position: (maxPos._max.position || 0) + 1 },
    })
    await db.taskHistory.create({
      data: { taskId: id, userName: session.displayName, action: 'subtask', detail: `Thêm "${title}"` },
    })
    await emitEvent({
      type: 'task.updated',
      module: 'tasks',
      actor: { id: session.id, displayName: session.displayName },
      payload: { title: task.title },
      targetId: id,
      logActivity: false,
    })
    return ok({ subtask })
  })
}

/** PATCH — đánh dấu subtask xong / đổi tên */
export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireModule('tasks', true)
    const { id } = await ctx.params
    const body = await readJson<{ subtaskId?: string; done?: boolean; title?: string }>(req)
    if (!body.subtaskId) return fail('Thiếu subtaskId')
    const sub = await db.subtask.findUnique({ where: { id: body.subtaskId }, include: { task: true } })
    if (!sub || sub.task.ownerId !== session.id) return fail('Công việc con không tồn tại', 404)
    const data: Record<string, unknown> = {}
    if (body.done !== undefined) data.done = body.done
    if (body.title?.trim()) data.title = body.title.trim()
    await db.subtask.update({ where: { id: body.subtaskId }, data })
    void id
    return ok({ ok: true })
  })
}

/** DELETE ?subtaskId= — xoá subtask (chỉ subtask của task thuộc tài khoản) */
export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireModule('tasks', true)
    const { id } = await ctx.params
    const subtaskId = req.nextUrl.searchParams.get('subtaskId')
    if (!subtaskId) return fail('Thiếu subtaskId')
    const sub = await db.subtask.findUnique({ where: { id: subtaskId }, include: { task: true } })
    if (!sub || sub.task.ownerId !== session.id) return fail('Công việc con không tồn tại', 404)
    await db.subtask.delete({ where: { id: subtaskId } })
    void id
    return ok({ ok: true })
  })
}
