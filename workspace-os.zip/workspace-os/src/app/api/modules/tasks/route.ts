import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireModule, handle, ok, fail, readJson, parseDateOrNull } from '@/core/server/api'
import { emitEvent } from '@/core/server/event-bus'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const PRIORITIES = ['low', 'medium', 'high', 'urgent']
const REPEATS = ['none', 'daily', 'weekly', 'monthly']

/** GET /api/modules/tasks?status=&projectId=&q= — chỉ task của tài khoản hiện tại */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireModule('tasks')
    const sp = req.nextUrl.searchParams
    const status = sp.get('status') || 'all'
    const projectId = sp.get('projectId')
    const q = sp.get('q')
    const tasks = await db.task.findMany({
      where: {
        ownerId: session.id,
        ...(status !== 'all' ? { status } : {}),
        ...(projectId ? { projectId } : {}),
        ...(q ? { OR: [{ title: { contains: q } }, { description: { contains: q } }] } : {}),
      },
      orderBy: [{ position: 'asc' }, { createdAt: 'desc' }],
      include: {
        subtasks: { orderBy: { position: 'asc' } },
        comments: { orderBy: { createdAt: 'asc' } },
        histories: { orderBy: { createdAt: 'desc' }, take: 20 },
      },
    })
    return ok({ tasks })
  })
}

/** POST — tạo công việc */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireModule('tasks', true)
    const body = await readJson<Record<string, unknown>>(req)
    const title = String(body.title || '').trim()
    if (!title) return fail('Nhập tiêu đề công việc')
    // projectId phải là project CỦA CHÍNH tài khoản (chống gán task sang project người khác)
    let projectId: string | null = null
    if (body.projectId) {
      projectId = String(body.projectId)
      const project = await db.project.findFirst({ where: { id: projectId, ownerId: session.id }, select: { id: true } })
      if (!project) return fail('Dự án không tồn tại (hoặc không phải của bạn)', 404)
    }
    const maxPos = await db.task.aggregate({ where: { ownerId: session.id }, _max: { position: true } })
    const task = await db.task.create({
      data: {
        ownerId: session.id,
        title,
        description: String(body.description || ''),
        priority: PRIORITIES.includes(String(body.priority)) ? String(body.priority) : 'medium',
        labels: JSON.stringify(Array.isArray(body.labels) ? body.labels : []),
        dueAt: parseDateOrNull(body.dueAt, 'Hạn chót'),
        reminderAt: parseDateOrNull(body.reminderAt, 'Nhắc việc'),
        repeat: REPEATS.includes(String(body.repeat)) ? String(body.repeat) : 'none',
        projectId,
        position: (maxPos._max.position || 0) + 1,
      },
    })
    await db.taskHistory.create({
      data: { taskId: task.id, userName: session.displayName, action: 'created', detail: 'Tạo công việc' },
    })
    await emitEvent({
      type: 'task.created',
      module: 'tasks',
      actor: { id: session.id, displayName: session.displayName },
      payload: { title },
      targetId: task.id,
      targetType: 'task',
    })
    return ok({ task })
  })
}
