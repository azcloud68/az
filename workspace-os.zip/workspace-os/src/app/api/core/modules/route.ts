import { NextRequest } from 'next/server'
import { getAllModules, setModuleEnabled, setModuleConfig, MODULE_MANIFESTS } from '@/core/server/module-registry'
import { emitEvent } from '@/core/server/event-bus'
import { handle, ok, fail, readJson, requireAdmin, requireSession } from '@/core/server/api'
import { getUserPermissions, permsAllowModule } from '@/core/server/user-permissions'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** GET /api/core/modules — runtime mọi module (enabled, config, permissions).
 *  Non-admin: lọc theo quyền riêng tài khoản (whitelist module + khoá file manager) —
 *  sidebar/dock/desktop icon/launchpad tự ẩn app không được phép. */
export async function GET() {
  return handle(async () => {
    const session = await requireSession()
    const modules = await getAllModules()
    const isAdmin = session.role === 'admin'
    const perms = isAdmin ? null : await getUserPermissions(session.id)
    return ok({
      modules: modules
        .filter((m) => isAdmin || permsAllowModule(perms, m.manifest.id))
        .map((m) => ({
          ...m.manifest,
          enabled: m.enabled,
          config: isAdmin ? m.config : {},
          canManage: isAdmin,
        })),
    })
  })
}

/** PATCH /api/core/modules — bật/tắt module hoặc lưu config */
export async function PATCH(req: NextRequest) {
  return handle(async () => {
    const session = await requireAdmin()
    const body = await readJson<{
      moduleId?: string
      enabled?: boolean
      config?: Record<string, unknown>
    }>(req)
    const moduleId = body.moduleId || ''
    const manifest = MODULE_MANIFESTS.find((m) => m.id === moduleId)
    if (!manifest) return fail('Module không tồn tại')

    if (typeof body.enabled === 'boolean') {
      if (manifest.core && body.enabled === false) {
        return fail(`Module lõi "${manifest.name}" không thể tắt`)
      }
      await setModuleEnabled(moduleId, body.enabled)
      await emitEvent({
        type: body.enabled ? 'module.enabled' : 'module.disabled',
        module: 'core',
        actor: { id: session.id, displayName: session.displayName },
        payload: { name: manifest.name },
        notify: {
          title: `${body.enabled ? 'Bật' : 'Tắt'} module ${manifest.name}`,
          type: 'system',
        },
      })
    }
    if (body.config && typeof body.config === 'object') {
      await setModuleConfig(moduleId, body.config)
      await emitEvent({
        type: 'settings.updated',
        module: 'core',
        actor: { id: session.id, displayName: session.displayName },
        payload: { name: `config ${manifest.name}` },
        logActivity: false,
      })
    }
    return ok({ ok: true })
  })
}
