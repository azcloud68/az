import { sysStats } from '@/core/server/sysinfo'
import { storageUsage } from '@/core/server/storage'
import { withUserStorage } from '@/core/server/user-scope'
import { handle, ok, requireSession } from '@/core/server/api'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** GET /api/core/stats — CPU/RAM/Disk hệ thống + dung lượng storage CỦA TÀI KHOẢN cho widget + Reports */
export async function GET() {
  return handle(async () => {
    const session = await requireSession()
    const [stats, storageBytes] = await Promise.all([
      sysStats(),
      withUserStorage(session.id, () => storageUsage()),
    ])
    return ok({ ...stats, storageBytes })
  })
}
