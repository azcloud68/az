import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireSession, handle, ok, fail, readJson } from '@/core/server/api'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/**
 * /api/core/layout — layout THEO TÀI KHOẢN (widget, vị trí icon desktop).
 * GET  ?scope=desktop  → { scope, value }   (value = JSON object)
 * PUT  { scope, value } → upsert (last-write-wins giữa các thiết bị)
 */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    const scope = req.nextUrl.searchParams.get('scope') === 'mobile' ? 'mobile' : 'desktop'
    const row = await db.userLayout.findUnique({
      where: { userId_scope_key: { userId: session.id, scope, key: '' } },
    })
    let value: unknown = {}
    try {
      value = row ? JSON.parse(row.value) : {}
    } catch {
      value = {}
    }
    return ok({ scope, value, updatedAt: row?.updatedAt || null })
  })
}

export async function PUT(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    const body = await readJson<{ scope?: string; value?: unknown }>(req)
    const scope = body.scope === 'mobile' ? 'mobile' : 'desktop'
    if (body.value === undefined) return fail('Thiếu value')
    if (typeof body.value === 'object' && body.value !== null) {
      const size = JSON.stringify(body.value).length
      if (size > 512 * 1024) return fail('Layout quá lớn (> 512KB)')
    }
    const value = JSON.stringify(body.value ?? {})
    await db.userLayout.upsert({
      where: { userId_scope_key: { userId: session.id, scope, key: '' } },
      update: { value },
      create: { userId: session.id, scope, key: '', value },
    })
    return ok({ ok: true, scope })
  })
}
