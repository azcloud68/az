import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { handle, ok, fail, readJson, requireAdmin, requireSession } from '@/core/server/api'
import { emitEvent } from '@/core/server/event-bus'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** GET /api/core/timeline — dòng thời gian của TÀI KHOẢN từ Event Bus (actorId = user) */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    const sp = req.nextUrl.searchParams
    const limit = Math.min(Number(sp.get('limit') || 100), 500)
    const moduleFilter = sp.get('module')
    const events = await db.eventRecord.findMany({
      where: {
        actorId: session.id,
        ...(moduleFilter && moduleFilter !== 'all' ? { module: moduleFilter } : {}),
      },
      orderBy: { createdAt: 'desc' },
      take: limit,
    })
    return ok({
      events: events.map((e) => {
        let payload: Record<string, unknown> = {}
        try {
          payload = JSON.parse(e.payload)
        } catch {
          payload = {}
        }
        return { ...e, payload }
      }),
    })
  })
}

/**
 * DELETE /api/core/timeline — dọn dẹp dữ liệu sự kiện:
 * {olderThan: 30} xoá sự kiện cũ hơn N ngày | {all: true} xoá toàn bộ (admin)
 */
export async function DELETE(req: NextRequest) {
  return handle(async () => {
    const session = await requireAdmin()
    const body = await readJson<{ olderThan?: number; all?: boolean }>(req)
    let deleted = 0
    if (body.all) {
      deleted = (await db.eventRecord.deleteMany({})).count
    } else if (body.olderThan && body.olderThan > 0) {
      const cutoff = new Date(Date.now() - body.olderThan * 86400000)
      deleted = (await db.eventRecord.deleteMany({ where: { createdAt: { lt: cutoff } } })).count
    } else {
      return fail('Chọn số ngày giữ lại hoặc xoá toàn bộ')
    }
    await emitEvent({
      type: 'settings.updated',
      module: 'core',
      actor: { id: session.id, displayName: session.displayName },
      payload: { title: `dọn ${deleted} sự kiện Timeline` },
      logActivity: false,
    })
    return ok({ deleted })
  })
}
