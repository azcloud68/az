import { NextRequest, NextResponse } from 'next/server'
import { requireSession, handle } from '@/core/server/api'
import { resolvePluginAssetReal } from '@/core/server/plugin-packs'
import { mimeOf } from '@/core/server/storage'
import { promises as fsp } from 'fs'
import path from 'path'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const IMG_EXT = new Set(['.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg', '.bmp', '.avif', '.ico'])
const MEDIA_EXT = new Set(['.mp3', '.wav', '.ogg', '.mp4', '.webm'])
const ALLOWED_EXT = new Set([...IMG_EXT, ...MEDIA_EXT, '.css', '.json', '.txt', '.md', '.woff', '.woff2'])

/**
 * GET /api/core/plugins/asset?slug=&file= — phục vụ file tài nguyên của plugin
 * (ảnh/css/… trong thư mục plugins/<slug>/). Plugin lấy URL qua WOS.assetUrl('x.png').
 * v2.3 — 3 LỚP kiểm tra:
 *   1. Lexical: chống path traversal tuyệt đối (../, dẫn tuyệt đối, NUL, '\\')
 *   2. REALPATH (chống symlink): resolvePluginAssetReal() hoá giải mọi symlink —
 *      đích thoát khỏi plugins/<slug>/ thật (vd link → /etc/passwd) → từ chối
 *   3. Phần mở rộng an toàn + kích thước ≤ 20MB
 */
export async function GET(req: NextRequest) {
  return handle(async () => {
    await requireSession()
    const slug = req.nextUrl.searchParams.get('slug') || ''
    const file = req.nextUrl.searchParams.get('file') || ''
    const full = await resolvePluginAssetReal(slug, file)
    if (!full) return NextResponse.json({ error: 'Đường dẫn không hợp lệ' }, { status: 400 })
    const ext = path.extname(full).toLowerCase()
    if (!ALLOWED_EXT.has(ext)) {
      return NextResponse.json({ error: `Loại file .${ext.replace('.', '')} không được phục vụ` }, { status: 400 })
    }
    let st
    try {
      st = await fsp.stat(full)
    } catch {
      return NextResponse.json({ error: 'Không tìm thấy tài nguyên' }, { status: 404 })
    }
    if (!st.isFile() || st.size > 20 * 1024 * 1024) {
      return NextResponse.json({ error: 'File quá lớn hoặc không hợp lệ' }, { status: 400 })
    }
    const buf = await fsp.readFile(full)
    return new NextResponse(new Uint8Array(buf), {
      headers: {
        'content-type': mimeOf(full) || 'application/octet-stream',
        'cache-control': 'private, max-age=3600',
        'content-length': String(st.size),
      },
    })
  })
}
