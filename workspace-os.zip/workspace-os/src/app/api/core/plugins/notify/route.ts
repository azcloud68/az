import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireSession, handle, ok, fail, readJson } from '@/core/server/api'
import { emitEvent } from '@/core/server/event-bus'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/**
 * POST /api/core/plugins/notify — plugin GỬI THÔNG BÁO (Notification Center).
 * Sửa lỗi "tính năng gửi thông báo không hoạt động": mọi plugin (đang bật) gọi được,
 * thông báo gắn module = slug plugin để lọc.
 */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    const body = await readJson<{ slug?: string; title?: string; content?: string; type?: string; action?: string }>(req)
    const slug = String(body.slug || '')
    const plugin = await db.plugin.findUnique({ where: { slug } })
    if (!plugin || !plugin.enabled) return fail(`Plugin "${slug}" không tồn tại hoặc đang tắt`, 404)
    const title = String(body.title || '').trim()
    if (!title) return fail('Thiếu tiêu đề thông báo')
    const type = ['info', 'reminder', 'alert', 'system'].includes(String(body.type)) ? String(body.type) : 'info'
    const notif = await db.notification.create({
      data: {
        userId: session.id, // per-account: người gọi mới thấy thông báo này
        title: title.slice(0, 180),
        content: String(body.content || '').slice(0, 1000),
        module: slug,
        type,
        action: String(body.action || ''),
      },
    })
    await emitEvent({
      type: 'plugin.notified',
      module: slug,
      actor: { id: session.id, displayName: session.displayName },
      payload: { title, name: plugin.name },
      logActivity: true,
    })
    return ok({ notification: notif })
  })
}
