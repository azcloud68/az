import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireSession, requireAdmin, handle, ok, fail, readJson } from '@/core/server/api'
import { ensureBuiltinPlugins } from '@/core/server/builtin-plugins'
import { scanPluginsDir, pluginsDir, parseManifest, upsertPluginFromPack, pluginPackDir } from '@/core/server/plugin-packs'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** Shape plugin client cần (không kèm entry khi không cần mã) */
function toMeta(p: {
  id: string; slug: string; name: string; description: string; version: string; author: string
  icon: string; color: string; kind: string; config: string; enabled: boolean; builtin: boolean
  desktopIcon: boolean; showDock: boolean; windowW: number; windowH: number; order: number
  styles?: string
}) {
  let config: Record<string, unknown> = {}
  try {
    config = JSON.parse(p.config || '{}')
  } catch {
    config = {}
  }
  return {
    id: p.id,
    slug: p.slug,
    name: p.name,
    description: p.description,
    version: p.version,
    author: p.author,
    icon: p.icon,
    color: p.color,
    kind: p.kind === 'pet' ? 'pet' : 'app',
    config,
    enabled: p.enabled,
    builtin: p.builtin,
    desktopIcon: p.desktopIcon,
    showDock: p.showDock,
    windowSize: { w: p.windowW, h: p.windowH },
    order: p.order,
  }
}

/**
 * GET /api/core/plugins — danh sách plugin (kèm entry để client chạy runtime).
 * Lần đầu gọi: tự cài 2 plugin dựng sẵn (calculator + anime pet) nếu chưa có.
 * Tự QUÉT thư mục plugins/ (upload code trực tiếp) — ?rescan=1 bỏ cache.
 * Trả kèm dir = đường dẫn thư mục plugin để admin biết chỗ upload code.
 */
export async function GET(req: NextRequest) {
  return handle(async () => {
    await requireSession()
    await ensureBuiltinPlugins()
    const force = req.nextUrl.searchParams.get('rescan') === '1'
    await scanPluginsDir(force).catch(() => 0)
    const list = await db.plugin.findMany({ orderBy: [{ order: 'asc' }, { createdAt: 'asc' }] })
    return ok({
      plugins: list.map((p) => ({ ...toMeta(p), entry: p.entry, styles: p.styles || '' })),
      pluginsDir: pluginsDir(),
    })
  })
}

/** POST /api/core/plugins — cài plugin mới (admin). Body = manifest + entry (JSON)
 *  hoặc { manifest: <object> } — dùng chung validator với pack .zip */
export async function POST(req: NextRequest) {
  return handle(async () => {
    await requireAdmin()
    const body = await readJson<Record<string, unknown>>(req)
    const manifestRaw = (body.manifest && typeof body.manifest === 'object' ? body.manifest : body) as Record<string, unknown>
    let def
    try {
      def = parseManifest(manifestRaw)
    } catch (err) {
      return fail(err instanceof Error ? err.message : 'Manifest không hợp lệ')
    }
    // entry: với kiểu JSON phải là mã JS inline (chuỗi nhiều dòng)
    const entry = String((manifestRaw as Record<string, unknown>).entry || '')
    if (!entry.trim()) return fail('Thiếu mã nguồn entry (JS)')
    if (entry.length > 200 * 1024) return fail('Mã nguồn quá lớn (> 200KB)')
    def.entry = entry
    def.styles = String((manifestRaw as Record<string, unknown>).styles || '')

    await upsertPluginFromPack(def, { source: 'json' })
    const plugin = await db.plugin.findUnique({ where: { slug: def.slug } })
    return ok({ plugin: toMeta(plugin!) })
  })
}

/** PATCH /api/core/plugins — cập nhật hàng loạt {slug, enabled?, desktopIcon?, showDock?, config?} */
export async function PATCH(req: NextRequest) {
  return handle(async () => {
    await requireAdmin()
    const body = await readJson<Record<string, unknown>>(req)
    const slug = String(body.slug || '')
    const plugin = await db.plugin.findUnique({ where: { slug } })
    if (!plugin) return fail('Plugin không tồn tại', 404)
    const data: Record<string, unknown> = {}
    if (body.enabled !== undefined) data.enabled = Boolean(body.enabled)
    if (body.desktopIcon !== undefined) data.desktopIcon = Boolean(body.desktopIcon)
    if (body.showDock !== undefined) data.showDock = Boolean(body.showDock)
    if (body.config !== undefined && typeof body.config === 'object') data.config = JSON.stringify(body.config)
    if (body.name !== undefined && String(body.name).trim()) data.name = String(body.name).trim()
    const updated = await db.plugin.update({ where: { slug }, data })
    return ok({ plugin: toMeta(updated) })
  })
}

/** DELETE /api/core/plugins?slug= — gỡ cài đặt (admin; không cho gỡ builtin).
 *  Plugin cài từ .zip/thư mục → xoá luôn pack trong plugins/<slug>/ */
export async function DELETE(req: NextRequest) {
  return handle(async () => {
    await requireAdmin()
    const slug = req.nextUrl.searchParams.get('slug') || ''
    const plugin = await db.plugin.findUnique({ where: { slug } })
    if (!plugin) return fail('Plugin không tồn tại', 404)
    if (plugin.builtin) return fail('Plugin dựng sẵn của hệ thống — chỉ tắt được, không gỡ')
    await db.plugin.delete({ where: { slug } })
    // dọn pack trên đĩa (nếu có — plugin .zip / thư mục)
    try {
      const packDir = pluginPackDir(slug)
      if (packDir) {
        await (await import('fs')).promises.rm(packDir, { recursive: true, force: true })
      }
    } catch {
      /* không có pack trên đĩa — bỏ qua */
    }
    return ok({ ok: true })
  })
}
