import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireSession, handle, ok, fail, readJson } from '@/core/server/api'
import { emitEvent } from '@/core/server/event-bus'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/**
 * POST /api/core/plugins/event — plugin PHÁT EVENT (server Event Bus).
 * Sửa lỗi "phát event không hoạt động": event ghi vào EventRecord (Timeline đọc được)
 * + ActivityLog. Event type tự do dạng "plugin.<slug>.<name>" hoặc "<slug>.<name>".
 */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    const body = await readJson<{ slug?: string; type?: string; payload?: Record<string, unknown> }>(req)
    const slug = String(body.slug || '')
    const plugin = await db.plugin.findUnique({ where: { slug } })
    if (!plugin || !plugin.enabled) return fail(`Plugin "${slug}" không tồn tại hoặc đang tắt`, 404)
    const raw = String(body.type || '').trim()
    if (!raw) return fail('Thiếu event type')
    // chuẩn hoá type: luôn tiền tố "plugin." để phân biệt với event hệ thống
    const type = raw.startsWith('plugin.') ? raw : `plugin.${slug}.${raw}`
    await emitEvent({
      type,
      module: slug,
      actor: { id: session.id, displayName: session.displayName },
      payload: (body.payload && typeof body.payload === 'object' ? body.payload : {}) as Record<string, unknown>,
      logActivity: true,
    })
    return ok({ ok: true, type })
  })
}
