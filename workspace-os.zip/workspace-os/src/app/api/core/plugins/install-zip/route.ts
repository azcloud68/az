import { NextRequest } from 'next/server'
import { requireAdmin, handle, ok, fail } from '@/core/server/api'
import { saveTempZip, installPluginZip } from '@/core/server/plugin-packs'
import { Readable } from 'stream'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/**
 * POST /api/core/plugins/install-zip — cài plugin từ file .zip (admin).
 * Multipart form: field 'file' = *.zip (cấu trúc plugin.json + main.js + assets…).
 * Giải nén → validate manifest/entry (chống zip-slip) → lưu vào
 * plugins/<slug>/ (thư mục riêng) → đăng ký DB → client refresh là hiện ra.
 */
export async function POST(req: NextRequest) {
  return handle(async () => {
    await requireAdmin()
    const form = await req.formData().catch(() => null)
    if (!form) return fail('Gửi dạng multipart/form-data với trường "file"')
    const file = form.get('file')
    if (!file || typeof file === 'string') return fail('Thiếu file .zip (trường "file")')
    if (!(file instanceof File)) return fail('Trường "file" phải là file .zip')
    const name = file.name || 'plugin.zip'
    if (!name.toLowerCase().endsWith('.zip')) return fail('Chỉ nhận file .zip')
    if (file.size <= 0) return fail('File rỗng')
    if (file.size > 100 * 1024 * 1024) return fail('File .zip quá lớn (> 100MB)')

    // File.stream() là web ReadableStream → bọc sang Node Readable
    const nodeStream = Readable.fromWeb(file.stream() as unknown as import('stream/web').ReadableStream<Uint8Array>) as Readable
    const { tmpPath } = await saveTempZip(nodeStream)
    const manifest = await installPluginZip(tmpPath)
    return ok({
      ok: true,
      plugin: {
        slug: manifest.slug,
        name: manifest.name,
        version: manifest.version,
        kind: manifest.kind,
      },
    })
  })
}
