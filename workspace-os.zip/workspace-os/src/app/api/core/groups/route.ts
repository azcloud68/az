import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { emitEvent } from '@/core/server/event-bus'
import { handle, ok, fail, readJson, requireAdmin } from '@/core/server/api'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** GET — danh sách nhóm */
export async function GET() {
  return handle(async () => {
    await requireAdmin()
    const groups = await db.group.findMany({ include: { _count: { select: { users: true } } }, orderBy: { name: 'asc' } })
    return ok({ groups: groups.map((g) => ({ ...g, userCount: g._count.users })) })
  })
}

/** POST — tạo nhóm */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAdmin()
    const body = await readJson<{ name?: string; description?: string }>(req)
    const name = (body.name || '').trim()
    if (!name) return fail('Nhập tên nhóm')
    if (await db.group.findUnique({ where: { name } })) return fail('Nhóm đã tồn tại')
    const group = await db.group.create({ data: { name, description: body.description?.trim() || '' } })
    await emitEvent({
      type: 'group.created',
      module: 'core',
      actor: { id: session.id, displayName: session.displayName },
      payload: { name },
      targetId: group.id,
      targetType: 'group',
    })
    return ok({ ok: true, id: group.id })
  })
}
