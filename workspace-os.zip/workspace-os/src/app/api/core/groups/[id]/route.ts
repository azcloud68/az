import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { handle, ok, fail, readJson, requireAdmin } from '@/core/server/api'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** PATCH — cập nhật nhóm */
export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    await requireAdmin()
    const { id } = await ctx.params
    const body = await readJson<{ name?: string; description?: string }>(req)
    const group = await db.group.findUnique({ where: { id } })
    if (!group) return fail('Nhóm không tồn tại', 404)
    const data: Record<string, unknown> = {}
    if (body.name?.trim()) data.name = body.name.trim()
    if (body.description !== undefined) data.description = body.description.trim()
    await db.group.update({ where: { id }, data })
    return ok({ ok: true })
  })
}

/** DELETE — xoá nhóm (user mất group) */
export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    await requireAdmin()
    const { id } = await ctx.params
    await db.user.updateMany({ where: { groupId: id }, data: { groupId: null } })
    await db.group.delete({ where: { id } })
    return ok({ ok: true })
  })
}
