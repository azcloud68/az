import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { hashPassword } from '@/core/server/auth'
import { emitEvent } from '@/core/server/event-bus'
import { handle, ok, fail, readJson, requireAdmin } from '@/core/server/api'
import { normalizePermissions, serializePermissions } from '@/core/server/user-permissions'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const COLORS = ['#f97316', '#10b981', '#0891b2', '#eab308', '#ec4899', '#84cc16', '#f43f5e', '#8b5cf6']

/** GET /api/core/users — danh sách người dùng + nhóm + mã đặt lại đang hiệu lực (kênh admin) */
export async function GET() {
  return handle(async () => {
    await requireAdmin()
    const [users, groups, resets] = await Promise.all([
      db.user.findMany({
        orderBy: { createdAt: 'asc' },
        include: {
          group: true,
          _count: { select: { sessions: true } },
          sessions: { orderBy: { createdAt: 'desc' }, take: 1, select: { createdAt: true } },
        },
      }),
      db.group.findMany({ include: { _count: { select: { users: true } } }, orderBy: { name: 'asc' } }),
      // Mã đặt lại CÒN HIỆU LỰC — kênh an toàn thay vì trả mã qua /forgot (public)
      db.passwordReset.findMany({
        where: { usedAt: null, expiresAt: { gt: new Date() } },
        orderBy: { createdAt: 'desc' },
      }),
    ])
    // PasswordReset không có relation — join tay theo userId
    const resetUserMap = new Map<string, { username: string; displayName: string }>()
    if (resets.length > 0) {
      const rusers = await db.user.findMany({
        where: { id: { in: [...new Set(resets.map((r) => r.userId))] } },
        select: { id: true, username: true, displayName: true },
      })
      for (const u of rusers) resetUserMap.set(u.id, { username: u.username, displayName: u.displayName })
    }
    return ok({
      users: users.map((u) => ({
        id: u.id,
        username: u.username,
        email: u.email,
        displayName: u.displayName,
        role: u.role,
        avatarColor: u.avatarColor,
        active: u.active,
        group: u.group ? { id: u.group.id, name: u.group.name } : null,
        sessionCount: u._count.sessions,
        createdAt: u.createdAt,
        lastLogin: u.sessions[0]?.createdAt || null,
        permissions: u.role === 'admin' ? null : normalizePermissions(u.permissions),
      })),
      groups: groups.map((g) => ({ id: g.id, name: g.name, description: g.description, userCount: g._count.users })),
      resetCodes: resets.map((r) => ({
        code: r.code,
        username: resetUserMap.get(r.userId)?.username ?? '',
        displayName: resetUserMap.get(r.userId)?.displayName ?? '',
        expiresAt: r.expiresAt,
      })),
    })
  })
}

/** POST — tạo người dùng mới (kèm quyền hạn riêng: whitelist module + file manager) */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAdmin()
    const body = await readJson<{
      username?: string
      password?: string
      displayName?: string
      email?: string
      role?: string
      groupId?: string
      permissions?: { modules?: string[] | null; allowFiles?: boolean } | null
    }>(req)
    const username = (body.username || '').trim().toLowerCase()
    if (!/^[a-z0-9_.-]{3,30}$/.test(username)) return fail('Tên đăng nhập 3-30 ký tự (a-z, 0-9, . _ -)')
    if (!body.password || body.password.length < 6) return fail('Mật khẩu tối thiểu 6 ký tự')
    if (await db.user.findUnique({ where: { username } })) return fail('Tên đăng nhập đã tồn tại')
    const role = ['admin', 'member', 'viewer'].includes(body.role || '') ? body.role : 'member'
    const user = await db.user.create({
      data: {
        username,
        passwordHash: hashPassword(body.password),
        displayName: body.displayName?.trim() || username,
        email: body.email?.trim() || null,
        role,
        groupId: body.groupId || null,
        avatarColor: COLORS[Math.floor(Math.random() * COLORS.length)],
        permissions: role === 'admin' ? '' : serializePermissions(body.permissions || null),
      },
    })
    await emitEvent({
      type: 'user.created',
      module: 'core',
      actor: { id: session.id, displayName: session.displayName },
      payload: { name: username },
      targetId: user.id,
      targetType: 'user',
    })
    return ok({ ok: true, id: user.id })
  })
}
