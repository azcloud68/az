import { hashPassword } from '@/core/server/auth'
import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { emitEvent } from '@/core/server/event-bus'
import { handle, ok, fail, readJson, requireAdmin } from '@/core/server/api'
import { serializePermissions, invalidateUserPermissions } from '@/core/server/user-permissions'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** PATCH /api/core/users/[id] — cập nhật user (role, tên, active, password...) */
export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireAdmin()
    const { id } = await ctx.params
    const body = await readJson<{
      displayName?: string
      email?: string
      role?: string
      active?: boolean
      groupId?: string | null
      password?: string
      avatarColor?: string
      permissions?: { modules?: string[] | null; allowFiles?: boolean } | null
    }>(req)
    const user = await db.user.findUnique({ where: { id } })
    if (!user) return fail('Người dùng không tồn tại', 404)

    const data: Record<string, unknown> = {}
    if (body.displayName !== undefined) data.displayName = body.displayName.trim()
    if (body.email !== undefined) data.email = body.email.trim() || null
    if (body.role !== undefined) {
      if (!['admin', 'member', 'viewer'].includes(body.role)) return fail('Role không hợp lệ')
      if (user.id === session.id && body.role !== 'admin') return fail('Không thể tự hạ quyền của chính mình')
      data.role = body.role
    }
    if (body.active !== undefined) {
      if (user.id === session.id && body.active === false) return fail('Không thể tự vô hiệu hoá chính mình')
      data.active = body.active
      if (!body.active) await db.session.deleteMany({ where: { userId: id } })
    }
    if (body.groupId !== undefined) data.groupId = body.groupId || null
    if (body.avatarColor !== undefined) data.avatarColor = body.avatarColor
    if (body.password) {
      if (body.password.length < 6) return fail('Mật khẩu tối thiểu 6 ký tự')
      data.passwordHash = hashPassword(body.password)
      await db.session.deleteMany({ where: { userId: id } })
    }
    if (body.permissions !== undefined) {
      const nextRole = (body.role !== undefined && ['admin', 'member', 'viewer'].includes(body.role) ? body.role : user.role) || 'member'
      data.permissions = nextRole === 'admin' ? '' : serializePermissions(body.permissions)
      invalidateUserPermissions(id)
    }
    await db.user.update({ where: { id }, data })
    await emitEvent({
      type: 'user.updated',
      module: 'core',
      actor: { id: session.id, displayName: session.displayName },
      payload: { name: user.username },
      targetId: id,
      targetType: 'user',
    })
    return ok({ ok: true })
  })
}

/** DELETE — xoá user (không xoá được chính mình) */
export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireAdmin()
    const { id } = await ctx.params
    if (id === session.id) return fail('Không thể xoá chính mình')
    const user = await db.user.findUnique({ where: { id } })
    if (!user) return fail('Người dùng không tồn tại', 404)
    await db.user.delete({ where: { id } })
    await emitEvent({
      type: 'user.deleted',
      module: 'core',
      actor: { id: session.id, displayName: session.displayName },
      payload: { name: user.username },
    })
    return ok({ ok: true })
  })
}
