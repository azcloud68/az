import { NextRequest } from 'next/server'
import { handle, ok, requireSession } from '@/core/server/api'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

// Cache 10 phút — nhẹ cho Orange Pi
const cache = new Map<string, { ts: number; data: unknown }>()
const CACHE_MS = 10 * 60 * 1000

/** GET /api/core/weather?lat=&lon= — open-meteo không cần API key.
 *  Dùng `current=` (API v2) để lấy ĐẦY ĐỦ số liệu: nhiệt độ, gió, mã thời tiết,
 *  độ phủ mây (cloud_cover), lượng mưa (precipitation), ngày/đêm (is_day)
 *  → hiệu ứng desktop AUTO + widget dùng cùng một nguồn, khớp nhau 100%.
 *  Giữ nguyên tên trường cũ (temperature/windspeed/weathercode) để client cũ không vỡ. */
export async function GET(req: NextRequest) {
  return handle(async () => {
    await requireSession()
    const lat = req.nextUrl.searchParams.get('lat') || '10.762622'
    const lon = req.nextUrl.searchParams.get('lon') || '106.660172'
    const key = `${lat},${lon}`
    const hit = cache.get(key)
    if (hit && Date.now() - hit.ts < CACHE_MS) return ok(hit.data)

    try {
      const url =
        `https://api.open-meteo.com/v1/forecast?latitude=${encodeURIComponent(lat)}&longitude=${encodeURIComponent(lon)}` +
        '&current=temperature_2m,weather_code,wind_speed_10m,precipitation,cloud_cover,is_day' +
        '&wind_speed_unit=kmh&timezone=auto'
      const res = await fetch(url, { signal: AbortSignal.timeout(6000) })
      if (!res.ok) throw new Error(`open-meteo ${res.status}`)
      const data = await res.json()
      const cur = data?.current || {}
      const out = {
        ok: true,
        temperature: Math.round(cur.temperature_2m ?? 0),
        windspeed: Math.round(cur.wind_speed_10m ?? 0),
        weathercode: cur.weather_code ?? 0,
        // Bổ sung cho hiệu ứng desktop auto + độ chính xác hiển thị
        cloudcover: typeof cur.cloud_cover === 'number' ? cur.cloud_cover : null,
        precipitation: typeof cur.precipitation === 'number' ? cur.precipitation : 0,
        isday: cur.is_day !== 0,
        fetchedAt: Date.now(),
      }
      cache.set(key, { ts: Date.now(), data: out })
      return ok(out)
    } catch {
      if (hit) return ok(hit.data)
      return ok({ ok: false, temperature: null })
    }
  })
}
