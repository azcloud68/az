import { NextRequest } from 'next/server'
import { consumeResetCode } from '@/core/server/auth'
import { handle, ok, fail, readJson, reqIp } from '@/core/server/api'
import { checkRate } from '@/core/server/rate-limit'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** POST /api/core/auth/reset — dùng mã reset để đặt lại mật khẩu (rate limit chống dò mã) */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const body = await readJson<{ username?: string; code?: string; password?: string }>(req)
    const { username, code, password } = body
    if (!username || !code || !password) return fail('Thiếu dữ liệu đặt lại mật khẩu')
    if (password.length < 6) return fail('Mật khẩu mới tối thiểu 6 ký tự')

    const uname = username.trim().toLowerCase()
    // 10 lần thử / 15 phút theo IP + username — mã 8 ký tự hex không dò được bằng nhịp này
    if (!checkRate(`reset:${reqIp(req)}:${uname}`, 10, 15 * 60 * 1000)) {
      return fail('Quá nhiều lần thử — thử lại sau 15 phút', 429)
    }

    const done = await consumeResetCode(uname, code.trim().toUpperCase(), password)
    if (!done) return fail('Mã đặt lại không đúng hoặc đã hết hạn', 400)
    return ok({ ok: true })
  })
}
