import { getSession } from '@/core/server/auth'
import { getAllModules } from '@/core/server/module-registry'
import { handle, ok } from '@/core/server/api'
import { getUserPermissions, permsAllowModule } from '@/core/server/user-permissions'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET() {
  return handle(async () => {
    const session = await getSession()
    if (!session) return ok({ user: null })
    const [modules, permissions] = await Promise.all([getAllModules(), getUserPermissions(session.id)])
    const enabled = modules
      .filter((m) => m.enabled)
      .filter((m) => {
        if (session.role === 'admin') return true
        const rolePerms = m.permissions[session.role] || []
        return rolePerms.includes('*') || rolePerms.includes('read') || rolePerms.includes('write')
      })
      .filter((m) => session.role === 'admin' || permsAllowModule(permissions, m.manifest.id))
      .map((m) => m.manifest.id)
    return ok({ user: { ...session, permissions }, enabledModules: enabled })
  })
}
