import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { verifyPassword } from '@/core/server/auth'
import { requireSession, handle, ok, fail, readJson } from '@/core/server/api'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/**
 * POST /api/core/auth/verify — kiểm tra mật khẩu của user hiện tại
 * (dùng cho mở khóa màn hình, xác nhận hành động nhạy cảm — KHÔNG tạo session mới)
 */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    const body = await readJson<{ password?: string }>(req)
    const password = String(body.password || '')
    if (!password) return fail('Nhập mật khẩu')
    const user = await db.user.findUnique({ where: { id: session.id }, select: { passwordHash: true } })
    if (!user || !verifyPassword(password, user.passwordHash)) {
      return fail('Mật khẩu không đúng', 403)
    }
    return ok({ ok: true })
  })
}
