import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { createSession, verifyPassword, SESSION_COOKIE, sessionCookieOptions } from '@/core/server/auth'
import { emitEvent } from '@/core/server/event-bus'
import { handle, ok, fail, reqIp, reqUserAgent, readJson } from '@/core/server/api'
import { normalizePermissions } from '@/core/server/user-permissions'
import { exceedsRate, bumpRate } from '@/core/server/rate-limit'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** Giới hạn brute-force login: 20 lần sai / 15 phút theo IP + 10 lần sai / 15 phút
 *  theo username. CHỈ đếm lần THẤT BẠI (bump sau khi verify sai) — người dùng gõ
 *  đúng bao nhiêu lần cũng không tự khoá mình. */
const LOGIN_WINDOW_MS = 15 * 60 * 1000
const LOGIN_IP_LIMIT = 20
const LOGIN_USER_LIMIT = 10

export async function POST(req: NextRequest) {
  return handle(async () => {
    const body = await readJson<{ username?: string; password?: string; remember?: boolean }>(req)
    const username = (body.username || '').trim().toLowerCase()
    const password = body.password || ''
    if (!username || !password) return fail('Nhập tên đăng nhập và mật khẩu')

    const ip = reqIp(req)
    if (exceedsRate(`login:ip:${ip}`, LOGIN_IP_LIMIT, LOGIN_WINDOW_MS)) {
      return fail('Quá nhiều lần đăng nhập từ thiết bị này — thử lại sau 15 phút', 429)
    }
    if (exceedsRate(`login:user:${username.slice(0, 60)}`, LOGIN_USER_LIMIT, LOGIN_WINDOW_MS)) {
      return fail('Tài khoản vừa đăng nhập sai nhiều lần — thử lại sau 15 phút', 429)
    }

    const user = await db.user.findUnique({ where: { username } })
    if (!user || !verifyPassword(password, user.passwordHash)) {
      // chỉ đếm lần SAI (IP + username) — chống brute-force mà không tự khoá user thật
      bumpRate(`login:ip:${ip}`, LOGIN_WINDOW_MS)
      bumpRate(`login:user:${username.slice(0, 60)}`, LOGIN_WINDOW_MS)
      return fail('Tên đăng nhập hoặc mật khẩu không đúng', 401)
    }
    if (!user.active) return fail('Tài khoản đã bị vô hiệu hoá', 403)

    const token = await createSession(user, {
      remember: body.remember !== false,
      userAgent: reqUserAgent(req),
      ip: reqIp(req),
    })
    await emitEvent({
      type: 'auth.login',
      module: 'core',
      actor: { id: user.id, displayName: user.displayName },
      payload: { username },
    })

    const res = ok({
      user: {
        id: user.id,
        username: user.username,
        displayName: user.displayName,
        role: user.role,
        avatarColor: user.avatarColor,
        email: user.email,
        permissions: normalizePermissions(user.permissions),
      },
    })
    res.cookies.set(SESSION_COOKIE, token, sessionCookieOptions(body.remember !== false))
    return res
  })
}
