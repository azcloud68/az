import { db } from '@/lib/db'
import { destroyAllSessions } from '@/core/server/auth'
import { handle, ok, readJson, requireSession } from '@/core/server/api'
import type { NextRequest } from 'next/server'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** Danh sách phiên đăng nhập của tôi (Settings → Security) */
export async function GET() {
  return handle(async () => {
    const session = await requireSession()
    const sessions = await db.session.findMany({
      where: { userId: session.id, expiresAt: { gt: new Date() } },
      orderBy: { createdAt: 'desc' },
      take: 20,
    })
    return ok({
      sessions: sessions.map((s) => ({
        id: s.id,
        ip: s.ip,
        userAgent: s.userAgent,
        createdAt: s.createdAt,
        expiresAt: s.expiresAt,
        current: s.id === session.sessionId,
      })),
    })
  })
}

/** Đăng xuất tất cả thiết bị khác (giữ phiên hiện tại) */
export async function DELETE(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    const body = await readJson<{ all?: boolean }>(req).catch(() => ({ all: false }))
    await destroyAllSessions(session.id, body.all ? undefined : session.sessionId)
    return ok({ ok: true })
  })
}
