import { changePassword, verifyPassword } from '@/core/server/auth'
import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { emitEvent } from '@/core/server/event-bus'
import { handle, ok, fail, readJson, requireSession } from '@/core/server/api'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function PUT(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    const body = await readJson<{ current?: string; next?: string }>(req)
    if (!body.current || !body.next) return fail('Nhập đủ mật khẩu hiện tại và mật khẩu mới')
    if (body.next.length < 6) return fail('Mật khẩu mới tối thiểu 6 ký tự')

    const user = await db.user.findUnique({ where: { id: session.id } })
    if (!user || !verifyPassword(body.current, user.passwordHash)) {
      return fail('Mật khẩu hiện tại không đúng', 403)
    }
    // Giữ nguyên session HIỆN TẠI — chỉ thu hồi các session khác
    await changePassword(user.id, body.next, session.sessionId)
    await emitEvent({
      type: 'auth.password',
      module: 'core',
      actor: { id: session.id, displayName: session.displayName },
    })
    return ok({ ok: true })
  })
}
