import { getSession, destroySession } from '@/core/server/auth'
import { emitEvent } from '@/core/server/event-bus'
import { handle, ok } from '@/core/server/api'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function POST() {
  return handle(async () => {
    const session = await getSession()
    if (session) {
      await emitEvent({
        type: 'auth.logout',
        module: 'core',
        actor: { id: session.id, displayName: session.displayName },
        payload: { username: session.username },
      })
    }
    await destroySession()
    return ok({ ok: true })
  })
}
