import { NextRequest } from 'next/server'
import { createResetCode } from '@/core/server/auth'
import { handle, ok, fail, readJson, reqIp } from '@/core/server/api'
import { checkRate } from '@/core/server/rate-limit'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/**
 * Quên mật khẩu — SINH mã reset nhưng KHÔNG trả mã qua API (chống chiếm tài khoản).
 * Mã chỉ đến qua 2 kênh an toàn:
 *   1. Log server:      journalctl -u wos | grep "WOS:reset"
 *   2. Administration → Users (admin đang đăng nhập thấy mã còn hiệu lực)
 * Rate limit: 5 lần / 15 phút theo IP, 3 mã / 15 phút theo username.
 */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const body = await readJson<{ username?: string }>(req)
    const username = (body.username || '').trim().toLowerCase()
    if (!username) return fail('Nhập tên đăng nhập')

    const ip = reqIp(req)
    if (!checkRate(`forgot:ip:${ip}`, 5, 15 * 60 * 1000)) {
      return fail('Quá nhiều yêu cầu — thử lại sau 15 phút', 429)
    }
    if (!checkRate(`forgot:user:${username}`, 3, 15 * 60 * 1000)) {
      return fail('Tài khoản này vừa yêu cầu mã — thử lại sau 15 phút', 429)
    }

    await createResetCode(username)
    // Không tiết lộ user tồn tại hay không — phản hồi luôn giống nhau
    return ok({
      ok: true,
      message:
        'Nếu tài khoản tồn tại, mã đặt lại (hiệu lực 15 phút) đã được sinh. ' +
        'Liên hệ quản trị viên hoặc xem log server (journalctl -u wos) để lấy mã.',
    })
  })
}
