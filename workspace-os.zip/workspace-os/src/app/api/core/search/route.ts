import { NextRequest } from 'next/server'
import { globalSearch } from '@/core/server/search-engine'
import { handle, ok, requireSession } from '@/core/server/api'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** GET /api/core/search?q=...&module=all — Global Search (Ctrl+K) */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    const q = (req.nextUrl.searchParams.get('q') || '').trim()
    const moduleFilter = req.nextUrl.searchParams.get('module') || 'all'
    if (q.length < 1) return ok({ results: [] })
    const results = await globalSearch(q, session, { module: moduleFilter, limit: 8 })
    return ok({ results })
  })
}
