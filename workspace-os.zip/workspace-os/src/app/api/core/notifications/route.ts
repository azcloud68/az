import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { handle, ok, fail, readJson, requireSession } from '@/core/server/api'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** GET /api/core/notifications?filter=unread|all|archived — của user + thông báo hệ thống (userId null) */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    const filter = req.nextUrl.searchParams.get('filter') || 'all'
    const mine = { OR: [{ userId: session.id }, { userId: null }] }
    const where =
      filter === 'unread'
        ? { ...mine, read: false, archived: false }
        : filter === 'archived'
          ? { ...mine, archived: true }
          : { ...mine, archived: false }
    const [items, unreadCount] = await Promise.all([
      db.notification.findMany({ where, orderBy: { createdAt: 'desc' }, take: 100 }),
      db.notification.count({ where: { ...mine, read: false, archived: false } }),
    ])
    return ok({ notifications: items, unreadCount })
  })
}

/** PATCH — đánh dấu đọc / lưu trữ (chỉ thông báo của user hoặc hệ thống) */
export async function PATCH(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    const body = await readJson<{ ids?: string[]; action?: string }>(req)
    const ids = body.ids || []
    const action = body.action || 'read'
    const mine = { OR: [{ userId: session.id }, { userId: null }] }
    // "Đọc tất cả" không cần ids — xử lý TRƯỚC khi check ids rỗng (fix nút không phản hồi)
    if (action === 'read-all') {
      await db.notification.updateMany({ where: { ...mine, read: false }, data: { read: true, readAt: new Date() } })
      return ok({ ok: true })
    }
    if (ids.length === 0) return fail('Chưa chọn thông báo')
    if (action === 'read') {
      await db.notification.updateMany({ where: { id: { in: ids }, ...mine }, data: { read: true, readAt: new Date() } })
    } else if (action === 'unread') {
      await db.notification.updateMany({ where: { id: { in: ids }, ...mine }, data: { read: false, readAt: null } })
    } else if (action === 'archive') {
      await db.notification.updateMany({ where: { id: { in: ids }, ...mine }, data: { archived: true } })
    } else if (action === 'unarchive') {
      await db.notification.updateMany({ where: { id: { in: ids }, ...mine }, data: { archived: false } })
    } else {
      return fail('Hành động không hợp lệ')
    }
    return ok({ ok: true })
  })
}

/** DELETE — xoá thông báo (chỉ của user hoặc hệ thống) */
export async function DELETE(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    const body = await readJson<{ ids?: string[]; archived?: boolean }>(req)
    const mine = { OR: [{ userId: session.id }, { userId: null }] }
    if (body.archived) {
      await db.notification.deleteMany({ where: { ...mine, archived: true } })
    } else if (body.ids?.length) {
      await db.notification.deleteMany({ where: { id: { in: body.ids }, ...mine } })
    } else {
      return fail('Chưa chọn thông báo')
    }
    return ok({ ok: true })
  })
}
