import { NextRequest } from 'next/server'
import { getSettings, setSettings, DEFAULT_SETTINGS } from '@/core/server/settings'
import { emitEvent } from '@/core/server/event-bus'
import { handle, ok, fail, readJson, requireSession } from '@/core/server/api'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** Module giữ theo TÀI KHOẢN (giao diện riêng mỗi user) — còn lại là global */
const PER_USER_MODULES = new Set(['appearance'])

/** Giá trị NHAY NHẨM — không bao giờ trả về client nguyên bản (fix lỗi 8):
 *  GET thay bằng "__SAVED__" để UI biết đã lưu mà không lộ mật khẩu SMTP. */
const SECRET_SETTING_KEYS = new Set(['email_smtp_password'])

/** GET /api/core/settings?module=core — settings theo module (gộp default) */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    const moduleScope = req.nextUrl.searchParams.get('module') || 'core'
    const defaults = DEFAULT_SETTINGS[moduleScope] || {}
    const saved = await getSettings(moduleScope, PER_USER_MODULES.has(moduleScope) ? session.id : undefined)
    const merged = { ...defaults, ...saved }
    for (const k of SECRET_SETTING_KEYS) {
      if (merged[k]) merged[k] = '__SAVED__'
    }
    return ok({ module: moduleScope, settings: merged })
  })
}

/** PUT /api/core/settings — lưu settings của module
 *  - Module PER-USER (appearance): user tự sửa bộ của mình
 *  - Module GLOBAL (tasks/calendar/files/projects/... + core): CHỈ ADMIN —
 *    member/viewer không được đổi cấu hình ảnh hưởng cả hệ thống */
export async function PUT(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    const body = await readJson<{ module?: string; settings?: Record<string, string> }>(req)
    const moduleScope = body.module || 'core'
    const settings = body.settings || {}
    const isPerUser = PER_USER_MODULES.has(moduleScope)
    if (!isPerUser && session.role !== 'admin') {
      return fail(`Cấu hình module "${moduleScope}" là toàn hệ thống — chỉ quản trị viên được sửa`, 403)
    }
    // Giá trị bí mật: UI gửi lại đúng placeholder "__SAVED__" = giữ nguyên giá trị cũ
    // (không ghi đè mật khẩu SMTP thật bằng placeholder)
    for (const k of SECRET_SETTING_KEYS) {
      if (settings[k] === '__SAVED__') delete settings[k]
    }
    await setSettings(moduleScope, settings, isPerUser ? session.id : undefined)
    await emitEvent({
      type: 'settings.updated',
      module: moduleScope,
      actor: { id: session.id, displayName: session.displayName },
      payload: { keys: Object.keys(settings).join(', ') },
      logActivity: moduleScope !== 'core',
    })
    return ok({ ok: true })
  })
}
