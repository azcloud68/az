import { NextRequest } from 'next/server'
import { getSettings, setSettings, DEFAULT_SETTINGS } from '@/core/server/settings'
import { emitEvent } from '@/core/server/event-bus'
import { handle, ok, fail, readJson, requireSession } from '@/core/server/api'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** Module giữ theo TÀI KHOẢN (giao diện riêng mỗi user) — còn lại là global */
const PER_USER_MODULES = new Set(['appearance'])

/** GET /api/core/settings?module=core — settings theo module (gộp default) */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    const moduleScope = req.nextUrl.searchParams.get('module') || 'core'
    const defaults = DEFAULT_SETTINGS[moduleScope] || {}
    const saved = await getSettings(moduleScope, PER_USER_MODULES.has(moduleScope) ? session.id : undefined)
    return ok({ module: moduleScope, settings: { ...defaults, ...saved } })
  })
}

/** PUT /api/core/settings — lưu settings của module
 *  - Module PER-USER (appearance): user tự sửa bộ của mình
 *  - Module GLOBAL (tasks/calendar/files/projects/... + core): CHỈ ADMIN —
 *    member/viewer không được đổi cấu hình ảnh hưởng cả hệ thống */
export async function PUT(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    const body = await readJson<{ module?: string; settings?: Record<string, string> }>(req)
    const moduleScope = body.module || 'core'
    const settings = body.settings || {}
    const isPerUser = PER_USER_MODULES.has(moduleScope)
    if (!isPerUser && session.role !== 'admin') {
      return fail(`Cấu hình module "${moduleScope}" là toàn hệ thống — chỉ quản trị viên được sửa`, 403)
    }
    await setSettings(moduleScope, settings, isPerUser ? session.id : undefined)
    await emitEvent({
      type: 'settings.updated',
      module: moduleScope,
      actor: { id: session.id, displayName: session.displayName },
      payload: { keys: Object.keys(settings).join(', ') },
      logActivity: moduleScope !== 'core',
    })
    return ok({ ok: true })
  })
}
