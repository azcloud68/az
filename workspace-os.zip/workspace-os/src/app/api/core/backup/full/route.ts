import { NextRequest, NextResponse } from 'next/server'
import { createReadStream } from 'fs'
import { promises as fsp } from 'fs'
import path from 'path'
import { execFile } from 'child_process'
import { promisify } from 'util'
import { randomBytes } from 'crypto'
import { Readable } from 'stream'
import { db } from '@/lib/db'
import { emitEvent } from '@/core/server/event-bus'
import { handle, ok, fail, requireAdmin } from '@/core/server/api'
import { ApiError } from '@/core/server/api-error'
import { MODULE_TABLES, sanitizeBackupSettings } from '@/core/server/backup-tables'
import {
  isBackupMeta, validateBackupPayload, applyBackupPayload, snapshotDbFile,
  snapshotStorageTree, restoreStorageTree, rollbackStorageTree, exportPayloadFromSqlite,
  pathIsFile, pathIsDir,
} from '@/core/server/backup-restore'
import { baseStorageRoot } from '@/core/server/storage'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 600

const execFileAsync = promisify(execFile)

/** Giới hạn upload bản full-backup restore (tar.gz) — mặc định 8GB, đổi qua env */
const MAX_RESTORE_UPLOAD = (() => {
  const mb = Number(process.env.WOS_MAX_BACKUP_MB || '8192')
  return Number.isFinite(mb) && mb > 0 ? mb * 1024 * 1024 : 8 * 1024 * 1024 * 1024
})()

function backupFileName(): string {
  const d = new Date()
  const pad = (n: number) => String(n).padStart(2, '0')
  return `wos-backup-${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}.tar.gz`
}

async function countFiles(dir: string): Promise<number> {
  let n = 0
  let entries
  try {
    entries = await fsp.readdir(dir, { withFileTypes: true })
  } catch {
    return 0
  }
  for (const e of entries) {
    if (e.isDirectory()) n += await countFiles(path.join(dir, e.name))
    else n++
  }
  return n
}

/**
 * GET /api/core/backup/full (fix lỗi 9) — XUẤT BẢN SAO LƯU ĐẦY ĐỦ tải trực tiếp:
 *   tar.gz chứa: db/wos.db (SQLite VACUUM snapshot) + files/ (toàn bộ storage
 *   mọi user) + config/wos-export.json (metadata JSON redact secret) + manifest.json
 * Không cần Google Drive — "backup nhanh" cho admin bất cứ lúc nào.
 */
export async function GET() {
  return handle(async () => {
    const session = await requireAdmin()
    const run = await db.backupRun.create({
      data: { trigger: 'manual', status: 'running', provider: 'manual-full', fileName: 'pending' },
    })
    const tmpDir = path.join(path.dirname(path.resolve(baseStorageRoot())), 'wos-backup-manual', `${Date.now()}-${randomBytes(3).toString('hex')}`)
    try {
      await fsp.rm(tmpDir, { recursive: true, force: true })
      await fsp.mkdir(tmpDir, { recursive: true })
      let fileCount = 0

      // 1) DB snapshot an toàn khi đang mở (VACUUM INTO)
      const snapshot = path.join(tmpDir, 'wos-snapshot.sqlite')
      await db.$executeRawUnsafe(`VACUUM INTO '${snapshot.replace(/'/g, "''")}'`)
      await fsp.mkdir(path.join(tmpDir, 'db'), { recursive: true })
      await fsp.copyFile(snapshot, path.join(tmpDir, 'db', 'wos.db'))
      await fsp.rm(snapshot, { force: true })
      fileCount++

      // 2) Toàn bộ storage (mọi user — root hệ thống)
      const storageRoot = path.resolve(baseStorageRoot())
      if (await pathIsDir(storageRoot)) {
        await fsp.cp(storageRoot, path.join(tmpDir, 'files'), { recursive: true })
        fileCount += await countFiles(path.join(tmpDir, 'files'))
      }

      // 3) Metadata JSON (như /api/core/backup — secret đã redact)
      const data: Record<string, unknown> = {
        _meta: { app: 'Workspace OS', version: '1.1.0', exportedAt: new Date().toISOString(), by: session.username, redacted: true },
      }
      for (const table of MODULE_TABLES) {
        const rows = await (db as unknown as Record<string, { findMany: () => Promise<unknown[]> }>)[table].findMany()
        data[table] = table === 'setting' ? sanitizeBackupSettings(rows as { id: string; value: string }[]) : rows
      }
      await fsp.mkdir(path.join(tmpDir, 'config'), { recursive: true })
      await fsp.writeFile(path.join(tmpDir, 'config', 'wos-export.json'), JSON.stringify(data), 'utf-8')
      fileCount++

      // 4) manifest — restore dựa vào đây để nhận diện bản sao lưu
      await fsp.writeFile(
        path.join(tmpDir, 'manifest.json'),
        JSON.stringify(
          {
            app: 'Workspace OS',
            wosVersion: '3.1',
            backupRunId: run.id,
            createdAt: new Date().toISOString(),
            trigger: 'manual-full',
            sources: { db: true, files: true, config: true },
            fileCount,
            by: session.displayName || session.username,
          },
          null,
          2,
        ),
        'utf-8',
      )

      // 5) Đóng gói tar.gz
      const include: string[] = ['manifest.json']
      for (const name of ['db', 'files', 'config']) {
        if (await pathIsDir(path.join(tmpDir, name))) include.push(name)
      }
      const fileName = backupFileName()
      const tarPath = path.join(tmpDir, fileName)
      await execFileAsync('tar', ['-czf', tarPath, '-C', tmpDir, ...include], { maxBuffer: 16 * 1024 * 1024 })
      const size = (await fsp.stat(tarPath)).size

      await db.backupRun.update({
        where: { id: run.id },
        data: { status: 'ok', fileName, size, fileCount, finishedAt: new Date() },
      })
      await emitEvent({
        type: 'backup.exported',
        module: 'core',
        actor: { id: session.id, displayName: session.displayName },
        payload: { title: fileName, size, fileCount, full: true },
        notify: { title: 'Sao lưu đầy đủ hoàn tất', content: `${fileName} • ${fileCount} mục • ${(size / 1024 / 1024).toFixed(1)}MB`, type: 'system' },
      })

      // 6) Stream file xuống client + dọn tmp khi xong (best-effort)
      const node = createReadStream(tarPath)
      node.on('close', () => {
        void fsp.rm(tmpDir, { recursive: true, force: true }).catch(() => {})
      })
      const web = Readable.toWeb(node) as unknown as ReadableStream<Uint8Array>
      return new NextResponse(web, {
        headers: {
          'content-type': 'application/gzip',
          'content-disposition': `attachment; filename="${fileName}"`,
          'content-length': String(size),
        },
      })
    } catch (err) {
      await db.backupRun.update({
        where: { id: run.id },
        data: { status: 'error', error: String(err instanceof Error ? err.message : err).slice(0, 500), finishedAt: new Date() },
      }).catch(() => {})
      await fsp.rm(tmpDir, { recursive: true, force: true }).catch(() => {})
      throw err
    }
  })
}

/**
 * POST /api/core/backup/full (fix lỗi 9) — PHỤC HỒI từ tar.gz đầy đủ:
 * multipart field 'file' (tar.gz xuất từ GET hoặc từ backup Google Drive).
 * An toàn: pre-scan tên entry tar (chặn '../' + tuyệt đối), snapshot DB +
 * snapshot storage TRƯỚC khi áp, DB áp trong 1 transaction, storage swap
 * có rollback.
 */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAdmin()
    const ctype = req.headers.get('content-type') || ''
    if (!ctype.toLowerCase().includes('multipart/form-data')) {
      return fail('Yêu cầu phải là multipart/form-data (trường file)')
    }

    const form = await req.formData()
    const file = form.get('file')
    if (!(file instanceof File)) return fail('Thiếu trường file (tar.gz)')
    if (file.size > MAX_RESTORE_UPLOAD) {
      return fail(`Bản sao lưu quá lớn (${(file.size / 1024 / 1024 / 1024).toFixed(1)}GB > giới hạn ${Math.round(MAX_RESTORE_UPLOAD / 1024 / 1024 / 1024)}GB)`, 413)
    }

    const workDir = path.join(path.dirname(path.resolve(baseStorageRoot())), 'wos-restore-manual', `${Date.now()}-${randomBytes(3).toString('hex')}`)
    try {
      await fsp.mkdir(workDir, { recursive: true })
      const tarPath = path.join(workDir, 'backup.tar.gz')
      const buf = Buffer.from(await file.arrayBuffer())
      await fsp.writeFile(tarPath, buf)

      // 1) pre-scan tên entry — chặn path traversal
      const { stdout: listOut } = await execFileAsync('tar', ['-tzf', tarPath], { maxBuffer: 16 * 1024 * 1024 })
      for (const line of listOut.split('\n')) {
        const name = line.trim()
        if (!name) continue
        if (name.startsWith('/') || name.split('/').includes('..')) {
          throw new ApiError('Bản backup chứa đường dẫn không an toàn — bị chặn')
        }
      }

      // 2) giải nén vào staging
      const stageDir = path.join(workDir, 'stage')
      await fsp.mkdir(stageDir, { recursive: true })
      await execFileAsync('tar', ['-xzf', tarPath, '-C', stageDir], { maxBuffer: 16 * 1024 * 1024 })

      // 3) manifest nhận diện (bản tar từ Drive cũng tương thích)
      const manifestPath = path.join(stageDir, 'manifest.json')
      if (await pathIsFile(manifestPath)) {
        const mf = JSON.parse(await fsp.readFile(manifestPath, 'utf-8')) as { app?: string }
        if (mf.app !== 'Workspace OS') throw new ApiError('Bản backup không phải của Workspace OS')
      }

      // 4) payload DB: config/wos-export.json → db/wos.db (python3) → db/custom.db
      let payload: Record<string, Record<string, unknown>[]>
      const jsonPath = path.join(stageDir, 'config', 'wos-export.json')
      if (await pathIsFile(jsonPath)) {
        payload = JSON.parse(await fsp.readFile(jsonPath, 'utf-8')) as Record<string, Record<string, unknown>[]>
        if (!isBackupMeta(payload._meta) || payload._meta.app !== 'Workspace OS') {
          throw new ApiError('File sao lưu không hợp lệ (thiếu _meta Workspace OS)')
        }
      } else {
        let dbFile = path.join(stageDir, 'db', 'wos.db')
        if (!(await pathIsFile(dbFile))) dbFile = path.join(stageDir, 'db', 'custom.db')
        if (!(await pathIsFile(dbFile))) {
          throw new ApiError('Bản backup không chứa dữ liệu DB (cần db/wos.db hoặc config/wos-export.json)')
        }
        payload = await exportPayloadFromSqlite(dbFile)
      }
      const validated = validateBackupPayload(payload as unknown as Record<string, unknown>)

      // 5) snapshot cả DB + storage trước khi áp (best-effort)
      await snapshotDbFile()
      const filesDir = path.join(stageDir, 'files')
      if (await pathIsDir(filesDir)) {
        await snapshotStorageTree()
      }

      // 6) áp DB (1 transaction) → áp storage (có rollback)
      const { restored } = await applyBackupPayload(validated)
      if (await pathIsDir(filesDir)) {
        const holding = path.join(workDir, 'holding')
        try {
          await restoreStorageTree(filesDir, holding)
        } catch (err) {
          await rollbackStorageTree(holding)
          throw err
        }
      }

      await emitEvent({
        type: 'backup.imported',
        module: 'core',
        actor: { id: session.id, displayName: session.displayName },
        payload: { rows: restored, full: true },
        notify: { title: 'Phục hồi bản sao lưu đầy đủ hoàn tất', content: `${restored} dòng dữ liệu + toàn bộ tệp trong storage`, type: 'system' },
      })
      return ok({ ok: true, restored, filesRestored: await pathIsDir(filesDir) })
    } finally {
      // dọn sạch workspace tạm (máy 2GB RAM không đủ chỗ chứa 2 bản)
      await fsp.rm(workDir, { recursive: true, force: true }).catch(() => {})
    }
  })
}
