import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { emitEvent } from '@/core/server/event-bus'
import { handle, ok, fail, readJson, requireAdmin } from '@/core/server/api'
import { sanitizeBackupSettings } from '@/core/server/backup-tables'
import {
  isBackupMeta, validateBackupPayload, applyBackupPayload, countMissingFiles, snapshotDbFile,
} from '@/core/server/backup-restore'
import { MODULE_TABLES } from '@/core/server/backup-tables'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** GET /api/core/backup — xuất dữ liệu metadata JSON (ĐÃ REDACT SECRET:
 *  core:auth_secret bị bỏ; client_secret/refresh_token/... → [REDACTED])
 *  LƯU Ý: JSON này CHỈ chứa metadata (kể cả FileNode) — KHÔNG chứa blob tệp.
 *  Muốn khôi phục CẢ TỆP dùng bản backup Google Drive (tar.gz) + action 'restore'. */
export async function GET() {
  return handle(async () => {
    const session = await requireAdmin()
    const data: Record<string, unknown> = {
      _meta: {
        app: 'Workspace OS',
        version: '1.1.0',
        exportedAt: new Date().toISOString(),
        by: session.username,
        redacted: true,
      },
    }
    for (const table of MODULE_TABLES) {
      const rows = await (db as unknown as Record<string, { findMany: () => Promise<unknown[]> }>)[table].findMany()
      data[table] = table === 'setting' ? sanitizeBackupSettings(rows as { id: string; value: string }[]) : rows
    }
    await emitEvent({
      type: 'backup.exported',
      module: 'core',
      actor: { id: session.id, displayName: session.displayName },
    })
    const json = JSON.stringify(data, null, 1)
    return new NextResponse(json, {
      headers: {
        'content-type': 'application/json; charset=utf-8',
        'content-disposition': `attachment; filename="wos-backup-${new Date().toISOString().slice(0, 10)}.json"`,
      },
    })
  })
}

/** POST /api/core/backup — restore METADATA JSON:
 *  - validate toàn bộ payload TRƯỚC khi đụng DB (bảng lạ / giá trị sai → 400)
 *  - snapshot DB file trước khi chạy (best-effort — python sqlite backup API,
 *    fallback copy thường). Thất bại KHÔNG chặn restore.
 *  - áp TOÀN BỘ trong 1 TRANSACTION (lỗi giữa chừng → rollback sạch) — logic dùng
 *    CHUNG với restore Drive trong core/server/backup-restore.ts (kể cả fix FK
 *    Group/User: tháo user.groupId trước khi deleteMany('group'))
 *  - sau restore: báo số FileNode trỏ tệp KHÔNG tồn tại trên đĩa (JSON backup
 *    không chứa blob tệp — trung thực với admin thay vì để UI tưởng đủ) */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAdmin()
    const body = await readJson<Record<string, unknown>>(req)
    if (!isBackupMeta(body._meta) || body._meta.app !== 'Workspace OS') {
      return fail('File sao lưu không hợp lệ (thiếu _meta Workspace OS)')
    }
    // validate TRƯỚC khi đụng DB: mọi bảng phải hợp lệ, mọi giá trị phải là mảng
    const payload = validateBackupPayload(body)

    const snapshot = await snapshotDbFile()
    const { restored } = await applyBackupPayload(payload)
    const missingFiles = await countMissingFiles(payload)

    await emitEvent({
      type: 'backup.imported',
      module: 'core',
      actor: { id: session.id, displayName: session.displayName },
      payload: { rows: restored, missingFiles },
      notify: { title: 'Nhập sao lưu hoàn tất', content: `${restored} dòng dữ liệu${missingFiles > 0 ? ` • ${missingFiles} tệp thiếu trên đĩa` : ''}`, type: 'system' },
    })
    return ok({
      ok: true,
      restored,
      snapshot,
      missingFiles,
      note: missingFiles > 0
        ? 'Backup JSON chỉ chứa METADATA — dùng bản backup Google Drive (Settings → Sync → action "restore") để khôi phục cả nội dung tệp'
        : undefined,
    })
  })
}
