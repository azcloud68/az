import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { handle, ok, fail, readJson, requireAdmin, requireSession } from '@/core/server/api'
import { emitEvent } from '@/core/server/event-bus'
import type { Prisma } from '@prisma/client'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** GET /api/core/activity — log thao tác CỦA TÀI KHOẢN, lọc + phân trang */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    const sp = req.nextUrl.searchParams
    const page = Math.max(1, Number(sp.get('page') || 1))
    const limit = Math.min(100, Number(sp.get('limit') || 50))
    // Dữ liệu activity tách theo tài khoản — luôn scope theo user hiện tại
    const where: Prisma.ActivityLogWhereInput = { userId: session.id }
    const moduleFilter = sp.get('module') || 'all'
    const userFilter = sp.get('userId') || 'all'
    const actionFilter = sp.get('action') || 'all'
    const q = sp.get('q') || ''
    const from = sp.get('from')
    const to = sp.get('to')
    if (moduleFilter !== 'all') where.module = moduleFilter
    if (userFilter !== 'all' && userFilter === session.id) where.userId = userFilter
    if (actionFilter !== 'all') where.action = actionFilter
    if (q) {
      where.OR = [
        { detail: { contains: q } },
        { userName: { contains: q } },
        { targetId: { contains: q } },
      ]
    }
    if (from || to) {
      where.createdAt = {
        ...(from ? { gte: new Date(from) } : {}),
        ...(to ? { lte: new Date(to) } : {}),
      }
    }
    const [logs, total] = await Promise.all([
      db.activityLog.findMany({ where, orderBy: { createdAt: 'desc' }, skip: (page - 1) * limit, take: limit }),
      db.activityLog.count({ where }),
    ])
    return ok({ logs, total, modules: [] })
  })
}

/**
 * DELETE /api/core/activity — dọn dẹp dữ liệu:
 * {olderThan: 30} xoá bản ghi cũ hơn N ngày | {all: true} xoá toàn bộ (admin)
 */
export async function DELETE(req: NextRequest) {
  return handle(async () => {
    const session = await requireAdmin()
    const body = await readJson<{ olderThan?: number; all?: boolean }>(req)
    let deleted = 0
    if (body.all) {
      deleted = (await db.activityLog.deleteMany({})).count
    } else if (body.olderThan && body.olderThan > 0) {
      const cutoff = new Date(Date.now() - body.olderThan * 86400000)
      deleted = (await db.activityLog.deleteMany({ where: { createdAt: { lt: cutoff } } })).count
    } else {
      return fail('Chọn số ngày giữ lại hoặc xoá toàn bộ')
    }
    await emitEvent({
      type: 'settings.updated',
      module: 'core',
      actor: { id: session.id, displayName: session.displayName },
      payload: { title: `dọn ${deleted} bản ghi Activity` },
      logActivity: false,
    })
    return ok({ deleted })
  })
}
