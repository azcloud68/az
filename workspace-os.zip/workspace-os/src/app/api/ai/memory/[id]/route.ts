import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireSession, handle, ok, fail, readJson, ApiError } from '@/core/server/api'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** PATCH /api/ai/memory/[id] — sửa nội dung / xác nhận / ghim / khôi phục bản bị thay thế */
export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireSession()
    const { id } = await ctx.params
    const row = await db.aIMemory.findFirst({ where: { id, userId: session.id } })
    if (!row) throw new ApiError('Ghi nhớ không tồn tại', 404)
    const body = await readJson<{ content?: string; confirmed?: boolean; pinned?: boolean; category?: string }>(req)
    const data: Record<string, unknown> = {}
    if (typeof body.content === 'string' && body.content.trim() && body.content !== row.content) {
      data.content = body.content.trim().slice(0, 500)
      data.version = row.version + 1
      const hist = safeHist(row.history)
      hist.push({ at: new Date().toISOString(), from: row.content, to: data.content, reason: 'user_edit' })
      data.history = JSON.stringify(hist.slice(-20))
    }
    if (typeof body.confirmed === 'boolean') data.confirmed = body.confirmed
    if (typeof body.pinned === 'boolean') data.pinned = body.pinned
    if (typeof body.category === 'string' && ['preference', 'project', 'decision', 'pending', 'fact'].includes(body.category)) {
      data.category = body.category
    }
    const updated = await db.aIMemory.update({ where: { id }, data })
    return ok({ memory: updated })
  })
}

function safeHist(raw: string) {
  try {
    const v = JSON.parse(raw || '[]')
    return Array.isArray(v) ? v : []
  } catch {
    return []
  }
}

/** DELETE — xoá 1 memory (mềm: nếu bị supersede, tách liên kết) */
export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireSession()
    const { id } = await ctx.params
    const row = await db.aIMemory.findFirst({ where: { id, userId: session.id }, select: { id: true } })
    if (!row) return fail('Ghi nhớ không tồn tại', 404)
    await db.aIMemory.delete({ where: { id } })
    return ok({ deleted: id })
  })
}
