import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireSession, handle, ok, fail, readJson, ApiError } from '@/core/server/api'
import { addMemory, MEMORY_CATEGORIES, CATEGORY_LABELS } from '@/core/server/ai/memory'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** GET /api/ai/memory?category=&q= — Memory Manager: xem bộ nhớ dài hạn (kèm bản đã supersede) */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    const sp = req.nextUrl.searchParams
    const category = sp.get('category') || ''
    const q = sp.get('q') || ''
    const rows = await db.aIMemory.findMany({
      where: {
        userId: session.id,
        ...(category && MEMORY_CATEGORIES.includes(category as never) ? { category } : {}),
        ...(q ? { content: { contains: q } } : {}),
      },
      orderBy: [{ supersededBy: 'asc' }, { pinned: 'desc' }, { updatedAt: 'desc' }],
      take: 300,
    })
    return ok({
      memories: rows.map((m) => ({
        id: m.id, category: m.category, categoryLabel: CATEGORY_LABELS[m.category] || m.category,
        content: m.content, source: m.source, confirmed: m.confirmed, pinned: m.pinned,
        confidence: m.confidence, version: m.version, supersededBy: m.supersededBy,
        history: safeHist(m.history), createdAt: m.createdAt, updatedAt: m.updatedAt,
      })),
      categories: MEMORY_CATEGORIES.map((c) => ({ value: c, label: CATEGORY_LABELS[c] })),
    })
  })
}

function safeHist(raw: string) {
  try {
    const v = JSON.parse(raw || '[]')
    return Array.isArray(v) ? v : []
  } catch {
    return []
  }
}

/** POST — thêm memory thủ công (người dùng tự viết = đã xác nhận) */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    const body = await readJson<{ category?: string; content?: string }>(req)
    const content = String(body.content || '').trim()
    if (!content) return fail('Nhập nội dung ghi nhớ')
    const r = await addMemory(
      session.id,
      { category: String(body.category || 'fact'), content },
      'manual',
    )
    return ok({ id: r.id, superseded: r.superseded || null })
  })
}

/** DELETE /api/ai/memory?all=1 — xoá toàn bộ bộ nhớ của user */
export async function DELETE(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    if (req.nextUrl.searchParams.get('all') === '1') {
      const r = await db.aIMemory.deleteMany({ where: { userId: session.id } })
      return ok({ deleted: r.count })
    }
    throw new ApiError('Thiếu tham số all=1', 400)
  })
}
