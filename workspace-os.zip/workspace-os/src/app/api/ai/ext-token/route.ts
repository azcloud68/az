import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireSession, handle, ok, readJson, ApiError } from '@/core/server/api'
import { randomBytes } from 'crypto'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** Mã ghép nối ngắn (dùng 1 lần trong 10 phút) để extension lấy token — không cần cookie */
export interface PairCode {
  code: string
  userId: string
  expiresAt: Date
}

/** GET /api/ai/ext-token — danh sách token của user (chỉ metadata, không lộ token) */
export async function GET() {
  return handle(async () => {
    const session = await requireSession()
    const rows = await db.aIExtToken.findMany({
      where: { userId: session.id, revoked: false },
      orderBy: { createdAt: 'desc' },
      take: 20,
    })
    return ok({
      tokens: rows.map((t) => ({
        id: t.id,
        label: t.label,
        hint: `${t.token.slice(0, 6)}…${t.token.slice(-4)}`,
        createdAt: t.createdAt,
        lastUsedAt: t.lastUsedAt,
      })),
    })
  })
}

/**
 * POST /api/ai/ext-token — tạo token kết nối browser extension.
 * body: { label?, pairCode? }
 *  - Có pairCode (do user sinh trong WOS): extension đổi mã lấy token (không cần cookie).
 *  - Không pairCode: cần đăng nhập WOS → sinh token + mã ghép nối mới.
 */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const body = await readJson<{ label?: string; pairCode?: string }>(req).catch(() => ({}) as { label?: string; pairCode?: string })

    // Đường dẫn A: extension đổi pairCode lấy token (không session)
    if (body.pairCode) {
      const store = pairStore()
      const entry = store.get(String(body.pairCode))
      if (!entry) throw new ApiError('Mã ghép nối không đúng hoặc đã hết hạn', 404)
      store.delete(String(body.pairCode)) // dùng 1 lần
      if (entry.expiresAt < new Date()) throw new ApiError('Mã ghép nối đã hết hạn (10 phút)', 401)
      const token = `wosext_${randomBytes(24).toString('hex')}`
      await db.aIExtToken.create({
        data: { userId: entry.userId, token, label: String(body.label || 'Browser Extension').slice(0, 60) },
      })
      return ok({ token, note: 'Giữ token này trong storage của extension — không chia sẻ.' })
    }

    // Đường dẫn B: user đăng nhập WOS sinh mã ghép nối
    const session = await requireSession()
    if (body.pairCode !== undefined) return ok({})
    const code = randomBytes(4).toString('hex').toUpperCase() // 8 ký tự
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000)
    pairStore().set(code, { code, userId: session.id, expiresAt })
    return ok({
      pairCode: code,
      expiresInMs: 10 * 60 * 1000,
      instructions:
        'Mở popup tiện ích mở rộng trên trình duyệt → dán địa chỉ Workspace OS và mã này để ghép nối. Mã dùng 1 lần, hết hạn sau 10 phút.',
    })
  })
}

/** DELETE /api/ai/ext-token?id= — thu hồi token */
export async function DELETE(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    const id = req.nextUrl.searchParams.get('id') || ''
    const row = await db.aIExtToken.findFirst({ where: { id, userId: session.id } })
    if (!row) throw new ApiError('Token không tồn tại', 404)
    await db.aIExtToken.update({ where: { id }, data: { revoked: true } })
    return ok({ revoked: id })
  })
}

/** in-memory pair code store (đủ dùng 1 máy chủ tự host) */
function pairStore(): Map<string, PairCode> {
  const g = globalThis as unknown as { __wosAiPairStore?: Map<string, PairCode> }
  if (!g.__wosAiPairStore) g.__wosAiPairStore = new Map()
  // dọn mã hết hạn
  const now = Date.now()
  for (const [k, v] of g.__wosAiPairStore) if (v.expiresAt.getTime() < now) g.__wosAiPairStore.delete(k)
  return g.__wosAiPairStore
}
