import { handle, ok } from '@/core/server/api'
import { requireSession } from '@/core/server/api'
import { getAiSetting, resolveProviderInfo } from '@/core/server/ai/provider'
import { db } from '@/lib/db'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** GET /api/ai/status — trạng thái tổng quan: provider, model, đếm hội thoại/bộ nhớ */
export async function GET() {
  return handle(async () => {
    const session = await requireSession()
    const s = await getAiSetting(session.id)
    const info = resolveProviderInfo({ provider: s.provider, model: s.model })
    const [convCount, msgCount, memCount, pendingMem, extPending] = await Promise.all([
      db.aIConversation.count({ where: { userId: session.id } }),
      db.aIMessage.count({ where: { conversation: { userId: session.id } } }),
      db.aIMemory.count({ where: { userId: session.id, supersededBy: '' } }),
      db.aIMemory.count({ where: { userId: session.id, confirmed: false, supersededBy: '' } }),
      db.aIExternalContext.count({ where: { userId: session.id, consumed: false } }),
    ])
    return ok({
      provider: info,
      stats: { conversations: convCount, messages: msgCount, memories: memCount, pendingMemories: pendingMem, pendingExternal: extPending },
      features: {
        chat: true,
        widget: true,
        memoryManager: true,
        toolCalling: info.supportsTools,
        browserExtension: true,
      },
    })
  })
}
