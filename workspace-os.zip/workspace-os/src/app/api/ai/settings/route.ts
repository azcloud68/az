import { NextRequest } from 'next/server'
import { requireSession, handle, ok, readJson } from '@/core/server/api'
import { getAiSetting, resolveProviderInfo, safeJson, availableProviders, listProviderModels } from '@/core/server/ai/provider'
import { getProvider } from '@/core/server/ai/providers'
import { DEFAULT_SOURCES, type ContextSourceFlags } from '@/core/server/ai/context'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** GET /api/ai/settings — cài đặt AI của user + trạng thái provider (KHÔNG lộ key) */
export async function GET() {
  return handle(async () => {
    const session = await requireSession()
    const s = await getAiSetting(session.id)
    const info = resolveProviderInfo({ provider: s.provider, model: s.model })
    return ok({
      settings: {
        provider: s.provider,
        model: s.model,
        temperature: s.temperature,
        contextMode: s.contextMode,
        sources: { ...DEFAULT_SOURCES, ...safeJson<Partial<ContextSourceFlags>>(s.sources, {}) },
        maxRecentMessages: s.maxRecentMessages,
        summarizeThreshold: s.summarizeThreshold,
        memoryEnabled: s.memoryEnabled,
        memoryExtractEvery: s.memoryExtractEvery,
      },
      provider: {
        active: info.provider,
        provider: info.provider, // back-compat: client cũ đọc .provider
        model: info.model,
        hasKey: info.hasKey,
        label: info.label,
        supportsTools: info.supportsTools,
      },
      // danh sách provider động từ registry — UI tự render, thêm provider mới không cần sửa client
      providers: availableProviders(),
      models: await listProviderModels(info.provider),
    })
  })
}

/** PATCH — cập nhật cài đặt (chỉ các trường an toàn, KHÔNG nhận apiKey) */
export async function PATCH(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    await getAiSetting(session.id)
    const body = await readJson<Record<string, unknown>>(req)
    const data: Record<string, unknown> = {}
    // validate provider động theo registry (không hard-code 'xai'/'zai' nữa)
    if (typeof body.provider === 'string') {
      const pid = body.provider.trim()
      if (pid === '' || (getProvider(pid) && getProvider(pid)!.isConfigured())) data.provider = pid
    }
    if (typeof body.model === 'string') data.model = body.model.trim().slice(0, 60)
    if (typeof body.temperature === 'number') data.temperature = Math.max(0, Math.min(2, body.temperature))
    if (typeof body.contextMode === 'string' && ['auto', 'workspace', 'manual'].includes(body.contextMode)) data.contextMode = body.contextMode
    if (body.sources && typeof body.sources === 'object') {
      const src = body.sources as Record<string, unknown>
      const merged = { ...DEFAULT_SOURCES }
      for (const k of Object.keys(DEFAULT_SOURCES) as Array<keyof ContextSourceFlags>) {
        if (typeof src[k] === 'boolean') merged[k] = src[k] as boolean
      }
      data.sources = JSON.stringify(merged)
    }
    if (typeof body.maxRecentMessages === 'number') data.maxRecentMessages = Math.max(2, Math.min(30, Math.floor(body.maxRecentMessages)))
    if (typeof body.summarizeThreshold === 'number') data.summarizeThreshold = Math.max(8, Math.min(80, Math.floor(body.summarizeThreshold)))
    if (typeof body.memoryEnabled === 'boolean') data.memoryEnabled = body.memoryEnabled
    if (typeof body.memoryExtractEvery === 'number') data.memoryExtractEvery = Math.max(3, Math.min(20, Math.floor(body.memoryExtractEvery)))
    const updated = await (await import('@/lib/db')).db.aISetting.update({ where: { id: session.id }, data })
    const info = resolveProviderInfo({ provider: updated.provider, model: updated.model })
    return ok({ settings: { ...updated, sources: safeJson(updated.sources, {}) }, provider: info })
  })
}
