import { NextRequest } from 'next/server'
import { requireSession, handle, ok, fail, readJson } from '@/core/server/api'
import {
  groqProvider,
  setGroqApiKey,
  setGroqBaseUrl,
  setGroqCustomModels,
  getGroqCustomModels,
  groqKey,
  groqBaseUrl,
  GROQ_DEFAULT_MODEL,
  GROQ_KNOWN_MODELS,
} from '@/core/server/ai/providers/groq'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/**
 * QUẢN LÝ GROQ (fix lỗi 4) — chỉ ADMIN:
 *   GET                      → trạng thái: configured, key từ env hay UI, models gộp
 *   PUT { apiKey?, baseUrl?, models? }  → lưu key/baseUrl/danh sách model tuỳ chỉnh
 *   DELETE                   → xoá key nhập từ UI (giữ nguyên env nếu có)
 *   POST { action:'test' | 'fetch-models' } → thử key / lấy danh sách model trực tiếp
 *
 * Key KHÔNG bao giờ trả về client — chỉ boolean hasKey/hasEnvKey.
 */
export async function GET() {
  return handle(async () => {
    const session = await requireSession()
    if (session.role !== 'admin') return fail('Chỉ quản trị viên được quản lý cấu hình Groq', 403)
    const key = await groqKey()
    const models = await (groqProvider.listModels ? groqProvider.listModels() : Promise.resolve([]))
    return ok({
      configured: Boolean(key),
      hasKey: Boolean(key),
      hasEnvKey: Boolean((process.env.GROQ_API_KEY || '').trim()),
      baseUrl: await groqBaseUrl(),
      defaultModel: GROQ_DEFAULT_MODEL,
      models,
      customModels: await getGroqCustomModels(),
      knownModels: GROQ_KNOWN_MODELS,
    })
  })
}

export async function PUT(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    if (session.role !== 'admin') return fail('Chỉ quản trị viên được quản lý cấu hình Groq', 403)
    const body = await readJson<{ apiKey?: string; baseUrl?: string; models?: string[]; action?: string }>(req)

    if (typeof body.apiKey === 'string') {
      await setGroqApiKey(body.apiKey)
    }
    if (typeof body.baseUrl === 'string') {
      await setGroqBaseUrl(body.baseUrl)
    }
    if (Array.isArray(body.models)) {
      await setGroqCustomModels(body.models.map(String))
    }
    const key = await groqKey()
    return ok({
      configured: Boolean(key),
      hasKey: Boolean(key),
      hasEnvKey: Boolean((process.env.GROQ_API_KEY || '').trim()),
      baseUrl: await groqBaseUrl(),
      models: await (groqProvider.listModels ? groqProvider.listModels() : Promise.resolve([])),
      customModels: await getGroqCustomModels(),
    })
  })
}

export async function DELETE() {
  return handle(async () => {
    const session = await requireSession()
    if (session.role !== 'admin') return fail('Chỉ quản trị viên được quản lý cấu hình Groq', 403)
    await setGroqApiKey('')
    return ok({ configured: Boolean((process.env.GROQ_API_KEY || '').trim()), hasKey: false })
  })
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    if (session.role !== 'admin') return fail('Chỉ quản trị viên được quản lý cấu hình Groq', 403)
    const body = await readJson<{ action?: string; model?: string }>(req)

    if (body.action === 'test') {
      const key = await groqKey()
      if (!key) return fail('Chưa có API key Groq')
      try {
        const res = await fetch(`${await groqBaseUrl()}/chat/completions`, {
          method: 'POST',
          headers: { 'content-type': 'application/json', authorization: `Bearer ${key}` },
          body: JSON.stringify({
            model: body.model || GROQ_DEFAULT_MODEL,
            messages: [{ role: 'user', content: 'Trả lời đúng 1 từ: OK' }],
            max_tokens: 8,
          }),
          signal: AbortSignal.timeout(30_000),
        })
        if (!res.ok) {
          const text = await res.text().catch(() => '')
          return fail(`Groq trả về ${res.status}: ${text.slice(0, 200)}`)
        }
        const json = (await res.json()) as { choices?: Array<{ message?: { content?: string } }> }
        return ok({ ok: true, reply: json.choices?.[0]?.message?.content || '' })
      } catch (err) {
        return fail(`Không kết nối được Groq: ${err instanceof Error ? err.message : ''}`)
      }
    }

    if (body.action === 'fetch-models') {
      const key = await groqKey()
      if (!key) return fail('Chưa có API key Groq')
      try {
        const res = await fetch(`${await groqBaseUrl()}/models`, {
          headers: { authorization: `Bearer ${key}` },
          signal: AbortSignal.timeout(20_000),
        })
        if (!res.ok) return fail(`Groq trả về ${res.status}`)
        const json = (await res.json()) as { data?: Array<{ id?: string }> }
        const ids = (json.data || []).map((m) => m.id || '').filter(Boolean)
        return ok({ models: ids })
      } catch (err) {
        return fail(`Không lấy được danh sách model: ${err instanceof Error ? err.message : ''}`)
      }
    }

    return fail('Action không hợp lệ (dùng: test | fetch-models)')
  })
}
