import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireSession, handle, ok, readJson, ApiError } from '@/core/server/api'
import { getAiSetting } from '@/core/server/ai/provider'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** GET /api/ai/conversations — danh sách hội thoại của user + active conversation */
export async function GET() {
  return handle(async () => {
    const session = await requireSession()
    const setting = await getAiSetting(session.id)
    const rows = await db.aIConversation.findMany({
      where: { userId: session.id, archived: false },
      orderBy: { updatedAt: 'desc' },
      take: 60,
      select: {
        id: true, title: true, summary: true, messageCount: true, createdAt: true, updatedAt: true,
      },
    })
    return ok({ conversations: rows, activeConversationId: setting.activeConversationId })
  })
}

/** POST /api/ai/conversations — tạo hội thoại mới + đặt làm active (widget/app dùng chung) */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    const body = await readJson<{ title?: string }>(req).catch(() => ({ title: '' }))
    const title = String(body.title || 'Hội thoại mới').slice(0, 80)
    const conv = await db.aIConversation.create({ data: { userId: session.id, title } })
    await db.aISetting.update({ where: { id: session.id }, data: { activeConversationId: conv.id } })
    return ok({ conversation: conv, activeConversationId: conv.id })
  })
}

/** PATCH /api/ai/conversations — đổi active conversation (đồng bộ widget ↔ chat app) */
export async function PATCH(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    const body = await readJson<{ activeConversationId?: string }>(req)
    const id = String(body.activeConversationId || '')
    if (id) {
      const conv = await db.aIConversation.findFirst({ where: { id, userId: session.id }, select: { id: true } })
      if (!conv) throw new ApiError('Hội thoại không tồn tại', 404)
    }
    await db.aISetting.update({ where: { id: session.id }, data: { activeConversationId: id } })
    return ok({ activeConversationId: id })
  })
}
