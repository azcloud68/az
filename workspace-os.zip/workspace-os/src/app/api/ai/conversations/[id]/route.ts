import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireSession, handle, ok, fail, readJson, ApiError } from '@/core/server/api'
import { getAiSetting } from '@/core/server/ai/provider'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/** GET /api/ai/conversations/[id] — toàn bộ tin nhắn của hội thoại (của chính user) */
export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireSession()
    const { id } = await ctx.params
    const conv = await db.aIConversation.findFirst({ where: { id, userId: session.id } })
    if (!conv) throw new ApiError('Hội thoại không tồn tại', 404)
    const messages = await db.aIMessage.findMany({
      where: { conversationId: id },
      orderBy: { createdAt: 'asc' },
      take: 500,
    })
    return ok({
      conversation: { id: conv.id, title: conv.title, summary: conv.summary, messageCount: conv.messageCount, updatedAt: conv.updatedAt },
      messages: messages.map((m) => ({ id: m.id, role: m.role, content: m.content, meta: safeMeta(m.meta), createdAt: m.createdAt })),
    })
  })
}

function safeMeta(raw: string) {
  try {
    return JSON.parse(raw || '{}')
  } catch {
    return {}
  }
}

/** PATCH — đổi tên / lưu trữ */
export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireSession()
    const { id } = await ctx.params
    const conv = await db.aIConversation.findFirst({ where: { id, userId: session.id }, select: { id: true } })
    if (!conv) throw new ApiError('Hội thoại không tồn tại', 404)
    const body = await readJson<{ title?: string; archived?: boolean; activate?: boolean }>(req)
    const data: Record<string, unknown> = {}
    if (typeof body.title === 'string' && body.title.trim()) data.title = body.title.trim().slice(0, 80)
    if (typeof body.archived === 'boolean') data.archived = body.archived
    const updated = await db.aIConversation.update({ where: { id }, data })
    if (body.activate) await db.aISetting.update({ where: { id: session.id }, data: { activeConversationId: id } })
    return ok({ conversation: updated })
  })
}

/** DELETE — xoá hội thoại (cascade messages). Nếu là active → xoá luôn tham chiếu */
export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = await requireSession()
    const { id } = await ctx.params
    const conv = await db.aIConversation.findFirst({ where: { id, userId: session.id }, select: { id: true } })
    if (!conv) return fail('Hội thoại không tồn tại', 404)
    await db.aIConversation.delete({ where: { id } })
    const setting = await getAiSetting(session.id)
    if (setting.activeConversationId === id) {
      await db.aISetting.update({ where: { id: session.id }, data: { activeConversationId: '' } })
    }
    return ok({ deleted: id })
  })
}
