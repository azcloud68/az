import { NextRequest } from 'next/server'
import { requireSession, handle, ok, readJson } from '@/core/server/api'
import { collectContext, DEFAULT_SOURCES, type ContextSourceFlags, type ActiveContextPayload } from '@/core/server/ai/context'
import { getAiSetting, safeJson } from '@/core/server/ai/provider'
import { retrieveRelevantMemories } from '@/core/server/ai/memory'
import { getUserTimezone, isoDateInTz } from '@/core/server/datetime'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/**
 * POST /api/ai/context/preview — XEM TRƯỚC dữ liệu sẽ gửi cho AI (trung minh):
 * người dùng kiểm tra nguồn nào bật, bao nhiêu bản ghi, nội dung gì — trước khi gửi.
 */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    const body = await readJson<{
      question?: string
      sources?: Partial<ContextSourceFlags>
      activeContext?: ActiveContextPayload
    }>(req)
    const setting = await getAiSetting(session.id)
    const flags: ContextSourceFlags = {
      ...DEFAULT_SOURCES,
      ...safeJson<Partial<ContextSourceFlags>>(setting.sources, {}),
      ...(body.sources || {}),
    }
    const { context, used, skipped } = await collectContext(session, flags, body.activeContext)
    const question = String(body.question || '')
    const memories = question ? await retrieveRelevantMemories(session.id, question, 10) : []
    const tz = await getUserTimezone()
    // đếm bản ghi mỗi nguồn
    const counts: Record<string, number> = {}
    for (const key of Object.keys(context) as Array<keyof typeof context>) {
      const v = context[key] as { count?: number; tasks?: unknown[]; events?: unknown[]; days?: unknown[]; projects?: unknown[]; openApps?: unknown[] } | undefined
      if (!v) continue
      counts[key] =
        typeof v.count === 'number' ? v.count
        : Array.isArray(v.tasks) ? v.tasks.length
        : Array.isArray(v.events) ? v.events.length
        : Array.isArray(v.projects) ? v.projects.length
        : Array.isArray(v.days) ? v.days.length
        : Array.isArray(v.openApps) ? v.openApps.length
        : 1
    }
    return ok({
      today: isoDateInTz(new Date(), tz),
      sources: { enabled: flags, used, skipped },
      counts,
      context,
      memories: memories.map((m) => ({ category: m.category, content: m.content, confirmed: m.confirmed })),
      approxChars: JSON.stringify(context).length,
    })
  })
}
