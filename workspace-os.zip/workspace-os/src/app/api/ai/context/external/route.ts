import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireSession, handle, ok, readJson, ApiError } from '@/core/server/api'
import { checkRate } from '@/core/server/rate-limit'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const MAX_CONTENT = 32 * 1024 // 32KB mỗi context

/** Xác thực extension qua Bearer token (không dùng cookie session) */
async function authExtToken(req: NextRequest): Promise<{ userId: string; tokenId: string } | null> {
  const auth = req.headers.get('authorization') || ''
  const token = auth.startsWith('Bearer ') ? auth.slice(7).trim() : ''
  if (!token.startsWith('wosext_')) return null
  const row = await db.aIExtToken.findUnique({ where: { token } })
  if (!row || row.revoked) return null
  await db.aIExtToken.update({ where: { id: row.id }, data: { lastUsedAt: new Date() } })
  return { userId: row.userId, tokenId: row.id }
}

/**
 * POST /api/ai/context/external (GĐ4) — extension gửi nội dung tab về WOS.
 * Auth: Bearer wosext_… (token user cấp). Dữ liệu lưu KHÔNG đáng tin — prompt luôn gắn nhãn.
 */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const ext = await authExtToken(req)
    if (!ext) throw new ApiError('Token tiện ích mở rộng không hợp lệ hoặc đã thu hồi', 401)
    if (!checkRate(`ai:ext:${ext.userId}`, 20, 60_000)) throw new ApiError('Gửi quá nhanh (giới hạn 20 context/phút)', 429)

    const body = await readJson<{
      url?: string
      title?: string
      content?: string
      selectionOnly?: boolean
    }>(req)
    const url = String(body.url || '').slice(0, 500)
    const title = String(body.title || '').slice(0, 200)
    const content = String(body.content || '').slice(0, MAX_CONTENT)
    if (!content.trim()) throw new ApiError('Thiếu nội dung context', 400)
    let site = ''
    try {
      site = new URL(url).hostname
    } catch {
      site = ''
    }
    const row = await db.aIExternalContext.create({
      data: {
        userId: ext.userId,
        url,
        title,
        content,
        selectionOnly: Boolean(body.selectionOnly),
        site,
      },
    })
    return ok({
      id: row.id,
      note: 'Đã nhận context (đánh dấu KHÔNG đáng tin). Mở WOS AI Assistant để hỏi kèm nội dung này.',
    })
  })
}

/** GET — user xem các context external đang chờ (session auth) */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    const sp = req.nextUrl.searchParams
    const all = sp.get('all') === '1'
    const rows = await db.aIExternalContext.findMany({
      where: { userId: session.id, ...(all ? {} : { consumed: false }) },
      orderBy: { createdAt: 'desc' },
      take: 50,
    })
    return ok({
      contexts: rows.map((r) => ({
        id: r.id, url: r.url, title: r.title, site: r.site,
        excerpt: r.content.slice(0, 300), chars: r.content.length,
        selectionOnly: r.selectionOnly, consumed: r.consumed, createdAt: r.createdAt,
      })),
    })
  })
}

/** DELETE /api/ai/context/external?id= — xoá context chờ */
export async function DELETE(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    const id = req.nextUrl.searchParams.get('id') || ''
    const row = await db.aIExternalContext.findFirst({ where: { id, userId: session.id } })
    if (!row) throw new ApiError('Context không tồn tại', 404)
    await db.aIExternalContext.delete({ where: { id } })
    return ok({ deleted: id })
  })
}
