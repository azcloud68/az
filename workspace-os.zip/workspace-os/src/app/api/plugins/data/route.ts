import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireSession, handle, ok, fail, readJson } from '@/core/server/api'
import { PLUGIN_DATA_LIMITS } from '@/core/server/plugins'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/**
 * KHO DỮ LIỆU PLUGIN (PluginRecord — namespace theo pluginId):
 *   GET    /api/plugins/data?plugin=<id>&key=<key>   → { value } (JSON string)
 *   GET    /api/plugins/data?plugin=<id>             → { entries: [{key, value}] } (liệt kê)
 *   PUT    {plugin, key, value}                      → lưu (JSON string ≤ 256KB, tổng ≤ 10MB)
 *   DELETE ?plugin=<id>&key=<key>                    → xoá 1 key
 *   DELETE ?plugin=<id>&all=1                        → xoá sạch dữ liệu plugin
 * Chỉ thao tác trên plugin đang bật + khai báo permission "storage".
 */
async function requireStoragePlugin(pluginId: string) {
  const plugin = await db.plugin.findUnique({ where: { id: pluginId } })
  if (!plugin) throw Object.assign(new Error('Plugin không tồn tại'), { status: 404 })
  if (!plugin.enabled) throw Object.assign(new Error('Plugin đang tắt'), { status: 403 })
  let perms: string[] = []
  try { perms = JSON.parse(plugin.permissions || '[]') } catch { /* [] */ }
  if (!perms.includes('storage')) throw Object.assign(new Error('Plugin chưa khai báo permission "storage"'), { status: 403 })
  return plugin
}

export async function GET(req: NextRequest) {
  return handle(async () => {
    await requireSession()
    const sp = req.nextUrl.searchParams
    const pluginId = sp.get('plugin') || ''
    const key = sp.get('key') || ''
    if (!pluginId) return fail('Thiếu ?plugin=<id>')
    await requireStoragePlugin(pluginId)
    if (key) {
      const row = await db.pluginRecord.findUnique({ where: { id: `${pluginId}:${key}` } })
      return ok({ key, value: row?.value ?? null })
    }
    const rows = await db.pluginRecord.findMany({ where: { pluginId }, orderBy: { updatedAt: 'desc' }, take: 500 })
    return ok({ entries: rows.map((r) => ({ key: r.key, value: r.value, updatedAt: r.updatedAt })) })
  })
}

export async function PUT(req: NextRequest) {
  return handle(async () => {
    await requireSession()
    const body = await readJson<{ plugin?: string; key?: string; value?: string }>(req)
    const pluginId = String(body.plugin || '')
    const key = String(body.key || '')
    if (!pluginId || !key) return fail('Thiếu plugin hoặc key')
    await requireStoragePlugin(pluginId)
    const value = String(body.value ?? '')
    if (Buffer.byteLength(value) > PLUGIN_DATA_LIMITS.maxValue) {
      return fail('Giá trị vượt 256KB — hãy tách nhỏ dữ liệu', 413)
    }
    // quota tổng theo plugin (cột size theo dõi byte của mỗi value)
    const agg = await db.pluginRecord.aggregate({ where: { pluginId }, _sum: { size: true } })
    const total = agg._sum.size || 0
    const existing = await db.pluginRecord.findUnique({ where: { id: `${pluginId}:${key}` } })
    const existingLen = existing?.size || 0
    if (total - existingLen + Buffer.byteLength(value) > PLUGIN_DATA_LIMITS.maxTotal) {
      return fail('Dữ liệu plugin vượt 10MB — hãy dọn bớt', 413)
    }
    await db.pluginRecord.upsert({
      where: { id: `${pluginId}:${key}` },
      update: { value, size: Buffer.byteLength(value), updatedAt: new Date() },
      create: { id: `${pluginId}:${key}`, pluginId, key, value, size: Buffer.byteLength(value) },
    })
    return ok({ ok: true })
  })
}

export async function DELETE(req: NextRequest) {
  return handle(async () => {
    await requireSession()
    const sp = req.nextUrl.searchParams
    const pluginId = sp.get('plugin') || ''
    const key = sp.get('key') || ''
    if (!pluginId) return fail('Thiếu ?plugin=<id>')
    await requireStoragePlugin(pluginId)
    if (sp.get('all') === '1') {
      const n = await db.pluginRecord.deleteMany({ where: { pluginId } })
      return ok({ deleted: n.count })
    }
    if (!key) return fail('Thiếu ?key=<key> (hoặc ?all=1 để xoá sạch)')
    await db.pluginRecord.deleteMany({ where: { pluginId, key } })
    return ok({ ok: true })
  })
}
