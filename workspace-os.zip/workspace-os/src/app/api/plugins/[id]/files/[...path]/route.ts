import { NextRequest, NextResponse } from 'next/server'
import { requireSession, handle } from '@/core/server/api'
import { pluginAssetPath } from '@/core/server/plugins'
import { promises as fsp } from 'fs'
import path from 'path'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const CONTENT_TYPES: Record<string, string> = {
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  '.ico': 'image/x-icon',
  '.html': 'text/html; charset=utf-8',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
}

/**
 * GET /api/plugins/[id]/files/[...path] — phục vụ asset của plugin (main.js, icon…).
 * Session bắt buộc (script tag same-origin vẫn gửi cookie) → không cho người lạ tải bundle.
 */
export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string; path: string[] }> }) {
  return handle(async () => {
    await requireSession()
    const { id, path: parts } = await ctx.params
    const rel = (parts || []).join('/')
    if (!rel || rel.includes('..')) return NextResponse.json({ error: 'Đường dẫn không hợp lệ' }, { status: 400 })

    let full: string
    try {
      full = pluginAssetPath(id, rel)
    } catch {
      return NextResponse.json({ error: 'Đường dẫn không hợp lệ' }, { status: 400 })
    }
    let buf: Buffer
    try {
      buf = await fsp.readFile(full)
    } catch {
      return NextResponse.json({ error: 'Không tìm thấy tài nguyên plugin' }, { status: 404 })
    }
    const type = CONTENT_TYPES[path.extname(full).toLowerCase()] || 'application/octet-stream'
    return new NextResponse(new Uint8Array(buf), {
      headers: {
        'content-type': type,
        // entry JS đổi theo version → cache dài an toàn (URL có ?v=)
        'cache-control': 'private, max-age=3600',
      },
    })
  })
}
