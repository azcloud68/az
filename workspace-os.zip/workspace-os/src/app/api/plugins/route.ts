import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireSession, requireAdmin, handle, ok, fail, readJson } from '@/core/server/api'
import { emitEvent } from '@/core/server/event-bus'
import { installPlugin, uninstallPlugin, pluginRowToJson } from '@/core/server/plugins'
import { promises as fsp } from 'fs'
import path from 'path'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/**
 * GET /api/plugins — danh sách plugin đã cài (kèm manifest parse sẵn)
 * POST /api/plugins — CÀI plugin (multipart file .wos/.zip, admin)
 * PATCH /api/plugins — {id, enabled} bật/tắt (admin)
 * DELETE /api/plugins — {id} gỡ (admin) — dùng body JSON (không path param để tránh xung đột)
 */
export async function GET() {
  return handle(async () => {
    await requireSession()
    const rows = await db.plugin.findMany({ orderBy: { installedAt: 'asc' } })
    return ok({ plugins: rows.map(pluginRowToJson) })
  })
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireAdmin()
    let form: FormData
    try {
      form = await req.formData()
    } catch {
      return fail('Không đọc được gói tải lên (multipart)', 400)
    }
    const file = form.get('file')
    if (!(file instanceof File)) return fail('Thiếu file gói plugin (trường "file")', 400)
    if (!/\.(wos|zip)$/i.test(file.name || '')) return fail('Gói plugin phải là .wos hoặc .zip', 400)

    // ghi ra file tạm trong plugins/ rồi install
    const tmp = path.join(process.env.STORAGE_ROOT || path.resolve(process.cwd(), 'storage'), 'plugins', `.wos_pkg_${Date.now()}.zip`)
    await fsp.mkdir(path.dirname(tmp), { recursive: true })
    await fsp.writeFile(tmp, Buffer.from(await file.arrayBuffer()))
    try {
      const { plugin, manifest } = await installPlugin(tmp)
      await emitEvent({
        type: 'plugin.installed',
        module: 'core',
        actor: { id: session.id, displayName: session.displayName },
        payload: { title: manifest.name, version: manifest.version },
        targetId: manifest.id,
        targetType: 'plugin',
        notify: { title: 'Đã cài ứng dụng bổ sung', content: `${manifest.name} v${manifest.version}`, action: 'settings:apps' },
      })
      return ok({ ok: true, plugin: pluginRowToJson(plugin as Parameters<typeof pluginRowToJson>[0]) })
    } finally {
      await fsp.rm(tmp, { force: true })
    }
  })
}

export async function PATCH(req: NextRequest) {
  return handle(async () => {
    const session = await requireAdmin()
    const body = await readJson<{ id?: string; enabled?: boolean }>(req)
    const id = String(body.id || '')
    if (!id) return fail('Thiếu id plugin')
    const existing = await db.plugin.findUnique({ where: { id } })
    if (!existing) return fail('Plugin không tồn tại', 404)
    const enabled = body.enabled !== false
    await db.plugin.update({ where: { id }, data: { enabled } })
    await emitEvent({
      type: enabled ? 'plugin.enabled' : 'plugin.disabled',
      module: 'core',
      actor: { id: session.id, displayName: session.displayName },
      payload: { title: existing.name },
      targetId: id,
      targetType: 'plugin',
    })
    return ok({ ok: true, enabled })
  })
}

export async function DELETE(req: NextRequest) {
  return handle(async () => {
    const session = await requireAdmin()
    const body = await readJson<{ id?: string }>(req)
    const id = String(body.id || '')
    if (!id) return fail('Thiếu id plugin')
    const existing = await db.plugin.findUnique({ where: { id } })
    if (!existing) return fail('Plugin không tồn tại', 404)
    await uninstallPlugin(id)
    await emitEvent({
      type: 'plugin.uninstalled',
      module: 'core',
      actor: { id: session.id, displayName: session.displayName },
      payload: { title: existing.name },
      targetType: 'plugin',
    })
    return ok({ ok: true })
  })
}
