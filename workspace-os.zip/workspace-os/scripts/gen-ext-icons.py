#!/usr/bin/env python3
"""Sinh icon cho WOS AI Bridge — nền tím gradient + chữ 'AI' trắng"""
from PIL import Image, ImageDraw, ImageFont
import os

OUT = '/home/z/my-project/browser-extension/icons'
os.makedirs(OUT, exist_ok=True)

FONT_CANDIDATES = [
    '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
    '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf',
    '/usr/share/fonts/truetype/freefont/FreeSansBold.ttf',
]
font_path = next((f for f in FONT_CANDIDATES if os.path.exists(f)), None)

def make(size):
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    r = size * 0.22
    # gradient tím dọc
    top = (139, 92, 246, 255)
    bottom = (99, 102, 241, 255)
    grad = Image.new('RGBA', (size, size))
    gd = ImageDraw.Draw(grad)
    for y in range(size):
        t = y / max(1, size - 1)
        c = tuple(int(top[i] + (bottom[i] - top[i]) * t) for i in range(3)) + (255,)
        gd.line([(0, y), (size, y)], fill=c)
    mask = Image.new('L', (size, size), 0)
    md = ImageDraw.Draw(mask)
    md.rounded_rectangle([0, 0, size, size], radius=r, fill=255)
    img.paste(grad, (0, 0), mask)
    # chữ AI
    if font_path:
        fsize = int(size * 0.5)
        font = ImageFont.truetype(font_path, fsize)
        bbox = d.textbbox((0, 0), 'AI', font=font)
        w, h = bbox[2] - bbox[0], bbox[3] - bbox[1]
        d.text(((size - w) / 2 - bbox[0], (size - h) / 2 - bbox[1]), 'AI', font=font, fill=(255, 255, 255, 255))
    else:
        d.ellipse([size*0.3, size*0.3, size*0.7, size*0.7], fill=(255, 255, 255, 255))
    img.save(f'{OUT}/icon{size}.png')
    print('saved', size)

for s in (16, 48, 128):
    make(s)
print('done')
