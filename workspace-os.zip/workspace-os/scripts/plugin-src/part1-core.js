/* ============================================================
 * WOS AI Assistant — main.js (plugin entry)
 * Chat App + Desktop Widget dùng CHUNG một bộ não:
 *   - cùng conversation ID (activeConversationId lưu server — AISetting)
 *   - cùng module-scope store (một plugin = một JS context)
 * Backend: /api/ai/* (proxy Grok phía server — plugin KHÔNG giữ API key)
 * ============================================================ */
'use strict'

var h = WOS.h, Fragment = WOS.Fragment
var useState = WOS.useState, useEffect = WOS.useEffect, useRef = WOS.useRef, useMemo = WOS.useMemo, useCallback = WOS.useCallback
var api = WOS.api, bus = WOS.bus

/* ---------- tiện ích chung ---------- */

function cx() {
  var out = []
  for (var i = 0; i < arguments.length; i++) {
    var a = arguments[i]
    if (!a) continue
    if (typeof a === 'string') out.push(a)
    else if (typeof a === 'object') for (var k in a) if (a[k]) out.push(k)
  }
  return out.join(' ')
}

function fmtTime(ts) {
  if (!ts) return ''
  var d = new Date(ts)
  return d.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })
}

function fmtDate(ts) {
  if (!ts) return ''
  var d = new Date(ts)
  return d.toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit' })
}

var SOURCE_DEFS = [
  { key: 'tasks', icon: '📋', name: 'Công việc', desc: 'Việc còn tồn, mức ưu tiên, hạn chót' },
  { key: 'calendar', icon: '📅', name: 'Lịch', desc: 'Sự kiện ±1 tuần' },
  { key: 'weekly', icon: '🗓️', name: 'Việc tuần', desc: 'Tiến độ từng ngày trong tuần' },
  { key: 'projects', icon: '📁', name: 'Dự án', desc: 'Dự án đang chạy' },
  { key: 'activeWindow', icon: '🪟', name: 'App đang mở', desc: 'Cửa sổ đang xem trên desktop' },
  { key: 'external', icon: '🌐', name: 'Tab ngoài', desc: 'Context extension gửi (không đáng tin)' },
]

var CAT_META = {
  preference: { label: 'Sở thích', color: '#d97706', bg: 'oklch(0.75 0.14 70 / 15%)' },
  project: { label: 'Dự án', color: '#2563eb', bg: 'oklch(0.62 0.15 255 / 14%)' },
  decision: { label: 'Quyết định', color: '#7c3aed', bg: 'oklch(0.62 0.17 290 / 14%)' },
  pending: { label: 'Chưa xong', color: '#dc2626', bg: 'oklch(0.62 0.19 25 / 13%)' },
  fact: { label: 'Thông tin', color: '#059669', bg: 'oklch(0.7 0.13 160 / 14%)' },
}

/* ============================================================
 * MARKDOWN-LITE — render an toàn bằng React elements (không innerHTML)
 * Hỗ trợ: heading, bold, italic, code inline, code block, danh sách,
 *          bảng, blockquote, link, hr
 * ============================================================ */

var INLINE_RE = /(\*\*[^*]+\*\*|\*[^*\n]+\*|`[^`\n]+`|\[[^\]]+\]\([^)\s]+\))/

function inlineNodes(s) {
  var parts = String(s).split(INLINE_RE)
  var nodes = []
  for (var i = 0; i < parts.length; i++) {
    var p = parts[i]
    if (!p) continue
    if (p.indexOf('**') === 0 && p.length > 4) {
      nodes.push(h('strong', { key: i }, p.slice(2, -2)))
    } else if (p.indexOf('*') === 0 && p.length > 2) {
      nodes.push(h('em', { key: i }, p.slice(1, -1)))
    } else if (p.indexOf('`') === 0 && p.length > 2) {
      nodes.push(h('code', { key: i }, p.slice(1, -1)))
    } else if (p.indexOf('[') === 0) {
      var m = /\[([^\]]+)\]\(([^)\s]+)\)/.exec(p)
      if (m) nodes.push(h('a', { key: i, href: m[2], target: '_blank', rel: 'noreferrer' }, m[1]))
      else nodes.push(p)
    } else {
      nodes.push(p)
    }
  }
  return nodes
}

function textBlocks(src) {
  var lines = String(src).split('\n')
  var out = []
  var i = 0
  var key = 0
  function K() { return 'b' + key++ }
  while (i < lines.length) {
    var line = lines[i]
    if (!line.trim()) { i++; continue }
    // heading
    var hm = /^(#{1,4})\s+(.*)$/.exec(line)
    if (hm) {
      var lv = Math.min(4, hm[1].length)
      out.push(h('h' + lv, { key: K() }, inlineNodes(hm[2])))
      i++
      continue
    }
    // hr
    if (/^(\s*[-*_]){3,}\s*$/.test(line)) { out.push(h('hr', { key: K() })); i++; continue }
    // blockquote
    if (/^>\s?/.test(line)) {
      var q = []
      while (i < lines.length && /^>\s?/.test(lines[i])) { q.push(lines[i].replace(/^>\s?/, '')); i++ }
      out.push(h('blockquote', { key: K() }, inlineNodes(q.join(' '))))
      continue
    }
    // bảng
    if (/\|/.test(line) && i + 1 < lines.length && /^\s*\|?[\s:|-]+\|[\s:|-]*$/.test(lines[i + 1])) {
      var rows = []
      while (i < lines.length && /\|/.test(lines[i]) && lines[i].trim()) { rows.push(lines[i]); i++ }
      if (rows.length >= 2) {
        var parse = function (r) {
          return r.replace(/^\s*\|/, '').replace(/\|\s*$/, '').split('|').map(function (c) { return c.trim() })
        }
        var head = parse(rows[0])
        var body = rows.slice(2).map(parse)
        out.push(
          h('table', { key: K() },
            h('thead', null, h('tr', null, head.map(function (c, ci) { return h('th', { key: ci }, inlineNodes(c)) }))),
            h('tbody', null, body.map(function (r, ri) {
              return h('tr', { key: ri }, r.map(function (c, ci) { return h('td', { key: ci }, inlineNodes(c)) }))
            }))
          )
        )
        continue
      }
    }
    // danh sách không thứ tự
    if (/^\s*[-*+]\s+/.test(line)) {
      var items = []
      while (i < lines.length && /^\s*[-*+]\s+/.test(lines[i])) { items.push(lines[i].replace(/^\s*[-*+]\s+/, '')); i++ }
      out.push(h('ul', { key: K() }, items.map(function (t, ii) { return h('li', { key: ii }, inlineNodes(t)) })))
      continue
    }
    // danh sách có thứ tự
    if (/^\s*\d+[.)]\s+/.test(line)) {
      var ol = []
      while (i < lines.length && /^\s*\d+[.)]\s+/.test(lines[i])) { ol.push(lines[i].replace(/^\s*\d+[.)]\s+/, '')); i++ }
      out.push(h('ol', { key: K() }, ol.map(function (t, ii) { return h('li', { key: ii }, inlineNodes(t)) })))
      continue
    }
    // đoạn văn — gộp các dòng liền
    var para = [line]
    i++
    while (
      i < lines.length && lines[i].trim() &&
      !/^(#{1,4}\s|>\s?|\s*[-*+]\s|\s*\d+[.)]\s)/.test(lines[i]) &&
      !/^(\s*[-*_]){3,}\s*$/.test(lines[i])
    ) { para.push(lines[i]); i++ }
    out.push(h('p', { key: K() }, inlineNodes(para.join(' '))))
  }
  return out
}

function renderMarkdown(text) {
  var src = String(text || '')
  var out = []
  var parts = src.split(/```/)
  for (var i = 0; i < parts.length; i++) {
    if (i % 2 === 0) {
      var blocks = textBlocks(parts[i])
      for (var j = 0; j < blocks.length; j++) out.push(blocks[j])
    } else {
      var code = parts[i]
      var nl = code.indexOf('\n')
      var lang = ''
      if (nl > 0 && /^[a-z0-9+#-]*$/i.test(code.slice(0, nl).trim())) {
        lang = code.slice(0, nl).trim()
        code = code.slice(nl + 1)
      }
      code = code.replace(/\n$/, '')
      out.push(
        h('pre', { key: 'code' + i },
          lang ? h('code', { 'data-lang': lang }, code) : h('code', null, code))
      )
    }
  }
  return out
}

/** bản thu gọn cho widget — bỏ markdown, chỉ text + cắt dài */
function plainPreview(text, max) {
  var s = String(text || '')
    .replace(/```[\s\S]*?```/g, ' [code] ')
    .replace(/[#*_>`|]/g, '')
    .replace(/\[(.*?)\]\(.*?\)/g, '$1')
    .replace(/\s+/g, ' ')
    .trim()
  if (s.length > (max || 220)) s = s.slice(0, max || 220) + '…'
  return s
}

/* ============================================================
 * SHARED STORE — bộ não chung của Chat App + Widget
 * (cùng 1 plugin runtime → cùng module scope)
 * ============================================================ */

var store = {
  loaded: false,        // đã boot dữ liệu chưa
  conversations: [],
  activeId: '',         // conversation đang mở (đồng bộ server AISetting)
  messages: [],         // messages của activeId
  settings: null,       // /api/ai/settings
  provider: null,
  status: null,
  busy: false,
  phase: '',
  error: '',
  lastMeta: null,       // meta câu trả lời gần nhất (nguồn + tools)
  mode: 'auto',         // auto | workspace | manual
  compat: null,         // {missing:true} khi máy chủ KHÔNG có AI backend (/api/ai/* 404)
  providers: [],        // danh sách provider động (từ server registry)
  models: [],           // model khả dụng của provider đang chọn
  sources: { tasks: true, calendar: true, weekly: true, projects: false, activeWindow: true, external: true },
  preview: null,        // kết quả preview context
  external: [],         // external contexts chờ dùng
  listeners: [],
}

function notifyStore() {
  for (var i = 0; i < store.listeners.length; i++) {
    try { store.listeners[i]() } catch (e) { /* ignore */ }
  }
}

/** hook — đăng ký re-render khi store đổi */
function useAiStore() {
  var r = useState(0)
  var force = r[1]
  useEffect(function () {
    function fn() { force(function (n) { return n + 1 }) }
    store.listeners.push(fn)
    return function () {
      var idx = store.listeners.indexOf(fn)
      if (idx >= 0) store.listeners.splice(idx, 1)
    }
  }, [])
  return store
}

/** boot 1 lần — cả widget lẫn app gọi, ai tới trước boot trước */
function ensureBoot() {
  if (store.loaded) return Promise.resolve()
  store.loaded = true
  return refreshAll()
}

function refreshAll() {
  return Promise.all([loadSettings(), loadConversations(), loadStatus(), loadExternal()])
    .then(function () { store.compat = null; notifyStore() })
    .catch(function (e) {
      var msg = (e && e.message) || ''
      // 404 từ /api/ai/* → máy chủ đang chạy bản Workspace OS CHƯA có AI backend
      if (e && (e.status === 404 || /HTTP 404/i.test(msg))) {
        store.compat = {
          missing: true,
          detail: 'Máy chủ Workspace OS này chưa có AI backend — mọi API /api/ai/* trả về 404.',
        }
      } else {
        store.error = msg
      }
      notifyStore()
    })
}

function loadSettings() {
  return api('/api/ai/settings').then(function (res) {
    store.settings = res.settings
    store.provider = res.provider
    store.providers = res.providers || []   // danh sách provider động từ registry server
    store.models = res.models || []          // model khả dụng của provider đang chọn
    if (res.settings && res.settings.contextMode) store.mode = res.settings.contextMode
    if (res.settings && res.settings.sources) {
      for (var k in store.sources) {
        if (typeof res.settings.sources[k] === 'boolean') store.sources[k] = res.settings.sources[k]
      }
    }
  })
}

function loadConversations() {
  return api('/api/ai/conversations').then(function (res) {
    store.conversations = res.conversations || []
    var active = res.activeConversationId || ''
    var exists = store.conversations.some(function (c) { return c.id === active })
    // chỉ nhận active từ server khi đang KHÔNG trong phiên gửi (tránh đè activeId vừa đặt)
    if (!store.busy) store.activeId = exists ? active : store.activeId
    if (store.activeId && store.messages.length === 0) return loadMessages(store.activeId)
  })
}

function loadMessages(id) {
  if (!id) { store.messages = []; notifyStore(); return Promise.resolve() }
  return api('/api/ai/conversations/' + encodeURIComponent(id)).then(function (res) {
    // tránh đè hội thoại đã chuyển sang khác
    if (store.activeId !== id) return
    store.messages = res.messages || []
    var last = store.messages[store.messages.length - 1]
    store.lastMeta = last && last.role === 'assistant' ? last.meta : store.lastMeta
    notifyStore()
  })
}

function loadStatus() {
  return api('/api/ai/status').then(function (res) { store.status = res })
}

function loadExternal() {
  return api('/api/ai/context/external').then(function (res) { store.external = res.contexts || [] })
}

function setActiveConversation(id, silent) {
  store.activeId = id || ''
  store.messages = []
  store.lastMeta = null
  store.preview = null
  notifyStore()
  var p = api('/api/ai/conversations', { method: 'PATCH', body: { activeConversationId: id || '' } })
    .catch(function () { return null })
  if (id) loadMessages(id)
  return p
}

function newConversation() {
  return api('/api/ai/conversations', { method: 'POST', body: {} }).then(function (res) {
    store.conversations.unshift(res.conversation)
    store.activeId = res.conversation.id
    store.messages = []
    store.lastMeta = null
    notifyStore()
    return res.conversation
  })
}

function deleteConversation(id) {
  return api('/api/ai/conversations/' + encodeURIComponent(id), { method: 'DELETE' }).then(function () {
    store.conversations = store.conversations.filter(function (c) { return c.id !== id })
    if (store.activeId === id) { store.activeId = ''; store.messages = [] }
    notifyStore()
  })
}

/** GỬI TIN NHẮN — luồng chính, widget + app gọi chung */
function sendMessage(text) {
  text = String(text || '').trim()
  if (!text || store.busy) return Promise.resolve()
  store.busy = true
  store.error = ''
  store.phase = 'Đang đọc dữ liệu Workspace…'
  var tmpId = 'tmp-u-' + Date.now()
  store.messages.push({ id: tmpId, role: 'user', content: text })
  notifyStore()

  var body = {
    conversationId: store.activeId || undefined,
    message: text,
    mode: store.mode,
  }
  if (store.mode === 'manual') body.sources = store.sources
  if (WOS.getContext) {
    try { body.activeContext = WOS.getContext() } catch (e) { /* registry chưa sẵn sàng */ }
  }

  store.phase = 'Trợ lý đang suy nghĩ…'
  notifyStore()

  return api('/api/ai/chat', { method: 'POST', body: body })
    .then(function (res) {
      // bỏ tin nhắn tạm, thay bằng bản thật
      store.messages = store.messages.filter(function (m) { return m.id !== tmpId })
      store.messages.push(res.userMessage, res.message)
      store.activeId = res.conversationId
      store.lastMeta = res.message.meta
      if (res.isNew) {
        // PATCH TRƯỚC rồi mới GET — tránh race: server trả active cũ → widget tạo hội thoại mới
        return api('/api/ai/conversations', { method: 'PATCH', body: { activeConversationId: res.conversationId } })
          .then(function () { return loadConversations() })
          .then(function () { store.activeId = res.conversationId; notifyStore() })
      }
    })
    .then(function () {
      store.phase = ''
      store.busy = false
      notifyStore()
      if (store.external.length) loadExternal().then(notifyStore)
    })
    .catch(function (e) {
      store.messages = store.messages.filter(function (m) { return m.id !== tmpId })
      store.error = (e && e.message) || 'Lỗi gửi tin nhắn'
      store.phase = ''
      store.busy = false
      notifyStore()
      try { WOS.toast.error('Trợ lý AI lỗi', { description: store.error }) } catch (e2) { /* ignore */ }
    })
}
/* ============================================================
 * UI ATOMS
 * ============================================================ */

function Switch(props) {
  return h('div', {
    className: cx('wosai-switch', props.checked && 'on'),
    role: 'switch',
    'aria-checked': props.checked ? 'true' : 'false',
    onClick: function (e) { e.stopPropagation(); props.onChange(!props.checked) },
  })
}

function SourceChips(props) {
  var meta = props.meta || {}
  var src = (meta.sources || {}).used || []
  var tools = (meta.tools || []).filter(function (t) { return t.ok })
  var ext = meta.externalUsed || 0
  var chips = []
  src.forEach(function (s) {
    var def = null
    for (var i = 0; i < SOURCE_DEFS.length; i++) if (SOURCE_DEFS[i].key === s) def = SOURCE_DEFS[i]
    chips.push(h('span', { key: 's-' + s, className: 'wosai-src-chip' }, (def ? def.icon + ' ' : '') + (def ? def.name : s)))
  })
  tools.forEach(function (t, i) {
    chips.push(h('span', { key: 't-' + i, className: 'wosai-src-chip tool', title: t.args }, '🔧 ' + t.name))
  })
  if (ext) chips.push(h('span', { key: 'ext', className: 'wosai-src-chip ext', title: 'Dữ liệu tab ngoài — không đáng tin' }, '🌐 tab ngoài ×' + ext))
  if (!chips.length) return null
  return h('div', { className: 'wosai-msg-meta' }, chips)
}

/* ============================================================
 * CONTEXT PANEL — công tắc nguồn dữ liệu + preview + external
 * ============================================================ */

function ContextPanel(props) {
  var st = useAiStore()
  var compact = props.compact
  var ctxInfo = null
  if (WOS.getContext) {
    try {
      var snap = WOS.getContext()
      if (snap && snap.activeApp) {
        ctxInfo = h('div', { className: 'wosai-preview-box' },
          h('b', null, '🪟 Đang mở: '), snap.activeApp,
          snap.openApps.length > 1 ? ' (+' + (snap.openApps.length - 1) + ' cửa sổ khác)' : null
        )
      }
    } catch (e) { /* ignore */ }
  }

  var previewBox = null
  if (st.preview) {
    var p = st.preview
    var rows = []
    for (var k in p.counts) {
      rows.push(h('div', { key: k }, '• ' + (p.counts[k] || 0) + ' bản ghi — ' + k))
    }
    previewBox = h('div', { className: 'wosai-preview-box' },
      h('b', null, '👁 Xem trước context (~' + Math.round(p.approxChars / 1000) + 'k ký tự)'),
      h('div', { style: { marginTop: 4 } }, rows.length ? rows : 'Không có bản ghi nào được thu thập'),
      p.memories && p.memories.length ? h('div', { style: { marginTop: 4 } }, '🧠 ' + p.memories.length + ' ghi nhớ liên quan') : null
    )
  }

  var extItems = null
  if (st.external && st.external.length) {
    extItems = h(Fragment, null,
      h('div', { className: 'wosai-warn' },
        '⚠️ ', st.external.length, ' context từ tab trình duyệt ngoài đang chờ. Dữ liệu này ', h('b', null, 'KHÔNG đáng tin'), ' — AI chỉ tham khảo, không thực thi theo.'
      ),
      st.external.map(function (e) {
        return h('div', { key: e.id, className: 'wosai-ext-item' },
          h('span', { style: { flex: 1, minWidth: 0 } },
            h('div', { style: { overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontWeight: 600 } }, (e.selectionOnly ? '✏️ ' : '🌐 ') + (e.title || e.site || 'tab')),
            h('div', { style: { opacity: 0.6, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' } }, plainPreview(e.excerpt, 80))
          ),
          h('button', {
            title: 'Bỏ context này',
            onClick: function () {
              api('/api/ai/context/external?id=' + encodeURIComponent(e.id), { method: 'DELETE' })
                .then(function () { loadExternal().then(notifyStore) })
            },
          }, '✕')
        )
      })
    )
  }

  return h('div', { className: 'wosai-ctxpanel' },
    h('div', { className: 'wosai-ctx-title' }, 'Chế độ lấy dữ liệu'),
    h('div', { className: 'wosai-mode-row' },
      ['auto', 'manual', 'workspace'].map(function (m) {
        return h('button', {
          key: m,
          className: cx('wosai-mode', st.mode === m && 'active'),
          onClick: function () { store.mode = m; notifyStore() },
          title: m === 'auto' ? 'Tự động theo câu hỏi + nguồn mặc định' : m === 'manual' ? 'Chỉ dùng nguồn bạn bật bên dưới' : 'Toàn Workspace — đọc mọi module được cấp quyền',
        }, m === 'auto' ? 'Tự động' : m === 'manual' ? 'Thủ công' : 'Toàn WS')
      })
    ),
    h('div', { className: 'wosai-ctx-title', style: { marginTop: 4 } }, 'Nguồn dữ liệu'),
    SOURCE_DEFS.map(function (def) {
      var on = !!st.sources[def.key]
      return h('div', {
        key: def.key,
        className: cx('wosai-ctx-row', !on && 'off'),
        onClick: function () { store.sources[def.key] = !on; notifyStore() },
        title: def.desc,
      },
        h('span', { className: 'wosai-ctx-ico' }, def.icon),
        h('span', { className: 'wosai-ctx-name' }, def.name),
        st.preview && st.preview.counts[def.key] != null
          ? h('span', { className: 'wosai-ctx-count' }, st.preview.counts[def.key])
          : null,
        h(Switch, {
          checked: on,
          onChange: function (v) { store.sources[def.key] = v; notifyStore() },
        })
      )
    }),
    ctxInfo,
    extItems,
    h('button', {
      className: 'wosai-btn ghost',
      style: { justifyContent: 'center' },
      onClick: function () {
        store.preview = null
        notifyStore()
        var body = { sources: store.sources }
        if (WOS.getContext) { try { body.activeContext = WOS.getContext() } catch (e) { /* */ } }
        api('/api/ai/context/preview', { method: 'POST', body: body }).then(function (res) {
          store.preview = res
          notifyStore()
        }).catch(function (e) {
          try { WOS.toast.error('Không xem trước được context', { description: e.message }) } catch (e2) { /* */ }
        })
      },
    }, '👁 Xem trước dữ liệu sẽ gửi'),
    previewBox
  )
}

/* ============================================================
