 * CHAT — khung tin nhắn + ô nhập
 * ============================================================ */

function MessageBubble(props) {
  var m = props.msg
  var isUser = m.role === 'user'
  return h('div', { className: cx('wosai-msg', isUser ? 'user' : 'bot') },
    h('div', { className: 'wosai-ava' }, isUser ? '🙋' : '🤖'),
    h('div', { className: 'wosai-bubble' },
      h('div', { className: 'wosai-md' }, renderMarkdown(m.content)),
      isUser ? null : h(SourceChips, { meta: m.meta })
    )
  )
}

var QUICK_PROMPTS = [
  'Việc gì còn tồn đọng?',
  'Ngày mai có lịch gì cần chuẩn bị?',
  'Tuần này công việc ra sao?',
  'Tóm tắt những gì đã thống nhất',
]

/* ---------- banner tương thích: thiếu AI backend ---------- */
function CompatBanner(props) {
  var st = useAiStore()
  if (!st.compat) return null
  return h('div', { className: 'wosai-compat' + (props.compact ? ' compact' : '') },
    h('div', { className: 'wosai-compat-icon' }, '⚠️'),
    h('div', { className: 'wosai-compat-body' },
      h('div', { className: 'wosai-compat-title' }, 'Plugin đã cài nhưng thiếu AI backend'),
      props.compact ? h('div', { className: 'wosai-compat-text' },
          st.compat.detail, ' Cần bản Workspace OS kèm module AI Assistant (GĐ1–4).'
        ) : h('div', { className: 'wosai-compat-text' },
          st.compat.detail,
          ' Plugin "Trợ lý AI" cần bản Workspace OS đã tích hợp AI Assistant (Giai đoạn 1–4) gồm:',
          h('ul', { className: 'wosai-compat-list' },
            h('li', null, '9 API ', h('b', null, '/api/ai/*'), ' (chat, hội thoại, bộ nhớ, cài đặt, ghép nối extension…)'),
            h('li', null, '6 model dữ liệu AI (', h('b', null, 'AIConversation, AIMessage, AIMemory, AISetting, AIExtToken, AIExternalContext'), ')'),
            h('li', null, 'Lõi mở rộng ', h('b', null, 'WOS.registerWidget'), ' + ', h('b', null, 'WOS.getContext'), ' trong plugin-runtime'),
            h('li', null, 'Provider AI phía server (Grok/x.ai hoặc built-in) — API key không nằm trong plugin')
          ),
          h('div', { className: 'wosai-compat-text' },
            '👉 Giải pháp: dùng gói mã nguồn đầy đủ ', h('b', null, 'workspace-os-ai-full.zip'),
            ' (kèm toàn bộ AI backend + plugin + extension), chạy ', h('b', null, 'bun install'),
            ' rồi ', h('b', null, 'bunx prisma db push'), ' và khởi động lại — xem README đi kèm.'
          )
        ),
      h('div', { style: { marginTop: 10, display: 'flex', gap: 8 } },
        h('button', {
          className: 'wosai-quick',
          onClick: function () { store.loaded = false; ensureBoot() },
        }, 'Kiểm tra lại'),
        props.compact ? h('button', {
          className: 'wosai-quick',
          onClick: function () { try { WOS.openApp('wos-ai-assistant') } catch (e) { /* */ } },
        }, 'Xem chi tiết') : null
      )
    )
  )
}

function ChatView(props) {
  var st = useAiStore()
  var compact = props.compact
  var inputRef = useRef(null)
  var scrollRef = useRef(null)
  var text = useState('')
  var val = text[0], setVal = text[1]

  useEffect(function () {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight
  }, [st.messages.length, st.phase])

  function submit() {
    if (!val.trim() || st.busy) return
    var t = val
    setVal('')
    sendMessage(t)
  }

  // thiếu AI backend → chỉ hiện banner chẩn đoán (không hiện khung chat)
  if (st.compat) {
    return h('div', { className: 'wosai-messages' }, h(CompatBanner, null))
  }

  var empty = st.messages.length === 0 && !st.busy
  var body
  if (empty) {
    body = h('div', { className: 'wosai-empty' },
      h('div', { className: 'wosai-empty-icon' }, '🤖'),
      h('div', { className: 'wosai-empty-title' }, 'Trợ lý AI Workspace OS'),
      h('div', { className: 'wosai-empty-sub' },
        'Tôi nhớ được những lần trao đổi trước, đọc được công việc, lịch, việc tuần và biết app nào đang mở. Hỏi tôi bất cứ điều gì về công việc của bạn.'
      ),
      h('div', { className: 'wosai-quickrow', style: { justifyContent: 'center', marginTop: 8 } },
        QUICK_PROMPTS.map(function (q) {
          return h('button', {
            key: q, className: 'wosai-quick',
            onClick: function () { sendMessage(q) },
          }, q)
        })
      )
    )
  } else {
    body = h('div', { className: 'wosai-scroll', ref: scrollRef },
      st.messages.map(function (m) { return h(MessageBubble, { key: m.id, msg: m }) }),
      st.busy && !st.phase ? h('div', { className: 'wosai-phase' }, h('div', { className: 'wosai-spin' }), 'Đang xử lý…') : null
    )
  }

  return h('div', { className: 'wosai-messages' },
    body,
    st.phase ? h('div', { className: 'wosai-phase' }, h('div', { className: 'wosai-spin' }), st.phase) : null,
    st.error && !st.busy ? h('div', { className: 'wosai-phase', style: { color: 'oklch(0.6 0.2 25)' } }, '⚠️ ', st.error) : null,
    h('div', { className: 'wosai-inputrow' },
      empty ? null : h('div', { className: 'wosai-quickrow' },
        QUICK_PROMPTS.slice(0, 2).map(function (q) {
          return h('button', { key: q, className: 'wosai-quick', onClick: function () { sendMessage(q) } }, q)
        })
      ),
      h('div', { className: 'wosai-inputbox' },
        h('textarea', {
          className: 'wosai-input',
          rows: 1,
          placeholder: 'Hỏi trợ lý về công việc, lịch, việc tuần…',
          value: val,
          ref: inputRef,
          onChange: function (e) { setVal(e.target.value) },
          onKeyDown: function (e) {
            if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); submit() }
          },
        }),
        h('button', {
          className: 'wosai-send',
          disabled: st.busy || !val.trim(),
          onClick: submit,
          'aria-label': 'Gửi',
        }, '➤')
      )
    )
  )
}

/* ============================================================
 * SIDEBAR — lịch sử hội thoại (dùng chung active với widget)
 * ============================================================ */

function Sidebar(props) {
  var st = useAiStore()
  return h('aside', { className: 'wosai-side' },
    h('div', { className: 'wosai-side-head' },
      h('div', { className: 'wosai-logo' }, '🤖'),
      h('div', null,
        h('div', { className: 'wosai-side-title' }, 'Trợ lý AI'),
        h('div', { className: 'wosai-side-sub' },
          st.provider ? st.provider.label : 'Đang tải…')
      )
    ),
    h('button', { className: 'wosai-newchat', onClick: function () { newConversation() } },
      '✚ Hội thoại mới'
    ),
    h('div', { className: 'wosai-conv-list' },
      st.conversations.length === 0
        ? h('div', { style: { padding: '10px 8px', fontSize: 11, opacity: 0.55 } }, 'Chưa có hội thoại nào')
        : st.conversations.map(function (c) {
          return h('div', {
            key: c.id,
            className: cx('wosai-conv', c.id === st.activeId && 'active'),
            onClick: function () { setActiveConversation(c.id) },
          },
            h('span', { className: 'wosai-conv-title', title: c.title }, '💬 ' + c.title),
            h('span', { className: 'wosai-conv-count' }, c.messageCount),
            h('button', {
              className: 'wosai-conv-del',
              title: 'Xoá hội thoại',
              onClick: function (e) {
                e.stopPropagation()
                deleteConversation(c.id)
              },
            }, '🗑')
          )
        })
    )
  )
}
/* ============================================================
