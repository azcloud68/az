 * MEMORY MANAGER (GĐ3) — xem/sửa/ghim/xoá bộ nhớ dài hạn
 * ============================================================ */

function MemoryPanel(props) {
  var st = useAiStore()
  var state = useState({ list: null, filter: '', adding: false, addCat: 'fact', addText: '', editing: null, editVal: '' })
  var s = state[0], set = state[1]

  var reload = useCallback(function () {
    api('/api/ai/memory' + (s.filter ? '?category=' + s.filter : '')).then(function (res) {
      set(function (prev) { return Object.assign({}, prev, { list: res.memories, cats: res.categories }) })
    }).catch(function (e) {
      set(function (prev) { return Object.assign({}, prev, { list: [], err: e.message }) })
    })
  }, [s.filter])

  useEffect(function () { reload() }, [reload])

  function patchMem(id, body) {
    return api('/api/ai/memory/' + encodeURIComponent(id), { method: 'PATCH', body: body }).then(reload)
  }

  var cats = s.cats || [
    { value: 'preference', label: 'Sở thích' }, { value: 'project', label: 'Dự án' },
    { value: 'decision', label: 'Quyết định' }, { value: 'pending', label: 'Chưa xong' },
    { value: 'fact', label: 'Thông tin' },
  ]

  var list = s.list
  var body
  if (!list) {
    body = h('div', { className: 'wosai-empty' }, h('div', { className: 'wosai-spin' }), 'Đang tải bộ nhớ…')
  } else if (list.length === 0) {
    body = h('div', { className: 'wosai-card', style: { textAlign: 'center', opacity: 0.7 } },
      '🧠 Chưa có ghi nhớ nào.', h('br', null),
      'Trợ lý sẽ tự ghi nhớ thông tin quan trọng sau các cuộc trò chuyện (bạn xác nhận trước khi tin), hoặc thêm thủ công bên dưới.'
    )
  } else {
    var pending = list.filter(function (m) { return !m.confirmed && !m.supersededBy })
    body = h(Fragment, null,
      pending.length ? h('div', { className: 'wosai-warn' },
        '⏳ ', pending.length, ' ghi nhớ do AI trích xuất đang chờ bạn xác nhận (viền nét đứt). Xác nhận để trợ lý tin vào các thông tin này.'
      ) : null,
      list.map(function (m) {
        var cat = CAT_META[m.category] || CAT_META.fact
        var isEditing = s.editing === m.id
        return h('div', {
          key: m.id,
          className: cx('wosai-mem', !m.confirmed && !m.supersededBy && 'unconfirmed', m.supersededBy && 'superseded'),
        },
          h('span', { className: 'wosai-mem-cat', style: { background: cat.bg, color: cat.color } }, cat.label),
          h('div', { className: 'wosai-mem-content' },
            isEditing
              ? h(Fragment, null,
                  h('textarea', {
                    className: 'wosai-text', value: s.editVal, rows: 3,
                    onChange: function (e) { set(function (p) { return Object.assign({}, p, { editVal: e.target.value }) }) },
                  }),
                  h('div', { style: { display: 'flex', gap: 6, marginTop: 6 } },
                    h('button', {
                      className: 'wosai-btn', style: { padding: '5px 12px' },
                      onClick: function () {
                        patchMem(m.id, { content: s.editVal }).then(function () {
                          set(function (p) { return Object.assign({}, p, { editing: null }) })
                        })
                      },
                    }, 'Lưu'),
                    h('button', {
                      className: 'wosai-btn ghost', style: { padding: '5px 12px' },
                      onClick: function () { set(function (p) { return Object.assign({}, p, { editing: null }) }) },
                    }, 'Huỷ')
                  )
                )
              : h('div', null, m.content),
            h('div', { className: 'wosai-mem-foot' },
              h('span', null, 'Nguồn: ', m.source === 'manual' ? '✍️ bạn tự thêm' : m.source.indexOf('conversation:') === 0 ? '🤖 AI trích xuất' : m.source),
              h('span', null, '• Cập nhật ' + fmtDate(m.updatedAt)),
              m.version > 1 ? h('span', null, '• v' + m.version) : null,
              m.confidence ? h('span', null, '• tin cậy ' + m.confidence + '%') : null,
              m.supersededBy ? h('span', null, '• đã bị thay thế') : null
            )
          ),
          !m.supersededBy ? h('div', { className: 'wosai-mem-actions' },
            !m.confirmed ? h('button', {
              className: 'wosai-iconbtn on', title: 'Xác nhận ghi nhớ này',
              onClick: function () { patchMem(m.id, { confirmed: true }) },
            }, '✓') : null,
            h('button', {
              className: cx('wosai-iconbtn', m.pinned && 'on'),
              title: m.pinned ? 'Bỏ ghim' : 'Ghim — luôn đưa vào mọi câu hỏi',
              onClick: function () { patchMem(m.id, { pinned: !m.pinned }) },
            }, '📌'),
            h('button', {
              className: 'wosai-iconbtn', title: 'Sửa nội dung',
              onClick: function () {
                set(function (p) { return Object.assign({}, p, { editing: m.id, editVal: m.content }) })
              },
            }, '✎'),
            h('button', {
              className: 'wosai-iconbtn danger', title: 'Xoá ghi nhớ',
              onClick: function () {
                api('/api/ai/memory/' + encodeURIComponent(m.id), { method: 'DELETE' }).then(reload)
              },
            }, '🗑')
          ) : null
        )
      })
    )
  }

  return h('div', { className: 'wosai-panel' },
    h('div', { className: 'wosai-panel-inner' },
      h('div', { className: 'wosai-section-title' }, '🧠 Bộ nhớ dài hạn',
        h('span', { style: { fontSize: 11, fontWeight: 400, opacity: 0.6 } },
          '— trợ lý nhớ sở thích, quyết định, dự án qua các phiên chat')
      ),
      h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: 5 } },
        h('button', {
          className: cx('wosai-quick', !s.filter && 'active'),
          style: !s.filter ? { background: 'oklch(0.62 0.17 290 / 15%)', borderColor: 'oklch(0.62 0.17 290 / 40%)' } : {},
          onClick: function () { set(function (p) { return Object.assign({}, p, { filter: '' }) }) },
        }, 'Tất cả'),
        cats.map(function (c) {
          return h('button', {
            key: c.value, className: 'wosai-quick',
            style: s.filter === c.value ? { background: 'oklch(0.62 0.17 290 / 15%)', borderColor: 'oklch(0.62 0.17 290 / 40%)' } : {},
            onClick: function () { set(function (p) { return Object.assign({}, p, { filter: c.value }) }) },
          }, c.label)
        }),
        h('button', {
          className: 'wosai-quick', style: { marginLeft: 'auto', color: 'oklch(0.6 0.2 25)' },
          onClick: function () {
            if (window.confirm('Xoá TOÀN BỘ bộ nhớ dài hạn? Hội thoại được giữ nguyên.')) {
              api('/api/ai/memory?all=1', { method: 'DELETE' }).then(reload)
            }
          },
        }, 'Xoá tất cả')
      ),
      s.adding ? h('div', { className: 'wosai-card' },
        h('div', { className: 'wosai-grid2' },
          h('div', { className: 'wosai-field' },
            h('label', null, 'Loại'),
            h('select', {
              className: 'wosai-text', value: s.addCat,
              onChange: function (e) { set(function (p) { return Object.assign({}, p, { addCat: e.target.value }) }) },
            }, cats.map(function (c) { return h('option', { key: c.value, value: c.value }, c.label) }))
          ),
          h('div', { className: 'wosai-field' },
            h('label', null, 'Nội dung ghi nhớ'),
            h('input', {
              className: 'wosai-text', placeholder: 'vd: Tôi thích trả lời ngắn gọn, đi thẳng vấn đề',
              value: s.addText,
              onChange: function (e) { set(function (p) { return Object.assign({}, p, { addText: e.target.value }) }) },
            })
          )
        ),
        h('div', { style: { display: 'flex', gap: 6, marginTop: 8 } },
          h('button', {
            className: 'wosai-btn', disabled: !s.addText.trim(),
            onClick: function () {
              api('/api/ai/memory', { method: 'POST', body: { category: s.addCat, content: s.addText } })
                .then(function () { set(function (p) { return Object.assign({}, p, { addText: '', adding: false }) }); reload() })
                .catch(function (e) { try { WOS.toast.error('Không thêm được', { description: e.message }) } catch (e2) { /* */ } })
            },
          }, 'Lưu ghi nhớ'),
          h('button', {
            className: 'wosai-btn ghost',
            onClick: function () { set(function (p) { return Object.assign({}, p, { adding: false }) }) },
          }, 'Đóng')
        )
      ) : h('button', { className: 'wosai-btn ghost', onClick: function () { set(function (p) { return Object.assign({}, p, { adding: true }) }) } },
        '✚ Thêm ghi nhớ thủ công'
      ),
      body
    )
  )
}

/* ============================================================
 * SETTINGS — model, context, bộ nhớ, ghép nối extension (GĐ4)
 * ============================================================ */

/* --- Groq Cloud (fix lỗi 4): admin nhập API key + quản lý model ngay trong UI --- */
function GroqCard(props) {
  var st = useAiStore()
  var state = useState({
    loading: true, err: '', admin: true, cfg: null,
    keyInput: '', baseInput: '', newModel: '',
    saving: false, testing: false, testMsg: '', fetching: false,
  })
  var s = state[0], set = state[1]
  function upd(patch) { set(function (p) { return Object.assign({}, p, patch) }) }

  function reload() {
    upd({ loading: true, err: '' })
    api('/api/ai/groq').then(function (res) {
      upd({ loading: false, cfg: res, baseInput: res.baseUrl || '', admin: true })
    }).catch(function (e) {
      var msg = (e && e.message) || 'Không tải được cấu hình Groq'
      var forbidden = /403|quản trị|admin/i.test(msg)
      upd({ loading: false, err: forbidden ? '' : msg, admin: !forbidden })
    })
  }
  useEffect(function () { reload() }, [])

  if (s.loading) {
    return h('div', { className: 'wosai-card' }, 'Đang tải cấu hình Groq…')
  }
  if (!s.admin) {
    return h('div', { className: 'wosai-card' },
      h('div', { className: 'wosai-warn' }, 'Chỉ quản trị viên (admin) được cấu hình API key Groq.'))
  }

  var cfg = s.cfg || { configured: false, hasKey: false, hasEnvKey: false, models: [], customModels: [], defaultModel: 'llama-3.3-70b-versatile' }

  function saveKey() {
    upd({ saving: true, err: '' })
    api('/api/ai/groq', { method: 'PUT', body: { apiKey: s.keyInput, baseUrl: s.baseInput } })
      .then(function (res) {
        upd({ saving: false, cfg: Object.assign({}, cfg, res, { models: res.models || [] }), keyInput: '' })
        try { WOS.toast.success('Đã lưu API key Groq') } catch (e) { /* */ }
      })
      .catch(function (e) {
        upd({ saving: false, err: (e && e.message) || 'Lỗi lưu key' })
      })
  }

  function clearKey() {
    upd({ saving: true, err: '' })
    api('/api/ai/groq', { method: 'DELETE' })
      .then(function (res) {
        upd({ saving: false, cfg: Object.assign({}, cfg, res) })
        try { WOS.toast.success('Đã xoá key Groq nhập từ UI') } catch (e) { /* */ }
      })
      .catch(function (e) { upd({ saving: false, err: (e && e.message) || 'Lỗi xoá key' }) })
  }

  function addModel() {
    var m = (s.newModel || '').trim()
    if (!m) return
    var next = (cfg.customModels || []).concat([m])
    api('/api/ai/groq', { method: 'PUT', body: { models: next } })
      .then(function (res) {
        upd({ newModel: '', cfg: Object.assign({}, cfg, res, { models: res.models || [] }) })
      })
      .catch(function (e) { upd({ err: (e && e.message) || 'Lỗi thêm model' }) })
  }

  function removeModel(m) {
    var next = (cfg.customModels || []).filter(function (x) { return x !== m })
    api('/api/ai/groq', { method: 'PUT', body: { models: next } })
      .then(function (res) {
        upd({ cfg: Object.assign({}, cfg, res, { models: res.models || [] }) })
      })
      .catch(function (e) { upd({ err: (e && e.message) || 'Lỗi xoá model' }) })
  }

  function fetchModels() {
    upd({ fetching: true, err: '' })
    api('/api/ai/groq', { method: 'POST', body: { action: 'fetch-models' } })
      .then(function (res) {
        upd({ fetching: false, cfg: Object.assign({}, cfg, { models: res.models || [] }) })
        try { WOS.toast.success('Đã lấy ' + ((res.models || []).length) + ' model từ Groq') } catch (e) { /* */ }
      })
      .catch(function (e) { upd({ fetching: false, err: (e && e.message) || 'Không lấy được danh sách model' }) })
  }

  function testKey() {
    upd({ testing: true, testMsg: '', err: '' })
    var model = (st.settings && st.settings.model) || cfg.defaultModel
    api('/api/ai/groq', { method: 'POST', body: { action: 'test', model: model } })
      .then(function (res) {
        upd({ testing: false, testMsg: 'Kết nối OK — model trả lời: ' + (res.reply || '…') })
      })
      .catch(function (e) { upd({ testing: false, testMsg: 'Lỗi: ' + ((e && e.message) || 'không kết nối được') }) })
  }

  return h('div', { className: 'wosai-card' },
    /* trạng thái key */
    h('div', { style: { display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 } },
      cfg.hasKey
        ? h('span', { style: { fontSize: 11.5, fontWeight: 600, color: '#059669' } }, '✅ Đã cấu hình key' + (cfg.hasEnvKey ? ' (từ .env — GROQ_API_KEY)' : ' (nhập từ UI)'))
        : h('span', { style: { fontSize: 11.5, fontWeight: 600, color: '#b45309' } }, '⚠️ Chưa có API key — lấy tại console.groq.com/keys (miễn phí)')
    ),
    /* nhập key + baseUrl */
    h('div', { className: 'wosai-grid2' },
      h('div', { className: 'wosai-field' },
        h('label', null, 'Groq API Key'),
        h('input', {
          className: 'wosai-text', type: 'password', value: s.keyInput,
          placeholder: cfg.hasKey ? '•••••••• (đã lưu — nhập để thay thế)' : 'gsk_...',
          onChange: function (e) { upd({ keyInput: e.target.value }) },
        })
      ),
      h('div', { className: 'wosai-field' },
        h('label', null, 'Base URL (tuỳ chọn)'),
        h('input', {
          className: 'wosai-text', value: s.baseInput, placeholder: 'https://api.groq.com/openai/v1',
          onChange: function (e) { upd({ baseInput: e.target.value }) },
        })
      )
    ),
    h('div', { style: { display: 'flex', gap: 6, marginTop: 6, flexWrap: 'wrap' } },
      h('button', {
        className: 'wosai-btn', disabled: s.saving || (!s.keyInput && !cfg.hasKey),
        onClick: saveKey,
      }, s.saving ? 'Đang lưu…' : '💾 Lưu key'),
      cfg.hasKey && !cfg.hasEnvKey
        ? h('button', { className: 'wosai-btn danger', disabled: s.saving, onClick: clearKey }, 'Xoá key')
        : null,
      h('button', { className: 'wosai-btn', disabled: s.testing || !cfg.hasKey, onClick: testKey },
          s.testing ? 'Đang thử…' : '🔍 Thử kết nối')
    ),
    s.testMsg
      ? h('div', { style: { marginTop: 6, fontSize: 11.5, opacity: 0.85 } }, s.testMsg)
      : null,
    /* quản lý model */
    h('div', { style: { marginTop: 12, paddingTop: 10, borderTop: '1px solid rgba(128,128,128,.2)' } },
      h('label', { style: { fontWeight: 600, fontSize: 12 } }, 'Model Groq'),
      h('div', { style: { marginTop: 4, marginBottom: 6, fontSize: 11, opacity: 0.75 } },
        'Model tuỳ chỉnh (admin thêm/xoá tay — hợp nhất với danh sách Groq trả về):'),
      h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: 4, marginBottom: 8 } },
        (cfg.customModels || []).length === 0
          ? h('span', { style: { fontSize: 11, opacity: 0.6 } }, '(chưa có model tuỳ chỉnh — dùng danh sách mặc định)')
          : (cfg.customModels || []).map(function (m) {
              return h('span', {
                key: m,
                style: {
                  display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 11,
                  padding: '2px 8px', borderRadius: 999,
                  background: 'rgba(124,58,237,.12)', color: '#7c3aed',
                },
              },
                m,
                h('button', {
                  onClick: function () { removeModel(m) },
                  style: { border: 'none', background: 'none', cursor: 'pointer', fontSize: 12, lineHeight: 1, color: '#7c3aed' },
                  title: 'Xoá model này',
                }, '×')
              )
            })
      ),
      h('div', { style: { display: 'flex', gap: 6 } },
        h('input', {
          className: 'wosai-text', style: { flex: 1 }, value: s.newModel,
          placeholder: 'Tên model mới (vd openai/gpt-oss-120b)',
          onChange: function (e) { upd({ newModel: e.target.value }) },
          onKeyDown: function (e) { if (e.key === 'Enter') { e.preventDefault(); addModel() } },
        }),
        h('button', { className: 'wosai-btn', disabled: !s.newModel, onClick: addModel }, '➕ Thêm')
      ),
      h('div', { style: { marginTop: 6 } },
        h('button', { className: 'wosai-btn', disabled: s.fetching || !cfg.hasKey, onClick: fetchModels },
          s.fetching ? 'Đang tải…' : '🔄 Lấy danh sách model từ Groq'),
        h('div', { style: { marginTop: 6, fontSize: 10.5, opacity: 0.65, lineHeight: 1.5 } },
          'Gợi ý chọn nhanh (đã có sẵn trên Groq): ',
          h('b', null, 'llama-3.3-70b-versatile'),
          ' (cân bằng — mặc định), ',
          h('b', null, 'llama-3.1-8b-instant'),
          ' (siêu nhanh), ',
          h('b', null, 'openai/gpt-oss-120b'),
          ' (mạnh, mã nguồn mở), ',
          h('b', null, 'meta-llama/llama-4-scout-17b-16e-instruct'),
          ' (đa phương thức).')
      ),
      (cfg.models && cfg.models.length)
        ? h('details', { style: { marginTop: 6 } },
            h('summary', { style: { fontSize: 11, cursor: 'pointer', opacity: 0.75 } },
              'Xem ' + cfg.models.length + ' model khả dụng'),
            h('div', { style: { fontSize: 10.5, opacity: 0.8, lineHeight: 1.7, maxHeight: 120, overflow: 'auto' } },
              cfg.models.join(' · '))
          )
        : null
    ),
    s.err
      ? h('div', { className: 'wosai-warn', style: { marginTop: 8 } }, s.err)
      : null
  )
}

function SettingsPanel(props) {
  var st = useAiStore()
  var state = useState({ saving: false, saved: false, pair: null, tokens: null })
  var s = state[0], set = state[1]
  var cfg = st.settings || {}

  function save(patch) {
    set(function (p) { return Object.assign({}, p, { saving: true, saved: false }) })
    api('/api/ai/settings', { method: 'PATCH', body: patch }).then(function () {
      return loadSettings()
    }).then(function () {
      set(function (p) { return Object.assign({}, p, { saving: false, saved: true }) })
      setTimeout(function () { set(function (p) { return Object.assign({}, p, { saved: false }) }) }, 1500)
      notifyStore()
    }).catch(function (e) {
      set(function (p) { return Object.assign({}, p, { saving: false }) })
      try { WOS.toast.error('Không lưu được cài đặt', { description: e.message }) } catch (e2) { /* */ }
    })
  }

  function loadTokens() {
    api('/api/ai/ext-token').then(function (res) {
      set(function (p) { return Object.assign({}, p, { tokens: res.tokens }) })
    }).catch(function () {
      set(function (p) { return Object.assign({}, p, { tokens: [] }) })
    })
  }
  useEffect(function () { loadTokens() }, [])

  var temp = useState(String(cfg.temperature != null ? cfg.temperature : 0.7))
  var tempVal = temp[0], setTemp = temp[1]

  return h('div', { className: 'wosai-panel' },
    h('div', { className: 'wosai-panel-inner' },
      /* --- Provider --- */
      h('div', { className: 'wosai-section-title' }, '⚙️ Bộ máy AI'),
      h('div', { className: 'wosai-card' },
        h('div', { className: 'wosai-grid2' },
          h('div', { className: 'wosai-field' },
            h('label', null, 'Provider'),
            h('select', {
              className: 'wosai-text', value: cfg.provider || '',
              onChange: function (e) { save({ provider: e.target.value }) },
            },
              h('option', { value: '' }, 'Tự động (provider tốt nhất đã cấu hình)'),
              (st.providers && st.providers.length ? st.providers : [
                { id: 'xai', label: 'Grok — x.ai', configured: false },
                { id: 'zai', label: 'Built-in (sandbox)', configured: true },
              ]).map(function (p) {
                return h('option', { key: p.id, value: p.id },
                  p.label + (p.configured ? '' : ' — chưa cấu hình'))
              })
            )
          ),
          h('div', { className: 'wosai-field' },
            h('label', null, 'Model'),
            h('div', { style: { display: 'flex', gap: 6 } },
              h('input', {
                className: 'wosai-text', style: { flex: 1 },
                defaultValue: cfg.model || '', placeholder: st.provider ? 'mặc định: ' + st.provider.model : '',
                list: 'wosai-model-list',
                onBlur: function (e) { save({ model: e.target.value.trim() }) },
              }),
              st.models && st.models.length
                ? h('datalist', { id: 'wosai-model-list' },
                    st.models.slice(0, 60).map(function (m) { return h('option', { key: m, value: m }) })
                  )
                : null
            )
          )
        ),
        h('div', { style: { marginTop: 10 } },
          !st.provider
            ? null
            : st.provider.provider === 'xai' && !st.provider.hasKey
              ? h('div', { className: 'wosai-warn' },
                  '🔑 Server chưa có XAI_API_KEY — đang dùng provider built-in. Để dùng Grok: thêm biến môi trường ',
                  h('code', null, 'XAI_API_KEY'), ' trong file .env của Workspace OS rồi khởi động lại.'
                )
              : h('div', { className: 'wosai-preview-box' },
                  '✅ Đang chạy: ', h('b', null, st.provider.label),
                  st.provider.supportsTools ? ' — tool calling đã bật.' : ' — tool calling không khả dụng với provider này.'
                )
        ),
        h('div', { style: { marginTop: 8, fontSize: 11, opacity: 0.7, lineHeight: 1.5 } },
          '💡 Thêm AI khác (Ollama local, OpenRouter, Groq, DeepSeek…) — không cần sửa code: cấu hình ',
          h('code', null, 'AI_COMPAT_BASE_URL'), ' / ', h('code', null, 'AI_COMPAT_API_KEY'), ' / ', h('code', null, 'AI_COMPAT_MODEL'),
          ' trong .env — xem ', h('b', null, 'docs/ai-integration-guide.md'), '.'
        )
      ),

      /* --- Groq Cloud (fix lỗi 4): nhập key + quản lý model ngay trong UI --- */
      h('div', { className: 'wosai-section-title' }, '⚡ Groq Cloud — API key & model'),
      h(GroqCard, null),

      /* --- Context --- */
      h('div', { className: 'wosai-section-title' }, '🧩 Ngữ cảnh & chi phí'),
      h('div', { className: 'wosai-card' },
        h('div', { className: 'wosai-grid2' },
          h('div', { className: 'wosai-field' },
            h('label', null, 'Số lượt chat gần nhất đưa vào prompt'),
            h('div', { className: 'wosai-range' },
              h('input', {
                type: 'range', min: 2, max: 30, value: cfg.maxRecentMessages || 10,
                onChange: function (e) { setTemp(e.target.value); save({ maxRecentMessages: Number(e.target.value) }) },
              }),
              h('span', { className: 'wosai-range-val' }, cfg.maxRecentMessages || 10)
            )
          ),
          h('div', { className: 'wosai-field' },
            h('label', null, 'Ngưỡng tự tóm tắt hội thoại (tin nhắn)'),
            h('div', { className: 'wosai-range' },
              h('input', {
                type: 'range', min: 8, max: 80, value: cfg.summarizeThreshold || 20,
                onChange: function (e) { save({ summarizeThreshold: Number(e.target.value) }) },
              }),
              h('span', { className: 'wosai-range-val' }, cfg.summarizeThreshold || 20)
            )
          )
        ),
        h('div', { style: { marginTop: 10 } },
          h('label', { className: 'wosai-ctx-row', style: { cursor: 'pointer' } },
            h('span', { className: 'wosai-ctx-ico' }, '🧠'),
            h('span', { className: 'wosai-ctx-name' }, 'Bộ nhớ dài hạn (ghi nhớ + trích xuất tự động)'),
            h(Switch, {
              checked: cfg.memoryEnabled !== false,
              onChange: function (v) { save({ memoryEnabled: v }) },
            })
          )
        )
      ),

      /* --- GĐ4: Browser Extension --- */
      h('div', { className: 'wosai-section-title' }, '🌐 Trình duyệt mở rộng (Giai đoạn 4)'),
      h('div', { className: 'wosai-card' },
        h('p', { style: { margin: '0 0 8px', fontSize: 11.5, opacity: 0.75, lineHeight: 1.5 } },
          'Cài tiện ích "WOS AI Bridge" trên Chrome để gửi nội dung tab ngoài (bài viết, email, bảng tính…) vào trợ lý. ',
          'Nội dung luôn được đánh dấu ', h('b', null, 'KHÔNG đáng tin'), ' — AI chỉ tham khảo, không thực thi theo.'
        ),
        s.pair ? h('div', null,
          h('div', { className: 'wosai-paircode' }, s.pair.pairCode),
          h('p', { style: { fontSize: 10.5, opacity: 0.65, textAlign: 'center', margin: '6px 0 10px' } }, s.pair.instructions)
        ) : null,
        h('div', { style: { display: 'flex', gap: 6, flexWrap: 'wrap' } },
          h('button', {
            className: 'wosai-btn',
            onClick: function () {
              api('/api/ai/ext-token', { method: 'POST', body: {} }).then(function (res) {
                set(function (p) { return Object.assign({}, p, { pair: res }) })
                loadTokens()
              })
            },
          }, '🔑 Tạo mã ghép nối'),
          s.pair ? h('button', {
            className: 'wosai-btn ghost',
            onClick: function () { set(function (p) { return Object.assign({}, p, { pair: null }) }) },
          }, 'Ẩn mã') : null
        ),
        s.tokens && s.tokens.length ? h('div', { style: { marginTop: 10 } },
          h('label', { style: { fontSize: 11, fontWeight: 600, opacity: 0.75 } }, 'Thiết bị đã ghép nối'),
          s.tokens.map(function (t) {
            return h('div', { key: t.id, className: 'wosai-token-row' },
              h('span', { className: 'hint' }, t.hint),
              h('span', { style: { opacity: 0.55, flex: 1 } }, t.label),
              h('button', {
                className: 'wosai-iconbtn danger',
                onClick: function () {
                  api('/api/ai/ext-token?id=' + encodeURIComponent(t.id), { method: 'DELETE' }).then(loadTokens)
                },
              }, 'Thu hồi')
            )
          })
        ) : null
      ),

      /* --- trạng thái lưu --- */
      h('div', { style: { textAlign: 'right', fontSize: 11, height: 16 } },
        s.saving ? 'Đang lưu…' : s.saved ? '✅ Đã lưu' : '')
    )
  )
}

/* ============================================================
 * CHAT APP — cửa sổ chính: sidebar + chat + context panel + tabs
 * ============================================================ */

function ChatApp(props) {
  var st = useAiStore()
  var tab = useState('chat')
  var cur = tab[0], setTab = tab[1]

  useEffect(function () { ensureBoot() }, [])

  var providerPill = st.provider
    ? h('span', { className: cx('wosai-provider-pill', !st.provider.hasKey && st.provider.provider !== 'xai' && 'warn'), title: st.provider.label },
        h('span', { className: 'wosai-dot' }),
        (st.providers && st.providers.length
          ? (st.providers.find(function (p) { return p.id === st.provider.provider }) || {}).label || st.provider.provider
          : st.provider.provider) + ' · ' + st.provider.model)
    : null

  var content
  if (cur === 'chat') {
    content = h('div', { className: 'wosai-chatwrap' },
      h(Sidebar),
      h(ChatView),
      h(ContextPanel)
    )
  } else if (cur === 'memory') {
    content = h(MemoryPanel)
  } else {
    content = h(SettingsPanel)
  }

  return h('div', { className: 'wosai-root' },
    h('div', { className: 'wosai-main' },
      h('div', { className: 'wosai-topbar' },
        h('div', { className: 'wosai-tabs' },
          h('button', { className: cx('wosai-tab', cur === 'chat' && 'active'), onClick: function () { setTab('chat') } }, '💬 Chat'),
          h('button', {
            className: cx('wosai-tab', cur === 'memory' && 'active'),
            onClick: function () { setTab('memory') },
            title: st.status ? st.status.stats.pendingMemories + ' ghi nhớ chờ xác nhận' : '',
          }, '🧠 Bộ nhớ', st.status && st.status.stats.pendingMemories ? h('span', { className: 'wosai-src-chip', style: { marginLeft: 4 } }, st.status.stats.pendingMemories) : null),
          h('button', { className: cx('wosai-tab', cur === 'settings' && 'active'), onClick: function () { setTab('settings') } }, '⚙️ Cài đặt')
        ),
        providerPill
      ),
      content
    )
  )
}

/* ============================================================
 * AI WIDGET (GĐ2) — mini chat trên desktop, dùng CHUNG conversation
 * với Chat App (activeConversationId đồng bộ qua server)
 * ============================================================ */

function AiWidget(props) {
  var st = useAiStore()
  var text = useState('')
  var val = text[0], setVal = text[1]
  var scrollRef = useRef(null)

  useEffect(function () { ensureBoot() }, [])
  useEffect(function () {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight
  }, [st.messages.length, st.phase])

  function submit() {
    if (!val.trim() || st.busy) return
    var t = val
    setVal('')
    sendMessage(t)
  }

  // thiếu AI backend → widget hiện cảnh báo gọn
  if (st.compat) {
    return h('div', { className: 'wosai-widget' }, h(CompatBanner, { compact: true }))
  }

  var recent = st.messages.slice(-12)
  var msgsBody
  if (recent.length === 0) {
    msgsBody = h('div', { className: 'wosai-w-empty' },
      h('div', { className: 'big' }, '🤖'),
      h('div', { style: { fontWeight: 700, fontSize: 12 } }, 'Trợ lý AI'),
      h('div', { style: { fontSize: 10.5, opacity: 0.7 } }, 'Hỏi nhanh — cùng bộ nhớ với cửa sổ chat')
    )
  } else {
    msgsBody = h('div', { className: 'wosai-w-msgs', ref: scrollRef },
      recent.map(function (m) {
        return h('div', {
          key: m.id,
          className: cx('wosai-w-bubble', m.role === 'user' ? 'user' : 'bot wide'),
          title: m.role === 'assistant' ? 'Bấm để mở toàn bộ câu trả lời' : '',
          onClick: m.role === 'assistant'
            ? function () { try { WOS.openApp('wos-ai-assistant') } catch (e) { /* */ } }
            : undefined,
        }, m.role === 'user' ? plainPreview(m.content, 160) : renderMarkdown(m.content))
      })
    )
  }

  return h('div', { className: 'wosai-widget' },
    h('div', { className: 'wosai-w-head' },
      h('div', { className: 'wosai-w-logo' }, '🤖'),
      h('div', { className: 'wosai-w-title' },
        'Trợ lý AI',
        st.activeId ? '' : ' — mới'
      ),
      h('button', {
        className: 'wosai-w-expand',
        title: 'Mở cửa sổ chat đầy đủ (cùng hội thoại)',
        onClick: function () { try { WOS.openApp('wos-ai-assistant') } catch (e) { /* */ } },
      }, '⤢ Mở đầy đủ')
    ),
    msgsBody,
    st.phase ? h('div', { className: 'wosai-w-phase' }, h('div', { className: 'wosai-spin' }), st.phase) : null,
    h('div', { className: 'wosai-w-inputrow' },
      h('input', {
        className: 'wosai-w-input',
        placeholder: 'Hỏi nhanh…',
        value: val,
        onChange: function (e) { setVal(e.target.value) },
        onKeyDown: function (e) { if (e.key === 'Enter') { e.preventDefault(); submit() } },
      }),
      h('button', { className: 'wosai-w-send', disabled: st.busy || !val.trim(), onClick: submit, 'aria-label': 'Gửi' }, '➤')
    )
  )
}

/* ============================================================
 * ĐĂNG KÝ — app cửa sổ + widget desktop (cùng bộ não)
 * ============================================================ */

WOS.registerApp({ component: ChatApp, windowSize: { w: 1020, h: 680 } })

/* widget desktop (GĐ2) — chỉ đăng ký khi lõi hỗ trợ (bản OS cũ chưa có
   WOS.registerWidget → bỏ qua để plugin vẫn mở được app + hiện banner hướng dẫn) */
if (typeof WOS.registerWidget === 'function') {
  WOS.registerWidget({
    type: 'bubble',
    title: 'Trợ lý AI',
    icon: '🤖',
    defaultW: 330,
    defaultH: 430,
    minW: 260,
    minH: 220,
    component: AiWidget,
  })
} else {
  try { console.warn('[wos-ai-assistant] Lõi Workspace OS chưa có WOS.registerWidget — widget desktop bị tắt. Cần bản OS kèm AI Assistant (GĐ1–4).') } catch (e) { /* */ }
}

/* phát event cài đặt thành công (Timeline/Activity ghi nhận) */
try {
  WOS.emitEvent('installed', { version: '1.0.0', features: ['chat', 'widget', 'memory', 'tools', 'extension'] })
} catch (e) { /* ignore */ }
