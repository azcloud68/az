#!/bin/bash
# Sandbox-only: khởi động wos-terminal-service với cấu hình proxy-mode (giữ nguyên của prod)
cd "$(dirname "$0")/../../mini-services/terminal-service" || exit 1
pkill -f "dist/index.js" 2>/dev/null || true
sleep 1
TERMINAL_PORT=3005 TERMINAL_SOCKET_PATH=/terminal-ws WOS_API_URL=http://127.0.0.1:3000 WOS_TERMINAL_CWD=/home/z \
  nohup node dist/index.js > /home/z/my-project/.zscripts/terminal-service.log 2>&1 &
echo "terminal-service started (pid $!)"
