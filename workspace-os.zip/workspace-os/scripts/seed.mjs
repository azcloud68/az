/**
 * WOS Seed — dữ liệu ban đầu cho Workspace OS
 * - Admin (env ADMIN_USER / ADMIN_PASSWORD, mặc định admin/admin123)
 * - User demo (viewer)
 * - Settings mặc định cho mọi module
 * - Dữ liệu demo: tasks, calendar, notes, wiki, projects, notifications
 * - Mọi dữ liệu demo gắn ownerId = admin; file demo nằm trong storage/users/<adminId>/
 *   (per-account isolation — các tài khoản khác bắt đầu trống trơn)
 * Chạy: node scripts/seed.mjs  (install.sh tự gọi sau khi prisma db push)
 */
import { PrismaClient } from '@prisma/client'
import { scryptSync, randomBytes } from 'crypto'
import { mkdirSync, writeFileSync } from 'fs'
import { resolve } from 'path'

const prisma = new PrismaClient({
  datasources: { db: { url: process.env.DATABASE_URL } },
})

function hashPassword(password) {
  const salt = randomBytes(16).toString('hex')
  const hash = scryptSync(password, salt, 64).toString('hex')
  return `${salt}:${hash}`
}

const STORAGE_CATEGORIES = ['Documents', 'Downloads', 'Pictures', 'Videos', 'Projects', 'AI', 'Backups', 'Shared', 'Desktop', 'Wallpapers', 'Icons']

/** Tạo storage riêng cho admin: <root>/users/<adminId>/... (tách theo tài khoản) */
function ensureStorage(adminId) {
  const base = process.env.STORAGE_ROOT || resolve(process.cwd(), 'storage')
  const root = resolve(base, 'users', adminId)
  mkdirSync(root, { recursive: true })
  for (const dir of STORAGE_CATEGORIES) {
    mkdirSync(resolve(root, dir), { recursive: true })
  }
  // vài file chào mừng
  writeFileSync(resolve(root, 'Documents', 'chao-mung.md'),
`# Chào mừng đến Workspace OS 🎉

Đây là hệ điều hành làm việc trên nền web của bạn.

## Bắt đầu
- Mở **Tasks** để thêm công việc đầu tiên
- Xem **Dashboard** — mọi widget được dựng từ Widget Engine
- Nhấn **Ctrl + K** để tìm kiếm toàn workspace
- Vào **Settings → Modules** để bật/tắt từng app

> Mọi thứ bạn thấy là module độc lập, giao tiếp qua Event Bus.
`)
  writeFileSync(resolve(root, 'Documents', 'huong-dan.md'),
`# Hướng dẫn nhanh

1. **Files**: kéo-thả để tải lên, right-click các thao tác
2. **Notes**: viết Markdown, có preview
3. **Wiki**: tạo cây tri thức, tự lưu phiên bản
4. **Reports**: xuất CSV/Excel, In ra PDF
`)
  console.log(`[seed] STORAGE_ROOT của admin sẵn sàng: ${root}`)
}

const DEFAULT_SETTINGS = {
  core: {
    workspace_name: 'Workspace OS',
    timezone: 'Asia/Bangkok',
    language: 'vi',
    date_format: 'dd/MM/yyyy',
    weather_city: 'Hồ Chí Minh',
    weather_lat: '10.762622',
    weather_lon: '106.660172',
    quota_gb: '20',
    ai_summary: 'on',
  },
  dashboard: { greeting: 'auto' },
  tasks: { default_view: 'list', default_priority: 'medium', quick_add: 'on' },
  calendar: { first_day: 'monday', show_holidays: 'on', day_start: '8' },
  notes: { autosave: 'on', font_size: '15' },
  wiki: { allow_anonymous_read: 'off' },
  files: { default_view: 'grid', preview_inline: 'on' },
  projects: { card_style: 'progress' },
  timeline: { group_by: 'day', limit: '150' },
  notifications: { browser: 'on', toast: 'on', reminder: 'on', email: 'off', email_to: '' },
  reports: { export_format: 'csv' },
  search: { hotkey: 'ctrl+k', limit: '24' },
  backup: { auto: 'off', keep: '5' },
  appearance: {},
  sync: { sources: '{"db":true,"files":true,"config":true}', schedule: 'off', keep: '7' },
  weekly: { cutoff_hour: '16', auto_prep_offset: 'on' },
}

async function main() {
  // ---- Admin ----
  const adminUser = process.env.ADMIN_USER || 'admin'
  const adminPassword = process.env.ADMIN_PASSWORD || 'admin123'
  let admin = await prisma.user.findUnique({ where: { username: adminUser } })
  if (!admin) {
    admin = await prisma.user.create({
      data: {
        username: adminUser,
        passwordHash: hashPassword(adminPassword),
        displayName: 'Tony',
        role: 'admin',
        email: 'admin@wos.local',
        avatarColor: '#f97316',
      },
    })
    console.log(`[seed] Admin: ${adminUser} / ${adminPassword}`)
  } else {
    console.log(`[seed] Admin đã tồn tại: ${adminUser}`)
  }
  const adminId = admin.id

  // ---- Storage riêng của admin (per-account) ----
  ensureStorage(adminId)

  // ---- Users demo ----
  const demo = [
    { username: 'linh', displayName: 'Linh Trần', role: 'member', color: '#ec4899' },
    { username: 'khang', displayName: 'Khang Lê', role: 'viewer', color: '#0891b2' },
  ]
  for (const u of demo) {
    if (!(await prisma.user.findUnique({ where: { username: u.username } }))) {
      await prisma.user.create({
        data: {
          username: u.username,
          passwordHash: hashPassword('demo123'),
          displayName: u.displayName,
          role: u.role,
          avatarColor: u.color,
        },
      })
    }
  }

  // ---- Groups ----
  if (!(await prisma.group.findUnique({ where: { name: 'Nhóm phát triển' } }))) {
    await prisma.group.create({ data: { name: 'Nhóm phát triển', description: 'Team dev Workspace OS' } })
  }
  if (!(await prisma.group.findUnique({ where: { name: 'Khách' } }))) {
    await prisma.group.create({ data: { name: 'Khách', description: 'Tài khoản chỉ xem' } })
  }

  // ---- Settings ----
  for (const [module, values] of Object.entries(DEFAULT_SETTINGS)) {
    for (const [key, value] of Object.entries(values)) {
      await prisma.setting.upsert({
        where: { id: `${module}:${key}` },
        update: {},
        create: { id: `${module}:${key}`, module, key, value },
      })
    }
  }
  console.log('[seed] Settings mặc định đã ghi')

  // ---- Không seed demo nếu đã có dữ liệu ----
  const taskCount = await prisma.task.count()
  if (taskCount > 0) {
    console.log('[seed] Đã có dữ liệu nghiệp vụ — bỏ qua seed demo')
    return
  }

  const now = Date.now()
  const day = 86400000
  const at = (offsetDays, hour = 9) => {
    const d = new Date(now + offsetDays * day)
    d.setHours(hour, 0, 0, 0)
    return d
  }

  // ---- Projects ----
  const wosProject = await prisma.project.create({
    data: {
      ownerId: adminId,
      name: 'Workspace OS v1',
      description: 'Hệ điều hành làm việc trên nền web — Giai đoạn 1 + 2',
      color: '#f97316',
      status: 'active',
      startDate: at(-14),
      dueDate: at(30),
      members: { create: [{ userName: 'Tony', role: 'owner' }, { userName: 'Linh Trần', role: 'member' }] },
      milestones: {
        create: [
          { title: 'Core Engine + Module Manager', done: true, position: 1 },
          { title: 'Dashboard + Widget Engine', done: true, position: 2 },
          { title: 'Giai đoạn 1: Tasks/Calendar/Notes/Wiki/Files', done: false, position: 3, dueAt: at(7) },
          { title: 'Giai đoạn 2: Projects/Timeline/Search/Reports', done: false, position: 4, dueAt: at(21) },
          { title: 'Đóng gói + bàn giao Orange Pi', done: false, position: 5, dueAt: at(30) },
        ],
      },
    },
  })
  await prisma.project.create({
    data: {
      ownerId: adminId,
      name: 'Nhà thông minh',
      description: 'Đồng bộ Orange Pi với cảm biến trong nhà',
      color: '#10b981',
      status: 'active',
      members: { create: [{ userName: 'Khang Lê', role: 'member' }] },
      milestones: {
        create: [
          { title: 'Lắp cảm biến nhiệt/ẩm', done: true, position: 1 },
          { title: 'Dashboard nhiệt độ realtime', done: false, position: 2 },
        ],
      },
    },
  })

  // ---- Tasks ----
  const tasks = [
    { title: 'Thiết kế Core Engine + Event Bus', status: 'done', priority: 'high', completedAt: at(-6), projectId: wosProject.id },
    { title: 'Dựng Widget Engine cho Dashboard', status: 'done', priority: 'high', completedAt: at(-4), projectId: wosProject.id },
    { title: 'Viết module Tasks (Kanban + List)', status: 'done', priority: 'urgent', completedAt: at(-2), projectId: wosProject.id },
    { title: 'Hoàn thiện Calendar view Week/Day', status: 'doing', priority: 'high', dueAt: at(1), projectId: wosProject.id },
    { title: 'Wiki: viết tài liệu kiến trúc', status: 'doing', priority: 'medium', dueAt: at(3), projectId: wosProject.id },
    { title: 'Files: nén/giải nén + share link', status: 'todo', priority: 'high', dueAt: at(0), projectId: wosProject.id },
    { title: 'Reports: xuất Excel/PDF', status: 'todo', priority: 'medium', dueAt: at(5), projectId: wosProject.id },
    { title: 'Global Search Ctrl+K mọi module', status: 'todo', priority: 'urgent', dueAt: at(2), projectId: wosProject.id },
    { title: 'Họp tổng kết tuần', status: 'todo', priority: 'low', dueAt: at(0) },
    { title: 'Backup storage sang SSD ngoài', status: 'todo', priority: 'medium', dueAt: at(6), repeat: 'weekly' },
    { title: 'Mua thêm RAM 2GB cho Orange Pi', status: 'archived', priority: 'low', completedAt: at(-10) },
  ]
  const createdTasks = []
  for (let i = 0; i < tasks.length; i++) {
    const t = tasks[i]
    const task = await prisma.task.create({
      data: {
        ownerId: adminId,
        title: t.title,
        status: t.status,
        priority: t.priority,
        dueAt: t.dueAt || null,
        repeat: t.repeat || 'none',
        projectId: t.projectId || null,
        completedAt: t.completedAt || null,
        position: i + 1,
        labels: JSON.stringify(t.priority === 'urgent' ? ['quan-trọng'] : []),
      },
    })
    createdTasks.push(task)
  }
  // Subtasks + comments cho task đầu
  await prisma.subtask.createMany({
    data: [
      { taskId: createdTasks[3].id, title: 'Week view grid 7 cột', position: 1 },
      { taskId: createdTasks[3].id, title: 'Sự kiện kéo 30 phút', position: 2, done: true },
      { taskId: createdTasks[3].id, title: 'Màu theo category', position: 3 },
    ],
  })
  await prisma.taskComment.createMany({
    data: [
      { taskId: createdTasks[3].id, authorName: 'Linh Trần', content: 'Em đã xong phần grid, chiều review nhé!' },
      { taskId: createdTasks[5].id, authorName: 'Tony', content: 'Nhớ test nén folder lớn (500MB+)' },
    ],
  })

  // ---- Calendar events ----
  await prisma.calendarEvent.createMany({
    data: [
      { ownerId: adminId, title: 'Standup sáng', category: 'meeting', start: at(0, 9), end: at(0, 10), recurring: 'daily' },
      { ownerId: adminId, title: 'Họp dự án Workspace OS', category: 'work', start: at(1, 14), end: at(1, 16), location: 'Phòng họp 1', projectId: wosProject.id },
      { ownerId: adminId, title: 'Review code Timeline module', category: 'work', start: at(2, 10), end: at(2, 11), reminderMinutes: 15 },
      { ownerId: adminId, title: 'Tập gym', category: 'personal', start: at(1, 18), end: at(1, 19), recurring: 'weekly' },
      { ownerId: adminId, title: 'Hạn chót Giai đoạn 1', category: 'work', start: at(7), end: at(7), allDay: true, color: '#f43f5e' },
    ],
  })

  // ---- Notes ----
  await prisma.note.createMany({
    data: [
      {
        ownerId: adminId,
        title: 'Ý tưởng cho Workspace OS',
        content:
`# Ý tưởng

- [x] Core Engine + Module Manager
- [x] Widget Engine
- [ ] AI Assistant module (Giai đoạn 3)
- [ ] Linux Monitor module
- [ ] Stock Dashboard module

> Nguyên tắc: thêm module mới KHÔNG sửa lõi.
`,
        pinned: true,
        tags: JSON.stringify(['ý-tưởng', 'wos']),
      },
      {
        ownerId: adminId,
        title: 'Checklist triển khai Orange Pi',
        content:
`## Trước khi cài
- [x] Burn image Debian 12
- [x] Cắm SSD qua USB3
- [ ] Tạo swap 2GB
- [ ] Mở cổng 3068

## Lệnh hay dùng
\`\`\`bash
sudo systemctl restart cloud-workspace
journalctl -u cloud-workspace -f
\`\`\`
`,
        tags: JSON.stringify(['ops', 'orangepi']),
      },
      {
        ownerId: adminId,
        title: 'Mua sắm cuối tuần',
        content: '- Sữa\n- Trứng\n- Cà phê Arabica\n- Ổ cứng SSD 1TB (cho Orange Pi)',
        tags: JSON.stringify(['cá-nhân']),
      },
    ],
  })

  // ---- Wiki ----
  const architecture = await prisma.wikiPage.create({
    data: { ownerId: adminId, title: 'Kiến trúc Workspace OS', icon: '🏗️', position: 1 },
  })
  const modulesPage = await prisma.wikiPage.create({
    data: { ownerId: adminId, title: 'Chuẩn Module', icon: '📦', parentId: architecture.id, position: 1 },
  })
  await prisma.wikiPage.create({
    data: { ownerId: adminId, title: 'Event Bus', icon: '⚡', parentId: architecture.id, position: 2 },
  })
  await prisma.wikiPage.create({
    data: { ownerId: adminId, title: 'Widget Engine', icon: '🧩', parentId: architecture.id, position: 3 },
  })
  const contentArchitecture =
`# Kiến trúc Workspace OS

WOS là **hệ điều hành làm việc trên nền Web**. Mọi chức năng là một **Module** — như app trên macOS.

## Core Engine
- Authentication · Permission · Database · API Gateway
- Event Bus · Notification Center · Search Engine
- Theme Engine · Widget Engine · Module Manager · Settings Engine

> Core gần như không thay đổi. Tính năng mới = module mới.

## Sơ đồ
\`\`\`
Workspace ──► Core Engine ──► Module Manager
                                ├── Dashboard
                                ├── Tasks · Calendar · Notes
                                ├── Wiki · Files · Projects
                                └── Timeline · Reports · Search
\`\`\`
`
  await prisma.wikiPage.update({ where: { id: architecture.id }, data: { content: contentArchitecture } })
  await prisma.wikiPage.update({
    where: { id: modulesPage.id },
    data: {
      content:
`# Chuẩn Module

Mọi module PHẢI có:

| Thành phần | Bắt buộc |
|---|---|
| Menu (Sidebar/Dock) | ✅ |
| Dashboard Widget | ✅ |
| Settings riêng | ✅ |
| Permissions | ✅ |
| API độc lập | ✅ |
| Events (Event Bus) | ✅ |
| Search Provider | ✅ |
| Notifications | ✅ |
| Activity Log | ✅ |
| Backup · Localization · Theme | ✅ |

## Cấu trúc thư mục
\`\`\`
module/
  manifest.json · api/ · services/ · models/ · repository/
  components/ · pages/ · widgets/ · settings/
  permissions/ · routes/ · events/ · translations/ · tests/
\`\`\`
`,
    },
  })
  await prisma.wikiVersion.createMany({
    data: [
      { pageId: architecture.id, version: 1, title: architecture.title, content: contentArchitecture, authorName: 'Tony' },
      { pageId: modulesPage.id, version: 1, title: modulesPage.title, content: 'Khởi tạo', authorName: 'Tony' },
    ],
  })

  // ---- Weekly Work (Quy trình + lịch tuần demo) ----
  const iso = (d) => {
    const y = d.getFullYear()
    const m = String(d.getMonth() + 1).padStart(2, '0')
    const day = String(d.getDate()).padStart(2, '0')
    return `${y}-${m}-${day}`
  }
  const today = new Date()
  const albumin = await prisma.workProcess.create({
    data: {
      ownerId: adminId,
      name: 'Test Albumin SC',
      description: 'Quy trình test Albumin theo lô hàng tuần',
      color: '#2563eb',
      icon: '🧪',
      order: 1,
      steps: {
        create: [
          { name: 'Test lô hàng chính', lotCount: 3, rowsPerLot: 8, order: 1, note: 'Chạy mẫu theo khay' },
          { name: 'Đọc kết quả OD', lotCount: 3, rowsPerLot: 8, order: 2, note: 'Ghi vào sổ' },
        ],
      },
      preps: {
        create: [
          {
            name: 'Pha hóa chất Albumin',
            offsetDays: 1,
            order: 1,
            detail: 'Lần 1: pha hóa chất Bufalot trước 1 ngày (chiu tối). Lần 2: sáng hôm sau pha thêm dung dịch thẩm tách mới sử dụng được.',
          },
        ],
      },
    },
  })
  await prisma.workProcess.create({
    data: {
      ownerId: adminId,
      name: 'Test Glucose HK',
      description: 'Quy trình test Glucose hàng tuần',
      color: '#10b981',
      icon: '🩸',
      order: 2,
      steps: {
        create: [{ name: 'Test mẫu Glucose', lotCount: 2, rowsPerLot: 10, order: 1 }],
      },
    },
  })
  // Sinh việc cho 4 ngày: hôm qua (1 prep), hôm nay (2 quy trình), ngày mai
  const dayTasks = []
  const mkDay = async (date, tasks) => {
    const d = await prisma.workDay.create({ data: { date, ownerId: adminId } })
    for (let i = 0; i < tasks.length; i++) {
      const t = tasks[i]
      dayTasks.push(
        await prisma.workTask.create({
          data: {
            dayId: d.id,
            processId: t.pid || null,
            processName: t.pname || '',
            name: t.name,
            lotCount: t.lot ?? null,
            rowsPerLot: t.rows ?? null,
            quantity: t.lot && t.rows ? t.lot * t.rows : null,
            isPrep: Boolean(t.prep),
            prepRound: t.round || 1,
            status: t.status || 'pending',
            note: t.note || '',
            order: i + 1,
            completedAt: t.status === 'done' ? new Date() : null,
          },
        }),
      )
    }
    return d
  }
  const yesterday = new Date(today)
  yesterday.setDate(today.getDate() - 1)
  const tomorrow = new Date(today)
  tomorrow.setDate(today.getDate() + 1)
  await mkDay(iso(yesterday), [
    { pid: albumin.id, pname: 'Test Albumin SC', name: 'Pha hóa chất Albumin', prep: true, round: 1, status: 'done', note: 'Lần 1: pha Bufalot 18:30 — đủ cho 3 lô', lot: null, rows: null },
  ])
  const todayId = await mkDay(iso(today), [
    { pid: albumin.id, pname: 'Test Albumin SC', name: 'Pha dung dịch thẩm tách', prep: true, round: 2, status: 'done', note: 'Lần 2: 07:15 pha xong, nhiệt độ đạt' },
    { pid: albumin.id, pname: 'Test Albumin SC', name: 'Test lô hàng chính', lot: 3, rows: 8, status: 'done' },
    { pid: albumin.id, pname: 'Test Albumin SC', name: 'Đọc kết quả OD', lot: 3, rows: 8, status: 'pending' },
    { name: 'Ghi sổ kết quả gửi trưởng ca', status: 'pending' },
  ])
  await mkDay(iso(tomorrow), [
    { pid: albumin.id, pname: 'Test Albumin SC', name: 'Test lô hàng chính', lot: 2, rows: 8, status: 'pending' },
    { name: 'Dọn và hiệu chuẩn máy', status: 'pending' },
  ])
  void todayId
  console.log('[seed] Weekly Work: 2 quy trình + 3 ngày demo ✅')

  // ---- Event records + Activity (Timeline có dữ liệu ngay) ----
  const eventTypes = [
    ['task.completed', 'tasks', 'Hoàn thành widget engine'],
    ['file.uploaded', 'files', 'tài-liệu.pdf'],
    ['wiki.updated', 'wiki', 'Chuẩn Module'],
    ['project.created', 'projects', 'Nhà thông minh'],
    ['note.created', 'notes', 'Ý tưởng cho Workspace OS'],
    ['event.created', 'calendar', 'Standup sáng'],
    ['auth.login', 'core', ''],
    ['task.created', 'tasks', 'Global Search Ctrl+K'],
  ]
  for (let i = 0; i < eventTypes.length; i++) {
    const [type, module, title] = eventTypes[i]
    const createdAt = new Date(now - (i + 1) * 3600000 * 2)
    await prisma.eventRecord.create({
      data: { type, module, actorId: adminId, actorName: 'Tony', payload: JSON.stringify(title ? { title } : {}), createdAt },
    })
    await prisma.activityLog.create({
      data: {
        userId: adminId,
        userName: 'Tony',
        module,
        action: type,
        detail: title ? `${type} "${title}"` : type,
        createdAt,
      },
    })
  }

  // ---- Notifications (demo của admin — tài khoản mới bắt đầu trống) ----
  await prisma.notification.createMany({
    data: [
      { userId: adminId, title: 'Chào mừng Workspace OS 🎉', content: 'Hệ thống đã sẵn sàng. Nhấn Ctrl+K để thử Global Search!', module: 'core', type: 'system', action: 'dashboard' },
      { userId: adminId, title: '5 công việc đến hạn hôm nay', content: 'Mở Tasks để xem danh sách', module: 'tasks', type: 'reminder', action: 'tasks' },
      { userId: adminId, title: 'Wiki có trang mới', content: 'Kiến trúc Workspace OS đã được tạo', module: 'wiki', type: 'info', action: 'wiki' },
    ],
  })

  console.log('[seed] Dữ liệu demo đã tạo ✅')
}

main()
  .catch((e) => {
    console.error('[seed] LỖI:', e)
    process.exit(1)
  })
  .finally(() => prisma.$disconnect())
