// Reset mật khẩu admin trong DB dev sandbox → admin123 (để test E2E)
import { PrismaClient } from '@prisma/client'
import { randomBytes, scryptSync } from 'crypto'

const prisma = new PrismaClient({ datasources: { db: { url: 'file:/home/z/my-project/db/custom.db' } } })

function hashPassword(password) {
  const salt = randomBytes(16).toString('hex')
  const hash = scryptSync(password, salt, 64).toString('hex')
  return `${salt}:${hash}`
}

const u = await prisma.user.update({
  where: { username: 'admin' },
  data: { passwordHash: hashPassword('admin123') },
  select: { username: true, displayName: true, role: true },
})
console.log('Đã reset mật khẩu:', u)
await prisma.$disconnect()
