/**
 * WOS AI Provider — FACADE gọi LLM phía server (KHÔNG bao giờ lộ key ra client).
 *
 * Kiến trúc mở (từ v1.1): provider cụ thể nằm trong `providers/` và được
 * đăng ký qua registry — file này chỉ còn là mặt tiền dùng chung:
 *   resolveProviderInfo() → chọn provider theo setting + trạng thái cấu hình
 *   aiComplete()          → getProvider(id).complete(...)
 *   aiText()              → bản ngắn gọn cho summarize/trích xuất
 *
 * ➕ THÊM PROVIDER MỚI: xem providers/index.ts + docs/ai-integration-guide.md
 *    (hoặc KHÔNG cần code: dịch vụ OpenAI-compatible → env AI_COMPAT_*)
 */
import { db } from '@/lib/db'
import { getProvider, listProviderInfos, allProviders, defaultProviderId } from './providers'

export interface AiChatMessage {
  role: 'system' | 'user' | 'assistant' | 'tool'
  content: string
  tool_calls?: AiToolCall[]
  tool_call_id?: string
  name?: string
}

export interface AiToolCall {
  id: string
  type: 'function'
  function: { name: string; arguments: string }
}

export interface AiToolDef {
  type: 'function'
  function: {
    name: string
    description: string
    parameters: Record<string, unknown>
  }
}

export interface AiCompleteOptions {
  messages: AiChatMessage[]
  tools?: AiToolDef[]
  temperature?: number
  model?: string
  maxTokens?: number
}

export interface AiCompleteResult {
  content: string
  toolCalls: AiToolCall[]
  model: string
  provider: string
  usage?: { prompt?: number; completion?: number }
}

export interface ProviderInfo {
  provider: string
  model: string
  hasKey: boolean
  label: string
  supportsTools: boolean
}

/** (back-compat) key Grok — xem providers/xai.ts */
export function xaiKey(): string {
  return (process.env.XAI_API_KEY || '').trim()
}

/**
 * Provider đang dùng + model mặc định.
 * Auto: provider configured đầu tiên theo thứ tự đăng ký (xai → openai-compat → zai).
 * User chọn provider chưa cấu hình → tự rơi về default (không chết hệ thống).
 */
export function resolveProviderInfo(userSetting?: { provider?: string; model?: string }): ProviderInfo {
  const chosen = (userSetting?.provider || '').trim()
  let providerId = ''
  if (chosen && getProvider(chosen)?.isConfigured()) {
    providerId = chosen
  } else {
    providerId = defaultProviderId()
  }
  const p = getProvider(providerId)
  const model =
    (userSetting?.model || '').trim() ||
    (p ? p.defaultModel() : 'glm-4.6')
  return {
    provider: providerId,
    model,
    hasKey: p ? p.isConfigured() : false,
    label: p ? `${p.label} (${model})` : `Built-in (${model})`,
    supportsTools: p ? p.supportsTools : false,
  }
}

/** Danh sách provider cho UI Settings (an toàn — không key) */
export function availableProviders() {
  return listProviderInfos()
}

/** Điểm vào duy nhất: gọi provider đã chọn (kèm fallback khi zai gặp lỗi model) */
export async function aiComplete(opts: AiCompleteOptions, userSetting?: { provider?: string; model?: string }): Promise<AiCompleteResult> {
  const info = resolveProviderInfo(userSetting)
  const p = getProvider(info.provider)
  if (!p) throw new Error(`Provider AI "${info.provider}" chưa được đăng ký trên server`)
  try {
    // provider không hỗ trợ tools → loại tools, dùng context thu thập sẵn
    const callOpts = p.supportsTools ? opts : { ...opts, tools: undefined }
    return await p.complete(callOpts, info.model)
  } catch (err) {
    // zai + model tùy chỉnh lỗi → thử lại model mặc định 1 lần
    if (info.provider === 'zai' && userSetting?.model && userSetting.model !== 'glm-4.6') {
      return p.complete({ ...opts, tools: undefined }, 'glm-4.6')
    }
    throw err
  }
}

/** Gọi ngắn gọn chỉ lấy text (dùng cho summarize / trích xuất memory — không cần tools) */
export async function aiText(system: string, user: string, userSetting?: { provider?: string; model?: string }): Promise<string> {
  const r = await aiComplete(
    { messages: [{ role: 'system', content: system }, { role: 'user', content: user }], maxTokens: 1024 },
    userSetting,
  )
  return r.content.trim()
}

/** Đọc setting AI của user (tự tạo mặc định nếu chưa có) */
export async function getAiSetting(userId: string) {
  const row = await db.aISetting.findUnique({ where: { id: userId } })
  if (row) return row
  return db.aISetting.create({ data: { id: userId } })
}

/** Parse JSON an toàn */
export function safeJson<T>(raw: string, fallback: T): T {
  try {
    return JSON.parse(raw) as T
  } catch {
    return fallback
  }
}

/** Danh sách model khả dụng của provider (nếu hỗ trợ) — cho UI chọn động */
export async function listProviderModels(providerId: string): Promise<string[]> {
  const p = getProvider(providerId)
  if (!p || typeof p.listModels !== 'function') return []
  try {
    return await p.listModels()
  } catch {
    return []
  }
}

export { allProviders }
