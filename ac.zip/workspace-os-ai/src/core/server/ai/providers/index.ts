/**
 * Providers — đăng ký toàn bộ provider built-in của Workspace OS.
 *
 * ══════════════ THÊM PROVIDER AI MỚI TRONG TƯƠNG LAI ══════════════
 * Tạo file mới (vd anthropic.ts) rồi thêm 1 dòng ở đây:
 *
 *   import { anthropicProvider } from './anthropic'
 *   registerProvider(anthropicProvider)
 *
 * Provider tự động: xuất hiện trong UI Settings, được validate ở API,
 * hoạt động với aiComplete()/aiText() — không cần sửa bất kỳ file nào khác.
 * Chi tiết đầy đủ: docs/ai-integration-guide.md
 */
import { registerProvider } from './registry'
import { xaiProvider } from './xai'
import { zaiProvider } from './zai'
import { openaiCompatProvider } from './openai-compat'

export * from './types'
export * from './registry'

/* ── Đăng ký provider built-in ──
 * Thứ tự = thứ tự ưu tiên khi "Tự động": provider configured đầu tiên
 * (khác zai) thắng. zai luôn ở cuối vai trò fallback sandbox.
 */
registerProvider(xaiProvider)            // Grok — x.ai (XAI_API_KEY)
registerProvider(openaiCompatProvider)   // Mọi dịch vụ OpenAI-compatible (AI_COMPAT_*)
registerProvider(zaiProvider)            // Built-in sandbox — luôn sẵn sàng
