import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireSession, handle, ok, fail, readJson, ApiError } from '@/core/server/api'
import { checkRate } from '@/core/server/rate-limit'
import { getUserTimezone, isoDateInTz } from '@/core/server/datetime'
import { getAiSetting, aiComplete, resolveProviderInfo, safeJson } from '@/core/server/ai/provider'
import { collectContext, DEFAULT_SOURCES, type ContextSourceFlags, type ActiveContextPayload } from '@/core/server/ai/context'
import { retrieveRelevantMemories, autoSummarizeConversation, extractMemories } from '@/core/server/ai/memory'
import { buildMessages, estimateTokens } from '@/core/server/ai/prompt'
import { availableTools, runWithTools } from '@/core/server/ai/tools'
import type { AiChatMessage } from '@/core/server/ai/provider'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 180

interface ChatBody {
  conversationId?: string
  message?: string
  sources?: Partial<ContextSourceFlags>
  mode?: 'auto' | 'workspace' | 'manual'
  activeContext?: ActiveContextPayload
}

/**
 * POST /api/ai/chat — AI proxy chính (Giai đoạn 1).
 * Plugin KHÔNG giữ API key: browser gửi câu hỏi + conversationId + ngữ cảnh,
 * server kiểm tra đăng nhập → thu thập dữ liệu theo quyền → dựng prompt → gọi Grok.
 */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = await requireSession()
    // giới hạn lượt gọi: 30 lượt/phút theo user (bảo vệ Orange Pi + hạn chi phí)
    if (!checkRate(`ai:chat:${session.id}`, 30, 60_000)) {
      throw new ApiError('Bạn hỏi quá nhanh — nghỉ chút rồi thử lại (giới hạn 30 lượt/phút)', 429)
    }
    const body = await readJson<ChatBody>(req)
    const question = String(body.message || '').trim().slice(0, 8000)
    if (!question) return fail('Nhập câu hỏi cho trợ lý')

    // 1) Hội thoại: dùng có sẵn (của chính user) hoặc tạo mới
    let conv = null
    if (body.conversationId) {
      conv = await db.aIConversation.findFirst({ where: { id: String(body.conversationId), userId: session.id } })
    }
    const isNew = !conv
    if (!conv) {
      conv = await db.aIConversation.create({
        data: {
          userId: session.id,
          title: question.slice(0, 60) + (question.length > 60 ? '…' : ''),
        },
      })
    }

    // 2) Cài đặt + nguồn dữ liệu
    const setting = await getAiSetting(session.id)
    const mode = ['auto', 'workspace', 'manual'].includes(String(body.mode)) ? String(body.mode) : setting.contextMode
    let flags: ContextSourceFlags = { ...DEFAULT_SOURCES, ...safeJson<Partial<ContextSourceFlags>>(setting.sources, {}) }
    if (mode === 'manual' && body.sources) flags = { ...DEFAULT_SOURCES, ...body.sources }
    if (mode === 'workspace') {
      // toàn workspace: bật hết nguồn nghiệp vụ (kể cả app không mở)
      flags = { ...flags, tasks: true, calendar: true, weekly: true, projects: true }
    }

    // 3) Lưu tin nhắn user NGAY (mất kết nối vẫn còn lịch sử)
    const userMsg = await db.aIMessage.create({
      data: {
        conversationId: conv.id,
        role: 'user',
        content: question,
        meta: JSON.stringify({ sources: flags, mode }),
      },
    })
    await db.aIConversation.update({
      where: { id: conv.id },
      data: { messageCount: { increment: 1 }, updatedAt: new Date() },
    })

    // 4) M4 — thu thập live context theo quyền (server đọc DB trực tiếp, KHÔNG qua HTTP)
    const { context, used, skipped } = await collectContext(session, flags, body.activeContext)

    // 5) GĐ4 — ngữ cảnh external (chưa tiêu thụ, của user) — đánh dấu KHÔNG đáng tin
    const extRows = flags.external
      ? await db.aIExternalContext.findMany({
          where: { userId: session.id, consumed: false, OR: [{ conversationId: '' }, { conversationId: conv.id }] },
          orderBy: { createdAt: 'desc' },
          take: 5,
        })
      : []

    // 6) M3 — truy xuất bộ nhớ liên quan đến câu hỏi
    const settingObj = { provider: setting.provider, model: setting.model }
    let memoryRows: Awaited<ReturnType<typeof retrieveRelevantMemories>> = []
    if (setting.memoryEnabled) memoryRows = await retrieveRelevantMemories(session.id, question, 20)

    // 7) M1 — tin nhắn gần nhất (SAU phần đã gộp vào summary)
    const recentRows = await db.aIMessage.findMany({
      where: { conversationId: conv.id, role: { in: ['user', 'assistant'] } },
      orderBy: { createdAt: 'desc' },
      take: Math.max(4, setting.maxRecentMessages),
    })
    const recent = recentRows
      .reverse()
      .map((m) => ({ role: m.role as 'user' | 'assistant', content: m.content }))

    // 8) Dựng prompt theo kiến trúc SYSTEM/USER MEMORY/WORKSPACE CONTEXT/RECENT/QUESTION
    const tz = await getUserTimezone()
    const providerInfo = resolveProviderInfo(settingObj)
    const baseMessages = buildMessages({
      question,
      memory: {
        summary: conv.summary,
        confirmed: memoryRows.filter((m) => m.confirmed).map((m) => ({ category: m.category, content: m.content, updatedAt: m.updatedAt })),
        candidates: memoryRows.filter((m) => !m.confirmed).map((m) => ({ category: m.category, content: m.content, updatedAt: m.updatedAt })),
      },
      context,
      externalContexts: extRows.map((e) => ({
        title: e.title, url: e.url, site: e.site, content: e.content, selectionOnly: e.selectionOnly,
      })),
      recent: [...recent, { role: 'user' as const, content: question }],
      today: isoDateInTz(new Date(), tz),
      tz,
      providerLabel: providerInfo.label,
    })

    // 9) Gọi AI — kèm tool calling có kiểm soát (GĐ3, chỉ provider hỗ trợ)
    const toolsEnabled = providerInfo.supportsTools
    const complete = (messages: AiChatMessage[]) =>
      aiComplete(
        {
          messages,
          tools: toolsEnabled ? availableTools() : undefined,
          temperature: setting.temperature,
        },
        settingObj,
      )
    let finalResult
    let toolTrace: Array<{ name: string; args: string; ok: boolean }> = []
    try {
      const r = await runWithTools(baseMessages, { session, activeContext: body.activeContext }, complete)
      finalResult = r.result
      toolTrace = r.toolTrace
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Lỗi gọi AI'
      console.error('[ai-chat]', err)
      // không lưu lỗi thành tin nhắn assistant rác — trả lỗi cho UI hiển thị
      throw new ApiError(`Trợ lý AI phản hồi lỗi: ${message.slice(0, 200)}`, 502)
    }
    if (!finalResult.content.trim()) {
      throw new ApiError('Trợ lý AI trả về phản hồi rỗng — thử lại hoặc đổi model trong Cài đặt AI', 502)
    }

    // 10) Lưu tin nhắn assistant + meta (nguồn đã dùng, tool trace, token)
    const meta = {
      sources: { used, skipped },
      tools: toolTrace,
      provider: finalResult.provider,
      model: finalResult.model,
      externalUsed: extRows.length,
      promptTokensEst: estimateTokens(baseMessages.map((m) => m.content).join('\n')),
      usage: finalResult.usage,
    }
    const assistantMsg = await db.aIMessage.create({
      data: {
        conversationId: conv.id,
        role: 'assistant',
        content: finalResult.content,
        meta: JSON.stringify(meta),
        tokens: finalResult.usage?.completion || 0,
      },
    })
    await db.aIConversation.update({
      where: { id: conv.id },
      data: { messageCount: { increment: 1 }, updatedAt: new Date() },
    })
    // đánh dấu external context đã tiêu thụ + gắn conversation
    if (extRows.length) {
      await db.aIExternalContext.updateMany({
        where: { id: { in: extRows.map((e) => e.id) } },
        data: { consumed: true, conversationId: conv.id },
      })
    }

    // 11) Hậu kỳ (GĐ3) — tự tóm tắt M2 + trích xuất memory M3 (chống phình prompt)
    let memoryNote = ''
    try {
      const sumRes = await autoSummarizeConversation(conv.id, {
        ...settingObj,
        summarizeThreshold: setting.summarizeThreshold,
      })
      let extracted = 0
      if (setting.memoryEnabled && (conv.messageCount + 2) % Math.max(3, setting.memoryExtractEvery) === 0) {
        const r = await extractMemories(conv.id, settingObj)
        extracted = r.extracted
      }
      memoryNote = sumRes.summarized ? 'Đã cập nhật tóm tắt hội thoại. ' : ''
      if (extracted) memoryNote += `Đã ghi ${extracted} ghi nhớ mới (chờ bạn xác nhận).`
    } catch (err) {
      console.warn('[ai-chat] post-process lỗi:', err)
    }

    return ok({
      conversationId: conv.id,
      isNew,
      userMessage: { id: userMsg.id, role: 'user', content: userMsg.content, createdAt: userMsg.createdAt },
      message: { id: assistantMsg.id, role: 'assistant', content: assistantMsg.content, meta, createdAt: assistantMsg.createdAt },
      sourcesUsed: used,
      sourcesSkipped: skipped,
      toolsUsed: toolTrace,
      memoryNote,
      provider: finalResult.provider,
      model: finalResult.model,
    })
  })
}
